# Ministero della Salute - ASL - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ministero della Salute - ASL**

## CodeSystem: Ministero della Salute - ASL 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/cs-asl | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:CsMDSASL |

 
Ministero della Salute - ASL 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VsMinisteroSaluteAsl](ValueSet-minsan-asl.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-asl",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/cs-asl",
  "version" : "0.2.0",
  "name" : "CsMDSASL",
  "title" : "Ministero della Salute - ASL",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Ministero della Salute - ASL",
  "caseSensitive" : false,
  "content" : "complete",
  "filter" : [{
    "code" : "regione",
    "description" : "Permette di ricercare i codici secondo il codice Regionale di appartenenza",
    "operator" : ["="],
    "value" : "codice della Regione"
  },
  {
    "code" : "comune",
    "description" : "Permette di ricercare i codici secondo il codice del comune di appartenenza",
    "operator" : ["="],
    "value" : "codice del Comune"
  },
  {
    "code" : "provincia",
    "description" : "Permette di ricercare i codici secondo il codice della provincia di appartenenza",
    "operator" : ["="],
    "value" : "codice della Provincia"
  }],
  "property" : [{
    "code" : "regione",
    "description" : "Proprietà che identifica la regione di appartenenza dell'ASL",
    "type" : "string"
  },
  {
    "code" : "comune",
    "description" : "Proprietà che identifica il comune di appartenenza dell'ASL",
    "type" : "string"
  },
  {
    "code" : "provincia",
    "description" : "Proprietà che identifica la provincia di appartenenza dell'ASL",
    "type" : "string"
  }],
  "concept" : [{
    "code" : "010203",
    "display" : "TO3",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001090"
    },
    {
      "code" : "provincia",
      "valueString" : "001"
    }]
  },
  {
    "code" : "010204",
    "display" : "TO4",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001082"
    },
    {
      "code" : "provincia",
      "valueString" : "001"
    }]
  },
  {
    "code" : "010205",
    "display" : "TO5",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001078"
    },
    {
      "code" : "provincia",
      "valueString" : "001"
    }]
  },
  {
    "code" : "010206",
    "display" : "VC",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "002158"
    },
    {
      "code" : "provincia",
      "valueString" : "002"
    }]
  },
  {
    "code" : "010207",
    "display" : "BI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "096047"
    },
    {
      "code" : "provincia",
      "valueString" : "096"
    }]
  },
  {
    "code" : "010208",
    "display" : "NO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003106"
    },
    {
      "code" : "provincia",
      "valueString" : "003"
    }]
  },
  {
    "code" : "010209",
    "display" : "VCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "103050"
    },
    {
      "code" : "provincia",
      "valueString" : "103"
    }]
  },
  {
    "code" : "010210",
    "display" : "CN1",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004078"
    },
    {
      "code" : "provincia",
      "valueString" : "004"
    }]
  },
  {
    "code" : "010211",
    "display" : "CN2",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004003"
    },
    {
      "code" : "provincia",
      "valueString" : "004"
    }]
  },
  {
    "code" : "010212",
    "display" : "AT",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "005005"
    },
    {
      "code" : "provincia",
      "valueString" : "005"
    }]
  },
  {
    "code" : "010213",
    "display" : "AL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006003"
    },
    {
      "code" : "provincia",
      "valueString" : "006"
    }]
  },
  {
    "code" : "010301",
    "display" : "ASL CITTA' DI TORINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "provincia",
      "valueString" : "001"
    }]
  },
  {
    "code" : "020101",
    "display" : "AZIENDA U.S.L. VALLE D'AOSTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "020"
    },
    {
      "code" : "comune",
      "valueString" : "007003"
    },
    {
      "code" : "provincia",
      "valueString" : "007"
    }]
  },
  {
    "code" : "030321",
    "display" : "ATS DELLA CITTA' METROPOLITANA DI MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "provincia",
      "valueString" : "015"
    }]
  },
  {
    "code" : "030322",
    "display" : "ATS DELL'INSUBRIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012133"
    },
    {
      "code" : "provincia",
      "valueString" : "012"
    }]
  },
  {
    "code" : "030323",
    "display" : "ATS DELLA MONTAGNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014061"
    },
    {
      "code" : "provincia",
      "valueString" : "014"
    }]
  },
  {
    "code" : "030324",
    "display" : "ATS DELLA BRIANZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015149"
    },
    {
      "code" : "provincia",
      "valueString" : "108"
    }]
  },
  {
    "code" : "030325",
    "display" : "ATS DI BERGAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "provincia",
      "valueString" : "016"
    }]
  },
  {
    "code" : "030326",
    "display" : "ATS DI BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "provincia",
      "valueString" : "017"
    }]
  },
  {
    "code" : "030327",
    "display" : "ATS DELLA VAL PADANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020030"
    },
    {
      "code" : "provincia",
      "valueString" : "020"
    }]
  },
  {
    "code" : "030328",
    "display" : "ATS DI PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "provincia",
      "valueString" : "018"
    }]
  },
  {
    "code" : "041201",
    "display" : "AZIENDA SANITARIA DELLA P.A. DI BOLZANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "provincia",
      "valueString" : "021"
    }]
  },
  {
    "code" : "042101",
    "display" : "TRENTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022205"
    },
    {
      "code" : "provincia",
      "valueString" : "022"
    }]
  },
  {
    "code" : "050501",
    "display" : "AZIENDA ULSS N. 1 DOLOMITI",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "025006"
    },
    {
      "code" : "provincia",
      "valueString" : "025"
    }]
  },
  {
    "code" : "050502",
    "display" : "AZIENDA ULSS N. 2 MARCA TREVIGIANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026086"
    },
    {
      "code" : "provincia",
      "valueString" : "026"
    }]
  },
  {
    "code" : "050503",
    "display" : "AZIENDA ULSS N. 3 SERENISSIMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "provincia",
      "valueString" : "027"
    }]
  },
  {
    "code" : "050504",
    "display" : "AZIENDA ULSS N. 4 VENETO ORIENTALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027033"
    },
    {
      "code" : "provincia",
      "valueString" : "027"
    }]
  },
  {
    "code" : "050505",
    "display" : "AZIENDA ULSS N. 5 POLESANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "029041"
    },
    {
      "code" : "provincia",
      "valueString" : "029"
    }]
  },
  {
    "code" : "050506",
    "display" : "AZIENDA ULSS N. 6 EUGANEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "provincia",
      "valueString" : "028"
    }]
  },
  {
    "code" : "050507",
    "display" : "AZIENDA ULSS N. 7 PEDEMONTANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024012"
    },
    {
      "code" : "provincia",
      "valueString" : "024"
    }]
  },
  {
    "code" : "050508",
    "display" : "AZIENDA ULSS N. 8 BERICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024116"
    },
    {
      "code" : "provincia",
      "valueString" : "024"
    }]
  },
  {
    "code" : "050509",
    "display" : "AZIENDA ULSS N. 9 SCALIGERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "provincia",
      "valueString" : "023"
    }]
  },
  {
    "code" : "060205",
    "display" : "AS FRIULI OCCIDENTALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "093033"
    },
    {
      "code" : "provincia",
      "valueString" : "093"
    }]
  },
  {
    "code" : "060206",
    "display" : "ASU FRIULI CENTRALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030129"
    },
    {
      "code" : "provincia",
      "valueString" : "030"
    }]
  },
  {
    "code" : "060207",
    "display" : "ASU GIULIANO ISONTINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "032006"
    },
    {
      "code" : "provincia",
      "valueString" : "032"
    }]
  },
  {
    "code" : "070101",
    "display" : "IMPERIESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "008055"
    },
    {
      "code" : "provincia",
      "valueString" : "008"
    }]
  },
  {
    "code" : "070102",
    "display" : "SAVONESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "009056"
    },
    {
      "code" : "provincia",
      "valueString" : "009"
    }]
  },
  {
    "code" : "070103",
    "display" : "GENOVESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "provincia",
      "valueString" : "010"
    }]
  },
  {
    "code" : "070104",
    "display" : "CHIAVARESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010015"
    },
    {
      "code" : "provincia",
      "valueString" : "010"
    }]
  },
  {
    "code" : "070105",
    "display" : "SPEZZINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "011015"
    },
    {
      "code" : "provincia",
      "valueString" : "011"
    }]
  },
  {
    "code" : "080101",
    "display" : "AZIENDA USL PIACENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "033032"
    },
    {
      "code" : "provincia",
      "valueString" : "033"
    }]
  },
  {
    "code" : "080102",
    "display" : "AZIENDA USL PARMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034027"
    },
    {
      "code" : "provincia",
      "valueString" : "034"
    }]
  },
  {
    "code" : "080103",
    "display" : "AZIENDA USL REGGIO EMILIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "035033"
    },
    {
      "code" : "provincia",
      "valueString" : "035"
    }]
  },
  {
    "code" : "080104",
    "display" : "AZIENDA USL MODENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "provincia",
      "valueString" : "036"
    }]
  },
  {
    "code" : "080105",
    "display" : "AZIENDA USL BOLOGNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "provincia",
      "valueString" : "037"
    }]
  },
  {
    "code" : "080106",
    "display" : "AZIENDA USL IMOLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037032"
    },
    {
      "code" : "provincia",
      "valueString" : "037"
    }]
  },
  {
    "code" : "080109",
    "display" : "AZIENDA USL FERRARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "038008"
    },
    {
      "code" : "provincia",
      "valueString" : "038"
    }]
  },
  {
    "code" : "080114",
    "display" : "AZIENDA USL DELLA ROMAGNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039014"
    },
    {
      "code" : "provincia",
      "valueString" : "039"
    }]
  },
  {
    "code" : "090201",
    "display" : "AZIENDA USL TOSCANA CENTRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "provincia",
      "valueString" : "048"
    }]
  },
  {
    "code" : "090202",
    "display" : "AZIENDA USL TOSCANA NORD-OVEST",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "provincia",
      "valueString" : "050"
    }]
  },
  {
    "code" : "090203",
    "display" : "AZIENDA USL TOSCANA SUD-EST",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051002"
    },
    {
      "code" : "provincia",
      "valueString" : "051"
    }]
  },
  {
    "code" : "100201",
    "display" : "AUSL UMBRIA N. 1",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "provincia",
      "valueString" : "054"
    }]
  },
  {
    "code" : "100202",
    "display" : "AUSL UMBRIA N. 2",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "055032"
    },
    {
      "code" : "provincia",
      "valueString" : "055"
    }]
  },
  {
    "code" : "110301",
    "display" : "AST1 DI PESARO E URBINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "041044"
    },
    {
      "code" : "provincia",
      "valueString" : "041"
    }]
  },
  {
    "code" : "110302",
    "display" : "AST2 DI ANCONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042002"
    },
    {
      "code" : "provincia",
      "valueString" : "042"
    }]
  },
  {
    "code" : "110303",
    "display" : "AST3 DI MACERATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "043023"
    },
    {
      "code" : "provincia",
      "valueString" : "043"
    }]
  },
  {
    "code" : "110304",
    "display" : "AST4 DI FERMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "044019"
    },
    {
      "code" : "provincia",
      "valueString" : "109"
    }]
  },
  {
    "code" : "110305",
    "display" : "AST5 DI ASCOLI PICENO",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "044007"
    },
    {
      "code" : "provincia",
      "valueString" : "044"
    }]
  },
  {
    "code" : "120109",
    "display" : "VITERBO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056059"
    },
    {
      "code" : "provincia",
      "valueString" : "056"
    }]
  },
  {
    "code" : "120110",
    "display" : "RIETI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "057059"
    },
    {
      "code" : "provincia",
      "valueString" : "057"
    }]
  },
  {
    "code" : "120111",
    "display" : "LATINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059011"
    },
    {
      "code" : "provincia",
      "valueString" : "059"
    }]
  },
  {
    "code" : "120112",
    "display" : "FROSINONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060038"
    },
    {
      "code" : "provincia",
      "valueString" : "060"
    }]
  },
  {
    "code" : "120201",
    "display" : "ROMA 1",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "120202",
    "display" : "ROMA 2",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "120203",
    "display" : "ROMA 3",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "120204",
    "display" : "ROMA 4",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058032"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "120205",
    "display" : "ROMA 5",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058104"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "120206",
    "display" : "ROMA 6",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058003"
    },
    {
      "code" : "provincia",
      "valueString" : "058"
    }]
  },
  {
    "code" : "130201",
    "display" : "AVEZZANO-SULMONA-L'AQUILA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066049"
    },
    {
      "code" : "provincia",
      "valueString" : "066"
    }]
  },
  {
    "code" : "130202",
    "display" : "LANCIANO-VASTO-CHIETI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069022"
    },
    {
      "code" : "provincia",
      "valueString" : "069"
    }]
  },
  {
    "code" : "130203",
    "display" : "PESCARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068028"
    },
    {
      "code" : "provincia",
      "valueString" : "068"
    }]
  },
  {
    "code" : "130204",
    "display" : "TERAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "067041"
    },
    {
      "code" : "provincia",
      "valueString" : "067"
    }]
  },
  {
    "code" : "140201",
    "display" : "ASREM",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070006"
    },
    {
      "code" : "provincia",
      "valueString" : "070"
    }]
  },
  {
    "code" : "150201",
    "display" : "A.S.L. AVELLINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064008"
    },
    {
      "code" : "provincia",
      "valueString" : "064"
    }]
  },
  {
    "code" : "150202",
    "display" : "A.S.L. BENEVENTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062008"
    },
    {
      "code" : "provincia",
      "valueString" : "062"
    }]
  },
  {
    "code" : "150203",
    "display" : "A.S.L. CASERTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061022"
    },
    {
      "code" : "provincia",
      "valueString" : "061"
    }]
  },
  {
    "code" : "150204",
    "display" : "A.S.L. NAPOLI 1 CENTRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "provincia",
      "valueString" : "063"
    }]
  },
  {
    "code" : "150205",
    "display" : "A.S.L. NAPOLI 2 NORD",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063032"
    },
    {
      "code" : "provincia",
      "valueString" : "063"
    }]
  },
  {
    "code" : "150206",
    "display" : "A.S.L. NAPOLI 3 SUD",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063084"
    },
    {
      "code" : "provincia",
      "valueString" : "063"
    }]
  },
  {
    "code" : "150207",
    "display" : "A.S.L. SALERNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065116"
    },
    {
      "code" : "provincia",
      "valueString" : "065"
    }]
  },
  {
    "code" : "160106",
    "display" : "ASL BR",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074001"
    },
    {
      "code" : "provincia",
      "valueString" : "074"
    }]
  },
  {
    "code" : "160112",
    "display" : "ASL TA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "provincia",
      "valueString" : "073"
    }]
  },
  {
    "code" : "160113",
    "display" : "ASL BT",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072005"
    },
    {
      "code" : "provincia",
      "valueString" : "110"
    }]
  },
  {
    "code" : "160114",
    "display" : "ASL BA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "provincia",
      "valueString" : "072"
    }]
  },
  {
    "code" : "160115",
    "display" : "ASL FG",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071024"
    },
    {
      "code" : "provincia",
      "valueString" : "071"
    }]
  },
  {
    "code" : "160116",
    "display" : "ASL LE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "provincia",
      "valueString" : "075"
    }]
  },
  {
    "code" : "170201",
    "display" : "AZIENDA SANITARIA LOCALE DI POTENZA ASP",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076063"
    },
    {
      "code" : "provincia",
      "valueString" : "076"
    }]
  },
  {
    "code" : "170202",
    "display" : "AZIENDA SANITARIA LOCALE DI MATERA  ASM",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "077014"
    },
    {
      "code" : "provincia",
      "valueString" : "077"
    }]
  },
  {
    "code" : "180201",
    "display" : "A.S.P. COSENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "provincia",
      "valueString" : "078"
    }]
  },
  {
    "code" : "180202",
    "display" : "A.S.P. CROTONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "provincia",
      "valueString" : "101"
    }]
  },
  {
    "code" : "180203",
    "display" : "A.S.P. CATANZARO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "provincia",
      "valueString" : "079"
    }]
  },
  {
    "code" : "180204",
    "display" : "A.S.P. VIBO VALENTIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "102047"
    },
    {
      "code" : "provincia",
      "valueString" : "102"
    }]
  },
  {
    "code" : "180205",
    "display" : "A.S.P. REGGIO CALABRIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "provincia",
      "valueString" : "080"
    }]
  },
  {
    "code" : "190201",
    "display" : "ASP AGRIGENTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084001"
    },
    {
      "code" : "provincia",
      "valueString" : "084"
    }]
  },
  {
    "code" : "190202",
    "display" : "ASP CALTANISSETTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085004"
    },
    {
      "code" : "provincia",
      "valueString" : "085"
    }]
  },
  {
    "code" : "190203",
    "display" : "ASP CATANIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "provincia",
      "valueString" : "087"
    }]
  },
  {
    "code" : "190204",
    "display" : "ASP ENNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086009"
    },
    {
      "code" : "provincia",
      "valueString" : "086"
    }]
  },
  {
    "code" : "190205",
    "display" : "ASP MESSINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "provincia",
      "valueString" : "083"
    }]
  },
  {
    "code" : "190206",
    "display" : "ASP PALERMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "provincia",
      "valueString" : "082"
    }]
  },
  {
    "code" : "190207",
    "display" : "ASP RAGUSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088009"
    },
    {
      "code" : "provincia",
      "valueString" : "088"
    }]
  },
  {
    "code" : "190208",
    "display" : "ASP SIRACUSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "provincia",
      "valueString" : "089"
    }]
  },
  {
    "code" : "190209",
    "display" : "ASP DI TRAPANI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081021"
    },
    {
      "code" : "provincia",
      "valueString" : "081"
    }]
  },
  {
    "code" : "200301",
    "display" : "ASL N. 1 DI SASSARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090064"
    },
    {
      "code" : "provincia",
      "valueString" : "090"
    }]
  },
  {
    "code" : "200302",
    "display" : "ASL N. 2 DELLA GALLURA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090047"
    },
    {
      "code" : "provincia",
      "valueString" : "090"
    }]
  },
  {
    "code" : "200303",
    "display" : "ASL N. 3 DI NUORO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091051"
    },
    {
      "code" : "provincia",
      "valueString" : "091"
    }]
  },
  {
    "code" : "200304",
    "display" : "ASL N. 4 DELL'OGLIASTRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091037"
    },
    {
      "code" : "provincia",
      "valueString" : "091"
    }]
  },
  {
    "code" : "200305",
    "display" : "ASL N. 5 DI ORISTANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "095038"
    },
    {
      "code" : "provincia",
      "valueString" : "095"
    }]
  },
  {
    "code" : "200306",
    "display" : "ASL N. 6 DEL MEDIO CAMPIDANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092057"
    },
    {
      "code" : "provincia",
      "valueString" : "111"
    }]
  },
  {
    "code" : "200307",
    "display" : "ASL N. 7 DEL SULCIS",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092012"
    },
    {
      "code" : "provincia",
      "valueString" : "111"
    }]
  },
  {
    "code" : "200308",
    "display" : "ASL N. 8 DI CAGLIARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "provincia",
      "valueString" : "092"
    }]
  }]
}

```
