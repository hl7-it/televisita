# Practitioner Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Practitioner Televisita**

## Resource Profile: Practitioner Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:PractitionerTelevisita |

 
Profilo della risorsa Practitioner utilizzato per rappresentare il professionista sanitario coinvolto nell'erogazione della televisita, inclusi medico specialista, medico prescrittore e altri operatori sanitari. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [Encounter Televisita](StructureDefinition-EncounterTelevisita.md), [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md), [Patient Televisita](StructureDefinition-PatientTelevisita.md)... Show 3 more, [PractitionerRoleTelevisita](StructureDefinition-PractitionerRoleTelevisita.md), [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md) and [ServiceRequest Televisita](StructureDefinition-ServiceRequestTelevisita.md)
* Examples for this Profile: [Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-PractitionerTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PractitionerTelevisita.csv), [Excel](StructureDefinition-PractitionerTelevisita.xlsx), [Schematron](StructureDefinition-PractitionerTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PractitionerTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
  "version" : "0.2.0",
  "name" : "PractitionerTelevisita",
  "title" : "Practitioner Televisita",
  "status" : "active",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Practitioner utilizzato per rappresentare il professionista sanitario coinvolto nell'erogazione della televisita, inclusi medico specialista, medico prescrittore e altri operatori sanitari.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Practitioner",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Practitioner",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Practitioner",
      "path" : "Practitioner",
      "short" : "Professionista sanitario coinvolto nella televisita.",
      "definition" : "Rappresenta un professionista sanitario (medico specialista, medico di medicina generale, infermiere o altra figura tecnica) coinvolto nell'erogazione o nella gestione della televisita."
    },
    {
      "id" : "Practitioner.identifier",
      "path" : "Practitioner.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "system"
        }],
        "description" : "Slice based on the identifier pattern",
        "rules" : "open"
      },
      "short" : "Identificativo dell'operatore sanitario",
      "definition" : "Un identificatore che si applica a questa persona in questo ruolo.",
      "min" : 1
    },
    {
      "id" : "Practitioner.identifier:codiceFiscale",
      "path" : "Practitioner.identifier",
      "sliceName" : "codiceFiscale",
      "short" : "Codice Fiscale",
      "definition" : "Codice Fiscale",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Practitioner.identifier:codiceFiscale.system",
      "path" : "Practitioner.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/codiceFiscale"
    },
    {
      "id" : "Practitioner.name",
      "path" : "Practitioner.name",
      "short" : "Nome del professionista sanitario.",
      "definition" : "Nome anagrafico del professionista sanitario coinvolto nella televisita, comprensivo di cognome, nome e, ove disponibili, altri elementi anagrafici.",
      "comment" : "La selezione della proprietà use deve garantire che sia specificato un unico nome usuale e che gli altri utilizzino il nickname (alias), il vecchio o altri valori, a seconda dei casi.  \n\nIn generale, selezionare il valore da utilizzare in ResourceReference.display in base a quanto segue:\n\n1. C'è più di un nome\n2. Uso = abituale\n3. Il periodo è attuale alla data dell'uso\n4. Uso = ufficiale\n5. Altro ordine deciso dalle regole aziendali interne."
    },
    {
      "id" : "Practitioner.telecom",
      "path" : "Practitioner.telecom",
      "short" : "Recapiti del professionista sanitario.",
      "definition" : "Numeri di telefono, indirizzi e-mail o altri recapiti del professionista sanitario, utilizzabili per comunicazioni nell'ambito del percorso di televisita."
    },
    {
      "id" : "Practitioner.gender",
      "path" : "Practitioner.gender",
      "short" : "Genere amministrativo del professionista.",
      "definition" : "Genere amministrativo del professionista sanitario utilizzato nei sistemi informativi."
    },
    {
      "id" : "Practitioner.birthDate",
      "path" : "Practitioner.birthDate",
      "short" : "Data di nascita del professionista.",
      "definition" : "Data di nascita del professionista sanitario, utile ai fini dell'identificazione anagrafica."
    },
    {
      "id" : "Practitioner.qualification",
      "path" : "Practitioner.qualification",
      "short" : "Qualifiche e abilitazioni professionali.",
      "definition" : "Certificazioni, abilitazioni e titoli professionali del professionista sanitario che attestano le competenze necessarie per l'erogazione della televisita."
    },
    {
      "id" : "Practitioner.qualification.code",
      "path" : "Practitioner.qualification.code",
      "short" : "Codice della qualifica professionale.",
      "definition" : "Codice che identifica il tipo di qualifica o abilitazione professionale del professionista (es. medico specialista in cardiologia, medico di medicina generale)."
    },
    {
      "id" : "Practitioner.communication",
      "path" : "Practitioner.communication",
      "short" : "Lingue parlate dal professionista.",
      "definition" : "Lingue in cui il professionista sanitario è in grado di comunicare con l'assistito, rilevante nel contesto di televisite che possono coinvolgere assistiti stranieri."
    }]
  }
}

```
