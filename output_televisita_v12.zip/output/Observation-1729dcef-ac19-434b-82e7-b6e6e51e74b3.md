# Diagnosi - Bronchite Cronica Mucopurulenta (ICD-9 491.1) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Diagnosi - Bronchite Cronica Mucopurulenta (ICD-9 491.1)**

## Example Observation: Diagnosi - Bronchite Cronica Mucopurulenta (ICD-9 491.1)

Profile: [Observation Televisita](StructureDefinition-ObservationTelevisita.md)

**status**: Final

**code**: Diagnosis Narrative

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: Bronchite cronica mucopurulenta (ICD-9: 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente), assenza di segni di riacutizzazione e buona risposta alla terapia inalatoria in corso.



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "1729dcef-ac19-434b-82e7-b6e6e51e74b3",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "29548-5",
      "display" : "Diagnosis Narrative"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "Bronchite cronica mucopurulenta (ICD-9: 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente), assenza di segni di riacutizzazione e buona risposta alla terapia inalatoria in corso."
}

```
