# Procedure - Prestazioni - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Procedure - Prestazioni**

## Procedure - Prestazioni

Questa pagina descrive la mappatura tra i campi dell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e il corrispondente profilo FHIR.

Allegato 1 Telemedicina → Prestazioni erogate

 La risorsa `Procedure` rappresenta le prestazioni erogate durante la televisita, inclusi codici, descrizioni, periodi di erogazione, modalità esecutive e strumentazione utilizzata. 

**Contesto di mappatura:**
`Composition.section[prestazioni].entry.resolve().ofType(Procedure)`

| | | | |
| :--- | :--- | :--- | :--- |
| Codice prestazione eseguita | Codice della prestazione eseguita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).code.coding.code` |
| Descrizione prestazione eseguita | Descrizione della prestazione eseguita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).code.text` |
| Data e ora di inizio erogazione | Data e ora di inizio erogazione della prestazione | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).performedPeriod.start` |
| Data e ora di fine erogazione | Data e ora di fine erogazione della prestazione | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).performedPeriod.end` |
| Codice procedura operativa | Codice della procedura operativa eseguita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).code.coding.code` |
| Descrizione procedura operativa | Descrizione procedura operativa eseguita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).code.coding.display` |
| Quantità | Numero di volte in cui la prestazione è stata eseguita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).extension:quantita / derived` |
| Modalità esecuzione procedura operativa | Descrizione modalità di esecuzione della procedura operativa. Rappresenta la declinazione pratica del come viene eseguita la procedura. | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).method` |
| Strumentazione utilizzata | Strumentazione utilizzata nel corso della procedura | Composition/Procedure/Device | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).usedReference.resolve().ofType(Device)` |
| Parametri descrittivi della procedura | Parametri rilevanti al fine di caratterizzare la procedura | Composition/Procedure/Observation | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).supportingInfo.resolve().ofType(Observation)` |
| Note | Note aggiuntive relative alla procedura eseguita durante la televisita | Composition/Procedure | `Composition.section[prestazioni].entry.resolve().ofType(Procedure).note.text` |

 Torna alla panoramica: [Modello di mappatura](modelmap.md) 

