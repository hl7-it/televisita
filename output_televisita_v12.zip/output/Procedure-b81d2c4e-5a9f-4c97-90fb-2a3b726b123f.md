# Esempio di Televisita Pneumologica - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Esempio di Televisita Pneumologica**

## Example Procedure: Esempio di Televisita Pneumologica

Profile: [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md)

**basedOn**: [ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md)

**status**: Completed

**category**: Pneumologia

**code**: VISITA PNEUMOLOGICA DI CONTROLLO. Incluso: eventuale rilevazione incruenta della saturazione arteriosa

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**encounter**: [Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --> 2025-06-16 09:45:00+0200](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)

**performed**: 2025-06-16 09:00:00+0200 --> 2025-06-16 09:45:00+0200

**recorder**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

### Performers

| | | |
| :--- | :--- | :--- |
| - | **Function** | **Actor** |
| * | Pulmonologist | [PractitionerRole: specialty = Pneumologia](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md) |

**reasonCode**: Chronic obstructive lung disease

**outcome**: Il paziente ha riportato lieve miglioramento della sintomatologia respiratoria. Terapia inalatoria confermata. Indicata spirometria di controllo tra 3 mesi.

**report**: [Composition Referto di Televisita](Composition-aa011502-6ad2-430b-a439-01dddc36fd4e.md)

**note**: 

> 

Televisita eseguita tramite piattaforma XTelemed. Durata 45 minuti.




## Resource Content

```json
{
  "resourceType" : "Procedure",
  "id" : "b81d2c4e-5a9f-4c97-90fb-2a3b726b123f",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
  }],
  "status" : "completed",
  "category" : {
    "coding" : [{
      "system" : "http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione",
      "code" : "22",
      "display" : "Pneumologia"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://hl7.it/fhir/televisita/CodeSystem/CodesystemCatalogoNazionalePrestazioni",
      "code" : "89.01.L",
      "display" : "VISITA PNEUMOLOGICA DI CONTROLLO. Incluso: eventuale rilevazione incruenta della saturazione arteriosa"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "encounter" : {
    "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
  },
  "performedPeriod" : {
    "start" : "2025-06-16T09:00:00+02:00",
    "end" : "2025-06-16T09:45:00+02:00"
  },
  "recorder" : {
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  },
  "performer" : [{
    "function" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "41672002",
        "display" : "Pulmonologist"
      }]
    },
    "actor" : {
      "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
    }
  }],
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "13645005",
      "display" : "Chronic obstructive lung disease"
    }]
  }],
  "outcome" : {
    "text" : "Il paziente ha riportato lieve miglioramento della sintomatologia respiratoria. Terapia inalatoria confermata. Indicata spirometria di controllo tra 3 mesi."
  },
  "report" : [{
    "reference" : "Composition/aa011502-6ad2-430b-a439-01dddc36fd4e"
  }],
  "note" : [{
    "text" : "Televisita eseguita tramite piattaforma XTelemed. Durata 45 minuti."
  }]
}

```
