# Quesito Diagnostico - Tosse persistente post-COVID - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Quesito Diagnostico - Tosse persistente post-COVID**

## Example Observation: Quesito Diagnostico - Tosse persistente post-COVID

Profile: [Observation Televisita](StructureDefinition-ObservationTelevisita.md)

**status**: Final

**code**: Reason for visit Narrative

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: Controllo post-COVID per tosse persistente (ICD-9: 786.2)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "7cbbe77d-dcdb-409b-a215-6361ad7873d5",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "29299-5",
      "display" : "Reason for visit Narrative"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "Controllo post-COVID per tosse persistente (ICD-9: 786.2)"
}

```
