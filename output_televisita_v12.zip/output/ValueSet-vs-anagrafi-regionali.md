# VS-Anagrafi Regionali - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VS-Anagrafi Regionali**

## ValueSet: VS-Anagrafi Regionali 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ValueSet/vs-anagrafi-regionali | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:VsAnagrafiRegionali |

 
VS-Anagrafi Regionali 

 **References** 

* [Organization T1 - Azienda Sanitaria](StructureDefinition-OrganizationT1.md)
* [Patient Televisita](StructureDefinition-PatientTelevisita.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vs-anagrafi-regionali",
  "url" : "http://hl7.it/fhir/televisita/ValueSet/vs-anagrafi-regionali",
  "version" : "0.2.0",
  "name" : "VsAnagrafiRegionali",
  "title" : "VS-Anagrafi Regionali",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "VS-Anagrafi Regionali",
  "compose" : {
    "include" : [{
      "system" : "urn:ietf:rfc:3986",
      "concept" : [{
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.10.4.1.",
        "display" : "Anagrafi Regionali - Piemonte"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.20.4.1",
        "display" : "Anagrafi Regionali - Valle d`aosta"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.30.4.1",
        "display" : "Anagrafi Regionali - Lombardia"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.41.4.1",
        "display" : "Anagrafi Regionali - prov. auton. bolzano"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.42.4.1",
        "display" : "Anagrafi Regionali - prov. auton. trento"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.50.4.1",
        "display" : "Anagrafi Regionali - Veneto"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.60.4.1",
        "display" : "Anagrafi Regionali - Friuli venezia giulia"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.70.4.1",
        "display" : "Anagrafi Regionali - Liguria"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.80.4.1",
        "display" : "Anagrafi Regionali - Emilia romagna"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.90.4.1",
        "display" : "Anagrafi Regionali - Toscana"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.100.4.1",
        "display" : "Anagrafi Regionali - Umbria"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.110.4.1",
        "display" : "Anagrafi Regionali - Marche"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.120.4.1",
        "display" : "Anagrafi Regionali - Lazio"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.130.4.1",
        "display" : "Anagrafi Regionali - Abruzzo"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.140.4.1",
        "display" : "Anagrafi Regionali - Molise"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.150.4.1",
        "display" : "Anagrafi Regionali - Campania"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.160.4.1",
        "display" : "Anagrafi Regionali - Puglia"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.170.4.1",
        "display" : "Anagrafi Regionali - Basilicata"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.180.4.1",
        "display" : "Anagrafi Regionali - Calabria"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.190.4.1",
        "display" : "Anagrafi Regionali - Sicilia"
      },
      {
        "code" : "urn:oid:2.16.840.1.113883.2.9.2.200.4.1",
        "display" : "Anagrafi Regionali - Sardegna"
      }]
    }]
  }
}

```
