# Referto di Televisita Pneumologica - Maria Rossi - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referto di Televisita Pneumologica - Maria Rossi**

## Example Composition: Referto di Televisita Pneumologica - Maria Rossi

Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)

**status**: Final

**type**: Telehealth Note

**encounter**: [Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --> 2025-06-16 09:45:00+0200](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)

**date**: 2025-06-16 10:30:00+0200

**author**: [PractitionerRole: specialty = Pneumologia](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md)

**title**: Referto di Televisita

### Attesters

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Mode** | **Time** | **Party** |
| * | Legal | 2025-06-16 10:30:00+0200 | [PractitionerRole: specialty = Pneumologia](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md) |



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "aa011502-6ad2-430b-a439-01dddc36fd4e",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"]
  },
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "75496-0",
      "display" : "Telehealth Note"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "encounter" : {
    "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
  },
  "date" : "2025-06-16T10:30:00+02:00",
  "author" : [{
    "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
  }],
  "title" : "Referto di Televisita",
  "attester" : [{
    "mode" : "legal",
    "time" : "2025-06-16T10:30:00+02:00",
    "party" : {
      "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
    }
  }],
  "section" : [{
    "title" : "Quesito Diagnostico",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "29299-5"
      }]
    },
    "entry" : [{
      "reference" : "Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5"
    }]
  },
  {
    "title" : "Inquadramento Clinico Iniziale",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "10164-2"
      }]
    },
    "section" : [{
      "title" : "Anamnesi",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11329-0"
        }]
      },
      "entry" : [{
        "reference" : "Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f"
      }]
    },
    {
      "title" : "Allergie",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48765-2"
        }]
      },
      "entry" : [{
        "reference" : "AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94"
      }]
    },
    {
      "title" : "Terapia farmacologica in atto",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10160-0"
        }]
      },
      "entry" : [{
        "reference" : "MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a"
      }]
    },
    {
      "title" : "Esame obiettivo",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29545-1"
        }]
      },
      "entry" : [{
        "reference" : "Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865"
      }]
    }]
  },
  {
    "title" : "Precedenti esami eseguiti",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "30954-2"
      }]
    },
    "entry" : [{
      "reference" : "Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476"
    }]
  },
  {
    "title" : "Confronto con esami precedenti",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "93126-1"
      }]
    },
    "entry" : [{
      "reference" : "Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393"
    }]
  },
  {
    "title" : "Referto",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "47045-0"
      }]
    },
    "entry" : [{
      "reference" : "Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94"
    }]
  },
  {
    "title" : "Diagnosi",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "29548-5"
      }]
    },
    "entry" : [{
      "reference" : "Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3"
    }]
  },
  {
    "title" : "Conclusioni",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "55110-1"
      }]
    },
    "entry" : [{
      "reference" : "Observation/1611ed98-7577-48ab-9587-7ab4fc96e191"
    }]
  },
  {
    "title" : "Suggerimenti per il medico prescrittore",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "62385-0"
      }]
    },
    "entry" : [{
      "reference" : "Observation/2054e65c-2012-4286-aac7-ce2f23e8be31"
    }]
  },
  {
    "title" : "Accertamenti/controlli consigliati",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "80615-8"
      }]
    },
    "entry" : [{
      "reference" : "Observation/1b401b53-f564-4730-bb13-45d5620596f0"
    }]
  },
  {
    "title" : "Terapia farmacologica consigliata",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "93341-6"
      }]
    },
    "entry" : [{
      "reference" : "MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f"
    }]
  },
  {
    "title" : "Prestazioni",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "62387-6"
      }]
    },
    "entry" : [{
      "reference" : "Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f"
    }]
  },
  {
    "title" : "Documenti allegati",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "77599-9"
      }]
    },
    "entry" : [{
      "reference" : "DocumentReference/4f6c71e1-cc6e-4428-ae9b-0118c0a928cb"
    }]
  }]
}

```
