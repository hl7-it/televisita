# U.O. Pneumologia - Ospedale Pertini - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **U.O. Pneumologia - Ospedale Pertini**

## Example Organization: U.O. Pneumologia - Ospedale Pertini

Profile: [Organization T3 - Unità Operativa / Ambulatorio](StructureDefinition-OrganizationT3.md)

**identifier**: `http://hl7.it/sid/hsp`/UO12345

**name**: U.O. Pneumologia

**partOf**: [Organization Ospedale Sandro Pertini](Organization-osp-pertini.md)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "uo-cardiologia-pertini",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3"]
  },
  "identifier" : [{
    "system" : "http://hl7.it/sid/hsp",
    "value" : "UO12345"
  }],
  "name" : "U.O. Pneumologia",
  "partOf" : {
    "reference" : "Organization/osp-pertini"
  }
}

```
