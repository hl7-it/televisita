# DUG (Denominazione Urbanistica Generica) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DUG (Denominazione Urbanistica Generica)**

## Extension: DUG (Denominazione Urbanistica Generica) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/address-dug | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ExtDug |

Denominazione Urbanistica Ufficiale.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Address - ITA](StructureDefinition-AddressItTelemedicina.md)
* Examples for this Extension: [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-address-dug.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-address-dug.csv), [Excel](StructureDefinition-address-dug.xlsx), [Schematron](StructureDefinition-address-dug.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "address-dug",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-dug",
  "version" : "0.2.0",
  "name" : "ExtDug",
  "title" : "DUG (Denominazione Urbanistica Generica)",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Denominazione Urbanistica Ufficiale.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Address.line"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "DUG (Denominazione Urbanistica Generica)",
      "definition" : "Denominazione Urbanistica Ufficiale."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.it/fhir/televisita/StructureDefinition/address-dug"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/istat-dug"
      }
    }]
  }
}

```
