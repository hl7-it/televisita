# Referto di Televisita Pneumologica - Maria Rossi (Transaction) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referto di Televisita Pneumologica - Maria Rossi (Transaction)**

## Example Bundle: Referto di Televisita Pneumologica - Maria Rossi (Transaction)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "RefertoDiTelevisitaTransaction",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertoDiTelevisitaTransaction"]
  },
  "type" : "transaction",
  "entry" : [{
    "fullUrl" : "http://example/Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82</b></p><a name=\"2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82\"> </a><a name=\"hc2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PatientTelevisita.html\">Patient Televisita</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 3331245678</li><li><a href=\"mailto:maria.rossi@mail.com\">maria.rossi@mail.com</a></li><li>Via della Libertà, 52 Milano Italia 20100 IT (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: Emergency Contact\">Emergency Contact:</td><td colspan=\"3\"><ul><li>Luigi Rossi </li><li>ph: 3312345567</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: Emergency Contact\">Emergency Contact:</td><td colspan=\"3\"><ul><li>Maria Bianchi </li><li>ph: 3311234598</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Estensione utilizzata per rappresentare il luogo di nascita dell'assistito secondo il formato italiano, strutturato come un indirizzo conforme al profilo AddressItTelemedicina. Nel contesto della televisita è rilevante per l'identificazione anagrafica dell'assistito.\"><a href=\"StructureDefinition-birth-place-ita.html\">Luogo di Nascita - ITA</a></td><td colspan=\"3\">Via della Vittoria, 1 Milano Italia 20100 IT </td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita",
        "valueAddress" : {
          "extension" : [{
            "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official",
            "valueBoolean" : true
          }],
          "line" : ["Via della Vittoria, 1"],
          "_line" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
              "valueString" : "Via della Vittoria"
            },
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
              "valueString" : "1"
            }]
          }],
          "city" : "Milano",
          "state" : "Italia",
          "postalCode" : "20100",
          "country" : "IT"
        }
      }],
      "identifier" : [{
        "system" : "http://hl7.it/sid/codiceFiscale",
        "value" : "RSSMRA71E41F205E"
      }],
      "name" : [{
        "family" : "Rossi",
        "given" : ["Maria"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "3331245678"
      },
      {
        "system" : "email",
        "value" : "maria.rossi@mail.com"
      }],
      "gender" : "female",
      "birthDate" : "1971-05-01",
      "address" : [{
        "extension" : [{
          "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official",
          "valueBoolean" : true
        },
        {
          "extension" : [{
            "url" : "who",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.it/fhir/televisita/CodeSystem/it-tipoEntita",
                "code" : "gov"
              }]
            }
          }],
          "url" : "http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"
        }],
        "use" : "home",
        "line" : ["Via della Libertà, 52"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-dug",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.it/fhir/televisita/CodeSystem/dug",
                "code" : "67",
                "display" : "via"
              }]
            }
          }]
        }],
        "city" : "Milano",
        "state" : "Italia",
        "postalCode" : "20100",
        "country" : "IT"
      }],
      "contact" : [{
        "relationship" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
            "code" : "C",
            "display" : "Emergency Contact"
          }]
        }],
        "name" : {
          "family" : "Rossi",
          "given" : ["Luigi"]
        },
        "telecom" : [{
          "system" : "phone",
          "value" : "3312345567"
        }]
      },
      {
        "relationship" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
            "code" : "C",
            "display" : "Emergency Contact"
          }]
        }],
        "name" : {
          "family" : "Bianchi",
          "given" : ["Maria"]
        },
        "telecom" : [{
          "system" : "phone",
          "value" : "3311234598"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient?identifier=http://hl7.it/sid/codiceFiscale|RSSMRA71E41F205E"
    }
  },
  {
    "fullUrl" : "http://example/Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "2b373c5c-0fbf-4167-875b-47ee7fc5cd5d",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_2b373c5c-0fbf-4167-875b-47ee7fc5cd5d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 2b373c5c-0fbf-4167-875b-47ee7fc5cd5d</b></p><a name=\"2b373c5c-0fbf-4167-875b-47ee7fc5cd5d\"> </a><a name=\"hc2b373c5c-0fbf-4167-875b-47ee7fc5cd5d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PractitionerTelevisita.html\">Practitioner Televisita</a></p></div><p><b>identifier</b>: <code>http://hl7.it/sid/codiceFiscale</code>/FRRMRC75T10H501K</p><p><b>name</b>: Marco Ferrari </p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.it/sid/codiceFiscale",
        "value" : "FRRMRC75T10H501K"
      }],
      "name" : [{
        "family" : "Ferrari",
        "given" : ["Marco"]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner?identifier=http://hl7.it/sid/codiceFiscale|FRRMRC75T10H501K"
    }
  },
  {
    "fullUrl" : "http://example/Organization/asl-roma-1",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "asl-roma-1",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_asl-roma-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization asl-roma-1</b></p><a name=\"asl-roma-1\"> </a><a name=\"hcasl-roma-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-OrganizationT1.html\">Organization T1 - Azienda Sanitaria</a></p></div><p><b>identifier</b>: <code>http://hl7.it/sid/fls</code>/120201, <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:2.16.840.1.113883.2.9.2.120.4.1, <code>http://hl7.it/sid/partitaIva</code>/12345678901, <code>http://hl7.it/sid/codiceFiscale</code>/01234567890</p><p><b>name</b>: ASL Roma 1</p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.it/sid/fls",
        "value" : "120201"
      },
      {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.840.1.113883.2.9.2.120.4.1"
      },
      {
        "system" : "http://hl7.it/sid/partitaIva",
        "value" : "12345678901"
      },
      {
        "system" : "http://hl7.it/sid/codiceFiscale",
        "value" : "01234567890"
      }],
      "name" : "ASL Roma 1"
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization?identifier=http://hl7.it/sid/fls|120201"
    }
  },
  {
    "fullUrl" : "http://example/Organization/osp-pertini",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "osp-pertini",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_osp-pertini\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization osp-pertini</b></p><a name=\"osp-pertini\"> </a><a name=\"hcosp-pertini\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-OrganizationT2.html\">Organization T2 - Presidio / Ospedale</a></p></div><p><b>identifier</b>: <code>http://hl7.it/sid/hsp</code>/HSP00123</p><p><b>name</b>: Ospedale Sandro Pertini</p><p><b>partOf</b>: <a href=\"Organization-asl-roma-1.html\">Organization ASL Roma 1</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.it/sid/hsp",
        "value" : "HSP00123"
      }],
      "name" : "Ospedale Sandro Pertini",
      "partOf" : {
        "reference" : "Organization/asl-roma-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization?identifier=http://hl7.it/sid/hsp|HSP00123"
    }
  },
  {
    "fullUrl" : "http://example/Organization/uo-cardiologia-pertini",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "uo-cardiologia-pertini",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_uo-cardiologia-pertini\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization uo-cardiologia-pertini</b></p><a name=\"uo-cardiologia-pertini\"> </a><a name=\"hcuo-cardiologia-pertini\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-OrganizationT3.html\">Organization T3 - Unità Operativa / Ambulatorio</a></p></div><p><b>identifier</b>: <code>http://hl7.it/sid/hsp</code>/UO12345</p><p><b>name</b>: U.O. Pneumologia</p><p><b>partOf</b>: <a href=\"Organization-osp-pertini.html\">Organization Ospedale Sandro Pertini</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.it/sid/hsp",
        "value" : "UO12345"
      }],
      "name" : "U.O. Pneumologia",
      "partOf" : {
        "reference" : "Organization/osp-pertini"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Organization?identifier=http://hl7.it/sid/hsp|UO12345"
    }
  },
  {
    "fullUrl" : "http://example/PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "e446e848-2bd4-423a-b2f8-5d25687e2f42",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_e446e848-2bd4-423a-b2f8-5d25687e2f42\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole e446e848-2bd4-423a-b2f8-5d25687e2f42</b></p><a name=\"e446e848-2bd4-423a-b2f8-5d25687e2f42\"> </a><a name=\"hce446e848-2bd4-423a-b2f8-5d25687e2f42\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PractitionerRoleTelevisita.html\">PractitionerRoleTelevisita</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>organization</b>: <a href=\"Organization-asl-roma-1.html\">Organization ASL Roma 1</a></p><p><b>specialty</b>: <span title=\"Codes:{http://hl7.it/fhir/televisita/CodeSystem/csspecialityPractitionerRole 68}\">Pneumologia</span></p></div>"
      },
      "practitioner" : {
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      },
      "organization" : {
        "reference" : "Organization/asl-roma-1"
      },
      "specialty" : [{
        "coding" : [{
          "system" : "http://hl7.it/fhir/televisita/CodeSystem/csspecialityPractitionerRole",
          "code" : "68",
          "display" : "Pneumologia"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "PractitionerRole?practitioner.identifier=http://hl7.it/sid/codiceFiscale|FRRMRC75T10H501K"
    }
  },
  {
    "fullUrl" : "http://example/Composition/aa011502-6ad2-430b-a439-01dddc36fd4e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "aa011502-6ad2-430b-a439-01dddc36fd4e",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_aa011502-6ad2-430b-a439-01dddc36fd4e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition aa011502-6ad2-430b-a439-01dddc36fd4e</b></p><a name=\"aa011502-6ad2-430b-a439-01dddc36fd4e\"> </a><a name=\"hcaa011502-6ad2-430b-a439-01dddc36fd4e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-CompositionRefertoTelevisita.html\">CompositionRefertoTelevisita</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 75496-0}\">Telehealth Note</span></p><p><b>encounter</b>: <a href=\"Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.html\">Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --&gt; 2025-06-16 09:45:00+0200</a></p><p><b>date</b>: 2025-06-16 10:30:00+0200</p><p><b>author</b>: <a href=\"PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.html\">PractitionerRole: specialty = Pneumologia</a></p><p><b>title</b>: Referto di Televisita</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Legal</td><td>2025-06-16 10:30:00+0200</td><td><a href=\"PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.html\">PractitionerRole: specialty = Pneumologia</a></td></tr></table></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75496-0",
          "display" : "Telehealth Note"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "encounter" : {
        "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
      },
      "date" : "2025-06-16T10:30:00+02:00",
      "author" : [{
        "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
      }],
      "title" : "Referto di Televisita",
      "attester" : [{
        "mode" : "legal",
        "time" : "2025-06-16T10:30:00+02:00",
        "party" : {
          "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
        }
      }],
      "section" : [{
        "title" : "Quesito Diagnostico",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "29299-5"
          }]
        },
        "entry" : [{
          "reference" : "Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5"
        }]
      },
      {
        "title" : "Inquadramento Clinico Iniziale",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "10164-2"
          }]
        },
        "section" : [{
          "title" : "Anamnesi",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "11329-0"
            }]
          },
          "entry" : [{
            "reference" : "Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f"
          }]
        },
        {
          "title" : "Allergie",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "48765-2"
            }]
          },
          "entry" : [{
            "reference" : "AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94"
          }]
        },
        {
          "title" : "Terapia farmacologica in atto",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "10160-0"
            }]
          },
          "entry" : [{
            "reference" : "MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a"
          }]
        },
        {
          "title" : "Esame obiettivo",
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "29545-1"
            }]
          },
          "entry" : [{
            "reference" : "Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865"
          }]
        }]
      },
      {
        "title" : "Precedenti esami eseguiti",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "30954-2"
          }]
        },
        "entry" : [{
          "reference" : "Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476"
        }]
      },
      {
        "title" : "Confronto con esami precedenti",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "93126-1"
          }]
        },
        "entry" : [{
          "reference" : "Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393"
        }]
      },
      {
        "title" : "Referto",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "47045-0"
          }]
        },
        "entry" : [{
          "reference" : "Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94"
        }]
      },
      {
        "title" : "Diagnosi",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "29548-5"
          }]
        },
        "entry" : [{
          "reference" : "Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3"
        }]
      },
      {
        "title" : "Conclusioni",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "55110-1"
          }]
        },
        "entry" : [{
          "reference" : "Observation/1611ed98-7577-48ab-9587-7ab4fc96e191"
        }]
      },
      {
        "title" : "Suggerimenti per il medico prescrittore",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "62385-0"
          }]
        },
        "entry" : [{
          "reference" : "Observation/2054e65c-2012-4286-aac7-ce2f23e8be31"
        }]
      },
      {
        "title" : "Accertamenti/controlli consigliati",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "80615-8"
          }]
        },
        "entry" : [{
          "reference" : "Observation/1b401b53-f564-4730-bb13-45d5620596f0"
        }]
      },
      {
        "title" : "Terapia farmacologica consigliata",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "93341-6"
          }]
        },
        "entry" : [{
          "reference" : "MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f"
        }]
      },
      {
        "title" : "Prestazioni",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "62387-6"
          }]
        },
        "entry" : [{
          "reference" : "Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f"
        }]
      },
      {
        "title" : "Documenti allegati",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "77599-9"
          }]
        },
        "entry" : [{
          "reference" : "DocumentReference/4f6c71e1-cc6e-4428-ae9b-0118c0a928cb"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Composition"
    }
  },
  {
    "fullUrl" : "http://example/Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2</b></p><a name=\"a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2\"> </a><a name=\"hca2aaf911-51e7-4e38-a7ca-2817c0fcc6d2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-EncounterTelevisita.html\">Encounter Televisita</a></p></div><p><b>identifier</b>: <code>http://hl7.it/fhir/televisita/sid/codiceNosologico</code>/POD.123e4567-e89b-12d3-a456-426614174000</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActCode.html#v3-ActCode-VR\">ActCode: VR</a> (Virtual)</p><p><b>priority</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ActPriority R}\">routine</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>basedOn</b>: <a href=\"ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.html\">ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed</a></p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Individual</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></td></tr></table><p><b>appointment</b>: <a href=\"Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.html\">Appointment: identifier = TV-20250616-001; status = booked; serviceCategory = Counselling; reasonCode = Chronic obstructive lung disease; start = 2025-06-16 09:00:00+0200; end = 2025-06-16 09:45:00+0200; created = 2025-06-02 09:00:00+0200</a></p><p><b>period</b>: 2025-06-16 09:00:00+0200 --&gt; 2025-06-16 09:45:00+0200</p><p><b>serviceProvider</b>: <a href=\"Organization-asl-roma-1.html\">Organization ASL Roma 1</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://hl7.it/fhir/televisita/sid/codiceNosologico",
        "value" : "POD.123e4567-e89b-12d3-a456-426614174000"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "VR",
        "display" : "Virtual"
      },
      "priority" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActPriority",
          "code" : "R",
          "display" : "routine"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
      }],
      "participant" : [{
        "individual" : {
          "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
        }
      }],
      "appointment" : [{
        "reference" : "Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908"
      }],
      "period" : {
        "start" : "2025-06-16T09:00:00+02:00",
        "end" : "2025-06-16T09:45:00+02:00"
      },
      "serviceProvider" : {
        "reference" : "Organization/asl-roma-1"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "http://example/ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc</b></p><a name=\"d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc\"> </a><a name=\"hcd3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ServiceRequestTelevisita.html\">ServiceRequest Televisita</a></p></div><p><b>identifier</b>: AAZ123456789</p><p><b>requisition</b>: REQ-20250616-0001</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione 22}\">Pneumologia</span></p><p><b>priority</b>: Routine</p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi</a></p><p><b>encounter</b>: <a href=\"Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.html\">Televisita 16/06/2025</a></p><p><b>occurrence</b>: 2025-06-16 09:00:00+0200</p><p><b>authoredOn</b>: 2025-06-02 09:15:00+0200</p><p><b>requester</b>: <a href=\"PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.html\">PractitionerRole: specialty = Pneumologia</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 13645005}\">Chronic obstructive lung disease</span></p><p><b>note</b>: </p><blockquote><div><p>Prestazione da eseguire in modalità remota tramite piattaforma XTelemed</p>\n</div></blockquote></div>"
      },
      "identifier" : [{
        "value" : "AAZ123456789"
      }],
      "requisition" : {
        "value" : "REQ-20250616-0001"
      },
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione",
          "code" : "22",
          "display" : "Pneumologia"
        }]
      }],
      "priority" : "routine",
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82",
        "display" : "Maria Rossi"
      },
      "encounter" : {
        "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2",
        "display" : "Televisita 16/06/2025"
      },
      "occurrenceDateTime" : "2025-06-16T09:00:00+02:00",
      "authoredOn" : "2025-06-02T09:15:00+02:00",
      "requester" : {
        "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "13645005",
          "display" : "Chronic obstructive lung disease"
        }]
      }],
      "note" : [{
        "text" : "Prestazione da eseguire in modalità remota tramite piattaforma XTelemed"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "http://example/Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908",
    "resource" : {
      "resourceType" : "Appointment",
      "id" : "9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Appointment_9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Appointment 9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908</b></p><a name=\"9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908\"> </a><a name=\"hc9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-AppointmentTelevisita.html\">AppointmentTelevisita</a></p></div><p><b>identifier</b>: TV-20250616-001</p><p><b>status</b>: Booked</p><p><b>serviceCategory</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/service-category 8}\">Counselling</span></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 13645005}\">Televisita pneumologica per follow-up bronchite cronica</span></p><p><b>start</b>: 2025-06-16 09:00:00+0200</p><p><b>end</b>: 2025-06-16 09:45:00+0200</p><p><b>created</b>: 2025-06-02 09:00:00+0200</p><p><b>basedOn</b>: <a href=\"ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.html\">ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed</a></p><blockquote><p><b>participant</b></p><p><b>actor</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>status</b>: Accepted</p></blockquote><blockquote><p><b>participant</b></p><p><b>actor</b>: <a href=\"PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.html\">PractitionerRole: specialty = Pneumologia</a></p><p><b>status</b>: Accepted</p></blockquote></div>"
      },
      "identifier" : [{
        "value" : "TV-20250616-001"
      }],
      "status" : "booked",
      "serviceCategory" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/service-category",
          "version" : "1.1.1",
          "code" : "8",
          "display" : "Counselling"
        }]
      }],
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "13645005",
          "display" : "Chronic obstructive lung disease"
        }],
        "text" : "Televisita pneumologica per follow-up bronchite cronica"
      }],
      "start" : "2025-06-16T09:00:00+02:00",
      "end" : "2025-06-16T09:45:00+02:00",
      "created" : "2025-06-02T09:00:00+02:00",
      "basedOn" : [{
        "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
      }],
      "participant" : [{
        "actor" : {
          "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
        },
        "status" : "accepted"
      },
      {
        "actor" : {
          "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
        },
        "status" : "accepted"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Appointment"
    }
  },
  {
    "fullUrl" : "http://example/AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "1360bd6a-3855-48d3-aa33-96a9d961bb94",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_1360bd6a-3855-48d3-aa33-96a9d961bb94\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AllergyIntolerance 1360bd6a-3855-48d3-aa33-96a9d961bb94</b></p><a name=\"1360bd6a-3855-48d3-aa33-96a9d961bb94\"> </a><a name=\"hc1360bd6a-3855-48d3-aa33-96a9d961bb94\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-AllergyIntoleranceTelevisita.html\">AllergyIntolerance Televisita</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 91936005}\">Allergy to penicillin</span></p><p><b>patient</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "91936005",
          "display" : "Allergy to penicillin"
        }]
      },
      "patient" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "AllergyIntolerance"
    }
  },
  {
    "fullUrl" : "http://example/MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "e62c9f1d-9c0b-4433-853b-06ec5074f19a",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_e62c9f1d-9c0b-4433-853b-06ec5074f19a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement e62c9f1d-9c0b-4433-853b-06ec5074f19a</b></p><a name=\"e62c9f1d-9c0b-4433-853b-06ec5074f19a\"> </a><a name=\"hce62c9f1d-9c0b-4433-853b-06ec5074f19a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MedicationStatementTelevisita.html\">MedicationStatement Televisita</a></p></div><p><b>status</b>: Active</p><p><b>medication</b>: <span title=\"Codes:{http://www.whocc.no/atc R03BA01}\">Beclometasone 100 mcg spray inalatorio</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>context</b>: <a href=\"Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.html\">Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --&gt; 2025-06-16 09:45:00+0200</a></p><p><b>effective</b>: 2025-01-10 --&gt; 2025-06-16</p><p><b>dateAsserted</b>: 2025-06-16</p><p><b>informationSource</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>reasonCode</b>: <span title=\"Codes:\">Bronchite cronica - terapia inalatoria di mantenimento</span></p><blockquote><p><b>dosage</b></p><p><b>text</b>: 2 inalazioni da 100 mcg due volte al giorno</p><p><b>route</b>: <span title=\"Codes:{http://snomed.info/sct 26643006}\">Oral route</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>100 mcg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeug = 'ug')</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://www.whocc.no/atc",
          "code" : "R03BA01",
          "display" : "beclometasone"
        }],
        "text" : "Beclometasone 100 mcg spray inalatorio"
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "context" : {
        "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
      },
      "effectivePeriod" : {
        "start" : "2025-01-10",
        "end" : "2025-06-16"
      },
      "dateAsserted" : "2025-06-16",
      "informationSource" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "reasonCode" : [{
        "text" : "Bronchite cronica - terapia inalatoria di mantenimento"
      }],
      "dosage" : [{
        "text" : "2 inalazioni da 100 mcg due volte al giorno",
        "route" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "26643006",
            "display" : "Oral route"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 100,
            "unit" : "mcg",
            "system" : "http://unitsofmeasure.org",
            "code" : "ug"
          }
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationStatement"
    }
  },
  {
    "fullUrl" : "http://example/MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "9282eb8d-b153-451a-bd0d-437efd13b45f",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_9282eb8d-b153-451a-bd0d-437efd13b45f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest 9282eb8d-b153-451a-bd0d-437efd13b45f</b></p><a name=\"9282eb8d-b153-451a-bd0d-437efd13b45f\"> </a><a name=\"hc9282eb8d-b153-451a-bd0d-437efd13b45f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-MedicationRequestTelevisita.html\">MedicationRequest Televisita</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Proposal</p><p><b>medication</b>: <span title=\"Codes:{http://www.whocc.no/atc R05CB01}\">N-acetilcisteina 600 mg granulato effervescente</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>authoredOn</b>: 2025-06-16</p><p><b>requester</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>1 bustina da 600 mg una volta al giorno, discolta in acqua</td></tr></table></div>"
      },
      "status" : "active",
      "intent" : "proposal",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://www.whocc.no/atc",
          "code" : "R05CB01",
          "display" : "acetylcysteine"
        }],
        "text" : "N-acetilcisteina 600 mg granulato effervescente"
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "authoredOn" : "2025-06-16",
      "requester" : {
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      },
      "dosageInstruction" : [{
        "text" : "1 bustina da 600 mg una volta al giorno, discolta in acqua"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationRequest"
    }
  },
  {
    "fullUrl" : "http://example/Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "b81d2c4e-5a9f-4c97-90fb-2a3b726b123f",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_b81d2c4e-5a9f-4c97-90fb-2a3b726b123f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure b81d2c4e-5a9f-4c97-90fb-2a3b726b123f</b></p><a name=\"b81d2c4e-5a9f-4c97-90fb-2a3b726b123f\"> </a><a name=\"hcb81d2c4e-5a9f-4c97-90fb-2a3b726b123f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ProcedureTelevisita.html\">Procedure Televisita</a></p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.html\">ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione 22}\">Pneumologia</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.it/fhir/televisita/CodeSystem/CodesystemCatalogoNazionalePrestazioni 89.01.L}\">VISITA PNEUMOLOGICA DI CONTROLLO. Incluso: eventuale rilevazione incruenta della saturazione arteriosa</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>encounter</b>: <a href=\"Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.html\">Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --&gt; 2025-06-16 09:45:00+0200</a></p><p><b>performed</b>: 2025-06-16 09:00:00+0200 --&gt; 2025-06-16 09:45:00+0200</p><p><b>recorder</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Function</b></td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 41672002}\">Pulmonologist</span></td><td><a href=\"PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.html\">PractitionerRole: specialty = Pneumologia</a></td></tr></table><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 13645005}\">Chronic obstructive lung disease</span></p><p><b>outcome</b>: <span title=\"Codes:\">Il paziente ha riportato lieve miglioramento della sintomatologia respiratoria. Terapia inalatoria confermata. Indicata spirometria di controllo tra 3 mesi.</span></p><p><b>report</b>: <a href=\"Composition-aa011502-6ad2-430b-a439-01dddc36fd4e.html\">Composition Referto di Televisita</a></p><p><b>note</b>: </p><blockquote><div><p>Televisita eseguita tramite piattaforma XTelemed. Durata 45 minuti.</p>\n</div></blockquote></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione",
          "code" : "22",
          "display" : "Pneumologia"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://hl7.it/fhir/televisita/CodeSystem/CodesystemCatalogoNazionalePrestazioni",
          "code" : "89.01.L",
          "display" : "VISITA PNEUMOLOGICA DI CONTROLLO. Incluso: eventuale rilevazione incruenta della saturazione arteriosa"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "encounter" : {
        "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
      },
      "performedPeriod" : {
        "start" : "2025-06-16T09:00:00+02:00",
        "end" : "2025-06-16T09:45:00+02:00"
      },
      "recorder" : {
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      },
      "performer" : [{
        "function" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "41672002",
            "display" : "Pulmonologist"
          }]
        },
        "actor" : {
          "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
        }
      }],
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "13645005",
          "display" : "Chronic obstructive lung disease"
        }]
      }],
      "outcome" : {
        "text" : "Il paziente ha riportato lieve miglioramento della sintomatologia respiratoria. Terapia inalatoria confermata. Indicata spirometria di controllo tra 3 mesi."
      },
      "report" : [{
        "reference" : "Composition/aa011502-6ad2-430b-a439-01dddc36fd4e"
      }],
      "note" : [{
        "text" : "Televisita eseguita tramite piattaforma XTelemed. Durata 45 minuti."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "http://example/Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "7cbbe77d-dcdb-409b-a215-6361ad7873d5",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_7cbbe77d-dcdb-409b-a215-6361ad7873d5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 7cbbe77d-dcdb-409b-a215-6361ad7873d5</b></p><a name=\"7cbbe77d-dcdb-409b-a215-6361ad7873d5\"> </a><a name=\"hc7cbbe77d-dcdb-409b-a215-6361ad7873d5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisita.html\">Observation Televisita</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29299-5}\">Reason for visit Narrative</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Controllo post-COVID per tosse persistente (ICD-9: 786.2)</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29299-5",
          "display" : "Reason for visit Narrative"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Controllo post-COVID per tosse persistente (ICD-9: 786.2)"
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "84f911ee-b09d-4325-a3f3-a973a0c5ad8f",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_84f911ee-b09d-4325-a3f3-a973a0c5ad8f\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 84f911ee-b09d-4325-a3f3-a973a0c5ad8f</b></p><a name=\"84f911ee-b09d-4325-a3f3-a973a0c5ad8f\"> </a><a name=\"hc84f911ee-b09d-4325-a3f3-a973a0c5ad8f\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11329-0}\">History general Narrative - Reported</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Paziente con anamnesi positiva per bronchite cronica, non fumatore.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11329-0"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Paziente con anamnesi positiva per bronchite cronica, non fumatore."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865</b></p><a name=\"c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865\"> </a><a name=\"hcc2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29545-1}\">Physical findings note</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Durante la conversazione si rileva tosse secca intermittente.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29545-1"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Durante la conversazione si rileva tosse secca intermittente."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "9dfdf0c9-a837-42d5-987c-6170c75cc476",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_9dfdf0c9-a837-42d5-987c-6170c75cc476\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 9dfdf0c9-a837-42d5-987c-6170c75cc476</b></p><a name=\"9dfdf0c9-a837-42d5-987c-6170c75cc476\"> </a><a name=\"hc9dfdf0c9-a837-42d5-987c-6170c75cc476\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 30954-2}\">Relevant diagnostic tests/laboratory data note</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 24627-2}\">CT Chest</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: TC torace eseguita il 10/05/2025. Referto: negativa per lesioni polmonari evolutive, lieve ispessimento peribronchiale compatibile con bronchite cronica.</p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "30954-2",
          "display" : "Relevant diagnostic tests/laboratory data note"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "24627-2",
          "display" : "CT Chest"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "TC torace eseguita il 10/05/2025. Referto: negativa per lesioni polmonari evolutive, lieve ispessimento peribronchiale compatibile con bronchite cronica."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "ecc5c95f-a1c0-483c-b48e-5fd84762c393",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_ecc5c95f-a1c0-483c-b48e-5fd84762c393\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation ecc5c95f-a1c0-483c-b48e-5fd84762c393</b></p><a name=\"ecc5c95f-a1c0-483c-b48e-5fd84762c393\"> </a><a name=\"hcecc5c95f-a1c0-483c-b48e-5fd84762c393\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 93126-1}\">Comparison with previous results</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Rispetto al controllo precedente, lieve miglioramento del quadro bronchiolitico.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "93126-1"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Rispetto al controllo precedente, lieve miglioramento del quadro bronchiolitico."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "a465cf01-05e6-4f38-8f6a-b5d6c4168c94",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_a465cf01-05e6-4f38-8f6a-b5d6c4168c94\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation a465cf01-05e6-4f38-8f6a-b5d6c4168c94</b></p><a name=\"a465cf01-05e6-4f38-8f6a-b5d6c4168c94\"> </a><a name=\"hca465cf01-05e6-4f38-8f6a-b5d6c4168c94\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisita.html\">Observation Televisita</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 47045-0}\">Study report</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Referto di televisita pneumologica: sintomi in miglioramento, non si evidenziano complicanze.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "47045-0"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Referto di televisita pneumologica: sintomi in miglioramento, non si evidenziano complicanze."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1729dcef-ac19-434b-82e7-b6e6e51e74b3",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_1729dcef-ac19-434b-82e7-b6e6e51e74b3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 1729dcef-ac19-434b-82e7-b6e6e51e74b3</b></p><a name=\"1729dcef-ac19-434b-82e7-b6e6e51e74b3\"> </a><a name=\"hc1729dcef-ac19-434b-82e7-b6e6e51e74b3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisita.html\">Observation Televisita</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29548-5}\">Diagnosis Narrative</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Bronchite cronica mucopurulenta (ICD-9: 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente), assenza di segni di riacutizzazione e buona risposta alla terapia inalatoria in corso.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29548-5",
          "display" : "Diagnosis Narrative"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Bronchite cronica mucopurulenta (ICD-9: 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente), assenza di segni di riacutizzazione e buona risposta alla terapia inalatoria in corso."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/1611ed98-7577-48ab-9587-7ab4fc96e191",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1611ed98-7577-48ab-9587-7ab4fc96e191",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_1611ed98-7577-48ab-9587-7ab4fc96e191\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 1611ed98-7577-48ab-9587-7ab4fc96e191</b></p><a name=\"1611ed98-7577-48ab-9587-7ab4fc96e191\"> </a><a name=\"hc1611ed98-7577-48ab-9587-7ab4fc96e191\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 55110-1}\">Conclusions [Interpretation] Document</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Buona risposta al trattamento inalatorio. Monitoraggio consigliato.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55110-1"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Buona risposta al trattamento inalatorio. Monitoraggio consigliato."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/2054e65c-2012-4286-aac7-ce2f23e8be31",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "2054e65c-2012-4286-aac7-ce2f23e8be31",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_2054e65c-2012-4286-aac7-ce2f23e8be31\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 2054e65c-2012-4286-aac7-ce2f23e8be31</b></p><a name=\"2054e65c-2012-4286-aac7-ce2f23e8be31\"> </a><a name=\"hc2054e65c-2012-4286-aac7-ce2f23e8be31\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisitaNarrative.html\">Observation Televisita Narrative</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 62385-0}\">Recommendation [Interpretation] Document</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Valutare spirometria di controllo tra 3 mesi.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "62385-0"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Valutare spirometria di controllo tra 3 mesi."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "http://example/Observation/1b401b53-f564-4730-bb13-45d5620596f0",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "1b401b53-f564-4730-bb13-45d5620596f0",
      "meta" : {
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_1b401b53-f564-4730-bb13-45d5620596f0\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation 1b401b53-f564-4730-bb13-45d5620596f0</b></p><a name=\"1b401b53-f564-4730-bb13-45d5620596f0\"> </a><a name=\"hc1b401b53-f564-4730-bb13-45d5620596f0\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ObservationTelevisita.html\">Observation Televisita</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80615-8}\">Recommended follow-up [Identifier] Narrative</span></p><p><b>subject</b>: <a href=\"Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.html\">Maria Rossi  Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)</a></p><p><b>effective</b>: 2025-06-16 10:30:00+0200</p><p><b>performer</b>: <a href=\"Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.html\">Practitioner Marco Ferrari </a></p><p><b>value</b>: Controllo emogasanalisi a domicilio.</p></div>"
      },
      "status" : "final",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80615-8"
        }]
      },
      "subject" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
      "performer" : [{
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      }],
      "valueString" : "Controllo emogasanalisi a domicilio."
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  }]
}

```
