# Encounter Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter Televisita**

## Resource Profile: Encounter Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:EncounterTelevisita |

 
Profilo della risorsa Encounter utilizzato per rappresentare la visita di telemedicina, incluse informazioni sulla modalità, la disciplina specialistica, i partecipanti e i riferimenti all'appuntamento e alla richiesta di servizio. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md) and [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md)
* Examples for this Profile: [Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-EncounterTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-EncounterTelevisita.csv), [Excel](StructureDefinition-EncounterTelevisita.xlsx), [Schematron](StructureDefinition-EncounterTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "EncounterTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita",
  "version" : "0.2.0",
  "name" : "EncounterTelevisita",
  "title" : "Encounter Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Encounter utilizzato per rappresentare la visita di telemedicina, incluse informazioni sulla modalità, la disciplina specialistica, i partecipanti e i riferimenti all'appuntamento e alla richiesta di servizio.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Encounter",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Encounter",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Encounter",
      "path" : "Encounter",
      "short" : "Visita di telemedicina (televisita).",
      "definition" : "Rappresenta l'evento di visita specialistica effettuato in modalità remota, comprensivo di informazioni sulla disciplina, la struttura erogante, i professionisti coinvolti e il periodo di erogazione."
    },
    {
      "id" : "Encounter.identifier",
      "path" : "Encounter.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Encounter.identifier:codiceNosologico",
      "path" : "Encounter.identifier",
      "sliceName" : "codiceNosologico",
      "short" : "Codice nosologico dell'incontro.",
      "definition" : "Identificativo univoco dell'incontro di telemedicina nel sistema informativo della struttura erogante (numero di accettazione, codice nosologico).",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Encounter.identifier:codiceNosologico.system",
      "path" : "Encounter.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/fhir/televisita/sid/codiceNosologico"
    },
    {
      "id" : "Encounter.status",
      "path" : "Encounter.status",
      "short" : "Stato attuale dell'incontro.",
      "definition" : "Stato attuale dell'incontro. Possibili valori: planned | arrived | triaged | in-progress | onleave | finished | cancelled"
    },
    {
      "id" : "Encounter.class",
      "path" : "Encounter.class",
      "short" : "Classificazione dell'incontro con il paziente.",
      "definition" : "Classificazione dell'incontro clinico. Nel contesto della telemedicina i valori ammessi sono 'VR' (virtual) per la visita da remoto e 'HH' (home health) per l'assistenza domiciliare.",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VsClassEncounterTelevisita"
      }
    },
    {
      "id" : "Encounter.type",
      "path" : "Encounter.type",
      "short" : "Disciplina specialistica della televisita.",
      "definition" : "Indica la branca specialistica nell'ambito della quale viene erogata la televisita (es. cardiologia, neurologia, dermatologia). Il valore è vincolato al ValueSet delle specialità ambulatoriali.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vsspecialityPractitionerRole"
      }
    },
    {
      "id" : "Encounter.serviceType",
      "path" : "Encounter.serviceType",
      "short" : "Tipologia di servizio erogato.",
      "definition" : "Identifica il servizio sanitario erogato durante l'incontro, ad esempio televisita specialistica, visita di controllo o follow-up.",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/specialita-mediche"
      }
    },
    {
      "id" : "Encounter.priority",
      "path" : "Encounter.priority",
      "short" : "Priorità della richiesta.",
      "definition" : "Priorità della richiesta."
    },
    {
      "id" : "Encounter.subject",
      "path" : "Encounter.subject",
      "short" : "Paziente coinvolto nell'incontro.",
      "definition" : "Riferimento all'assistito che è oggetto della televisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "Encounter.episodeOfCare",
      "path" : "Encounter.episodeOfCare",
      "short" : "Percorso assistenziale di riferimento.",
      "definition" : "Riferimento all'episodio di cura o al percorso assistenziale nel quale la televisita è inserita."
    },
    {
      "id" : "Encounter.basedOn",
      "path" : "Encounter.basedOn",
      "short" : "Richiesta che ha avviato la visita.",
      "definition" : "La richiesta di servizio (ServiceRequest) che questa visita soddisfa.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
      }]
    },
    {
      "id" : "Encounter.participant",
      "path" : "Encounter.participant",
      "short" : "Altre figure tecniche coinvolte.",
      "definition" : "BackboneElement contenente la lista dei coinvolti nella visita oltre al Patient.",
      "comment" : "In participant.individual può essere inserito il riferimento al Practitioner o al PractitionerRole che prende in carico la visita."
    },
    {
      "id" : "Encounter.participant.type",
      "path" : "Encounter.participant.type",
      "short" : "Ruolo del partecipante.",
      "definition" : "Specifica il ruolo ricoperto dal partecipante durante la televisita (es. medico specialista, infermiere, caregiver)."
    },
    {
      "id" : "Encounter.participant.period",
      "path" : "Encounter.participant.period",
      "short" : "Periodo di partecipazione.",
      "definition" : "Intervallo temporale durante il quale il partecipante ha preso parte alla televisita."
    },
    {
      "id" : "Encounter.participant.individual",
      "path" : "Encounter.participant.individual",
      "short" : "Professionista sanitario partecipante.",
      "definition" : "Professionista sanitario che ha preso parte alla televisita in qualità di medico specialista o altro operatore.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Encounter.appointment",
      "path" : "Encounter.appointment",
      "short" : "Appuntamento da cui è partita l'incontro.",
      "definition" : "L'appuntamento prenotato da cui ha avuto origine questa televisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita"]
      }]
    },
    {
      "id" : "Encounter.period",
      "path" : "Encounter.period",
      "short" : "Data e ora di inizio e di fine dell'incontro.",
      "definition" : "Intervallo temporale che indica l'inizio e la fine effettiva della televisita.",
      "comment" : "Se non è (ancora) nota, la fine del Periodo può essere omessa."
    },
    {
      "id" : "Encounter.reasonCode",
      "path" : "Encounter.reasonCode",
      "short" : "Motivazione clinica della televisita.",
      "definition" : "Descrive il quesito clinico, il motivo della visita o la problematica sanitaria che ha determinato l'erogazione della televisita."
    },
    {
      "id" : "Encounter.reasonReference",
      "path" : "Encounter.reasonReference",
      "short" : "Motivo scatenante l'incontro (Procedure).",
      "definition" : "Riferimento alla Procedure che ha motivato o è correlata all'incontro di telemedicina.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
      }]
    },
    {
      "id" : "Encounter.diagnosis",
      "path" : "Encounter.diagnosis",
      "short" : "Diagnosi associate all'incontro.",
      "definition" : "Elenco delle diagnosi formulate, confermate o rivalutate nel corso della televisita."
    },
    {
      "id" : "Encounter.diagnosis.condition",
      "path" : "Encounter.diagnosis.condition",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition"]
      }]
    },
    {
      "id" : "Encounter.hospitalization",
      "path" : "Encounter.hospitalization",
      "max" : "0"
    },
    {
      "id" : "Encounter.serviceProvider",
      "path" : "Encounter.serviceProvider",
      "short" : "Organizzazione che eroga il servizio.",
      "definition" : "Riferimento alla struttura sanitaria (OrganizationT1) che eroga la televisita, intesa come poliambulatorio o unità organizzativa responsabile.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
      }]
    }]
  }
}

```
