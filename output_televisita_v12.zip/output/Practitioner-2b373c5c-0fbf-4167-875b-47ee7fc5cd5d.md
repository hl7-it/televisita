# Specialista - Dr. Marco Ferrari - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Specialista - Dr. Marco Ferrari**

## Example Practitioner: Specialista - Dr. Marco Ferrari

Profile: [Practitioner Televisita](StructureDefinition-PractitionerTelevisita.md)

**identifier**: `http://hl7.it/sid/codiceFiscale`/FRRMRC75T10H501K

**name**: Marco Ferrari 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "2b373c5c-0fbf-4167-875b-47ee7fc5cd5d",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
  },
  "identifier" : [{
    "system" : "http://hl7.it/sid/codiceFiscale",
    "value" : "FRRMRC75T10H501K"
  }],
  "name" : [{
    "family" : "Ferrari",
    "given" : ["Marco"]
  }]
}

```
