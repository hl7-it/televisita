# Presidio Sandro Pertini - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presidio Sandro Pertini**

## Example Organization: Presidio Sandro Pertini

Profile: [Organization T2 - Presidio / Ospedale](StructureDefinition-OrganizationT2.md)

**identifier**: `http://hl7.it/sid/hsp`/HSP00123

**name**: Ospedale Sandro Pertini

**partOf**: [Organization ASL Roma 1](Organization-asl-roma-1.md)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "osp-pertini",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2"]
  },
  "identifier" : [{
    "system" : "http://hl7.it/sid/hsp",
    "value" : "HSP00123"
  }],
  "name" : "Ospedale Sandro Pertini",
  "partOf" : {
    "reference" : "Organization/asl-roma-1"
  }
}

```
