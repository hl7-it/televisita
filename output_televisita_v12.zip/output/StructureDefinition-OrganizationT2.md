# Organization T2 - Presidio / Ospedale - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization T2 - Presidio / Ospedale**

## Resource Profile: Organization T2 - Presidio / Ospedale 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2 | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:OrganizationT2 |

 
Profilo della risorsa Organization di tipo 2, utilizzato per rappresentare i presidi ospedalieri, i distretti sanitari e le strutture di secondo livello nel contesto della telemedicina. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [Organization T3 - Unità Operativa / Ambulatorio](StructureDefinition-OrganizationT3.md)
* Examples for this Profile: [Ospedale Sandro Pertini](Organization-osp-pertini.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-OrganizationT2.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-OrganizationT2.csv), [Excel](StructureDefinition-OrganizationT2.xlsx), [Schematron](StructureDefinition-OrganizationT2.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "OrganizationT2",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2",
  "version" : "0.2.0",
  "name" : "OrganizationT2",
  "title" : "Organization T2 - Presidio / Ospedale",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Organization di tipo 2, utilizzato per rappresentare i presidi ospedalieri, i distretti sanitari e le strutture di secondo livello nel contesto della telemedicina.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Organization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Organization",
      "path" : "Organization",
      "short" : "Presidio ospedaliero o struttura di secondo livello.",
      "definition" : "Rappresenta un presidio ospedaliero, distretto sanitario o altra struttura di secondo livello che eroga la televisita nell'ambito dell'azienda sanitaria (OrganizationT1)."
    },
    {
      "id" : "Organization.identifier",
      "path" : "Organization.identifier",
      "short" : "Codice del presidio.",
      "definition" : "Identificativi di Organization usati per identificare l'Organization su diversi sistemi.",
      "min" : 1
    },
    {
      "id" : "Organization.active",
      "path" : "Organization.active",
      "short" : "Stato di validità del presidio.",
      "definition" : "Indica se il presidio ospedaliero o la struttura sanitaria è attiva e disponibile per l'erogazione di prestazioni sanitarie, incluse le televisite."
    },
    {
      "id" : "Organization.type",
      "path" : "Organization.type",
      "short" : "Tipo di organizzazione.",
      "definition" : "Il tipo di organizzazione di cui si tratta.",
      "comment" : "Le organizzazioni possono essere di diversi tipi.",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/organization-type"
      }
    },
    {
      "id" : "Organization.name",
      "path" : "Organization.name",
      "short" : "Nome dell'organizzazione.",
      "definition" : "Denominazione ufficiale del presidio ospedaliero o della struttura di secondo livello."
    },
    {
      "id" : "Organization.alias",
      "path" : "Organization.alias",
      "short" : "Denominazioni alternative del presidio.",
      "definition" : "Eventuali denominazioni alternative, sigle o nomi con cui il presidio è comunemente identificato."
    },
    {
      "id" : "Organization.telecom",
      "path" : "Organization.telecom",
      "short" : "Recapiti del presidio.",
      "definition" : "Recapiti telefonici, indirizzi e-mail o altri contatti elettronici del presidio ospedaliero."
    },
    {
      "id" : "Organization.address.city",
      "path" : "Organization.address.city",
      "short" : "Comune."
    },
    {
      "id" : "Organization.address.district",
      "path" : "Organization.address.district",
      "short" : "Nome della provincia."
    },
    {
      "id" : "Organization.address.state",
      "path" : "Organization.address.state",
      "short" : "Sotto-unità dello stato (Regione)."
    },
    {
      "id" : "Organization.partOf",
      "path" : "Organization.partOf",
      "short" : "Azienda sanitaria (T1) di cui questo presidio fa parte.",
      "definition" : "Riferimento all'azienda sanitaria (OrganizationT1) alla quale appartiene il presidio ospedaliero o la struttura di secondo livello.",
      "comment" : "Tale reference assume rilevanza in caso di Organization di tipo poliambulatorio, che è parte di una Organization di tipo asl: in questo caso si può ricorrere ad una reference di tipo logico."
    },
    {
      "id" : "Organization.contact",
      "path" : "Organization.contact",
      "short" : "Referenti del presidio.",
      "definition" : "Informazioni di contatto relative ai referenti amministrativi o sanitari del presidio."
    }]
  }
}

```
