# Observation Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation Televisita**

## Resource Profile: Observation Televisita ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ObservationTelevisita |

 
Profilo della risorsa Observation utilizzato per rappresentare parametri clinici, misurazioni e osservazioni rilevate nel contesto della televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md) and [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md)
* Examples for this Profile: [Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3](Observation-1729dcef-ac19-434b-82e7-b6e6e51e74b3.md), [Observation/1b401b53-f564-4730-bb13-45d5620596f0](Observation-1b401b53-f564-4730-bb13-45d5620596f0.md), [Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5](Observation-7cbbe77d-dcdb-409b-a215-6361ad7873d5.md) and [Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94](Observation-a465cf01-05e6-4f38-8f6a-b5d6c4168c94.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-ObservationTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ObservationTelevisita.csv), [Excel](StructureDefinition-ObservationTelevisita.xlsx), [Schematron](StructureDefinition-ObservationTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ObservationTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita",
  "version" : "0.2.0",
  "name" : "ObservationTelevisita",
  "title" : "Observation Televisita",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Observation utilizzato per rappresentare parametri clinici, misurazioni e osservazioni rilevate nel contesto della televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "short" : "Parametro clinico o misurazione rilevata durante la televisita.",
      "definition" : "Rappresenta una misurazione, un parametro vitale o un risultato clinico rilevato o comunicato dall'assistito nel corso della televisita."
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "short" : "Stato dell'osservazione.",
      "definition" : "Stato attuale dell'osservazione. I valori possibili includono: registered, preliminary, final, amended, corrected, cancelled, entered-in-error, unknown."
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "short" : "Categoria dell'osservazione.",
      "definition" : "Classifica l'osservazione in una categoria (es. parametri vitali, esame fisico, risultato di laboratorio). Nel contesto della televisita è tipicamente utilizzata per parametri vitali o dati auto-riferiti dall'assistito."
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Codice del parametro osservato.",
      "definition" : "Codice che identifica il tipo di osservazione eseguita (es. pressione arteriosa, frequenza cardiaca, peso corporeo). Preferibilmente espresso con codifica LOINC o SNOMED CT."
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "short" : "Assistito oggetto dell'osservazione.",
      "definition" : "Riferimento all'assistito coinvolto nella televisita per il quale è stata rilevata l'osservazione."
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "short" : "Data e ora di rilevazione del parametro.",
      "definition" : "Data e ora in cui l'osservazione è stata effettuata o a cui si riferisce clinicamente."
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "short" : "Responsabile dell'osservazione.",
      "definition" : "Riferimento al professionista sanitario, all'assistito stesso o al dispositivo che ha effettuato la misurazione. Nel contesto della televisita può trattarsi di un dispositivo medico utilizzato a domicilio dall'assistito."
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "Valore misurato o rilevato.",
      "definition" : "Risultato dell'osservazione espresso come quantità, codice, stringa o altro tipo. Nel contesto della televisita rappresenta il valore del parametro clinico riportato."
    },
    {
      "id" : "Observation.dataAbsentReason",
      "path" : "Observation.dataAbsentReason",
      "short" : "Motivo dell'assenza del valore.",
      "definition" : "Indica il motivo per cui il valore dell'osservazione non è disponibile (es. non rilevato, sconosciuto, errore di strumentazione)."
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "short" : "Interpretazione clinica del valore.",
      "definition" : "Codice che esprime l'interpretazione del valore misurato rispetto ai valori di riferimento (es. normale, alto, basso)."
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "short" : "Note aggiuntive sull'osservazione.",
      "definition" : "Commenti o annotazioni in testo libero relativi all'osservazione, utili a fornire contesto clinico aggiuntivo."
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "short" : "Componenti dell'osservazione (misurazioni multiple).",
      "definition" : "Utilizzato quando l'osservazione è composta da più misurazioni correlate (es. pressione arteriosa sistolica e diastolica). Ogni componente ha il proprio codice e valore."
    },
    {
      "id" : "Observation.component.code",
      "path" : "Observation.component.code",
      "short" : "Codice della componente.",
      "definition" : "Identifica la specifica componente dell'osservazione."
    },
    {
      "id" : "Observation.component.value[x]",
      "path" : "Observation.component.value[x]",
      "short" : "Valore della componente.",
      "definition" : "Risultato numerico o codificato della singola componente dell'osservazione."
    }]
  }
}

```
