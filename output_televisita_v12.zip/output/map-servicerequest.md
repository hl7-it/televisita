# ServiceRequest - Richiesta - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **ServiceRequest - Richiesta**

## ServiceRequest - Richiesta

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR.

Allegato 1 Telemedicina → Richiesta di televisita

 Questa pagina illustra come gli elementi informativi relativi alla richiesta di televisita, previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina", siano rappresentati nel corrispondente profilo FHIR. 

| | | | |
| :--- | :--- | :--- | :--- |
| Cognome medico prescrittore | Cognome del medico prescrittore (medico del ruolo unico di assistenza primaria/PLS o Specialista) | ServiceRequest / PractitionerRole / Practitioner | ServiceRequest.requester.practitioner.name.family |
| Nome medico prescrittore | Nome del medico prescrittore (medico del ruolo unico di assistenza primaria/PLS o Specialista) | ServiceRequest / PractitionerRole / Practitioner | ServiceRequest.requester.practitioner.name.given |
| Codice fiscale medico prescrittore | Codice fiscale del medico prescrittore (medico del ruolo unico di assistenza primaria/PLS o Specialista) | ServiceRequest / PractitionerRole / Practitioner | ServiceRequest.requester.practitioner.identifier |
| Numero ricetta medica | Numero della ricetta medica (NRE) | ServiceRequest | ServiceRequest.requisition |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

