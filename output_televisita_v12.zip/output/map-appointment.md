# Appointment - Appuntamento - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Appointment - Appuntamento**

## Appointment - Appuntamento

Questa pagina descrive la mappatura tra i campi dell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e il corrispondente profilo FHIR.

Allegato 1 Telemedicina → Prenotazione dell'appuntamento

 La risorsa `Appointment` rappresenta la prenotazione dell'appuntamento di televisita, incluse date, partecipanti, categoria del servizio e motivazione clinica. 

**Contesto di mappatura:**
`Appointment`

| | | | |
| :--- | :--- | :--- | :--- |
| Codice prenotazione | Identificativo univoco della prenotazione della televisita | Appointment | `Appointment.identifier.value` |
| Data e ora inizio appuntamento | Data e ora di inizio della televisita | Appointment | `Appointment.start` |
| Data e ora fine appuntamento | Data e ora di conclusione della televisita | Appointment | `Appointment.end` |
| Data creazione prenotazione | Data in cui è stata creata la prenotazione dell'appuntamento | Appointment | `Appointment.created` |
| Categoria servizio | Categorizzazione del servizio erogato durante l'appuntamento (es. branca specialistica) | Appointment | `Appointment.serviceCategory.coding.code` |
| Motivo dell'appuntamento | Motivazione clinica per cui è stato prenotato l'appuntamento di televisita | Appointment | `Appointment.reasonCode.text` |
| Riferimento alla richiesta | Riferimento alla ServiceRequest da cui origina la prenotazione | Appointment | `Appointment.basedOn` |
| Paziente | Riferimento al paziente partecipante all'appuntamento di televisita | Appointment | `Appointment.participant.actor.resolve().ofType(Patient)` |
| Medico specialista | Riferimento al medico specialista (PractitionerRole) partecipante all'appuntamento | Appointment | `Appointment.participant.actor.resolve().ofType(PractitionerRole)` |

 Torna alla panoramica: [Modello di mappatura](modelmap.md) 

