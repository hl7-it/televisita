# Luogo di Nascita - ITA - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Luogo di Nascita - ITA**

## Extension: Luogo di Nascita - ITA 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:BirthPlaceIta |

Estensione utilizzata per rappresentare il luogo di nascita dell'assistito secondo il formato italiano, strutturato come un indirizzo conforme al profilo AddressItTelemedicina. Nel contesto della televisita è rilevante per l'identificazione anagrafica dell'assistito.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Patient Televisita](StructureDefinition-PatientTelevisita.md)
* Examples for this Extension: [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-birth-place-ita.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-birth-place-ita.csv), [Excel](StructureDefinition-birth-place-ita.xlsx), [Schematron](StructureDefinition-birth-place-ita.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "birth-place-ita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita",
  "version" : "0.2.0",
  "name" : "BirthPlaceIta",
  "title" : "Luogo di Nascita - ITA",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Estensione utilizzata per rappresentare il luogo di nascita dell'assistito secondo il formato italiano, strutturato come un indirizzo conforme al profilo AddressItTelemedicina. Nel contesto della televisita è rilevante per l'identificazione anagrafica dell'assistito.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Patient"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Luogo di nascita dell'assistito (formato italiano).",
      "definition" : "Contiene l'indirizzo del luogo di nascita dell'assistito, espresso secondo il profilo AddressItTelemedicina. Include comune, provincia, regione e stato di nascita, utili per l'identificazione anagrafica nel sistema sanitario italiano."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "short" : "Indirizzo del luogo di nascita.",
      "definition" : "Indirizzo strutturato del luogo di nascita, conforme al datatype AddressItTelemedicina. Comprende comune (city), provincia (district), regione (state) e stato (country) di nascita.",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AddressItTelemedicina"]
      }]
    }]
  }
}

```
