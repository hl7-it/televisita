# Organization T1 - Azienda Sanitaria - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization T1 - Azienda Sanitaria**

## Resource Profile: Organization T1 - Azienda Sanitaria 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1 | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:OrganizationT1 |

 
Profilo della risorsa Organization di tipo 1, utilizzato per rappresentare le aziende sanitarie locali (ASL), aziende ospedaliere (AO) e IRCCS nel contesto della telemedicina. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [Encounter Televisita](StructureDefinition-EncounterTelevisita.md), [Patient Televisita](StructureDefinition-PatientTelevisita.md), [PractitionerRoleTelevisita](StructureDefinition-PractitionerRoleTelevisita.md) and [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md)
* Examples for this Profile: [ASL Roma 1](Organization-asl-roma-1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-OrganizationT1.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-OrganizationT1.csv), [Excel](StructureDefinition-OrganizationT1.xlsx), [Schematron](StructureDefinition-OrganizationT1.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "OrganizationT1",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1",
  "version" : "0.2.0",
  "name" : "OrganizationT1",
  "title" : "Organization T1 - Azienda Sanitaria",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Organization di tipo 1, utilizzato per rappresentare le aziende sanitarie locali (ASL), aziende ospedaliere (AO) e IRCCS nel contesto della telemedicina.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Organization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Organization",
      "path" : "Organization",
      "short" : "Azienda sanitaria, AO o IRCCS responsabile della televisita.",
      "definition" : "Rappresenta l'organizzazione sanitaria di primo livello (ASL, AO, IRCCS) che eroga o supervisiona il servizio di televisita. Può contenere riferimenti a strutture di livello inferiore tramite i profili OrganizationT2 e OrganizationT3."
    },
    {
      "id" : "Organization.identifier",
      "path" : "Organization.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "value"
        },
        {
          "type" : "pattern",
          "path" : "system"
        }],
        "description" : "Slice based on the identifier pattern",
        "rules" : "open"
      },
      "short" : "Identificativo dell'organizzazione.",
      "definition" : "Identificativi di Organization usati per identificare l'Organization su diversi sistemi",
      "min" : 1
    },
    {
      "id" : "Organization.identifier:asl",
      "path" : "Organization.identifier",
      "sliceName" : "asl",
      "short" : "Identificativo Azienda Sanitaria Locale",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:asl.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/fls"
    },
    {
      "id" : "Organization.identifier:asl.value",
      "path" : "Organization.identifier.value",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/minsan-asl"
      }
    },
    {
      "id" : "Organization.identifier:aslRegione",
      "path" : "Organization.identifier",
      "sliceName" : "aslRegione",
      "short" : "Identificativo Regionale Azienda Sanitaria Locale",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:aslRegione.value",
      "path" : "Organization.identifier.value",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vs-anagrafi-regionali"
      }
    },
    {
      "id" : "Organization.identifier:aziendaOspedaliera",
      "path" : "Organization.identifier",
      "sliceName" : "aziendaOspedaliera",
      "short" : "Identificativo Azienda Ospedaliera",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:aziendaOspedaliera.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/hsp"
    },
    {
      "id" : "Organization.identifier:aziendaOspedaliera.value",
      "path" : "Organization.identifier.value",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/minsan-idAziendeOspedaliere"
      }
    },
    {
      "id" : "Organization.identifier:struttura",
      "path" : "Organization.identifier",
      "sliceName" : "struttura",
      "short" : "Identificativo Struttura di Ricovero",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:struttura.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/hsp"
    },
    {
      "id" : "Organization.identifier:struttura.value",
      "path" : "Organization.identifier.value",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/minsan-idStrutture"
      }
    },
    {
      "id" : "Organization.identifier:partitaIva",
      "path" : "Organization.identifier",
      "sliceName" : "partitaIva",
      "short" : "Partita IVA Organizzazione",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:partitaIva.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/partitaIva"
    },
    {
      "id" : "Organization.identifier:codiceFiscale",
      "path" : "Organization.identifier",
      "sliceName" : "codiceFiscale",
      "short" : "Codice Fiscale Organizzazione",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:codiceFiscale.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/codiceFiscale"
    },
    {
      "id" : "Organization.identifier:strutturaInterna",
      "path" : "Organization.identifier",
      "sliceName" : "strutturaInterna",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Organization.identifier:strutturaInterna.system",
      "path" : "Organization.identifier.system",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/hsp"
    },
    {
      "id" : "Organization.identifier:strutturaInterna.value",
      "path" : "Organization.identifier.value",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/minsan-idStruttureInterne"
      }
    },
    {
      "id" : "Organization.type",
      "path" : "Organization.type",
      "short" : "Tipo di organizzazione",
      "definition" : "Il tipo di organizzazione di cui si tratta",
      "comment" : "Le organizzazioni possono essere di diversi tipi"
    },
    {
      "id" : "Organization.name",
      "path" : "Organization.name",
      "short" : "Nome dell'organizzazione.",
      "definition" : "Descrizione della Organization"
    },
    {
      "id" : "Organization.telecom",
      "path" : "Organization.telecom",
      "short" : "Recapiti telefonici o elettronici dell'organizzazione.",
      "definition" : "Numeri di telefono, indirizzi e-mail o altri recapiti elettronici dell'organizzazione sanitaria."
    },
    {
      "id" : "Organization.address.city",
      "path" : "Organization.address.city",
      "short" : "Comune"
    },
    {
      "id" : "Organization.address.district",
      "path" : "Organization.address.district",
      "short" : "Nome della provincia"
    },
    {
      "id" : "Organization.address.state",
      "path" : "Organization.address.state",
      "short" : "Sotto-unità dello stato (Regione)."
    },
    {
      "id" : "Organization.partOf",
      "path" : "Organization.partOf",
      "short" : "Organizzazione gerarchicamente superiore.",
      "definition" : "L'organizzazione di cui questa è parte. Assume rilevanza in caso di struttura che è parte di un'ASL, consentendo di risalire alla gerarchia organizzativa.",
      "comment" : "Tale reference assume rilevanza in caso di Organization di tipo poliambulatorio, che è parte di una Organization di tipo asl: in questo caso si può ricorrere ad una reference di tipo logico"
    },
    {
      "id" : "Organization.contact",
      "path" : "Organization.contact",
      "short" : "Recapiti dell'organizzazione.",
      "definition" : "Informazioni di contatto dell'azienda sanitaria, inclusi numeri di telefono del CUP, indirizzi e-mail istituzionali e altri recapiti."
    }]
  }
}

```
