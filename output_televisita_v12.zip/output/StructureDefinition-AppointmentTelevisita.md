# AppointmentTelevisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AppointmentTelevisita**

## Resource Profile: AppointmentTelevisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:AppointmentTelevisita |

 
Profilo base del Appointment condiviso in tutti i documenti di Telemedicina 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md)
* Refer to this Profile: [Encounter Televisita](StructureDefinition-EncounterTelevisita.md)
* Examples for this Profile: [Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908](Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-AppointmentTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-AppointmentTelevisita.csv), [Excel](StructureDefinition-AppointmentTelevisita.xlsx), [Schematron](StructureDefinition-AppointmentTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "AppointmentTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita",
  "version" : "0.2.0",
  "name" : "AppointmentTelevisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo base del Appointment condiviso in tutti i documenti di Telemedicina",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "ical",
    "uri" : "http://ietf.org/rfc/2445",
    "name" : "iCalendar"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Appointment",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Appointment",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Appointment",
      "path" : "Appointment"
    },
    {
      "id" : "Appointment.identifier",
      "path" : "Appointment.identifier",
      "short" : "Codice della prenotazione",
      "definition" : "Elemento di tipo identifier contenente gli identificativi univoci della risorsa.",
      "min" : 1
    },
    {
      "id" : "Appointment.serviceCategory",
      "path" : "Appointment.serviceCategory",
      "short" : "Categorizzazione del servizio erogato durante l'appuntamento.",
      "definition" : "Categorizzazione del servizio erogato durante l'appuntamento."
    },
    {
      "id" : "Appointment.reasonCode",
      "path" : "Appointment.reasonCode",
      "short" : "Motivo dell'appuntamento.",
      "definition" : "Elemento di tipo CodableConcept che contiene l'informazione per cui nasce l'Appointment."
    },
    {
      "id" : "Appointment.start",
      "path" : "Appointment.start",
      "short" : "Data e ora di inizio dell'appuntamento.",
      "definition" : "Contiene la data dell'appuntamento.",
      "comment" : "Nota: questa opzione è destinata ai casi in cui è necessario osservare con precisione gli orari, tipicamente i log di sistema e così via, e non gli orari riferiti dall'uomo; per questi ultimi, vedere date e dateTime (che può essere preciso come un istante, ma non è necessario che lo sia). Il fuso orario è sempre richiesto"
    },
    {
      "id" : "Appointment.end",
      "path" : "Appointment.end",
      "short" : "Data e ora di fine dell'appuntamento",
      "definition" : "Data/ora in cui l'appuntamento si conclude.  Le date possono essere omesse in caso di status proposed o cancelled.",
      "comment" : "Nota: questa opzione è destinata ai casi in cui è necessario osservare con precisione gli orari, tipicamente i log di sistema e così via, e non gli orari riferiti dall'uomo; per questi ultimi, vedere date e dateTime (che può essere preciso come un istante, ma non è necessario che lo sia). Il fuso orario è sempre richiesto"
    },
    {
      "id" : "Appointment.created",
      "path" : "Appointment.created",
      "short" : "Data di creazione dell'appuntamento.",
      "definition" : "Elemento di tipo dateTime che contiene la data di creazione iniziale dell'appuntamento",
      "comment" : "Questa proprietà è necessaria per molti casi d'uso in cui l'età di un appuntamento viene considerata nell'elaborazione dei flussi di lavoro per la programmazione e la fatturazione degli appuntamenti."
    },
    {
      "id" : "Appointment.basedOn",
      "path" : "Appointment.basedOn",
      "short" : "La richiesta di servizio per la quale viene assegnato questo appuntamento",
      "definition" : "La richiesta di servizio per la quale è stato assegnato l'appuntamento (ad es. richiesta di referto o di procedura in arrivo).",
      "comment" : "I riferimenti DEVONO essere un riferimento a una risorsa FHIR effettiva e DEVONO essere risolvibili (consentendo il controllo dell'accesso, la temporanea indisponibilità, ecc.) La risoluzione può avvenire tramite recupero dall'URL o, se applicabile per tipo di risorsa, trattando un riferimento assoluto come un URL canonico e cercandolo in un registro/repository locale.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
      }]
    },
    {
      "id" : "Appointment.participant",
      "path" : "Appointment.participant",
      "short" : "Partecipanti coinvolti nell'appuntamento.",
      "definition" : "BackboneElement contenente la lista dei coinvolti nella visita (Patient e PractitionerRole)."
    },
    {
      "id" : "Appointment.participant.actor",
      "path" : "Appointment.participant.actor",
      "short" : "Partecipanti all'appuntamento per la richiesta di televisita.",
      "definition" : "Contiene il riferimento ai Practitioner che prendono in carico la visita e al Patient oggetto della visita.",
      "comment" : "I riferimenti DEVONO essere un riferimento a una risorsa FHIR effettiva e DEVONO essere risolvibili (consentendo il controllo dell'accesso, la non disponibilità temporanea, ecc.) La risoluzione può avvenire tramite recupero dall'URL o, se applicabile per tipo di risorsa, trattando un riferimento assoluto come un URL canonico e cercandolo in un registro/repository locale."
    },
    {
      "id" : "Appointment.participant.status",
      "path" : "Appointment.participant.status",
      "definition" : "Stato di partecipazione.",
      "comment" : "Si noti che le stringhe FHIR NON devono superare la dimensione di 1MB."
    }]
  }
}

```
