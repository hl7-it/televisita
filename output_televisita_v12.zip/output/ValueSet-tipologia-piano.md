# ValueSet_TipologiaPiano - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ValueSet_TipologiaPiano**

## ValueSet: ValueSet_TipologiaPiano 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ValueSet/tipologia-piano | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:ValueSet_TipologiaPiano |

 
ValueSet contenente tutti i codici per definire la tipologia del piano. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "tipologia-piano",
  "url" : "http://hl7.it/fhir/televisita/ValueSet/tipologia-piano",
  "version" : "0.2.0",
  "name" : "ValueSet_TipologiaPiano",
  "title" : "ValueSet_TipologiaPiano",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "ValueSet contenente tutti i codici per definire la tipologia del piano.",
  "compose" : {
    "include" : [{
      "system" : "http://hl7.it/fhir/televisita/CodeSystem/csTipologiaPiano"
    }]
  }
}

```
