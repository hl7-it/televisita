# HL7 Italia - Tipi di identificatore - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7 Italia - Tipi di identificatore**

## CodeSystem: HL7 Italia - Tipi di identificatore (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/it-identifier-type | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:CsItIdentifierType |

 
Estensione (codici addizionali) alla tabella per i tipi di identificatore 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VstipoIdentificatore](ValueSet-VstipoIdentificatore.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "it-identifier-type",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/it-identifier-type",
  "version" : "0.2.0",
  "name" : "CsItIdentifierType",
  "title" : "HL7 Italia - Tipi di identificatore",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Estensione (codici addizionali) alla tabella  per i tipi di identificatore",
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "ENI",
    "display" : "Europeo Non Iscritto"
  },
  {
    "code" : "STP",
    "display" : "Straniero Temporaneamente Presente"
  },
  {
    "code" : "CF",
    "display" : "Cittadino italiano o straniero residente, iscritto SSN"
  },
  {
    "code" : "TEAM",
    "display" : "Soggetti assicurati da istituzioni estere"
  },
  {
    "code" : "ANA",
    "display" : "Codice Anagrafica Nazionale degli Assistiti"
  }]
}

```
