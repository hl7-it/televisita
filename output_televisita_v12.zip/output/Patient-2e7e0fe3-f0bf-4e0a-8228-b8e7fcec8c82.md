# Paziente - Maria Rossi - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Paziente - Maria Rossi**

## Example Patient: Paziente - Maria Rossi

Profile: [Patient Televisita](StructureDefinition-PatientTelevisita.md)

Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)

-------

| | |
| :--- | :--- |
| Contact Detail | * ph: 3331245678
* [maria.rossi@mail.com](mailto:maria.rossi@mail.com)
* Via della Libertà, 52 Milano Italia 20100 IT (home)
 |
| Emergency Contact: | * Luigi Rossi 
* ph: 3312345567
 |
| Emergency Contact: | * Maria Bianchi 
* ph: 3311234598
 |
| [Luogo di Nascita - ITA](StructureDefinition-birth-place-ita.md) | Via della Vittoria, 1 Milano Italia 20100 IT |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
  },
  "extension" : [{
    "url" : "http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita",
    "valueAddress" : {
      "extension" : [{
        "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official",
        "valueBoolean" : true
      }],
      "line" : ["Via della Vittoria, 1"],
      "_line" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
          "valueString" : "Via della Vittoria"
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
          "valueString" : "1"
        }]
      }],
      "city" : "Milano",
      "state" : "Italia",
      "postalCode" : "20100",
      "country" : "IT"
    }
  }],
  "identifier" : [{
    "system" : "http://hl7.it/sid/codiceFiscale",
    "value" : "RSSMRA71E41F205E"
  }],
  "name" : [{
    "family" : "Rossi",
    "given" : ["Maria"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "3331245678"
  },
  {
    "system" : "email",
    "value" : "maria.rossi@mail.com"
  }],
  "gender" : "female",
  "birthDate" : "1971-05-01",
  "address" : [{
    "extension" : [{
      "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official",
      "valueBoolean" : true
    },
    {
      "extension" : [{
        "url" : "who",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.it/fhir/televisita/CodeSystem/it-tipoEntita",
            "code" : "gov"
          }]
        }
      }],
      "url" : "http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"
    }],
    "use" : "home",
    "line" : ["Via della Libertà, 52"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-dug",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.it/fhir/televisita/CodeSystem/dug",
            "code" : "67",
            "display" : "via"
          }]
        }
      }]
    }],
    "city" : "Milano",
    "state" : "Italia",
    "postalCode" : "20100",
    "country" : "IT"
  }],
  "contact" : [{
    "relationship" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
        "code" : "C",
        "display" : "Emergency Contact"
      }]
    }],
    "name" : {
      "family" : "Rossi",
      "given" : ["Luigi"]
    },
    "telecom" : [{
      "system" : "phone",
      "value" : "3312345567"
    }]
  },
  {
    "relationship" : [{
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
        "code" : "C",
        "display" : "Emergency Contact"
      }]
    }],
    "name" : {
      "family" : "Bianchi",
      "given" : ["Maria"]
    },
    "telecom" : [{
      "system" : "phone",
      "value" : "3311234598"
    }]
  }]
}

```
