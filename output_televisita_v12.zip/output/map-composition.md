# Composition - Referto di Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Composition - Referto di Televisita**

## Composition - Referto di Televisita

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR e sulle risorse ad esso correlate.

Allegato 1 Telemedicina → Composizione del referto

 Questa pagina illustra come gli elementi informativi previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" siano rappresentati nel corrispondente profilo FHIR e nelle risorse correlate presenti nelle sezioni del documento. 

| | | | |
| :--- | :--- | :--- | :--- |
| Data firma referto | Data di firma del referto | Composition | Composition.attester[legalAuthenticator].time |
| Codici identificazione oggetti correlati | Codici per identificare eventuali oggetti associati al referto (es. ID PACS, Accession number, Studio DICOM). | Composition | Composition.relatesTo.targetIdentifier / Composition.relatesTo.targetReference |
| Tipologia Accesso | Tipologia di accesso (programmata / ad accesso diretto) | Composition | Composition.event.code |
| Codice quesito diagnostico | Codice ICD9-CM del quesito diagnostico | Composition / Observation | Composition.section[questitoDiagnostico].entry.resolve().ofType(Observation).code.coding.code |
| Descrizione quesito diagnostico | Descrizione del quesito diagnostico | Composition / Observation | Composition.section[questitoDiagnostico].entry.resolve().ofType(Observation).code.text |
| Anamnesi | Descrizione testuale dell'anamnesi (quadro clinico) | Composition / Observation | Composition.section[InquadramentoClinicoIniziale].section[anamnesi].entry.resolve().ofType(Observation).note.text |
| Precedenti esami eseguiti | Codice, descrizione, metodica e data di eventuali esami precedenti eseguiti dal paziente e ritenuti rilevanti ai fini della formulazione del referto | Composition / Observation | Composition.section[precedentiEsamiEseguiti].entry.resolve().ofType(Observation).note.text / code / effective[x] |
| Codice AIC/ATC farmaco | Codice AIC/ATC del farmaco o dei farmaci assunti nella terapia in atto | Composition / MedicationStatement | Composition.section[InquadramentoClinicoIniziale].section[terapiaFarmacologicaInAtto].entry.resolve().ofType(MedicationStatement).medicationCodeableConcept.coding.code |
| Descrizione terapia farmacologica | Descrizione della terapia farmacologica attualmente in atto al momento della televisita | Composition / MedicationStatement | Composition.section[InquadramentoClinicoIniziale].section[terapiaFarmacologicaInAtto].entry.resolve().ofType(MedicationStatement).medicationCodeableConcept.text |
| Esame obiettivo | Resoconto dell'esame obiettivo effettuato durante la televisita | Composition / Observation | Composition.section[InquadramentoClinicoIniziale].section[esameObiettivo].entry.resolve().ofType(Observation).note.text |
| Strumentazione utilizzata | Strumentazione utilizzata nel corso della procedura | Composition / Procedure / Device | Composition.section[prestazioni].entry.resolve().ofType(Procedure).usedReference.resolve().ofType(Device) |
| Parametri descrittivi della procedura | Parametri rilevanti al fine di caratterizzare la procedura | Composition / Procedure / Observation | Composition.section[prestazioni].entry.resolve().ofType(Procedure).supportingInfo.resolve().ofType(Observation) |
| Confronto con precedenti esami eseguiti | Confronto con precedenti esami eseguiti. Permette di riportare un confronto tra quanto emerso nel corso di precedenti esami eseguiti e quanto rilevato durante la televisita. | Composition / Observation | Composition.section[confrontoPrecedentiEsamiEseguiti].entry.resolve().ofType(Observation).note.text |
| Refertazione | Referto della/e prestazione/i, oggetto principale del referto | Composition / Observation | Composition.section[referto].entry.resolve().ofType(Observation).note.text / value[x] |
| Codice diagnosi | Codice diagnosi formulata sulla base di quanto emerso nel corso della prestazione | Composition / Observation | Composition.section[diagnosi].entry.resolve().ofType(Observation).code.coding.code |
| Descrizione diagnosi | Descrizione diagnosi formulata sulla base di quanto emerso nel corso della prestazione | Composition / Observation | Composition.section[diagnosi].entry.resolve().ofType(Observation).code.text |
| Conclusioni | Conclusioni formulate dal medico specialista a seguito della televisita | Composition / Observation | Composition.section[conclusioni].entry.resolve().ofType(Observation).note.text / value[x] |
| Suggerimenti per il medico prescrittore | Indicazioni e suggerimenti rivolti al medico prescrittore a seguito della televisita | Composition / Observation | Composition.section[suggerimentiPerMedicoPrescrittore].entry.resolve().ofType(Observation).note.text |
| Codice accertamento consigliato | Codice accertamento/i o prestazione/i consigliata/e da eseguire a seguito della prestazione | Composition / Observation | Composition.section[accertamentiControlliConsigliati].entry.resolve().ofType(Observation).code.coding.code |
| Descrizione accertamento consigliato | Descrizione accertamento/i o prestazione/i consigliata/e da eseguire a seguito della prestazione | Composition / Observation | Composition.section[accertamentiControlliConsigliati].entry.resolve().ofType(Observation).code.coding.display |
| Codice AIC/ATC farmaco consigliato | Codice AIC/ATC del farmaco o dei farmaci consigliato per la terapia farmacologica | Composition / MedicationRequest | Composition.section[terapiaFarmacologicaConsigliata].entry.resolve().ofType(MedicationRequest).medicationCodeableConcept.coding.code |
| Descrizione terapia farmacologica consigliata | Descrizione della terapia farmacologica consigliata | Composition / MedicationRequest | Composition.section[terapiaFarmacologicaConsigliata].entry.resolve().ofType(MedicationRequest).medicationCodeableConcept.text |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

