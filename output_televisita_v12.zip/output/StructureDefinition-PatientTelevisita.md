# Patient Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Televisita**

## Resource Profile: Patient Televisita ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita | *Version*:0.2.0 |
| Draft as of 2024-04-29 | *Computable Name*:PatientTelevisita |

 
Profilo della risorsa Patient utilizzato per rappresentare l'assistito coinvolto nel servizio di televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [AllergyIntolerance Televisita](StructureDefinition-AllergyIntoleranceTelevisita.md), [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [Encounter Televisita](StructureDefinition-EncounterTelevisita.md), [MedicationRequest Televisita](StructureDefinition-MedicationRequestTelevisita.md)... Show 3 more, [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md), [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md) and [ServiceRequest Televisita](StructureDefinition-ServiceRequestTelevisita.md)
* Examples for this Profile: [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-PatientTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PatientTelevisita.csv), [Excel](StructureDefinition-PatientTelevisita.xlsx), [Schematron](StructureDefinition-PatientTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PatientTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita",
  "version" : "0.2.0",
  "name" : "PatientTelevisita",
  "title" : "Patient Televisita",
  "status" : "draft",
  "experimental" : true,
  "date" : "2024-04-29T16:08:42+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Patient utilizzato per rappresentare l'assistito coinvolto nel servizio di televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient.extension",
      "path" : "Patient.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Patient.extension:luogoNascita",
      "path" : "Patient.extension",
      "sliceName" : "luogoNascita",
      "short" : "Luogo di nascita dell'assistito.",
      "definition" : "Estensione utilizzata per rappresentare il luogo di nascita dell'assistito, ove richiesto per l'identificazione del paziente nel contesto nazionale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/birth-place-ita"]
      }]
    },
    {
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this.system"
        }],
        "rules" : "open"
      },
      "short" : "Identificativi dell'assistito.",
      "definition" : "Identificativi utilizzati per riconoscere l'assistito coinvolto nella televisita, quali Codice Fiscale, identificativo regionale, identificativo ANPR, STP, ENI, ANA o tessera TEAM.",
      "comment" : "Nel contesto della televisita è necessario disporre di identificativi idonei a garantire il corretto riconoscimento dell'assistito e l'associazione del referto al relativo percorso assistenziale.",
      "min" : 1
    },
    {
      "id" : "Patient.identifier.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier.type",
      "path" : "Patient.identifier.type",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VstipoIdentificatore"
      }
    },
    {
      "id" : "Patient.identifier:codiceFiscale",
      "path" : "Patient.identifier",
      "sliceName" : "codiceFiscale",
      "short" : "Codice Fiscale dell'assistito.",
      "definition" : "Identificativo fiscale nazionale dell'assistito, utilizzato per l'identificazione univoca nel contesto sanitario italiano.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:codiceFiscale.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:codiceFiscale.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione del Codice Fiscale.",
      "definition" : "URI del sistema di identificazione utilizzato per il Codice Fiscale.",
      "min" : 1,
      "fixedUri" : "http://hl7.it/sid/codiceFiscale"
    },
    {
      "id" : "Patient.identifier:codiceFiscale.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore del Codice Fiscale.",
      "definition" : "Valore alfanumerico del Codice Fiscale dell'assistito.",
      "constraint" : [{
        "key" : "pat-id-cf-1",
        "severity" : "error",
        "human" : "Il Codice Fiscale deve essere composto da 16 caratteri alfanumerici secondo il formato previsto dalla normativa italiana.",
        "expression" : "matches('^[A-Za-z]{6}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{3}[A-Za-z]{1}$')",
        "xpath" : "matches(@value,'^[A-Za-z]{6}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{2}[A-Za-z]{1}[0-9LMNPQRSTUV]{3}[A-Za-z]{1}$')",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"
      }]
    },
    {
      "id" : "Patient.identifier:anpr",
      "path" : "Patient.identifier",
      "sliceName" : "anpr",
      "short" : "Identificativo ANPR dell'assistito.",
      "definition" : "Identificativo dell'assistito nell'Anagrafe Nazionale della Popolazione Residente.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:anpr.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:anpr.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione ANPR.",
      "definition" : "URI del sistema di identificazione dell'Anagrafe Nazionale della Popolazione Residente.",
      "min" : 1,
      "patternUri" : "http://hl7.it/sid/anpr"
    },
    {
      "id" : "Patient.identifier:anpr.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore dell'identificativo ANPR.",
      "definition" : "Valore dell'identificativo dell'assistito nell'ANPR."
    },
    {
      "id" : "Patient.identifier:idRegionale",
      "path" : "Patient.identifier",
      "sliceName" : "idRegionale",
      "short" : "Identificativo regionale dell'assistito.",
      "definition" : "Identificativo assegnato all'assistito da un sistema sanitario regionale.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:idRegionale.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:idRegionale.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione regionale.",
      "definition" : "URI del sistema regionale che assegna l'identificativo dell'assistito.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vs-anagrafi-regionali"
      }
    },
    {
      "id" : "Patient.identifier:idRegionale.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore dell'identificativo regionale.",
      "definition" : "Valore dell'identificativo regionale dell'assistito."
    },
    {
      "id" : "Patient.identifier:codiceENI",
      "path" : "Patient.identifier",
      "sliceName" : "codiceENI",
      "short" : "Codice ENI dell'assistito.",
      "definition" : "Codice identificativo assegnato agli assistiti europei non iscritti al Servizio Sanitario Nazionale.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:codiceENI.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:codiceENI.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione ENI.",
      "definition" : "URI del sistema di identificazione utilizzato per il codice ENI.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vs-uri-id-eni"
      }
    },
    {
      "id" : "Patient.identifier:codiceENI.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore del codice ENI.",
      "definition" : "Valore del codice ENI associato all'assistito."
    },
    {
      "id" : "Patient.identifier:codiceANA",
      "path" : "Patient.identifier",
      "sliceName" : "codiceANA",
      "short" : "Codice ANA dell'assistito.",
      "definition" : "Codice identificativo dell'assistito utilizzato nell'Anagrafe Nazionale degli Assistiti.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:codiceANA.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:codiceANA.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione ANA.",
      "definition" : "OID del sistema di identificazione dell'Anagrafe Nazionale degli Assistiti.",
      "min" : 1,
      "patternUri" : "urn:oid:2.16.840.1.113883.2.9.4.3.15"
    },
    {
      "id" : "Patient.identifier:codiceANA.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore del codice ANA.",
      "definition" : "Valore del codice ANA associato all'assistito."
    },
    {
      "id" : "Patient.identifier:tesseraTEAM",
      "path" : "Patient.identifier",
      "sliceName" : "tesseraTEAM",
      "short" : "Numero della tessera TEAM.",
      "definition" : "Identificativo della Tessera Europea di Assicurazione Malattia dell'assistito.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:tesseraTEAM.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:tesseraTEAM.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione TEAM.",
      "definition" : "OID del sistema di identificazione della Tessera Europea di Assicurazione Malattia.",
      "min" : 1,
      "patternUri" : "urn:oid:2.16.840.1.113883.2.9.4.3.7"
    },
    {
      "id" : "Patient.identifier:tesseraTEAM.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore della tessera TEAM.",
      "definition" : "Numero o valore identificativo della tessera TEAM dell'assistito."
    },
    {
      "id" : "Patient.identifier:codiceSTP",
      "path" : "Patient.identifier",
      "sliceName" : "codiceSTP",
      "short" : "Codice STP dell'assistito.",
      "definition" : "Codice identificativo assegnato allo straniero temporaneamente presente.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:codiceSTP.extension:certificazioneId",
      "path" : "Patient.identifier.extension",
      "sliceName" : "certificazioneId",
      "short" : "Certificazione dell'identificativo.",
      "definition" : "Indica che l'identificativo è stato certificato da una fonte autorevole. È utilizzato tipicamente per il Codice Fiscale.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Patient.identifier:codiceSTP.system",
      "path" : "Patient.identifier.system",
      "short" : "Sistema di identificazione STP.",
      "definition" : "URI del sistema di identificazione utilizzato per il codice STP.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VstipoIdentificatore"
      }
    },
    {
      "id" : "Patient.identifier:codiceSTP.value",
      "path" : "Patient.identifier.value",
      "short" : "Valore del codice STP.",
      "definition" : "Valore del codice STP associato all'assistito."
    },
    {
      "id" : "Patient.name",
      "path" : "Patient.name",
      "short" : "Nome dell'assistito.",
      "definition" : "Nome anagrafico dell'assistito coinvolto nella televisita.",
      "comment" : "Il nome dell'assistito può includere cognome, nome e altri elementi anagrafici utili alla corretta identificazione del paziente.",
      "requirements" : "Il nome dell'assistito è necessario per supportare il riconoscimento del paziente e la corretta associazione del referto di televisita alla persona assistita.",
      "min" : 1,
      "constraint" : [{
        "key" : "it-pat-1",
        "severity" : "error",
        "human" : "Patient.name.given o Patient.name.family, oppure entrambi, DEVONO essere presenti.",
        "expression" : "family.exists() or given.exists()",
        "xpath" : "f:given or f:family",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"
      }]
    },
    {
      "id" : "Patient.telecom",
      "path" : "Patient.telecom",
      "short" : "Recapiti dell'assistito.",
      "definition" : "Recapiti di contatto dell'assistito, quali numero telefonico o indirizzo e-mail.",
      "comment" : "Nel contesto della televisita i recapiti possono essere utilizzati per finalità organizzative, ad esempio per comunicazioni relative all'appuntamento o all'accesso alla piattaforma."
    },
    {
      "id" : "Patient.gender",
      "path" : "Patient.gender",
      "short" : "Genere amministrativo dell'assistito.",
      "definition" : "Genere amministrativo dell'assistito utilizzato nei sistemi informativi sanitari.",
      "comment" : "Il genere amministrativo può non coincidere con il sesso biologico o con l'identità di genere della persona. Deve essere utilizzato con attenzione nei processi clinici e decisionali.",
      "min" : 1
    },
    {
      "id" : "Patient.birthDate",
      "path" : "Patient.birthDate",
      "short" : "Data di nascita dell'assistito.",
      "definition" : "Data di nascita dell'assistito.",
      "comment" : "La data di nascita contribuisce all'identificazione anagrafica del paziente e alla corretta associazione delle informazioni cliniche.",
      "min" : 1
    },
    {
      "id" : "Patient.deceased[x]",
      "path" : "Patient.deceased[x]",
      "short" : "Indicatore di decesso dell'assistito.",
      "definition" : "Indica se l'assistito risulta deceduto.",
      "comment" : "L'assenza di valorizzazione indica che non è disponibile alcuna informazione sullo stato di decesso dell'assistito.",
      "mustSupport" : false
    },
    {
      "id" : "Patient.address",
      "path" : "Patient.address",
      "short" : "Indirizzo dell'assistito.",
      "definition" : "Indirizzo di residenza, domicilio o altro recapito territoriale dell'assistito.",
      "comment" : "Nel contesto della televisita l'indirizzo può essere rilevante per identificare il contesto territoriale di presa in carico o la collocazione dell'assistito.",
      "type" : [{
        "code" : "Address",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AddressItTelemedicina"]
      }]
    },
    {
      "id" : "Patient.maritalStatus",
      "path" : "Patient.maritalStatus",
      "short" : "Stato civile dell'assistito.",
      "definition" : "Stato civile dell'assistito, ove rilevante per il contesto assistenziale o amministrativo.",
      "comment" : "Lo stato civile può essere utilizzato per finalità amministrative o di contesto, ma normalmente non costituisce un'informazione centrale per l'erogazione della televisita."
    },
    {
      "id" : "Patient.generalPractitioner",
      "path" : "Patient.generalPractitioner",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "Medico o struttura di assistenza di riferimento.",
      "definition" : "Riferimenti al Medico di Medicina Generale, Pediatra di Libera Scelta o all'organizzazione sanitaria responsabile dell'assistenza dell'assistito.",
      "comment" : "Nel contesto della televisita consente di indicare il professionista o l'organizzazione di riferimento dell'assistito, utile per la continuità assistenziale e per la condivisione dell'esito della prestazione."
    },
    {
      "id" : "Patient.generalPractitioner:mmgPlsRole",
      "path" : "Patient.generalPractitioner",
      "sliceName" : "mmgPlsRole",
      "short" : "Ruolo del MMG o PLS.",
      "definition" : "Riferimento al ruolo professionale del Medico di Medicina Generale o del Pediatra di Libera Scelta dell'assistito.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Patient.generalPractitioner:mmgPls",
      "path" : "Patient.generalPractitioner",
      "sliceName" : "mmgPls",
      "short" : "MMG o PLS dell'assistito.",
      "definition" : "Riferimento al Medico di Medicina Generale o al Pediatra di Libera Scelta dell'assistito.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "Patient.generalPractitioner:aziendaAssistenza",
      "path" : "Patient.generalPractitioner",
      "sliceName" : "aziendaAssistenza",
      "short" : "Azienda sanitaria di assistenza.",
      "definition" : "Riferimento all'organizzazione sanitaria responsabile dell'assistenza territoriale dell'assistito.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
      }]
    }]
  }
}

```
