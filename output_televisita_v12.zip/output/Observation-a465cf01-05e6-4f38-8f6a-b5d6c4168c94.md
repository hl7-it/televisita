# Referto Televisita Pneumologica - Maria Rossi - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referto Televisita Pneumologica - Maria Rossi**

## Example Observation: Referto Televisita Pneumologica - Maria Rossi

Profile: [Observation Televisita](StructureDefinition-ObservationTelevisita.md)

**status**: Final

**code**: Study report

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: Referto di televisita pneumologica: sintomi in miglioramento, non si evidenziano complicanze.



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "a465cf01-05e6-4f38-8f6a-b5d6c4168c94",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "47045-0"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "Referto di televisita pneumologica: sintomi in miglioramento, non si evidenziano complicanze."
}

```
