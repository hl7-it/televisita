# Encounter - Sessione di Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Encounter - Sessione di Televisita**

## Encounter - Sessione di Televisita

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR.

Allegato 1 Telemedicina → Visita/Sessione di televisita

 Questa pagina illustra come gli elementi informativi relativi alla visita/sessione di televisita, previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina", siano rappresentati nel corrispondente profilo FHIR. 

| | | | |
| :--- | :--- | :--- | :--- |
| Cognome altra figura tecnica coinvolta nell'esecuzione della procedura | Cognome del medico specialista o altra figura tecnica partecipante alla televisita | Encounter / Practitioner | Encounter.participant.individual.resolve().ofType(Practitioner).name.family |
| Nome altra figura tecnica coinvolta nell'esecuzione della procedura | Nome del medico specialista o altra figura tecnica partecipante alla televisita | Encounter / Practitioner | Encounter.participant.individual.resolve().ofType(Practitioner).name.given |
| Codice fiscale altra figura tecnica coinvolta nell'esecuzione della procedura | Codice fiscale del medico specialista o altra figura tecnica partecipante alla televisita | Encounter / Practitioner | Encounter.participant.individual.resolve().ofType(Practitioner).identifier |
| Codice Nosologico | Codice nosologico associato all'incontro di televisita, ove applicabile | Encounter | Encounter.identifier.where(type='codiceNosologico').value |
| Provenienza | Provenienza del paziente (es. territoriale, domiciliare, ambulatoriale) | Encounter | Encounter.class |
| Disciplina | Disciplina specialistica ambulatoriale | Encounter | Encounter.serviceType |
| Branca | Branca specialistica ambulatoriale | Encounter | Encounter.serviceType |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

