# Ruolo - Dr. Marco Ferrari, Pneumologo ASL Roma 1 - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ruolo - Dr. Marco Ferrari, Pneumologo ASL Roma 1**

## Example PractitionerRole: Ruolo - Dr. Marco Ferrari, Pneumologo ASL Roma 1

Profile: [PractitionerRoleTelevisita](StructureDefinition-PractitionerRoleTelevisita.md)

**practitioner**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**organization**: [Organization ASL Roma 1](Organization-asl-roma-1.md)

**specialty**: Pneumologia



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "e446e848-2bd4-423a-b2f8-5d25687e2f42",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
  },
  "practitioner" : {
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  },
  "organization" : {
    "reference" : "Organization/asl-roma-1"
  },
  "specialty" : [{
    "coding" : [{
      "system" : "http://hl7.it/fhir/televisita/CodeSystem/csspecialityPractitionerRole",
      "code" : "68",
      "display" : "Pneumologia"
    }]
  }]
}

```
