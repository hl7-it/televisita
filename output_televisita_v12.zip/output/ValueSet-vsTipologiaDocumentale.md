# VS - Tipologia documentale - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VS - Tipologia documentale**

## ValueSet: VS - Tipologia documentale 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ValueSet/vsTipologiaDocumentale | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:VsTipologiaDocumentale |

 
Codici LOINC dei documenti 

 **References** 

* [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vsTipologiaDocumentale",
  "url" : "http://hl7.it/fhir/televisita/ValueSet/vsTipologiaDocumentale",
  "version" : "0.2.0",
  "name" : "VsTipologiaDocumentale",
  "title" : "VS - Tipologia documentale",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Codici LOINC dei documenti",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "53576-5",
        "display" : "Personal health monitoring report Document"
      },
      {
        "code" : "75496-0",
        "display" : "Telehealth Note"
      },
      {
        "code" : "85208-7",
        "display" : "Telehealth Consult note"
      },
      {
        "code" : "91531-4",
        "display" : "Social worker Telehealth Note"
      },
      {
        "code" : "64296-7",
        "display" : "Personal health monitoring report Automated"
      }]
    }]
  }
}

```
