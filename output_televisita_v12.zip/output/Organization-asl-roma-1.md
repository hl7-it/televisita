# ASL Roma 1 - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ASL Roma 1**

## Example Organization: ASL Roma 1

Profile: [Organization T1 - Azienda Sanitaria](StructureDefinition-OrganizationT1.md)

**identifier**: `http://hl7.it/sid/fls`/120201, [Uniform Resource Identifier (URI)](http://terminology.hl7.org/7.2.0/NamingSystem-uri.html)/urn:oid:2.16.840.1.113883.2.9.2.120.4.1, `http://hl7.it/sid/partitaIva`/12345678901, `http://hl7.it/sid/codiceFiscale`/01234567890

**name**: ASL Roma 1



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "asl-roma-1",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
  },
  "identifier" : [{
    "system" : "http://hl7.it/sid/fls",
    "value" : "120201"
  },
  {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.2.9.2.120.4.1"
  },
  {
    "system" : "http://hl7.it/sid/partitaIva",
    "value" : "12345678901"
  },
  {
    "system" : "http://hl7.it/sid/codiceFiscale",
    "value" : "01234567890"
  }],
  "name" : "ASL Roma 1"
}

```
