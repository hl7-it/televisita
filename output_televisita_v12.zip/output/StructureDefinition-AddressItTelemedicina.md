# Address - ITA - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Address - ITA**

## Data Type Profile: Address - ITA 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/AddressItTelemedicina | *Version*:0.2.0 | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:AddressItTelemedicina |

 
Descrizione di Address con parti addizionali specifiche per gli indirizzi italiani. Questo profilo struttura l'elemento Address.line in più parti, consente la codifica di alcune di queste parti e supporta la caratterizzazine degli indirizzi di tipo Residenza. Questa prima versione è ispirata al data type Address Olandese. 

**Usages:**

* Use this DataType Profile: [Patient Televisita](StructureDefinition-PatientTelevisita.md) and [Luogo di Nascita - ITA](StructureDefinition-birth-place-ita.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-AddressItTelemedicina.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-AddressItTelemedicina.csv), [Excel](StructureDefinition-AddressItTelemedicina.xlsx), [Schematron](StructureDefinition-AddressItTelemedicina.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "AddressItTelemedicina",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use"
  }],
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/AddressItTelemedicina",
  "version" : "0.2.0",
  "name" : "AddressItTelemedicina",
  "title" : "Address - ITA",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Descrizione di Address con parti addizionali specifiche per gli indirizzi italiani. Questo profilo struttura l'elemento  Address.line in più parti, consente la codifica di alcune di queste parti e supporta la caratterizzazine degli indirizzi di tipo Residenza. Questa prima versione è ispirata al data type Address Olandese.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "vcard",
    "uri" : "http://w3.org/vcard",
    "name" : "vCard Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Address",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Address",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Address",
      "path" : "Address",
      "short" : "Indirizzo fisico o postale",
      "definition" : "Esiste una varietà di formati di indirizzi postali definiti in tutto il mondo. Questo profilo (address-it-base) estende il datatype base Address includendo una serie di informazioni rilevanti per esprimere gli indirizzi in Italia. \r \n \r \n Un address-it-base è un indirizzo FHIR valido; i sistemi che non supportano le estensioni utilizzate saranno in grado comunque di eseguire il rendering e lavorare con un XXXX. \r \n \r \n Un indirizzo rende alcune parti di indirizzo comunicabili separatamente. Queste parti sono necessarie in alcuni scenari d'uso italiani, ma potrebbero non avere valore per i sistemi internazionali quando le informazioni vengono inviate all'estero.",
      "comment" : "Nota: address è per indirizzi postali, non per la localizzazione fisica.",
      "alias" : ["Indirizzo"]
    },
    {
      "id" : "Address.extension:residenza",
      "path" : "Address.extension",
      "sliceName" : "residenza",
      "short" : "Indica l'indirizzo di residenza",
      "definition" : "Indica se questo indirizzo è quello di residenza, come indirizzo 'ufficialmente registrato' address.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/address-official"]
      }]
    },
    {
      "id" : "Address.extension:certificazioneIndirizzo",
      "path" : "Address.extension",
      "sliceName" : "certificazioneIndirizzo",
      "short" : "Certificazione Indirizzo",
      "definition" : "Indica che i dati di questo indirizzo sono stati certificati da una specifica entità",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"]
      }]
    },
    {
      "id" : "Address.line",
      "path" : "Address.line",
      "short" : "Nome completo strada (e.g. Via Corta 1, interno 2)",
      "mustSupport" : true
    },
    {
      "id" : "Address.line.extension",
      "path" : "Address.line.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Address.line.extension:odonimo",
      "path" : "Address.line.extension",
      "sliceName" : "odonimo",
      "short" : "Odonimo, Toponimo Stradale",
      "requirements" : "Nome della Strada",
      "alias" : ["Toponimo Stradale", "user content"],
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName|5.3.0"]
      }],
      "example" : [{
        "label" : "ex-1",
        "valueString" : "Via Corta"
      }]
    },
    {
      "id" : "Address.line.extension:dugCode",
      "path" : "Address.line.extension",
      "sliceName" : "dugCode",
      "short" : "Codice Denominazione Urbanistica Generica (DUG)",
      "alias" : ["specie", "user content"],
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/address-dug"]
      }],
      "example" : [{
        "label" : "ex-1",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.it/fhir/televisita/CodeSystem/dug",
            "code" : "67",
            "display" : "via"
          }]
        }
      }]
    },
    {
      "id" : "Address.line.extension:denominazioneUrbanisticaUfficiale",
      "path" : "Address.line.extension",
      "sliceName" : "denominazioneUrbanisticaUfficiale",
      "short" : "Denominazione Urbanistica Ufficiale (DUF)",
      "alias" : ["denominazione", "user content"],
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameBase|5.3.0"]
      }],
      "example" : [{
        "label" : "ex-1",
        "valueString" : "Corta"
      }]
    },
    {
      "id" : "Address.line.extension:houseNumber",
      "path" : "Address.line.extension",
      "sliceName" : "houseNumber",
      "short" : "Numero Civico",
      "requirements" : "Numero Civico",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber|5.3.0"]
      }],
      "example" : [{
        "label" : "ex-1",
        "valueString" : "1"
      }]
    },
    {
      "id" : "Address.line.extension:denominazioneUrbanisticaGenerica",
      "path" : "Address.line.extension",
      "sliceName" : "denominazioneUrbanisticaGenerica",
      "short" : "Denominazione Urbanistica Generica (DUG)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameType|5.3.0"]
      }],
      "example" : [{
        "label" : "ex-1",
        "valueString" : "Via"
      }]
    },
    {
      "id" : "Address.city",
      "path" : "Address.city",
      "definition" : "Nome della città, paese, frazione, ecc.",
      "alias" : ["Comune"]
    },
    {
      "id" : "Address.district",
      "path" : "Address.district",
      "short" : "Nome della Provincia",
      "definition" : "Nome dell'area amministrativa (county).\r\nPer gli indirizzi italiani è usato per indicare la Provincia",
      "alias" : ["Provincia"]
    },
    {
      "id" : "Address.district.extension",
      "path" : "Address.district.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Address.district.extension:codiceProvincia",
      "path" : "Address.district.extension",
      "sliceName" : "codiceProvincia",
      "short" : "Codice Provincia",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding|5.3.0"]
      }]
    },
    {
      "id" : "Address.state",
      "path" : "Address.state",
      "short" : "Sotto-unità dello stato (Regione).",
      "definition" : "Sotto-unità dello stato con limitata sovranità in uno stato oragnizzato federalmente.\r\nNel contesto italiano indica la \"Regione\"",
      "alias" : ["Regione", "Territory"],
      "min" : 1
    },
    {
      "id" : "Address.state.extension",
      "path" : "Address.state.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Address.state.extension:codiceRegione",
      "path" : "Address.state.extension",
      "sliceName" : "codiceRegione",
      "short" : "Codice Regione",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding|5.3.0"]
      }]
    },
    {
      "id" : "Address.postalCode",
      "path" : "Address.postalCode",
      "comment" : "I codici postali italiani hanno un pattern '[1,9]{4}'.",
      "alias" : ["CAP", "postcode"],
      "constraint" : [{
        "key" : "it-postal-code-pattern",
        "severity" : "error",
        "human" : "I codici postali italiani hanno un pattern 'nnnnn' (n intero)",
        "expression" : "matches('[0-9]{5}')",
        "xpath" : "matches(@value,'[0-9]{5}')",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/AddressItTelemedicina"
      }]
    },
    {
      "id" : "Address.country.extension",
      "path" : "Address.country.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Address.country.extension:codiceStato",
      "path" : "Address.country.extension",
      "sliceName" : "codiceStato",
      "short" : "Codice Stato",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/iso21090-SC-coding|5.3.0"]
      }]
    }]
  }
}

```
