# Confronto Esami - Miglioramento quadro bronchiolitico - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Confronto Esami - Miglioramento quadro bronchiolitico**

## Example Observation: Confronto Esami - Miglioramento quadro bronchiolitico

Profile: [Observation Televisita Narrative](StructureDefinition-ObservationTelevisitaNarrative.md)

**status**: Final

**code**: Comparison with previous results

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: Rispetto al controllo precedente, lieve miglioramento del quadro bronchiolitico.



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ecc5c95f-a1c0-483c-b48e-5fd84762c393",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "93126-1"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "Rispetto al controllo precedente, lieve miglioramento del quadro bronchiolitico."
}

```
