# Bundle Referto di Televisita - Transaction - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle Referto di Televisita - Transaction**

## Resource Profile: Bundle Referto di Televisita - Transaction 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertoDiTelevisitaTransaction | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:BundleRefertoDiTelevisitaTransaction |

 
Bundle FHIR di tipo transaction per il Referto di Televisita. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) utilizzano PUT con URL basato sull'identificatore per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment, DocumentReference) utilizzano POST. 

**Usages:**

* Examples for this Profile: [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-BundleRefertoDiTelevisitaTransaction.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleRefertoDiTelevisitaTransaction.csv), [Excel](StructureDefinition-BundleRefertoDiTelevisitaTransaction.xlsx), [Schematron](StructureDefinition-BundleRefertoDiTelevisitaTransaction.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleRefertoDiTelevisitaTransaction",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertoDiTelevisitaTransaction",
  "version" : "0.2.0",
  "name" : "BundleRefertoDiTelevisitaTransaction",
  "title" : "Bundle Referto di Televisita - Transaction",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Bundle FHIR di tipo transaction per il Referto di Televisita. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) utilizzano PUT con URL basato sull'identificatore per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment, DocumentReference) utilizzano POST.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Bundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.type",
      "path" : "Bundle.type",
      "short" : "Tipo del Bundle: transaction.",
      "definition" : "Il Bundle è di tipo transaction: ogni entry contiene un elemento request con method e url per l'operazione da eseguire sul server FHIR.",
      "fixedCode" : "transaction"
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "resource"
        },
        {
          "type" : "profile",
          "path" : "resource"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 2
    },
    {
      "id" : "Bundle.entry:composition",
      "path" : "Bundle.entry",
      "sliceName" : "composition",
      "short" : "Documento clinico - POST.",
      "definition" : "Composition del referto di televisita inviata con POST.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:composition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Composition",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:composition.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:patient",
      "path" : "Bundle.entry",
      "sliceName" : "patient",
      "short" : "Paziente - PUT.",
      "definition" : "Risorsa Patient inviata con PUT e identifier-based URL per garantire idempotenza.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:patient.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Patient",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:patient.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "PUT"
    },
    {
      "id" : "Bundle.entry:serviceRequest",
      "path" : "Bundle.entry",
      "sliceName" : "serviceRequest",
      "short" : "Richiesta di televisita - POST.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:serviceRequest.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "ServiceRequest",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:serviceRequest.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:appointment",
      "path" : "Bundle.entry",
      "sliceName" : "appointment",
      "short" : "Appuntamento - POST.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:appointment.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Appointment",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:appointment.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:practitionerRole",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerRole",
      "short" : "Ruolo del professionista - PUT.",
      "definition" : "Risorsa PractitionerRole inviata con PUT e identifier-based URL.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitionerRole.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "PractitionerRole",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:practitionerRole.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "PUT"
    },
    {
      "id" : "Bundle.entry:practitioner",
      "path" : "Bundle.entry",
      "sliceName" : "practitioner",
      "short" : "Professionista - PUT.",
      "definition" : "Risorsa Practitioner inviata con PUT e identifier-based URL.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitioner.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Practitioner",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:practitioner.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "PUT"
    },
    {
      "id" : "Bundle.entry:organization",
      "path" : "Bundle.entry",
      "sliceName" : "organization",
      "short" : "Organizzazione - PUT.",
      "definition" : "Risorsa Organization (ASL, Presidio, UO) inviata con PUT e identifier-based URL.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:organization.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Organization",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3"]
      }]
    },
    {
      "id" : "Bundle.entry:organization.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "PUT"
    },
    {
      "id" : "Bundle.entry:observation",
      "path" : "Bundle.entry",
      "sliceName" : "observation",
      "short" : "Osservazione clinica - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:observation.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Observation",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:observation.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:medicationRequest",
      "path" : "Bundle.entry",
      "sliceName" : "medicationRequest",
      "short" : "Prescrizione farmacologica - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:medicationRequest.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "MedicationRequest",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:medicationRequest.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:medicationStatement",
      "path" : "Bundle.entry",
      "sliceName" : "medicationStatement",
      "short" : "Terapia in atto - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:medicationStatement.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "MedicationStatement"
      }]
    },
    {
      "id" : "Bundle.entry:medicationStatement.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:allergyIntolerance",
      "path" : "Bundle.entry",
      "sliceName" : "allergyIntolerance",
      "short" : "Allergia/intolleranza - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:allergyIntolerance.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "AllergyIntolerance",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:allergyIntolerance.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:encounter",
      "path" : "Bundle.entry",
      "sliceName" : "encounter",
      "short" : "Incontro di televisita - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:encounter.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Encounter",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:encounter.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    },
    {
      "id" : "Bundle.entry:procedure",
      "path" : "Bundle.entry",
      "sliceName" : "procedure",
      "short" : "Prestazione eseguita - POST.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:procedure.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Procedure",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:procedure.request.method",
      "path" : "Bundle.entry.request.method",
      "patternCode" : "POST"
    }]
  }
}

```
