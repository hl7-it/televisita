# Esami Precedenti - TC Torace 10/05/2025 - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Esami Precedenti - TC Torace 10/05/2025**

## Example Observation: Esami Precedenti - TC Torace 10/05/2025

Profile: [Observation Televisita Narrative](StructureDefinition-ObservationTelevisitaNarrative.md)

**status**: Final

**category**: Relevant diagnostic tests/laboratory data note

**code**: CT Chest

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: TC torace eseguita il 10/05/2025. Referto: negativa per lesioni polmonari evolutive, lieve ispessimento peribronchiale compatibile con bronchite cronica.



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "9dfdf0c9-a837-42d5-987c-6170c75cc476",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "30954-2",
      "display" : "Relevant diagnostic tests/laboratory data note"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "24627-2",
      "display" : "CT Chest"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "TC torace eseguita il 10/05/2025. Referto: negativa per lesioni polmonari evolutive, lieve ispessimento peribronchiale compatibile con bronchite cronica."
}

```
