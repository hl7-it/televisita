# Richiesta Televisita Pneumologica - Maria Rossi - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Richiesta Televisita Pneumologica - Maria Rossi**

## Example ServiceRequest: Richiesta Televisita Pneumologica - Maria Rossi

Profile: [ServiceRequest Televisita](StructureDefinition-ServiceRequestTelevisita.md)

**identifier**: AAZ123456789

**requisition**: REQ-20250616-0001

**status**: Active

**intent**: Order

**category**: Pneumologia

**priority**: Routine

**subject**: [Maria Rossi](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**encounter**: [Televisita 16/06/2025](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)

**occurrence**: 2025-06-16 09:00:00+0200

**authoredOn**: 2025-06-02 09:15:00+0200

**requester**: [PractitionerRole: specialty = Pneumologia](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md)

**reasonCode**: Chronic obstructive lung disease

**note**: 

> 

Prestazione da eseguire in modalità remota tramite piattaforma XTelemed




## Resource Content

```json
{
  "resourceType" : "ServiceRequest",
  "id" : "d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
  },
  "identifier" : [{
    "value" : "AAZ123456789"
  }],
  "requisition" : {
    "value" : "REQ-20250616-0001"
  },
  "status" : "active",
  "intent" : "order",
  "category" : [{
    "coding" : [{
      "system" : "http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione",
      "code" : "22",
      "display" : "Pneumologia"
    }]
  }],
  "priority" : "routine",
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82",
    "display" : "Maria Rossi"
  },
  "encounter" : {
    "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2",
    "display" : "Televisita 16/06/2025"
  },
  "occurrenceDateTime" : "2025-06-16T09:00:00+02:00",
  "authoredOn" : "2025-06-02T09:15:00+02:00",
  "requester" : {
    "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
  },
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "13645005",
      "display" : "Chronic obstructive lung disease"
    }]
  }],
  "note" : [{
    "text" : "Prestazione da eseguire in modalità remota tramite piattaforma XTelemed"
  }]
}

```
