# Codesystem catalogo nazionale prestazioni - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Codesystem catalogo nazionale prestazioni**

## CodeSystem: Codesystem catalogo nazionale prestazioni 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/CsCatalogoNazionalePrestazioni | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CsCatalogoNazionalePrestazioni |

 
Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSet_CatalogoNazionalePrestazioni](ValueSet-ValueSetCatalogoNazionalePrestazioni.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CsCatalogoNazionalePrestazioni",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/CsCatalogoNazionalePrestazioni",
  "version" : "0.2.0",
  "name" : "CsCatalogoNazionalePrestazioni",
  "title" : "Codesystem catalogo nazionale prestazioni",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 2108,
  "concept" : [{
    "code" : "02.39.1",
    "display" : "PUNTURA DI RESERVOIR CRANICO PER DELIQUORAZIONE"
  },
  {
    "code" : "02.93.1",
    "display" : "CONTROLLO / PROGRAMMAZIONE DI NEUROSTIMOLATORE ENCEFALICONon associabile a Visita neurologica di controllo 89.01.C"
  },
  {
    "code" : "02.95",
    "display" : "RIMOZIONE DI TRAZIONE TRANSCRANICA O DISPOSITIVO DI HALO"
  },
  {
    "code" : "03.31",
    "display" : "RACHICENTESI"
  },
  {
    "code" : "03.8",
    "display" : "INIEZIONE DI FARMACI CITOTOSSICI NEL CANALE VERTEBRALE. Iniezione endorachide di antiblastici. Incluso farmaco"
  },
  {
    "code" : "03.91.1",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE ANALGESICHE NEL CANALE VERTEBRALE CON POSIZIONAMENTO DI CATETERE PERIDURALE [Catetere temporaneo, con pompa infusore, con tunnel sottocutaneo] Fino ad un massimo di 10 rifornimenti. Escluso: Iniezione di farmaco citotossico nel canale vertebrale (03.8), anestesia effettuata per intervento. Incluso farmaco"
  },
  {
    "code" : "03.91.2",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE ANALGESICHE NEL CANALE VERTEBRALE IN PORTATORE DI CATETERE PERIDURALE [RIFORNIMENTO]. Fino ad un massimo di 10 rifornimenti. Escluso: Iniezione di farmaco citotossico nel canale vertebrale (03.8), anestesia effettuata per intervento Non associabile a 03.91.1. Incluso farmaco"
  },
  {
    "code" : "03.92",
    "display" : "INIEZIONE DI ALTRI FARMACI NEL CANALE VERTEBRALE. Iniezione intratecale [endorachide]. Escluso: Iniezione di liquido di contrasto per mielogramma, Iniezione di farmaco citotossico nel canale vertebrale (03.8). Incluso farmaco"
  },
  {
    "code" : "03.93.1",
    "display" : "CONTROLLO / PROGRAMMAZIONE DI NEUROSTIMOLATORE SPINALE"
  },
  {
    "code" : "03.96.1",
    "display" : "BLOCCO PERCUTANEO PARAVERTEBRALE DELLE FACCETTE ARTICOLARI"
  },
  {
    "code" : "03.96.2",
    "display" : "BLOCCO DELLE FACCETTE ARTICOLARI VERTEBRALI CON ANESTETICI LOCALI. A GUIDA RADIOLOGICA O ECOGRAFICA. Intero trattamento"
  },
  {
    "code" : "03.99.1",
    "display" : "INSERZIONE DI DISPOSITIVO DI ACCESSO PERIDURALE TOTALMENTE IMPIANTABILE. Non associabile a 03.91.1"
  },
  {
    "code" : "04.07.1",
    "display" : "RESEZIONE O ASPORTAZIONE DEI NERVI PERIFERICI. Curettage, sbrigliamento, resezione di nervo periferico (o di relativa lesione). Asportazione di neuroma periferico. Escluso: Biopsia di nervo periferico (04.11.1)"
  },
  {
    "code" : "04.11.1",
    "display" : "BIOPSIA [PERCUTANEA][AGOBIOPSIA] DEI NERVI PERIFERICI"
  },
  {
    "code" : "04.12",
    "display" : "BIOPSIA A CIELO APERTO DEI NERVI PERIFERICI"
  },
  {
    "code" : "04.43",
    "display" : "LIBERAZIONE DEL TUNNEL CARPALE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "04.44",
    "display" : "LIBERAZIONE DEL TUNNEL TARSALE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "04.49",
    "display" : "LIBERAZIONE DEL TUNNEL CUBITALE, DI SCIATICO POPLITEO ESTERNO (SPE) AL CAPITELLO PERONEALE.Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "04.81.1",
    "display" : "INIEZIONE DI ANESTETICO IN NERVO PERIFERICO PER ANALGESIA. Blocco del Ganglio di Gasser e dei suoi rami. Incluso farmaco. Escluso: le anestesie per intervento. Incluso: eventuale guida ecografica"
  },
  {
    "code" : "04.81.2",
    "display" : "INIEZIONE DI ANESTETICO IN NERVO PERIFERICO PER ANALGESIA Blocco degli intercostali e di altre vie nervose, Infiltrazioni paravertebrali e punti trigger. Incluso farmaco. Escluso: le anestesie per intervento"
  },
  {
    "code" : "04.93",
    "display" : "RIMOZIONE DI NEUROSTIMOLATORE DEI NERVI PERIFERICI"
  },
  {
    "code" : "05.31",
    "display" : "INIEZIONE DI ANESTETICO NEI NERVI SIMPATICI PER ANALGESIA A GUIDA ECOGRAFICA. Blocco simpatico regionale arto superiore o inferiore, Blocco del Ganglio celiaco, Blocco del Ganglio stellato, Blocco del simpatico lombare. Incluso il farmaco"
  },
  {
    "code" : "05.32",
    "display" : "INIEZIONE DI AGENTI NEUROLITICI NEI NERVI SIMPATICI. Incluso farmaco"
  },
  {
    "code" : "06.01",
    "display" : "AGOASPIRAZIONE/DRENAGGIO ECOGUIDATI NELLA REGIONE TIROIDEA"
  },
  {
    "code" : "06.01.1",
    "display" : "AGOASPIRAZIONE NELLA REGIONE TIROIDEA"
  },
  {
    "code" : "06.11.2",
    "display" : "BIOPSIA ECOGUIDATA DELLA TIROIDE"
  },
  {
    "code" : "06.98.1",
    "display" : "ALCOLIZZAZIONE ECOGUIDATA DEI NODULI TIROIDEI"
  },
  {
    "code" : "08.01",
    "display" : "INCISIONE DELLA PALPEBRA. Incluso: Incisione di ascesso palpebrale"
  },
  {
    "code" : "08.02",
    "display" : "APERTURA DI BLEFARORRAFIA Cantorrafia,Tarsorrafia"
  },
  {
    "code" : "08.11",
    "display" : "BIOPSIA DELLA PALPEBRA"
  },
  {
    "code" : "08.21",
    "display" : "ASPORTAZIONE DI CALAZIO"
  },
  {
    "code" : "08.22",
    "display" : "ASPORTAZIONE DI LESIONE MINORE DELLA PALPEBRA Asportazione di verruca, papilloma, cisti, porro, condiloma. Incluso: asportazione punti di sutura palpebrale e stent vie lacrimali"
  },
  {
    "code" : "08.23",
    "display" : "ASPORTAZIONE DI LESIONE MAGGIORE DELLA PALPEBRA, NON A TUTTO SPESSORE. Asportazione che include un quarto o più del margine palpebrale a spessore parziale Xantelasma"
  },
  {
    "code" : "08.24",
    "display" : "ASPORTAZIONE DI LESIONE MAGGIORE DELLA PALPEBRA, A TUTTO SPESSORE. Asportazione che include un quarto o più del margine palpebrale a tutto spessore Resezione a cuneo della palpebra"
  },
  {
    "code" : "08.25",
    "display" : "DEMOLIZIONE DI LESIONE DELLA PALPEBRA. Intervento per blefarocalasi"
  },
  {
    "code" : "08.38",
    "display" : "CORREZIONE DI RETRAZIONE DELLA PALPEBRA"
  },
  {
    "code" : "08.42",
    "display" : "RIPARAZIONE DI ENTROPION O ECTROPION CON TECNICA DI SUTURA"
  },
  {
    "code" : "08.43",
    "display" : "RIPARAZIONE DI ENTROPION O ECTROPION CON RESEZIONE CUNEIFORME"
  },
  {
    "code" : "08.44",
    "display" : "RIPARAZIONE DI ENTROPION O ECTROPION CON RICOSTRUZIONE DELLA PALPEBRA. Riparazione di ectropion con innesto o lembo"
  },
  {
    "code" : "08.51",
    "display" : "CANTOTOMIA"
  },
  {
    "code" : "08.52",
    "display" : "BLEFARORRAFIA. Cantorrafia, Tarsorrafia"
  },
  {
    "code" : "08.6",
    "display" : "RICOSTRUZIONE DELLA PALPEBRA CON LEMBO O INNESTO Escluso: le ricostruzioni associate a riparazione di entropion o ectropion (08.44) e la ricostruzione della palpebra non a tutto spessore (08.72)"
  },
  {
    "code" : "08.72",
    "display" : "RICOSTRUZIONE DELLA PALPEBRA NON A TUTTO SPESSORE. Escluso: RIPARAZIONE DI ENTROPION O ECTROPION CON RICOSTRUZIONE DELLA PALPEBRA (08.44) RICOSTRUZIONE DELLA PALPEBRA CON LEMBO O INNESTO (08.6)"
  },
  {
    "code" : "08.74",
    "display" : "RICOSTRUZIONE DELLA PALPEBRA A TUTTO SPESSORE. Escluso: RIPARAZIONE DI ENTROPION O ECTROPION CON RICOSTRUZIONE DELLA PALPEBRA (08.44) RICOSTRUZIONE DELLA PALPEBRA CON LEMBO O INNESTO (08.6)"
  },
  {
    "code" : "08.81",
    "display" : "RIPARAZIONE LINEARE DI LACERAZIONE DELLA PALPEBRA E DELLE SOPRACCIGLIA"
  },
  {
    "code" : "08.82",
    "display" : "RIPARAZIONE DI LACERAZIONE DELLA PALPEBRA NON A TUTTO SPESSORE"
  },
  {
    "code" : "08.84",
    "display" : "RIPARAZIONE DI LACERAZIONE DELLA PALPEBRA A TUTTO SPESSORE"
  },
  {
    "code" : "08.92",
    "display" : "DEPILAZIONE CRIOCHIRURGICA DELLA PALPEBRA"
  },
  {
    "code" : "08.99.2",
    "display" : "INFILTRAZIONE PALPEBRALE, PERIOCULARE, MUSCOLARE, ORBITARIA DI FARMACI. Incluso farmaco"
  },
  {
    "code" : "09.0",
    "display" : "INCISIONE DELLA GHIANDOLA LACRIMALE. Incisione di cisti lacrimale (con drenaggio)"
  },
  {
    "code" : "09.11",
    "display" : "BIOPSIA DELLA GHIANDOLA LACRIMALE"
  },
  {
    "code" : "09.12",
    "display" : "BIOPSIA DEL SACCO LACRIMALE"
  },
  {
    "code" : "09.19",
    "display" : "ANALISI DELLA SUPERFICIE OCULARE [test di Schirmer, break up time (BUT), esame con coloranti]. Escluso: Dacriocistografia (87.05), Rx del tessuto molle del dotto naso-lacrimale"
  },
  {
    "code" : "09.21",
    "display" : "ASPORTAZIONE DELLA GHIANDOLA LACRIMALE Escluso: Biopsia della ghiandola lacrimale (09.11)"
  },
  {
    "code" : "09.42",
    "display" : "SPECILLAZIONE DELLE VIE LACRIMALI Sondaggio meccanico delle vie lacrimari. Incluso: Rimozione di calcolo, dilatazione (intero trattamento)"
  },
  {
    "code" : "09.43",
    "display" : "ENDOSCOPIA DELLE VIE LACRIMALI. Incluso: Rimozione di calcolo, dilatazione"
  },
  {
    "code" : "09.44",
    "display" : "INTUBAZIONE E INSERIMENTO DI SONDINO O STENT NEL DOTTO NASO- LACRIMALE. Incluso: sondino"
  },
  {
    "code" : "09.51",
    "display" : "PLASTICA DEL PUNTO LACRIMALE"
  },
  {
    "code" : "09.53",
    "display" : "INCISIONE DEL SACCO LACRIMALE"
  },
  {
    "code" : "09.73",
    "display" : "PLASTICA O RIPARAZIONE DEI CANALICOLI LACRIMALI"
  },
  {
    "code" : "09.91",
    "display" : "INSERZIONE DI OCCLUSORE DEL PUNTO LACRIMALE PER RIDUZIONE DELLA PRODUZIONE LACRIMALE, OCCHIO SECCO, CHERATITI, LAGOFTALMO, SURFACE SYNDROME, CHERATITE PUNTATA. Incluso: obliterazione del punto lacrimale"
  },
  {
    "code" : "10.0",
    "display" : "RIMOZIONE DI CORPO ESTRANEO DALLA CONGIUNTIVA PER INCISIONE"
  },
  {
    "code" : "10.21",
    "display" : "BIOPSIA DELLA CONGIUNTIVA"
  },
  {
    "code" : "10.31",
    "display" : "ASPORTAZIONE/DEMOLIZIONE DI LESIONE O TESSUTO DELLA CONGIUNTIVA. Incluso: Asportazione pinguecola. Escluso: Biopsia della congiuntiva (10.21)"
  },
  {
    "code" : "10.4",
    "display" : "CONGIUNTIVOPLASTICA CON O SENZA INNESTO LIBERO"
  },
  {
    "code" : "10.6",
    "display" : "RIPARAZIONE DI LACERAZIONE DELLA CONGIUNTIVA"
  },
  {
    "code" : "10.91",
    "display" : "INIEZIONE SOTTOCONGIUNTIVALE. Incluso farmaco"
  },
  {
    "code" : "11.21",
    "display" : "CURETTAGE DELLA CORNEA PER STRISCIO O COLTURA"
  },
  {
    "code" : "11.22",
    "display" : "BIOPSIA DELLA CORNEA"
  },
  {
    "code" : "11.31",
    "display" : "ASPORTAZIONE / TRASPOSIZIONE DELLO PTERIGIUM"
  },
  {
    "code" : "11.43",
    "display" : "CRIOTERAPIA DI LESIONE DELLA CORNEA"
  },
  {
    "code" : "11.53.1",
    "display" : "RIPARAZIONE DI LACERAZIONE O FERITA DELLA CORNEA A TUTTO SPESSORE E NON A TUTTO SPESSORE"
  },
  {
    "code" : "11.75.1",
    "display" : "CHIRURGIA INCISIONALE DELLA CORNEA PER ASTIGMATISMI"
  },
  {
    "code" : "11.99.2",
    "display" : "CORREZIONE DEI VIZI DI REFRAZIONE Con laser a eccimeri (PRK) O LASEK/LASIK. Incluso: due visite di controllo 89.01.D"
  },
  {
    "code" : "11.99.3",
    "display" : "CORREZIONE DI ALTERAZIONI CORNEALI Con laser a eccimeri (PTK). Incluso: due visite di controllo 89.01.D"
  },
  {
    "code" : "11.99.5",
    "display" : "IMPRINTING CORNEO-CONGIUNTIVALE [Cross linking corneale]. Incluso: Visita ed esami pre intervento, intervento e visite di controllo entro i 12 mesi"
  },
  {
    "code" : "11.99.6",
    "display" : "ASPORTAZIONE SUTURA CORNEALE O CORNEOSCLERALE a seguito di intervento di cheratoplastica"
  },
  {
    "code" : "12.14",
    "display" : "IRIDECTOMIA CHIRURGICA Escluso: Iridectomia associata a estrazione di cataratta (13.64) e Iridotomia laser (12.41)"
  },
  {
    "code" : "12.22",
    "display" : "BIOPSIA CHIRURGICA DELL'IRIDE"
  },
  {
    "code" : "12.22.1",
    "display" : "AGOBIOPSIA IRIDE"
  },
  {
    "code" : "12.31",
    "display" : "LISI DI GONIOSINECHIE O ALTRE SINECHIE DEL SEGMENTO ANTERIORE MEDIANTE YAG-LASER"
  },
  {
    "code" : "12.35.1",
    "display" : "IRIDOPLASTICA/COREOPLASTICA"
  },
  {
    "code" : "12.41",
    "display" : "IRIDOTOMIA LASER. Escluso: Iridectomia chirurgica (12.14)"
  },
  {
    "code" : "12.59",
    "display" : "TRABECULOPLASTICA Mediante laser"
  },
  {
    "code" : "12.66",
    "display" : "REVISIONE POSTOPERATORIA DI INTERVENTI DI FISTOLIZZAZIONE DELLA SCLERA"
  },
  {
    "code" : "12.72",
    "display" : "CICLOCRIOTERAPIA"
  },
  {
    "code" : "12.73",
    "display" : "CICLOFOTOCOAGULAZIONE"
  },
  {
    "code" : "12.82",
    "display" : "RIPARAZIONE DI FISTOLA DELLA SCLERA"
  },
  {
    "code" : "12.84",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE DELLA SCLERA"
  },
  {
    "code" : "12.91",
    "display" : "SVUOTAMENTO DIAGNOSTICO O TERAPEUTICO DELLA CAMERA ANTERIORE"
  },
  {
    "code" : "12.92",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE NELLA CAMERA ANTERIORE. Incluso farmaco"
  },
  {
    "code" : "12.92.1",
    "display" : "INIEZIONE INTRAOCULARE DI SOSTANZE TERAPEUTICHE. Incluso farmaco"
  },
  {
    "code" : "13.41",
    "display" : "INTERVENTO DI CATARATTA SENZA IMPIANTO DI LENTE INTRAOCULARE. Incluso: Visita preintervento e visite di controllo, Biometria"
  },
  {
    "code" : "13.64",
    "display" : "CAPSULOTOMIA YAG-LASER PER CATARATTA SECONDARIA"
  },
  {
    "code" : "13.70.1",
    "display" : "INSERZIONE DI CRISTALLINO ARTIFICIALE A SCOPO REFRATTIVO (in occhio fachico). Incluso: Visita preintervento e visite di controllo, Biometria. Incluso cristallino"
  },
  {
    "code" : "13.71",
    "display" : "INTERVENTO DI CATARATTA CON IMPIANTO DI LENTE INTRAOCULARE. Incluso: Visita preintervento e visite di controllo, Biometria. Incluso lenti"
  },
  {
    "code" : "13.72",
    "display" : "IMPIANTO SECONDARIO DI CRISTALLINO ARTIFICIALE. Incluso: Visita preintervento e visite di controllo, Biometria"
  },
  {
    "code" : "13.8",
    "display" : "RIMOZIONE DI CRISTALLINO ARTIFICIALE IMPIANTATO"
  },
  {
    "code" : "14.22",
    "display" : "DEMOLIZIONE DI LESIONE CORIORETINICA MEDIANTE CRIOTERAPIA"
  },
  {
    "code" : "14.24",
    "display" : "FOTOCOAGULAZIONE PANRETINICA. Intero trattamento. Minimo tre sedute"
  },
  {
    "code" : "14.24.1",
    "display" : "TERAPIA FOTODINAMICA LASER PER IL TRATTAMENTO DI LESIONI RETINICHE CON VERTEPORFINA. Fino a 3 trattamenti/anno nello stesso occhio. Incluso farmaco"
  },
  {
    "code" : "14.24.2",
    "display" : "TERAPIA LASER DELLE PATOLOGIE VASCOLARI RETINICHE"
  },
  {
    "code" : "14.24.3",
    "display" : "DEMOLIZIONE DI LESIONE CORIORETINICA MEDIANTE LASER- FOTOCOAGULAZIONE"
  },
  {
    "code" : "14.29.1",
    "display" : "TERAPIA LASER E TERMOTERAPIA TRANSPUPILLARE (TTT) DELLE PATOLOGIE TUMORALI RETINO-COROIDEALI"
  },
  {
    "code" : "14.32",
    "display" : "RIPARAZIONE DI LACERAZIONE DELLA RETINA MEDIANTE CRIOTERAPIA"
  },
  {
    "code" : "14.34",
    "display" : "FOTOGOAGULAZIONE LASER DELLA RETINA"
  },
  {
    "code" : "14.59.1",
    "display" : "PNEUMORETINOPESSIA"
  },
  {
    "code" : "14.75",
    "display" : "INIEZIONE DI SOSTITUTI VITREALI (Sostanze tamponanti ab interno: perfluori, gas e/o oli di silicone. Incluse le sostanze"
  },
  {
    "code" : "14.79",
    "display" : "INIEZIONE INTRAVITREALE DI SOSTANZE TERAPEUTICHE. Incluso: Visita ed esami pre procedura. Escluso: costo del farmaco"
  },
  {
    "code" : "16.22",
    "display" : "AGOBIOPSIA ORBITARIA"
  },
  {
    "code" : "16.71",
    "display" : "RIMOZIONE / REINSERIMENTO DI PROTESI OCULARE (a scopo igienico)"
  },
  {
    "code" : "16.91",
    "display" : "INIEZIONE RETROBULBARE DI SOSTANZE TERAPEUTICHE Escluso: Iniezione di sostanza per contrasto radiografico, Iniezione otticociliare. Incluso farmaco"
  },
  {
    "code" : "18.02",
    "display" : "INCISIONE DEL CANALE UDITIVO ESTERNO E DEL PADIGLIONE AURICOLARE. Escluso: Rimozione di corpo estraneo intraluminale (98.11)"
  },
  {
    "code" : "18.12",
    "display" : "BIOPSIA DELL'ORECCHIO ESTERNO"
  },
  {
    "code" : "18.21",
    "display" : "ASPORTAZIONE DEL SENO PREAURICOLARE. Non associabile a ASPORTAZIONE O DEMOLIZIONE DI LESIONE DELL'ORECCHIO ESTERNO (18.29)"
  },
  {
    "code" : "18.29",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE DELL'ORECCHIO ESTERNO. Cauterizzazione Coagulazione Criochirurgia Curettage Elettrocoagulazione Enucleazione Asportazione di: residuo (appendice) preauricolare polipi, cisti. Escluso: Biopsia dell'orecchio esterno (18.12), Rimozione di cerume (96.52). Non associabile a 18.21"
  },
  {
    "code" : "18.31.1",
    "display" : "ASPORTAZIONE RADICALE DI NEOFORMAZIONE DELL'ORECCHIO ESTERNO"
  },
  {
    "code" : "19.4",
    "display" : "RIPOSIZIONAMENTO O ALTRA RIPARAZIONE DI PERFORAZIONE TRAUMATICA DELLA MEMBRANA TIMPANICA"
  },
  {
    "code" : "20.01",
    "display" : "MIRINGOTOMIA CON INSERZIONE DI TUBO [MIRINGOTOMIA]. Incluso: anestesia e drenaggio"
  },
  {
    "code" : "20.09.1",
    "display" : "MIRINGOCENTESI SENZA INSERZIONE DI TUBO"
  },
  {
    "code" : "20.31",
    "display" : "ELETTROCOCLEOGRAFIA"
  },
  {
    "code" : "20.32.1",
    "display" : "BIOPSIA DELL'ORECCHIO MEDIO"
  },
  {
    "code" : "20.39.1",
    "display" : "EMISSIONI OTOACUSTICHE"
  },
  {
    "code" : "20.8",
    "display" : "INTERVENTI SULLA TUBA DI EUSTACHIO. Cateterismo, Insufflazione (acido borico, acido salicilico), Intubazione, Politzerizzazione"
  },
  {
    "code" : "20.94",
    "display" : "INFILTRAZIONE TRANSTIMPANICA DI FARMACI IN OTOMICROSCOPIA. Incluso farmaco"
  },
  {
    "code" : "20.94.A",
    "display" : "MEDICAZIONE IN OTOMICROSCOPIA"
  },
  {
    "code" : "21.01",
    "display" : "CONTROLLO DI EPISTASSI MEDIANTE TAMPONAMENTO NASALE ANTERIORE"
  },
  {
    "code" : "21.02",
    "display" : "CONTROLLO DI EPISTASSI MEDIANTE TAMPONAMENTO NASALE POSTERIORE E ANTERIORE"
  },
  {
    "code" : "21.03",
    "display" : "CONTROLLO DI EPISTASSI MEDIANTE CAUTERIZZAZIONE E TAMPONAMENTO. Cura completa"
  },
  {
    "code" : "21.22",
    "display" : "BIOPSIA DEL NASO"
  },
  {
    "code" : "21.31",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE INTRANASALE"
  },
  {
    "code" : "21.69.1",
    "display" : "TURBINOPLASTICA [turbinectomia, frattura turbinati, decongestione chirurgica dei turbinati]"
  },
  {
    "code" : "21.71",
    "display" : "RIDUZIONE CHIUSA DI FRATTURA NASALE NON A CIELO APERTO. Incluso: Contenzione e sua rimozione"
  },
  {
    "code" : "21.88",
    "display" : "SETTOPLASTICA"
  },
  {
    "code" : "21.91",
    "display" : "LISI DI ADERENZE DEL NASO. Sinechia nasale"
  },
  {
    "code" : "22.01",
    "display" : "PUNTURA DEI SENI NASALI PER ASPIRAZIONE O LAVAGGIO. Drenaggio mascellare per via diameatica"
  },
  {
    "code" : "22.02",
    "display" : "ASPIRAZIONE O LAVAGGIO DEI SENI NASALI Non associabile a Puntura dei seni nasali per aspirazione o lavaggio (22.01)"
  },
  {
    "code" : "22.11",
    "display" : "BIOPSIA DEI SENI NASALI"
  },
  {
    "code" : "22.19.1",
    "display" : "ALTRI INTERVENTI SUI SENI NASALI PER VIA ENDOSCOPICA. Inclusa medicazione"
  },
  {
    "code" : "22.19.2",
    "display" : "MEDICAZIONE A GUIDA ENDOSCOPICA DEI SENI NASALI"
  },
  {
    "code" : "22.71.1",
    "display" : "CHIUSURA DI FISTOLA OROSINUSALE IMMEDIATA"
  },
  {
    "code" : "22.71.2",
    "display" : "CHIUSURA DI FISTOLA OROSINUSALE COMPLICATA"
  },
  {
    "code" : "23.01",
    "display" : "ESTRAZIONE DI DENTE DECIDUO Incluso: Anestesia"
  },
  {
    "code" : "23.09",
    "display" : "ESTRAZIONE DI DENTE PERMANENTE O RADICI. Estrazione di altro dente NAS. Incluso: Odontectomia revisione della cavità e sutura e Anestesia"
  },
  {
    "code" : "23.19",
    "display" : "ALTRA ESTRAZIONE CHIRURGICA DI DENTE O RADICI Odontectomia NAS, rimozione di dente incluso, allacciamento di dente incluso, germectomia,estrazione dentale con elevazione di lembo muco- periostale. Incluso: Anestesia"
  },
  {
    "code" : "23.20.1",
    "display" : "RICOSTRUZIONE DI DENTE FINO A DUE SUPERFICI. Incluso: otturazione ed incappucciamento diretto della polpa"
  },
  {
    "code" : "23.20.2",
    "display" : "RICOSTRUZIONE DI DENTE A TRE O PIU' SUPERFICI. Incluso:otturazione ed incappucciamento diretto della polpa"
  },
  {
    "code" : "23.20.3",
    "display" : "RICOSTRUZIONE DI DENTE O RADICE CON USO DI PERNI ENDOCANALARI PER TERAPIA CONSERVATIVA. Incluso: perno endocanalare"
  },
  {
    "code" : "23.3",
    "display" : "RICOSTRUZIONE PROTESICA PARZIALE (faccetta)"
  },
  {
    "code" : "23.41.1",
    "display" : "TRATTAMENTO PER APPLICAZIONE DI CORONA DEFINITIVA. Incluso rilevazione impronte"
  },
  {
    "code" : "23.41.3",
    "display" : "APPLICAZIONE DI PERNO ENDOCANALARE CON METODO INDIRETTO IN TERAPIA PROTESICA"
  },
  {
    "code" : "23.41.5",
    "display" : "APPLICAZIONE DI PERNO ENDOCANALARE CON METODO DIRETTO IN TERAPIA PROTESICA"
  },
  {
    "code" : "23.42.1",
    "display" : "TRATTAMENTO PER APPLICAZIONE DI PROTESI FISSA PROVVISORIA Incluso: rilevazione impronte ed inserimento di manufatto protesico (per singolo dente pilastro)"
  },
  {
    "code" : "23.42.2",
    "display" : "TRATTAMENTO PER APPLICAZIONE DI PROTESI FISSA DEFINITIVA. Incluso: rilevazione impronte ed inserimento di manufatto protesico (per singolo dente pilastro)"
  },
  {
    "code" : "23.43.1",
    "display" : "INSERZIONE DI PROTESI RIMOVIBILE TOTALE. Trattamento per applicazione protesi rimovibile completa. Incluso: rilevazione impronte ed inserimento del manufatto (Per arcata)"
  },
  {
    "code" : "23.43.2",
    "display" : "INSERZIONE DI PROTESI RIMOVIBILE PARZIALE. Trattamento per applicazione protesi rimovibile parziale Incluso: Eventuali attacchi di precisione (per arcata)"
  },
  {
    "code" : "23.43.6",
    "display" : "APPLICAZIONE DI PLACCA INTEROCCLUSALE DI SVINCOLO DI RIPOSIZIONAMENTO O DI STABILIZZAZIONE. Incluso: rilevazione impronte"
  },
  {
    "code" : "23.49.1",
    "display" : "MOLAGGIO SELETTIVO DEI DENTI. Per seduta"
  },
  {
    "code" : "23.5",
    "display" : "REIMPIANTO O RIDUZIONE DI ELEMENTI DENTARI O AVULSI O LUSSATI. Incluso: eventuale contenzione dentale"
  },
  {
    "code" : "23.50.1",
    "display" : "INCOLLAGGIO DI FRAMMENTO DENTALE FRATTURATO"
  },
  {
    "code" : "23.71.1",
    "display" : "TERAPIA CANALARE IN DENTE MONORADICOLATO Escluso: codici 23.20.1, 23.20.2"
  },
  {
    "code" : "23.71.2",
    "display" : "TERAPIA CANALARE IN DENTE PLURIRADICOLATO Escluso: codici 23.20.1, 23.20.2"
  },
  {
    "code" : "23.72.1",
    "display" : "APICIFICAZIONE Terapia canalare in dente ad apice immaturo. Fino ad un massimo di 10 sedute"
  },
  {
    "code" : "23.72.2",
    "display" : "APICOGENESI [PULPOTOMIA - INCAPPUCCIAMENTO DIRETTO]"
  },
  {
    "code" : "23.72.3",
    "display" : "PULPOTOMIA"
  },
  {
    "code" : "23.73",
    "display" : "APICECTOMIA. Incluso: Otturazione retrograda"
  },
  {
    "code" : "24.00.1",
    "display" : "GENGIVECTOMIA. (Per gruppo di 4 denti) Incluso: Innesto libero o peduncolato"
  },
  {
    "code" : "24.00.2",
    "display" : "CHIRURGIA ORALE RICOSTRUTTIVA. Incluso: Applicazione di materiale autologo, Osteoplastica. Per emiarcata. Incluso: CHIRURGIA PARODONTALE (24.20.1)"
  },
  {
    "code" : "24.00.3",
    "display" : "CHIRURGIA ORALE RICOSTRUTTIVA. Incluso: Applicazione di materiale alloplastico. Per emiarcata. Incluso: CHIRURGIA PARODONTALE (24.20.1) Non associabile a 24.00.2"
  },
  {
    "code" : "24.11",
    "display" : "BIOPSIA DELLA GENGIVA"
  },
  {
    "code" : "24.12",
    "display" : "BIOPSIA DELL'ALVEOLO"
  },
  {
    "code" : "24.19.1",
    "display" : "TRATTAMENTO IMMEDIATO DELLE URGENZE ODONTOSTOMATOLOGICHE. Incluso: Pulpotomia, Molaggio di irregolarità smalto-dentinali conseguente a frattura, Otturazione dentaria provvisoria con cementi temporanei(trattamento delle infezioni acute, emorragie, dolore acuto, fratture)"
  },
  {
    "code" : "24.20.1",
    "display" : "CHIRURGIA PARODONTALE Lembo di Widman modificato con levigatura radici e curettage tasche infraossee. Per emiarcata. Non associabile a 24.00.2 e 24.00.3"
  },
  {
    "code" : "24.31",
    "display" : "ASPORTAZIONE DI LESIONE O TESSUTO DELLA GENGIVA Asportazione di epulidi Escluso: Biopsia della gengiva (24.11), Asportazione di lesione odontogenica dei mascellari (24.4)"
  },
  {
    "code" : "24.39.1",
    "display" : "LEVIGATURA DELLE RADICI Levigatura di radici e/o curettage delle tasche parodontali a cielo coperto. Per emiarcata"
  },
  {
    "code" : "24.39.2",
    "display" : "INTERVENTO CHIRURGICO PREPROTESICO. Incluso: alveoloplastica. Per emiarcata"
  },
  {
    "code" : "24.4",
    "display" : "ASPORTAZIONE DI LESIONE ODONTOGENICA DEI MASCELLARI"
  },
  {
    "code" : "24.6",
    "display" : "ESPOSIZIONE CHIRURGICA DI DENTE INCLUSO"
  },
  {
    "code" : "24.70.1",
    "display" : "TRATTAMENTO ORTODONTICO CON APPARECCHI MOBILI. Escluso: Contenzione. Per massimo 6 mesi"
  },
  {
    "code" : "24.70.2",
    "display" : "TRATTAMENTO ORTODONTICO CON APPARECCHI FISSI. Escluso: Contenzione. Per massimo 6 mesi e non ripetibile"
  },
  {
    "code" : "24.80.1",
    "display" : "RIPARAZIONE DI APPARECCHIO ORTODONTICO"
  },
  {
    "code" : "24.80.2",
    "display" : "RIMOZIONE DI FERULE O DI BRACKETS ORTODONTICI"
  },
  {
    "code" : "24.80.3",
    "display" : "STABILIZZAZIONE E CONTENZIONE FINE TRATTAMENTO ORTODONTICO. Non associabile a 89.01.E"
  },
  {
    "code" : "25.01",
    "display" : "BIOPSIA [AGOBIOPSIA] DELLA LINGUA"
  },
  {
    "code" : "25.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE O TESSUTO DELLA LINGUA"
  },
  {
    "code" : "25.91",
    "display" : "FRENULOTOMIA E FRENULECTOMIA LINGUALE. Escluso: FRENULOTOMIA LABIALE (27.91)"
  },
  {
    "code" : "26.0",
    "display" : "INCISIONE DELLE GHIANDOLE O DOTTI SALIVARI. Asportazione di calcoli del dotto salivare"
  },
  {
    "code" : "26.11",
    "display" : "BIOPSIA [AGOBIOPSIA] DI GHIANDOLA O DOTTO SALIVARE"
  },
  {
    "code" : "26.91",
    "display" : "SPECILLAZIONE DI DOTTO SALIVARE"
  },
  {
    "code" : "27.00.1",
    "display" : "DRENAGGIO DELLA FACCIA E DEL PAVIMENTO DELLA BOCCA, DELLA REGIONE FACCIALE, REGIONE FASCIALE DELLA FACCIA, ANGINA DI LUDWIG (ascesso, ematoma) Escl.: drenaggio del tratto tireoglosso (06.09)"
  },
  {
    "code" : "27.00.2",
    "display" : "RIMOZIONE DRENAGGIO DELLA FACCIA E DEL PAVIMENTO DELLA BOCCA, DELLA REGIONE FACCIALE, REGIONE FASCIALE DELLA FACCIA, ANGINA DI LUDWIG (ascesso, ematoma)"
  },
  {
    "code" : "27.21",
    "display" : "BIOPSIA DEL PALATO OSSEO"
  },
  {
    "code" : "27.23",
    "display" : "BIOPSIA DEL LABBRO"
  },
  {
    "code" : "27.24",
    "display" : "BIOPSIA DEL CAVO ORALE. Esclusa: biopsia del labbro e delle ghiandole salivari"
  },
  {
    "code" : "27.31",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO DEL PALATO OSSEO"
  },
  {
    "code" : "27.41",
    "display" : "FRENULECTOMIA LABIALE Escluso: Sezione del frenulo labiale (27.91)"
  },
  {
    "code" : "27.43",
    "display" : "ASPORTAZIONE DI LESIONE O NEOFORMAZIONE DEL LABBRO"
  },
  {
    "code" : "27.49.1",
    "display" : "ASPORTAZIONE DI LESIONE O NEOFORMAZIONE DEL CAVO ORALE"
  },
  {
    "code" : "27.51",
    "display" : "SUTURA DI LACERAZIONE DEL LABBRO"
  },
  {
    "code" : "27.52",
    "display" : "SUTURA DI LACERAZIONE DI CAVO ORALE"
  },
  {
    "code" : "27.71",
    "display" : "INCISIONE DELL' UGOLA"
  },
  {
    "code" : "27.72",
    "display" : "ASPORTAZIONE DELL'UGOLA"
  },
  {
    "code" : "27.79.1",
    "display" : "ALTRI INTERVENTI CONSERVATIVI SULL'UGOLA. Escluso: riparazione"
  },
  {
    "code" : "27.91",
    "display" : "FRENULOTOMIA LABIALE Sezione del frenulo labiale Escluso: Frenulotomia linguale (25.91)"
  },
  {
    "code" : "28.00.1",
    "display" : "INCISIONE E DRENAGGIO ASCESSO PERITONSILLARE"
  },
  {
    "code" : "28.91",
    "display" : "RIMOZIONE DI CORPO ESTRANEO DA TONSILLE E ADENOIDI MEDIANTE INCISIONE"
  },
  {
    "code" : "29.12",
    "display" : "BIOPSIA FARINGEA"
  },
  {
    "code" : "29.19.1",
    "display" : "VIDEOENDOSCOPIA DELLE VIE AEREE E DIGESTIVE SUPERIORI (VADS)"
  },
  {
    "code" : "31.42.2",
    "display" : "LARINGOSTROBOSCOPIA"
  },
  {
    "code" : "31.43",
    "display" : "BIOPSIA DELLA LARINGE. In laringoscopia indiretta o con fibre ottiche Incluso: Anestesia"
  },
  {
    "code" : "31.48.2",
    "display" : "ANALISI STRUMENTALE DELLA VOCE"
  },
  {
    "code" : "31.94.1",
    "display" : "INIEZIONE DI SOSTANZE ISPESSENTI NELLA PARETE DI FISTOLA TRACHEO- ESOFAGEA"
  },
  {
    "code" : "31.98.1",
    "display" : "SOSTITUZIONE DI PROTESI FONATORIA. Incluso: protesi"
  },
  {
    "code" : "33.21",
    "display" : "BRONCOSCOPIA ATTRAVERSO STOMA ARTIFICIALE"
  },
  {
    "code" : "33.22",
    "display" : "BRONCOSCOPIA [fibre-ottiche -autofluorescenza - Ebus]. Tracheobroncoscopia esplorativa"
  },
  {
    "code" : "33.24",
    "display" : "PRELIEVO BRONCHIALE IN CORSO DI BRONCOSCOPIA. Biopsia bronchiale, brushing, washing, BAL"
  },
  {
    "code" : "34.23",
    "display" : "BIOPSIA DELLA PARETE TORACICA TC-GUIDATA"
  },
  {
    "code" : "34.24",
    "display" : "BIOPSIA DELLA PLEURA. Biopsia con ago sottile TC guidata"
  },
  {
    "code" : "34.29",
    "display" : "AGOBIOPSIA ECOGUIDATA TRANSTRACHEALE O TRANSBRONCHIALE DI LINFONODI ILO MEDIASTINICI"
  },
  {
    "code" : "34.91",
    "display" : "TORACENTESI"
  },
  {
    "code" : "34.91.1",
    "display" : "TORACENTESI TC-guidata"
  },
  {
    "code" : "34.91.2",
    "display" : "TORACENTESI ECOGUIDATA"
  },
  {
    "code" : "34.92",
    "display" : "INIEZIONE NELLA CAVITA' TORACICA Pleurodesi chimica, iniezione di agente citotossico o tetraciclina. Incluso farmaco. Per eventuale chemioterapico antitumorale codificare anche 99.25. Escluso: Iniezione per collasso del polmone"
  },
  {
    "code" : "37.26.1",
    "display" : "ELETTROSTIMOLAZIONE TRANSESOFAGEA DIAGNOSTICA O PER LA TERAPIA DELLE ARITMIE"
  },
  {
    "code" : "37.79.1",
    "display" : "IMPIANTO DI LOOP RECORDER"
  },
  {
    "code" : "37.85",
    "display" : "SOSTITUZIONE DI PACE MAKER CON DISPOSITIVO A CAMERA SINGOLA, FREQUENZA DI RISPOSTA NON SPECIFICATA"
  },
  {
    "code" : "37.86",
    "display" : "SOSTITUZIONE DI PACE MAKER CON DISPOSITIVO A CAMERA SINGOLA, CON FREQUENZA DI RISPOSTA"
  },
  {
    "code" : "37.87",
    "display" : "SOSTITUZIONE DI PACE MAKER CON DISPOSITIVO A CAMERA DOPPIA"
  },
  {
    "code" : "38.00.1",
    "display" : "INCISIONE DI VENA SUPERFICIALE PER TROMBOFLEBITE O VARICOFLEBITE"
  },
  {
    "code" : "38.00.2",
    "display" : "INCISIONE DI VENA TROMBIZZATA DOPO SCLEROTERAPIA"
  },
  {
    "code" : "38.21",
    "display" : "BIOPSIA DEI VASI SANGUIGNI"
  },
  {
    "code" : "38.22.1",
    "display" : "CAPILLAROSCOPIA CON VIDEOREGISTRAZIONE"
  },
  {
    "code" : "38.50.1",
    "display" : "LEGATURA VENA PERFORANTE INCONTINENTE"
  },
  {
    "code" : "38.53",
    "display" : "ASPORTAZIONE DI VENE DELL'ARTO SUPERIORE"
  },
  {
    "code" : "38.59.1",
    "display" : "MINISTRIPPING [VARICECTOMIA] DI VENE VARICOSE DELL' ARTO INFERIORE. Stripping delle collaterali. Escluse le safene"
  },
  {
    "code" : "38.59.2",
    "display" : "DECONNESSIONE DEGLI SBOCCHI SAFENO-FEMORALE E SAFENO- POPLITEO. Escluso: trombosi dell'ostio"
  },
  {
    "code" : "38.80.1",
    "display" : "OCCLUSIONE PERCUTANEA DI VASI VENOSI PER VIA ENDOLUMINALE. Escluse safene"
  },
  {
    "code" : "38.93.1",
    "display" : "CATETERISMO VENOSO PER NUTRIZIONE PARENTERALE"
  },
  {
    "code" : "38.94.A",
    "display" : "RIMOZIONE DI CATETERE TUNNELLIZZATO. Asportazione di catetere tipo port o Groshong"
  },
  {
    "code" : "38.95.1",
    "display" : "POSIZIONAMENTO CATETERE VENOSO FEMORALE TEMPORANEO PER DIALISI RENALE. Inclusa eventuale guida ecografica"
  },
  {
    "code" : "38.95.2",
    "display" : "POSIZIONAMENTO CATETERE VENOSO FEMORALE PERMANENTE CON TUNNELLIZZAZIONE PER DIALISI RENALE. Inclusa eventuale guida ecografica"
  },
  {
    "code" : "38.95.3",
    "display" : "SOSTITUZIONE O RIMOZIONE DI CATETERE VENOSO FEMORALE TEMPORANEO PER DIALISI RENALE"
  },
  {
    "code" : "38.95.4",
    "display" : "SOSTITUZIONE O RIMOZIONE DI CATETERE VENOSO FEMORALE PERMANENTE CON TUNNELLIZZAZIONE PER DIALISI RENALE"
  },
  {
    "code" : "38.95.6",
    "display" : "POSIZIONAMENTO ECOGUIDATO DI CATETERE VENOSO CENTRALE TEMPORANEO PER DIALISI RENALE"
  },
  {
    "code" : "38.95.8",
    "display" : "POSIZIONAMENTO ECOGUIDATO DI CATETERE VENOSO CENTRALE PERMANENTE PER DIALISI RENALE CON TUNNELLIZZAZIONE"
  },
  {
    "code" : "38.95.9",
    "display" : "POSIZIONAMENTO DI CATETERE VENOSO CENTRALE PERMANENTE UNICO PER DIALISI EXTRACORPOREA CON TUNNELLIZZAZIONE"
  },
  {
    "code" : "38.95.A",
    "display" : "POSIZIONAMENTO DI CATETERE VENOSO CENTRALE PERMANENTE DOPPIO PER DIALISI EXTRACORPOREA CON TUNNELLIZZAZIONE"
  },
  {
    "code" : "38.97",
    "display" : "POSIZIONAMENTO DI CATETERE VENOSO CENTRALE O DI DOPPIO CATETERE GIUGULARE O FEMORALE [Catetere a permanenza, con pompa del paziente (PCA), con tunnel, con port].Incluso: radiografia di controllo"
  },
  {
    "code" : "38.97.1",
    "display" : "INSERZIONE DI CATETERE VENOSO CENTRALE CON ACCESSO CHIRURGICO. Incluso: radiografia di controllo"
  },
  {
    "code" : "38.97.2",
    "display" : "INSERZIONE DI CATETERE VENOSO CENTRALE PER VIA PERCUTANEA. Incluso: radiografia di controllo"
  },
  {
    "code" : "39.27",
    "display" : "CONFEZIONAMENTO DI FISTOLA PERIFERICA ARTEROVENOSA PER DIALISI RENALE"
  },
  {
    "code" : "39.27.1",
    "display" : "CONFEZIONAMENTO DI FISTOLA PROSSIMALE ARTEROVENOSA PER DIALISI RENALE"
  },
  {
    "code" : "39.42",
    "display" : "REVISIONE DI FISTOLA PERIFERICA ARTEROVENOSA PER DIALISI RENALE"
  },
  {
    "code" : "39.43",
    "display" : "CHIUSURA DI FISTOLA PERIFERICA ARTEROVENOSA PER DIALISI RENALE"
  },
  {
    "code" : "39.92.1",
    "display" : "INIEZIONE INTRAVENOSA DI SOSTANZE SCLEROSANTI. Escluso: Alcolizzazioni, Iniezioni per varici esofagee, emorroidi (49.42), malformazioni vascolari congenite, teleangectasie"
  },
  {
    "code" : "39.92.2",
    "display" : "INIEZIONE INTRAVENOSA ECO/FLEBOGUIDATA DI SOSTANZE SCLEROSANTI. Escluso alcolizzazioni"
  },
  {
    "code" : "39.95.2",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SINTETICHE A BASSO ED ALTO FLUSSO AD ASSISTENZA LIMITATA. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.3",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SINTETICHE A BASSO ED ALTO FLUSSO, A DOMICILIO. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.4",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SINTETICHE A BASSO ED ALTO FLUSSO. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.5",
    "display" : "EMODIAFILTRAZIONE. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.6",
    "display" : "EMODIAFILTRAZIONE AD ASSISTENZA LIMITATA. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.7",
    "display" : "ALTRA EMODIAFILTRAZIONE [Hemodia Filtration Reinfusion (HFR), Acetate Free Biofiltration (AFB), MID Dilution, MIXED Dilution]. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.8",
    "display" : "EMOFILTRAZIONE. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.B",
    "display" : "EMODIAFILTRAZIONE A DOMICILIO. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.C",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SPECIFICHE AD ASSISTENZA LIMITATA. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.D",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SINTETICHE A BASSO ED ALTO FLUSSO CON INFUSIONE DI NUTRIENTI AD ASSISTENZA LIMITATA Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.E",
    "display" : "TRAINING PER DIALISI PERITONEALE DOMICILIARE. Per seduta. Fino a 3 sedute"
  },
  {
    "code" : "39.95.F",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SPECIFICHE A DOMICILIO. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.G",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SPECIFICHE. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.H",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE SINTETICHE A BASSO ED ALTO FLUSSO CON INFUSIONE DI NUTRIENTI. Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.I",
    "display" : "EMODIALISI IN BICARBONATO E MEMBRANE AD ALTO/ALTISSIMO CUT- OFF (rimozione di soluti tossici di peso molecolare ≥ 45 kDa). Per seduta"
  },
  {
    "code" : "39.95.J",
    "display" : "EMODIAFILTRAZIONE- CON INFUSIONE DI NUTRIENTI"
  },
  {
    "code" : "39.95.K",
    "display" : "EMODIAFILTRAZIONE E MEMBRANE AD ALTO/ALTISSIMO CUT-OFF (rimozione di soluti tossici di peso molecolare ≥ 45 kDa). Per seduta"
  },
  {
    "code" : "39.95.L",
    "display" : "ALTRA EMODIAFILTRAZIONE AD ASSISTENZA LIMITATA. EMODIAFILTRAZIONE CON ULTRAFILTRATO > 17 LT. [Hemodia Filtration Reinfusion (HFR), Acetate Free Biofiltration (AFB), MID Dilution, MIXED Dilution] Per seduta. Ciclo fino a 13 sedute."
  },
  {
    "code" : "39.95.M",
    "display" : "EMODIAFILTRAZIONE AD ASSISTENZA LIMITATA - CON INFUSIONE DI NUTRIENTI Per seduta. Ciclo fino a 13 sedute"
  },
  {
    "code" : "39.95.N",
    "display" : "EMOFILTRAZIONE AD ASSISTENZA LIMITATA. Per seduta. Ciclo fino a 13 sedute."
  },
  {
    "code" : "39.95.O",
    "display" : "EMODIALISI GIORNALIERA DOMICILIARE PER ALMENO 12 ORE SETTIMANALI. Per seduta"
  },
  {
    "code" : "39.95.P",
    "display" : "EMODIALISI HIGH DOSE DOMICILIARE PER ALMENO 21 ORE SETTIMANALI. Per seduta"
  },
  {
    "code" : "39.95.Q",
    "display" : "ULTRAFILTRAZIONE/EMODIALISI IN PAZIENTE CON SCOMPENSO CARDIACO"
  },
  {
    "code" : "39.99.1",
    "display" : "VALUTAZIONE DEL RICIRCOLO DI FISTOLA ARTEROVENOSA"
  },
  {
    "code" : "39.99.2",
    "display" : "DISOSTRUZIONE CON TROMBOLITICI DI FISTOLA ARTEROVENOSA (CON UROCHINASI E/O rTPA)"
  },
  {
    "code" : "39.99.3",
    "display" : "DISOSTRUZIONE DI CATETERE VENOSO CENTRALE O DI DOPPIO CATETERE GIUGULARE O FEMORALE. Incluso: Sostituzione kit innesto"
  },
  {
    "code" : "39.99.4",
    "display" : "VALUTAZIONE DELLA PORTATA DELLA FISTOLA ARTEROVENOSA"
  },
  {
    "code" : "39.99.5",
    "display" : "ECODOPPLER FISTOLA ARTEROVENOSA"
  },
  {
    "code" : "39.99.6",
    "display" : "TERAPIA INTRALUMINALE LOCALE DEL CATETERE (LOCK THERAPY)"
  },
  {
    "code" : "40.11.1",
    "display" : "BIOPSIA INCISIONALE DI STRUTTURE LINFATICHE. Biopsia di linfonodi cervicali superficiali, sopraclaveari o prescalenici. Biopsia di linfonodi ascellari o inguinali"
  },
  {
    "code" : "40.11.2",
    "display" : "BIOPSIA ESCISSIONALE DI SINGOLO LINFONODO ASCELLARE O INGUINALE"
  },
  {
    "code" : "40.19.1",
    "display" : "AGOBIOPSIA LINFONODALE ECOGUIDATA"
  },
  {
    "code" : "40.19.2",
    "display" : "AGOBIOPSIA LINFONODALE TC-GUIDATA"
  },
  {
    "code" : "40.29",
    "display" : "ASPORTAZIONE SEMPLICE DI ALTRE STRUTTURE LINFATICHE. Asportazione di Igroma cistico, Linfangioma. Escluso: Linfadenectomia singola"
  },
  {
    "code" : "41.31",
    "display" : "BIOPSIA [AGOBIOPSIA] DEL MIDOLLO OSSEO"
  },
  {
    "code" : "42.24",
    "display" : "ESOFAGOGASTRODUODENOSCOPIA [EGDS] CON BIOPSIA DELL'ESOFAGO. Non associabile a 42.24.1"
  },
  {
    "code" : "42.24.1",
    "display" : "BIOPSIA DELL' ESOFAGO IN CORSO DI EGDS Brushing e/o washing per raccolta di campione Non associabile a 45.16.1 e 45.16.2"
  },
  {
    "code" : "42.29.2",
    "display" : "pH METRIA ESOFAGEA (24 ORE)"
  },
  {
    "code" : "42.29.3",
    "display" : "pH-METRIA TELEMETRICA"
  },
  {
    "code" : "42.29.4",
    "display" : "IMPEDENZIOMETRIA ESOFAGEA (24 ORE)"
  },
  {
    "code" : "42.33.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE O TESSUTO ESOFAGEO in corso di EGDS: polipectomia esofagea e/o mucosectomia. Escluso: Biopsia dell' esofago in corso di EGDS (42.24.1)"
  },
  {
    "code" : "42.33.2",
    "display" : "ASPORTAZIONE DI LESIONE O TESSUTO ESOFAGEO O RICANALIZZAZIONE ENDOSCOPICA Mediante laser o Argon Plasma. Incluso: EGDS (45.13). Escluso: biopsia dell'esofago in corso di EGDS (42.24.1)"
  },
  {
    "code" : "42.33.3",
    "display" : "SCLEROTERAPIA DI VARICI ESOFAGEE IN CORSO DI EGDS (45.13)"
  },
  {
    "code" : "42.33.4",
    "display" : "LEGATURE DI VARICI ESOFAGEE IN CORSO DI EGDS (45.13)"
  },
  {
    "code" : "42.92.1",
    "display" : "DILATAZIONE DELL'ESOFAGO Incluso: EGDS (45.13)"
  },
  {
    "code" : "42.93",
    "display" : "INIEZIONE PERENDOSCOPICA DI TOSSINA BOTULINICA"
  },
  {
    "code" : "43.11.1",
    "display" : "SOSTITUZIONE GASTROSTOMIA E/O DIGIUNOSTOMIA PERCUTANEA"
  },
  {
    "code" : "43.41.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO DELLO STOMACO IN CORSO DI EGDS. Polipectomia gastrica e/o mucosectomia. Escluso: Biopsia dello stomaco in corso di EGDS (44.14). Incluso: Controllo di emorragia"
  },
  {
    "code" : "43.41.2",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO DELLO STOMACO Incluso: EGDS (45.13) e Controllo di emorragia. Mediante laser o Argon Plasma. Escluso: Biopsia dello stomaco in corso di EGDS (44.14)"
  },
  {
    "code" : "44.14",
    "display" : "BIOPSIA DELLO STOMACO IN CORSO DI EGDS. Brushing e/o washing per prelievo di campione. Escluso: Esofagogastroduodenoscopia [EGDS] con biopsia (45.16.1 e 45.16.2)"
  },
  {
    "code" : "44.14.1",
    "display" : "BIOPSIA TRANSPARIETALE [ECOENDOSCOPICA] ESOFAGOGASTRODUODENALE. Non associabile a: 45.14.1, 45.14.2, 45.14.3; 45.16.1; 45.16.2; 44.19.3"
  },
  {
    "code" : "44.19.2",
    "display" : "BREATH TEST PER HELICOBACTER PYLORI (UREA C13). Compresa somministrazione Urea C13"
  },
  {
    "code" : "44.19.3",
    "display" : "ECOENDOSCOPIA ESOFAGOGASTRODUODENALE Non associabile a 45.13, 44.14.1"
  },
  {
    "code" : "44.22.1",
    "display" : "DILATAZIONE ENDOSCOPICA DELLO STOMACO, DEL PILORO. Incluso: EGDS (45.13)"
  },
  {
    "code" : "44.93.1",
    "display" : "POSIZIONAMENTO DI PALLONE INTRAGASTRICO"
  },
  {
    "code" : "44.94.1",
    "display" : "RIMOZIONE DI PALLONE INTRAGASTRICO"
  },
  {
    "code" : "45.13",
    "display" : "ESOFAGOGASTRODUODENOSCOPIA [EGDS]. Non associabile a Esofagogastroduodenoscopia con biopsia in sede unica (45.16.1), Esofagogastroduodenoscopia con biopsia in sede multipla (45.16.2)"
  },
  {
    "code" : "45.13.1",
    "display" : "ENTEROSCOPIA CON MICROCAMERA INGERIBILE"
  },
  {
    "code" : "45.13.2",
    "display" : "ENTEROSCOPIA PER VIA ANTEROGRADA"
  },
  {
    "code" : "45.13.3",
    "display" : "ENTEROSCOPIA PER VIA ANTEROGRADA CON BIOPSIA"
  },
  {
    "code" : "45.14.1",
    "display" : "BIOPSIA DEL DUODENO IN CORSO DI EGDS Brushing o washing per prelievo di campione Non associabile a Esofagogastroduodenoscopia [EGDS] con biopsia (45.16.1;45.16.2)"
  },
  {
    "code" : "45.14.2",
    "display" : "BIOPSIA DELL' INTESTINUO TENUE IN CORSO DI ENTEROSCOPIA Brushing e/o washing per prelievo di campione. Non associabile a Esofagogastroduodenoscopia [EGDS] con biopsia (45.16.1, 45.16.2)"
  },
  {
    "code" : "45.14.3",
    "display" : "BIOPSIA IN SEDE MULTIPLA IN CORSO DI ILEOCOLONSCOPIA RETROGRADA"
  },
  {
    "code" : "45.16.1",
    "display" : "ESOFAGOGASTRODUODENOSCOPIA [EGDS] CON BIOPSIA IN SEDE UNICA. Non associabile a: Biopsia dell'esofago (42.24 E 42.24.1); Biopsia dello stomaco (44.14); Biopsia del duodeno (45.14.1)"
  },
  {
    "code" : "45.16.2",
    "display" : "ESOFAGOGASTRODUODENOSCOPIA [EGDS] CON BIOPSIA IN SEDE MULTIPLA. Non associabile a: Biopsia dell'esofago (42.24 e 42.24.1); Biopsia dello stomaco (44.14); Biopsia del duodeno (45.14.1)"
  },
  {
    "code" : "45.19.1",
    "display" : "MARCATURA DI LESIONE DEL TUBO DIGERENTE IN CORSO DI EGDS (45.13) O RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE (45.24) O COLONSCOPIA TOTALE CON ENDOSCOPIO FLESSIBILE (45.23)"
  },
  {
    "code" : "45.19.2",
    "display" : "COLORAZIONI VITALI IN CORSO DI EGDS (45.13) O RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE (45.24) O COLONSCOPIA TOTALE CON ENDOSCOPIO FLESSIBILE (45.23) O ILEOSCOPIA RETROGADA (45.23.1)"
  },
  {
    "code" : "45.23",
    "display" : "COLONSCOPIA TOTALE CON ENDOSCOPIO FLESSIBILE. Escluso: RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE (45.24), PROCTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO (48.23)"
  },
  {
    "code" : "45.23.1",
    "display" : "ILEOCOLONSCOPIA RETROGRADA"
  },
  {
    "code" : "45.23.2",
    "display" : "ILEOCOLONSCOPIA RETROGRADA CON BIOPSIA"
  },
  {
    "code" : "45.23.3",
    "display" : "COLONSCOPIA TOTALE CON BIOPSIA IN SEDE UNICA per singolo segmento di colon. Escluso: i tratti parziali e le biopsie in sede unica"
  },
  {
    "code" : "45.23.4",
    "display" : "COLONSCOPIA TOTALE CON BIOPSIA IN SEDE MULTIPLA per più segmenti di colon. Escluso: i tratti parziali e le biopsie in sede multipla"
  },
  {
    "code" : "45.24",
    "display" : "RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE. Endoscopia del colon discendente . Escluso: Proctosigmoidoscopia con endoscopio rigido (48.23)"
  },
  {
    "code" : "45.24.1",
    "display" : "RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE CON BIOPSIA IN SEDE UNICA. Endoscopia del colon discendente. scluso: Proctosigmoidoscopia con endoscopio rigido (48.23)"
  },
  {
    "code" : "45.24.2",
    "display" : "RETTOSIGMOIDOSCOPIA CON ENDOSCOPIO FLESSIBILE CON BIOPSIA IN SEDE MULTIPLA. Endoscopia del colon discendente. Escluso: Proctosigmoidoscopia con endoscopio rigido (48.23)"
  },
  {
    "code" : "45.25",
    "display" : "BIOPSIA IN SEDE UNICA DELL' INTESTINO CRASSO IN CORSO DI COLONSCOPIA TOTALE CON TUBO FLESSIBILE. Brushing o washing per prelievo di campione. Escluso: BIOPSIA IN CORSO DI PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO (48.24)"
  },
  {
    "code" : "45.25.1",
    "display" : "BIOPSIA IN SEDE MULTIPLA DELL' INTESTINO CRASSO IN CORSO DI COLONSCOPIA TOTALE CON TUBO FLESSIBILE. Brushing e/o washing per prelievo di campione. Escluso: BIOPSIA IN CORSO DI PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO (48.24)"
  },
  {
    "code" : "45.25.2",
    "display" : "BIOPSIA SEDE UNICA IN CORSO DI RETTOSIGMOIDOSCOPIA"
  },
  {
    "code" : "45.25.3",
    "display" : "BIOPSIA SEDE MULTIPLA IN CORSO DI RETTOSIGMOIDOSCOPIA"
  },
  {
    "code" : "45.26.1",
    "display" : "BIOPSIA TRANSPARIETALE [ECOENDOSCOPICA] DEL COLON Non associabile a 45.25, 45.25.1 45.25.2 e 45.25.3. Incluso: Ecoendoscopia del colon (45.29.5)"
  },
  {
    "code" : "45.29.1",
    "display" : "BREATH TEST PER DETERMINAZIONE TEMPO DI TRANSITO INTESTINALE, SVUOTAMENTO GASTRICO"
  },
  {
    "code" : "45.29.2",
    "display" : "BREATH TEST PER DETERMINAZIONE DI COLONIZZAZIONE BATTERICA ANOMALA"
  },
  {
    "code" : "45.29.3",
    "display" : "BREATH TEST PER INTOLLERANZA AL LATTOSIO"
  },
  {
    "code" : "45.29.5",
    "display" : "ECOENDOSCOPIA DEL COLON. Non associabile a 45.23, 45.23.1, 45.24, 45.26.1"
  },
  {
    "code" : "45.29.6",
    "display" : "BREATH TEST PER LO STUDIO DELLA FUNZIONALITA' EPATICA"
  },
  {
    "code" : "45.29.7",
    "display" : "BREATH TEST PER LO STUDIO DELLA FUNZIONALITA' PANCREATICA"
  },
  {
    "code" : "45.29.8",
    "display" : "TEST DI PERMEABILITA' INTESTINALE"
  },
  {
    "code" : "45.30.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE DEL DUODENO IN CORSO DI EGDS Polipectomia e/o mucosectomia. Escluso: Biopsia del Duodeno (45.14.1)"
  },
  {
    "code" : "45.30.2",
    "display" : "ASPORTAZIONE DI LESIONE O TESSUTO DUODENALE O RICANALIZZAZIONE ENDOSCOPICA Mediante laser o Argon Plasma. Incluso: EGDS (45.13). Escluso: Biopsia del duodeno (45.14.1)"
  },
  {
    "code" : "45.42",
    "display" : "POLIPECTOMIA DELL' INTESTINO CRASSO IN CORSO DI ENDOSCOPIA SEDE UNICA. Polipectomia di uno o più polipi"
  },
  {
    "code" : "45.42.1",
    "display" : "POLIPECTOMIA DELL' INTESTINO CRASSO IN CORSO DI ENDOSCOPIA SEDE MULTIPLA. Polipectomia di uno o più polipi"
  },
  {
    "code" : "45.42.2",
    "display" : "MUCOSECTOMIA DELL'INTESTINO CRASSO IN CORSO DI ENDOSCOPIA"
  },
  {
    "code" : "45.43.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO DELL' INTESTINO CRASSO PER VIA ENDOSCOPICA . Mediante laser o Argon Plasma. Incluso: Controllo di emorragia. Escluso: Politectomia dell'intestino crasso in corso di endoscopia sede unica (45.42); Polipectomia dell'intestino crasso in corso di endoscopia sede multipla (45.42.1)"
  },
  {
    "code" : "46.85.1",
    "display" : "DILATAZIONE DELL'INTESTINO Incluso: Colonscopia Totale con endoscopio flessibile (45.23) e Retto-sigmoidoscopia con endoscopio flessibile (45.24)"
  },
  {
    "code" : "48.23",
    "display" : "PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO. Escluso: Rettosigmoidoscopia con endoscopio flessibile (45.24)"
  },
  {
    "code" : "48.23.1",
    "display" : "PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO CON BIOPSIA. Escluso: Rettosigmoidoscopia con endoscopio flessibile (45.24)"
  },
  {
    "code" : "48.24",
    "display" : "BIOPSIA IN CORSO DI PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO"
  },
  {
    "code" : "48.24.1",
    "display" : "BIOPSIA TRANSPARIETALE [ECOENDOSCOPICA] DEL RETTO-SIGMA Non associabile a 48.24"
  },
  {
    "code" : "48.29.1",
    "display" : "MANOMETRIA ANO-RETTALE"
  },
  {
    "code" : "48.29.2",
    "display" : "ECOENDOSCOPIA DEL RETTO-SIGMA Non associabile a PROCTORETTOSIGMOIDOSCOPIA CON ENDOSCOPIO RIGIDO (48.23); Ecoendoscopia del colon (45.29.5); Biopsia [ecoendoscopica] del retto- sigma (48.24.1)"
  },
  {
    "code" : "49.01",
    "display" : "INCISIONE DI ASCESSO PERIANALE"
  },
  {
    "code" : "49.02",
    "display" : "INCISIONE DI TESSUTI PERIANALI"
  },
  {
    "code" : "49.04",
    "display" : "ASPORTAZIONE DI TESSUTI PERIANALI"
  },
  {
    "code" : "49.11",
    "display" : "FISTULOTOMIA ANALE Extrasfinterica"
  },
  {
    "code" : "49.21",
    "display" : "ANOSCOPIA"
  },
  {
    "code" : "49.23",
    "display" : "BIOPSIA DELL' ANO E DEI TESSUTI PERIANALI"
  },
  {
    "code" : "49.39",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO DELL'ANO"
  },
  {
    "code" : "49.41",
    "display" : "RIDUZIONE DI EMORROIDI"
  },
  {
    "code" : "49.42",
    "display" : "INIEZIONI SCLEROSANTI DELLE EMORROIDI"
  },
  {
    "code" : "49.44",
    "display" : "TRATTAMENTO CRIOTERAPICO DI EMORROIDI"
  },
  {
    "code" : "49.45",
    "display" : "LEGATURA ELASTICA DELLE EMORROIDI"
  },
  {
    "code" : "49.47",
    "display" : "RIMOZIONE DI EMORROIDI TROMBIZZATE [Trombectomia]"
  },
  {
    "code" : "49.49.1",
    "display" : "TRATTAMENTO DI EMORROIDI CON FOTOCOAGULAZIONE"
  },
  {
    "code" : "49.59",
    "display" : "SFINTEROTOMIA ANALE. Divisione interna di sfintere"
  },
  {
    "code" : "50.11",
    "display" : "AGOBIOPSIA PERCUTANEA O AGOASPIRATO DEL FEGATO ECOGUIDATA. Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "50.19.1",
    "display" : "AGOBIOPSIA PERCUTANEA O AGOASPIRATO DEL FEGATO TC GUIDATA. Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "50.91.1",
    "display" : "ASPIRAZIONE PERCUTANEA DI CISTI DEL FEGATO ECOGUIDATA.Escluso: Agobiopsia percutanea (50.11). Non associabile all'ecografia del fegato con mezzo di contrasto (88.79.H)"
  },
  {
    "code" : "50.91.2",
    "display" : "ALCOLIZZAZIONE PERCUTANEA ECOGUIDATA DI NODULI DEL FEGATO. Escluso: Agobiopsia percutanea (50.11). Non associabile all'ecografia del fegato con mezzo di contrasto (88.79.H)"
  },
  {
    "code" : "51.14.1",
    "display" : "BIOPSIA ENDOSCOPICA DELL'ALBERO BILIARE O DELLO SFINTERE DI ODDI"
  },
  {
    "code" : "52.13",
    "display" : "ECOENDOSCOPIA BILIOPANCREATICA"
  },
  {
    "code" : "52.14",
    "display" : "BIOPSIA TRANSPARIETALE [ECOENDOSCOPICA] BILIOPANCREATICA"
  },
  {
    "code" : "53.00.1",
    "display" : "RIPARAZIONE MONOLATERALE DI ERNIA INGUINALE DIRETTA O INDIRETTA. Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "53.00.2",
    "display" : "RIPARAZIONE MONOLATERALE DI ERNIA INGUINALE CON INNESTO O PROTESI DIRETTA O INDIRETTA..Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "53.21.1",
    "display" : "RIPARAZIONE MONOLATERALE DI ERNIA CRURALE CON INNESTO O PROTESI. Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "53.29.1",
    "display" : "RIPARAZIONE MONOLATERALE DI ERNIA CRURALE. Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "53.41",
    "display" : "RIPARAZIONE DI ERNIA OMBELICALE CON PROTESI. Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "53.49.1",
    "display" : "RIPARAZIONE DI ERNIA OMBELICALE. Incluso: Visita anestesiologica, ECG, esami di laboratorio, Visita post intervento"
  },
  {
    "code" : "54.00",
    "display" : "INCISIONE/DRENAGGIO DELLA PARETE ADDOMINALE"
  },
  {
    "code" : "54.22",
    "display" : "BIOPSIA DELLA PARETE ADDOMINALE O DELL' OMBELICO"
  },
  {
    "code" : "54.24.1",
    "display" : "BIOPSIA [PERCUTANEA][AGOBIOPSIA] ECOGUIDATA DI MASSA INTRADDOMINALE Escluso: Agobiopsia di tube di Fallopio, ovaio (65.11.1), peritoneo, legamenti dell' utero, utero (68.16.1)"
  },
  {
    "code" : "54.24.2",
    "display" : "BIOPSIA [PERCUTANEA][AGOBIOPSIA] TC-GUIDATA DI MASSA INTRADDOMINALE. Escluso: Agobiopsia di tube di Fallopio, ovaio (65.11.1), peritoneo, legamenti dell' utero, utero (68.16.1)"
  },
  {
    "code" : "54.91",
    "display" : "PARACENTESI. Escluso: Creazione di fistola cutaneoperitoneale (54.93)"
  },
  {
    "code" : "54.91.1",
    "display" : "DRENAGGIO TC-GUIDATO PERCUTANEO ADDOMINALE. Drenaggio delle regioni superficiali"
  },
  {
    "code" : "54.91.2",
    "display" : "DRENAGGIO ECO-GUIDATO PERCUTANEO ADDOMINALE. Drenaggio delle regioni superficiali"
  },
  {
    "code" : "54.93",
    "display" : "POSIZIONAMENTO DI CATETERE PERMANENTE PER DIALISI PERITONEALE. Incluso: Creazione di fistola cutaneoperitoneale"
  },
  {
    "code" : "54.93.1",
    "display" : "REVISIONE DI CATETERE PERITONEALE. Revisione di catetere per dialisi peritoneale, cambio set di connessione, sostituzione di parti di catetere"
  },
  {
    "code" : "54.93.2",
    "display" : "RIMOZIONE DI CATETERE PERITONEALE"
  },
  {
    "code" : "54.97",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE AD AZIONE LOCALE NELLA CAVITA' PERITONEALE. Incluso farmaco. Escluso: Dialisi peritoneale (da 54.98.1 a 54.98.7)"
  },
  {
    "code" : "54.98.1",
    "display" : "DIALISI PERITONEALE AUTOMATIZZATA (CCPD E/O APD) CON SOLUZIONI DI GLUCOSIO IPERTONICHE. Per seduta. Ciclo MENSILE"
  },
  {
    "code" : "54.98.2",
    "display" : "DIALISI PERITONEALE CONTINUA [CAPD] con addestramento. Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.3",
    "display" : "DIALISI PERITONEALE AUTOMATIZZATA (CCPD E/O APD) CON BICARBONATO E/O AGENTE OSMOTICO DIVERSO DAL GLUCOSIO. Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.4",
    "display" : "DIALISI PERITONEALE AUTOMATIZZATA (CCPD e/o APD). Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.5",
    "display" : "DIALISI PERITONEALE [CAPD] CON SOLUZIONI DI GLUCOSIO IPERTONICHE. Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.6",
    "display" : "DIALISI PERITONEALE CONTINUA [CAPD] con bicarbonato e/o agente osmotico diverso dal glucosio. Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.7",
    "display" : "DIALISI PERITONEALE INTERMITTENTE [IPD]. Per seduta. Ciclo mensile fino a 31 sedute"
  },
  {
    "code" : "54.98.8",
    "display" : "TEST DI EQUILIBRAZIONE PERITONEALE. Incluso: esami di laboratorio KT/V e ClCr/BSA"
  },
  {
    "code" : "54.98.A",
    "display" : "ULTRAFILTRAZIONE/DIALISI PERITONEALE IN PAZIENTE CON SCOMPENSO CARDIACO"
  },
  {
    "code" : "55.03",
    "display" : "NEFROSTOMIA PERCUTANEA SENZA FRAMMENTAZIONE"
  },
  {
    "code" : "55.92",
    "display" : "ASPIRAZIONE PERCUTANEA RENALE. Puntura di cisti renale con o senza sclerotizzazione"
  },
  {
    "code" : "55.93",
    "display" : "SOSTITUZIONE DI CATETERE NEFROSTOMICO"
  },
  {
    "code" : "56.62",
    "display" : "REVISIONE DI URETEROCUTANEOSTOMIA"
  },
  {
    "code" : "57.17",
    "display" : "CISTOSTOMIA PERCUTANEA. Escluso: Rimozione di sonda cistostomica, Sostituzione di sonda cistostomica, Cistotomia e cistostomia come approccio chirurgico"
  },
  {
    "code" : "57.32",
    "display" : "URETROCISTOSCOPIA Escluso: Cistoureteroscopia con biopsia ureterale, Pielografia retrograda della vescica, della prostata (87.74.1 e 87.74.2). Non associabile a Cateterizzazione ureterale (59.8)"
  },
  {
    "code" : "57.33",
    "display" : "URETROCISTOSCOPIA CON BIOPSIA"
  },
  {
    "code" : "57.39.2",
    "display" : "ESAME URODINAMICO INVASIVO. Incluso: Cistomanometria, Elettromiografia dello sfintere, Profilo pressorio uretrale, Holter"
  },
  {
    "code" : "57.94",
    "display" : "CATETERISMO VESCICALE. Incluso: lavaggio vescicale"
  },
  {
    "code" : "58.23",
    "display" : "BIOPSIA DELL' URETRA"
  },
  {
    "code" : "58.31",
    "display" : "ASPORTAZIONE O ELETTROCOAGULAZIONE DI LESIONE O TESSUTO DELL'URETRA. Asportazione di caruncola uretrale"
  },
  {
    "code" : "58.60.1",
    "display" : "DILATAZIONE URETRALE Dilatazione di giuntura uretrovescicale, passaggio di sonda attraverso l'uretra (Seduta unica)"
  },
  {
    "code" : "58.60.2",
    "display" : "DILATAZIONI URETRALI PROGRESSIVE. Per seduta"
  },
  {
    "code" : "58.60.3",
    "display" : "RIMOZIONE [ENDOSCOPICA] DI CALCOLO URETRALE E/O CORPO ESTRANEO"
  },
  {
    "code" : "59.8",
    "display" : "CATETERIZZAZIONE URETERALE. Drenaggio del rene con catetere, dilatazione dell'orifizio ureterovescicale. Escluso: Cateterizzazione per estrazione di calcolo renale, Pielografia retrograda (87.74.1 e 87.74.2). Non associabile a: Uretrocistoscopia (57.32)"
  },
  {
    "code" : "60.11",
    "display" : "AGOBIOPSIA ECOGUIDATA DELLA PROSTATA. Approccio transperineale o transrettale"
  },
  {
    "code" : "60.13",
    "display" : "AGOBIOPSIA ECOGUIDATA DELLE VESCICHETTE SEMINALI. Approccio transrettale o transperineale"
  },
  {
    "code" : "61.91",
    "display" : "PUNTURA EVACUATIVA DI IDROCELE DELLA TUNICA VAGINALE. Aspirazione percutanea della tunica vaginale"
  },
  {
    "code" : "62.11",
    "display" : "AGOASPIRATO GONADE MASCHILE. Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "63.52",
    "display" : "DEROTAZIONE MANUALE DEL FUNICOLO E DEL TESTICOLO. Escluso: quella associata ad orchidopessi"
  },
  {
    "code" : "63.71",
    "display" : "LEGATURA DEI DOTTI DEFERENTI"
  },
  {
    "code" : "63.99.1",
    "display" : "SCLEROTIZZAZIONE DI VARICOCELE"
  },
  {
    "code" : "64.0",
    "display" : "CIRCONCISIONE TERAPEUTICA"
  },
  {
    "code" : "64.11",
    "display" : "BIOPSIA DEL PENE"
  },
  {
    "code" : "64.2",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONE DEL PENE. Asportazione condilomi. Escluso: Biopsia del pene (64.11)"
  },
  {
    "code" : "64.92.1",
    "display" : "FRENULOTOMIA PREPUZIALE"
  },
  {
    "code" : "64.93",
    "display" : "LIBERAZIONE DI SINECHIE PENIENE"
  },
  {
    "code" : "65.11",
    "display" : "AGOASPIRAZIONE ECOGUIDATA DEI FOLLICOLI [Pick up ovocitario]. Prelievo ovociti. Inclusa valutazione ovocitaria. Incluso: eventuale congelamento e conservazione"
  },
  {
    "code" : "65.11.1",
    "display" : "BIOPSIA ASPIRATIVA DELL'OVAIO"
  },
  {
    "code" : "65.91",
    "display" : "AGOASPIRAZIONE DI CISTI DELL' OVAIO. Aspirazione dell'ovaio ecoguidata. Escluso: Biopsia aspirativa dell'ovaio (65.11.1)"
  },
  {
    "code" : "67.12",
    "display" : "BIOPSIA MIRATA ENDOCERVICALE A GUIDA ISTEROSCOPICA"
  },
  {
    "code" : "67.19.1",
    "display" : "BIOPSIA MIRATA DELLA PORTIO E DELL'ENDOCERVICE A GUIDA COLPOSCOPICA SU UNA O PIU' SEDI. Non associabile a COLPOSCOPIA (70.21)"
  },
  {
    "code" : "67.32",
    "display" : "DEMOLIZIONE/ESCISSIONE DI LESIONE DELLA CERVICE UTERINA. Asportazione polipi cervicali, Asportazione condilomi mediante Diatermocoagulazione, Crioterapia, Laserterapia"
  },
  {
    "code" : "67.32.1",
    "display" : "CONIZZAZIONE DELLA CERVICE UTERINA CON ANSA DIATERMICA O LASER A GUIDA COLPOSCOPICA"
  },
  {
    "code" : "68.12.1",
    "display" : "ISTEROSCOPIA DIAGNOSTICA CON O SENZA BIOPSIA DELL'ENDOMETRIO"
  },
  {
    "code" : "68.16.1",
    "display" : "BIOPSIA ENDOMETRIALE. Non associabile a 68.12.1 ISTEROSCOPIA DIAGNOSTICA CON O SENZA BIOPSIA DELL'ENDOMETRIO"
  },
  {
    "code" : "68.29.2",
    "display" : "ASPORTAZIONE POLIPI ENDOMETRIALI/MIOMI A GUIDA ISTEROSCOPICA"
  },
  {
    "code" : "69.7",
    "display" : "INSERZIONE DI DISPOSITIVO CONTRACCETTIVO INTRAUTERINO (I.U.D.)"
  },
  {
    "code" : "69.92.1",
    "display" : "CAPACITAZIONE DEL MATERIALE SEMINALE [SWIM UP]"
  },
  {
    "code" : "69.92.2",
    "display" : "FECONDAZIONE IN VITRO CON O SENZA INSEMINAZIONE INTRACITOPLASMATICA (ICSI) OMOLOGA. Incluso: coltura. Incluso: eventuale scongelamento."
  },
  {
    "code" : "69.92.3",
    "display" : "FECONDAZIONE IN VITRO CON O SENZA INSEMINAZIONE INTRACITOPLASMATICA (ICSI) ETEROLOGA CON OVOCITI A FRESCO. Incluso: coltura."
  },
  {
    "code" : "69.92.4",
    "display" : "AGOASPIRAZIONE TESTICOLARE (TESA). Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "69.92.5",
    "display" : "TRASFERIMENTO EMBRIONI (ET). Inclusa: valutazione embrionaria pre- transfer. Escluso: per via laparoscopica"
  },
  {
    "code" : "69.92.6",
    "display" : "TRASFERIMENTO DI GAMETI INTRATUBARICO. Escluso: per via laparoscopica"
  },
  {
    "code" : "69.92.7",
    "display" : "FECONDAZIONE IN VITRO CON O SENZA INSEMINAZIONE INTRACITOPLASMATICA (ICSI) ETEROLOGA CON OVOCITI CONGELATI. Incluso: coltura. Incluso: scongelamento."
  },
  {
    "code" : "69.92.8",
    "display" : "FECONDAZIONE IN VITRO CON O SENZA INSEMINAZIONE INTRACITOPLASMATICA (ICSI) ETEROLOGA CON GAMETI MASCHILI. Incluso: coltura. Incluso: eventuale scongelamento."
  },
  {
    "code" : "69.92.9",
    "display" : "INSEMINAZIONE INTRAUTERINA [IUI] DA DONAZIONE DI GAMETI MASCHILI"
  },
  {
    "code" : "69.92.A",
    "display" : "INSEMINAZIONE INTRAUTERINA [IUI] OMOLOGA"
  },
  {
    "code" : "69.92.B",
    "display" : "CRIOCONSERVAZIONE DI GAMETI MASCHILI"
  },
  {
    "code" : "70.21",
    "display" : "COLPOSCOPIA. Incluso: vulvoscopia. Non associabile a 67.19.1 BIOPSIA MIRATA DELLA PORTIO E DELL'ENDOCERVICE A GUIDA COLPOSCOPICA SU UNA O PIU' SEDI"
  },
  {
    "code" : "70.29.1",
    "display" : "BIOPSIA DELLE PARETI VAGINALI A GUIDA COLPOSCOPICA Non associabile a 70.21 COLPOSCOPIA. Incluso: vulvoscopia"
  },
  {
    "code" : "70.33.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONI DELLA VAGINA. Incluso: condilomi vaginali"
  },
  {
    "code" : "71.11",
    "display" : "BIOPSIA DELLA VULVA O DELLA CUTE PERINEALE con o senza vulvoscopia. Non associabile a COLPOSCOPIA (70.21). Incluso: vulvoscopia"
  },
  {
    "code" : "71.22",
    "display" : "INCISIONE E MARSUPIALIZZAZIONE DI ASCESSO O CISTI DELLA GHIANDOLA DEL BARTOLINO"
  },
  {
    "code" : "71.30.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI LESIONI VULVARI E PERINEALI INCLUSI CONDILOMI. Non associabile a 70.33.1 ASPORTAZIONE O DEMOLIZIONE DI LESIONI DELLA VAGINA e 67.32 DEMOLIZIONE/ESCISSIONE DI LESIONE DELLA CERVICE"
  },
  {
    "code" : "75.10.1",
    "display" : "PRELIEVO DEI VILLI CORIALI"
  },
  {
    "code" : "75.10.2",
    "display" : "AMNIOCENTESI"
  },
  {
    "code" : "75.33.1",
    "display" : "FUNICOLOCENTESI PER LA DIAGNOSI PRENATALE DI PATOLOGIE DEL FETO"
  },
  {
    "code" : "75.34.1",
    "display" : "CARDIOTOCOGRAFIA ESTERNA"
  },
  {
    "code" : "76.01",
    "display" : "SEQUESTRECTOMIA DI OSSO FACCIALE Rimozione di frammento osseo necrotico da osso della faccia"
  },
  {
    "code" : "76.2",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE DELLE OSSA FACCIALI Asportazione o marsupializzazione di cisti dei mascellari"
  },
  {
    "code" : "76.77",
    "display" : "RIDUZIONE APERTA DI FRATTURA ALVEOLARE Riduzione di frattura alveolare con stabilizzazione dei denti"
  },
  {
    "code" : "76.93",
    "display" : "RIDUZIONE CHIUSA DI LUSSAZIONE TEMPOROMANDIBOLARE"
  },
  {
    "code" : "76.96",
    "display" : "INIEZIONE DI SOSTANZA TERAPEUTICA NELL'ARTICOLAZIONE TEMPOROMANDIBOLARE. Incluso farmaco"
  },
  {
    "code" : "76.97",
    "display" : "RIMOZIONE DI MEZZI DI FISSAZIONE INTERNA DALLE OSSA FACCIALI.Escluso: rimozione di mezzo di fissazione SAI esterno alla mandibola, cerchiaggio dentale"
  },
  {
    "code" : "76.99",
    "display" : "BLOCCAGGIO O SBLOCCAGGIO INTERMASCELLARE"
  },
  {
    "code" : "77.40",
    "display" : "BIOPSIA DELL'OSSO IN SEDE NON SPECIFICATA"
  },
  {
    "code" : "77.56",
    "display" : "RIPARAZIONE DI DITO A MARTELLO/ARTIGLIO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "78.60",
    "display" : "RIMOZIONE DI DISPOSITIVO ORTOPEDICO IMPIANTATO, sede non specificata"
  },
  {
    "code" : "80.20",
    "display" : "ARTROSCOPIA SEDE NON SPECIFICATA. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento (incluso eventuale shaving cartilagineo), medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "80.30",
    "display" : "BIOPSIA DELLE STRUTTURE ARTICOLARI, SEDE NON SPECIFICATA. Escluso: Biopsia dell'anca"
  },
  {
    "code" : "81.16",
    "display" : "ARTRODESI METATARSOFALANGEA.Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.25",
    "display" : "ARTRODESI CARPO-RADIALE Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.26",
    "display" : "ARTRODESI METACARPOCARPALE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.27",
    "display" : "ARTRODESI METACARPOFALANGEA. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.28",
    "display" : "ARTRODESI INTERFALANGEA. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.72",
    "display" : "ARTROPLASTICA DELL' ARTICOLAZIONE METACARPOFALANGEA E INTERFALANGEA SENZA IMPIANTO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.75",
    "display" : "ARTROPLASTICA DELL' ARTICOLAZIONE CARPOCARPALE E CARPOMETACARPALE SENZA IMPIANTO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "81.91",
    "display" : "ARTROCENTESI Aspirazione articolare Escluso: quella per biopsia delle strutture articolari (80.30), iniezione di farmaci (81.92), artrografia (88.32)"
  },
  {
    "code" : "81.91.1",
    "display" : "ARTROCENTESI ARTICOLAZIONE TEMPOROMANDIBOLARE Incluso: eventuale iniezione di sostanze terapeutiche nell'ATM. Non associabile a 76.96"
  },
  {
    "code" : "81.92",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE NELL'ARTICOLAZIONE O NEL LEGAMENTO, O NELLE BORSE, O NEI TENDINI. Incluso: eventuale guida ecografica. Per seduta. Incluso farmaco"
  },
  {
    "code" : "81.92.1",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE SPECIFICHE NEL LEGAMENTO [CORDONE RETRAENTE] DELLA MANO. Incluso: visita pre e post procedura, estensione manuale post-24 ore. Incluso farmaco"
  },
  {
    "code" : "82.04",
    "display" : "INCISIONE E DRENAGGIO DELLO SPAZIO PALMARE O TENARE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.21",
    "display" : "ASPORTAZIONE DI LESIONE DELLA FASCIA TENDINEA DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.22",
    "display" : "ASPORTAZIONE DI LESIONE DEI MUSCOLI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.29",
    "display" : "ASPORTAZIONE DI ALTRE LESIONI DEI TESSUTI MOLLI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.31",
    "display" : "BORSECTOMIA DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.41",
    "display" : "SUTURA DELLA FASCIA TENDINEA DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.45",
    "display" : "SUTURA DEI TENDINI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.46",
    "display" : "SUTURA DEI MUSCOLI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.53",
    "display" : "REINSERZIONE DI TENDINI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.54",
    "display" : "REINSERZIONE DI MUSCOLI DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "82.91",
    "display" : "LISI DI ADERENZE DELLA MANO [Dito a scatto]. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "83.02",
    "display" : "MIOTOMIA. Escluso: Miotomia cricofaringea"
  },
  {
    "code" : "83.03",
    "display" : "BORSOTOMIA. Rimozione di deposito calcareo della borsa. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti di sutura, visita di controllo. Escluso: Aspirazione percutanea della borsa"
  },
  {
    "code" : "83.21",
    "display" : "BIOPSIA DEI TESSUTI MOLLI/MUSCOLI. Escluso: Biopsia di cute e tessuto sottocutaneo (86.11)"
  },
  {
    "code" : "83.21.1",
    "display" : "BIOPSIA ECOGUIDATA DEI TESSUTI MOLLI/MUSCOLI"
  },
  {
    "code" : "83.31",
    "display" : "ASPORTAZIONE DI LESIONE DELLE FASCE TENDINEE"
  },
  {
    "code" : "83.61",
    "display" : "SUTURA DI GUAINA TENDINEA"
  },
  {
    "code" : "83.65.1",
    "display" : "SUTURA DI MUSCOLI O FASCE"
  },
  {
    "code" : "83.65.2",
    "display" : "SUTURA DI FERITA PROFONDA CON LESIONE FASCIALE"
  },
  {
    "code" : "83.98",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE AD AZIONE LOCALE ALL'INTERNO DI ALTRI TESSUTI MOLLI Escluso: Iniezioni da 99.25 a 99.29.9. Incluso: costo del farmaco ed eventuale guida ecografica"
  },
  {
    "code" : "84.01",
    "display" : "AMPUTAZIONE E DISARTICOLAZIONE DI DITA DELLA MANO. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "84.02",
    "display" : "AMPUTAZIONE E DISARTICOLAZIONE DEL POLLICE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "84.11",
    "display" : "AMPUTAZIONE DI DITA DEL PIEDE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "84.3",
    "display" : "REVISIONE DEL MONCONE DI AMPUTAZIONE. Incluso: Visita anestesiologica ed anestesia, esami pre intervento, intervento, medicazioni, rimozione punti, visita di controllo"
  },
  {
    "code" : "85.0",
    "display" : "MASTOTOMIA Incisione della mammella (cute) Mammotomia. Escluso: Aspirazione della mammella, Rimozione di protesi"
  },
  {
    "code" : "85.11",
    "display" : "AGOASPIRATO DELLA MAMMELLA. Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "85.11.1",
    "display" : "AGOSPIRATO ECOGUIDATO DELLA MAMMELLA. Biopsia con ago sottile della mammella"
  },
  {
    "code" : "85.11.2",
    "display" : "AGOASPIRATO DELLA MAMMELLA IN STEREOTASSI. Incluso: valutazione adeguatezza del prelievo"
  },
  {
    "code" : "85.11.3",
    "display" : "BIOPSIA [PERCUTANEA] MAMMARIA 'VACUUM ASSISTED ECOGUIDATA'"
  },
  {
    "code" : "85.11.4",
    "display" : "BIOPSIA [PERCUTANEA] MAMMARIA 'VACUUM ASSISTED' IN STEREOTASSI"
  },
  {
    "code" : "85.11.5",
    "display" : "BIOPSIA DELLA MAMMELLA CON TRU-CUT"
  },
  {
    "code" : "85.11.6",
    "display" : "BIOPSIA ECOGUIDATA DELLA MAMMELLA CON TRU-CUT"
  },
  {
    "code" : "85.11.7",
    "display" : "BIOPSIA STEROTASSICA DELLA MAMMELLA CON TRU-CUT"
  },
  {
    "code" : "85.11.9",
    "display" : "BIOPSIA RM DELLA MAMMELLA CON RETROASPIRAZIONE"
  },
  {
    "code" : "85.19.1",
    "display" : "BIOPSIA CHIRURGICA DELLA MAMMELLA CON O SENZA REPERAGGIO STEREOTASSICO"
  },
  {
    "code" : "85.20",
    "display" : "ASPORTAZIONE O DEMOLIZIONE DI TESSUTO DELLA MAMMELLA. Incisione di ascesso mammario"
  },
  {
    "code" : "85.21",
    "display" : "ASPORTAZIONE LOCALE DI LESIONE DELLA MAMMELLA. Rimozione di area fibrosa dalla mammella Escluso: Agoaspirato della mammella (85.11)"
  },
  {
    "code" : "85.21.1",
    "display" : "ASPIRAZIONE PERCUTANEA DI CISTI DELLA MAMMELLA Ecoguidata"
  },
  {
    "code" : "85.24",
    "display" : "ASPORTAZIONE DI TESSUTO ECTOPICO DELLA MAMMELLA"
  },
  {
    "code" : "85.25",
    "display" : "ASPORTAZIONE DEL CAPEZZOLO"
  },
  {
    "code" : "86.01",
    "display" : "ASPIRAZIONE DELLA CUTE E DEL TESSUTO SOTTOCUTANEO. Sulle unghie, sulla pelle o sul tessuto sottocutaneo aspirazione di: ascesso, ematoma, sieroma"
  },
  {
    "code" : "86.02.1",
    "display" : "SCLEROSI DI FISTOLA PILONIDALE"
  },
  {
    "code" : "86.02.2",
    "display" : "INFILTRAZIONE DI CHELOIDE. Per seduta. Incluso farmaco"
  },
  {
    "code" : "86.02.3",
    "display" : "TATUAGGIO PER PIGMENTAZIONE DEL COMPLESSO AREOLA- CAPEZZOLO"
  },
  {
    "code" : "86.03",
    "display" : "INCISIONE DI CISTI O SENO PILONIDALE. Escluso: Marsupializzazione"
  },
  {
    "code" : "86.04",
    "display" : "INCISIONE CON DRENAGGIO DELLA CUTE E DEL TESSUTO SOTTOCUTANEO. Incluso: incisione di ascesso, favo o flemmone. Escluso: Drenaggio di compartimento fasciale del viso e bocca, spazio palmare o tenare, cisti o seno pilonidale (86.03)"
  },
  {
    "code" : "86.05.1",
    "display" : "INCISIONE CON RIMOZIONE DI CORPO ESTRANEO DA CUTE E TESSUTO SOTTOCUTANEO Estrazione di corpo estraneo profondo Escluso: RIMOZIONE DI CORPO ESTRANEO, NAS (98.20) e RIMOZIONE DI CORPO ESTRANEO DA SCROTO E PENE, SENZA INCISIONE (98.24)"
  },
  {
    "code" : "86.05.2",
    "display" : "REVISIONE O RIMOZIONE DI LOOP RECORDER"
  },
  {
    "code" : "86.06",
    "display" : "INSERZIONE DI POMPA DI INFUSIONE TOTALMENTE IMPIANTABILE. Non associabile a 03.91.1"
  },
  {
    "code" : "86.06.1",
    "display" : "INIEZIONE DI SOSTANZE TERAPEUTICHE/ANALGESICHE PER RIFORNIMENTO DI POMPA ELASTOMERICA. Per via sottocutanea o endovenosa. Incluso farmaco"
  },
  {
    "code" : "86.07",
    "display" : "INSERZIONE DI DISPOSITIVO DI ACCESSO VASCOLARE TOTALMENTE IMPIANTABILE. Non associabile a 03.91.1"
  },
  {
    "code" : "86.11",
    "display" : "BIOPSIA DELLA CUTE E DEL TESSUTO SOTTOCUTANEO"
  },
  {
    "code" : "86.23",
    "display" : "RIMOZIONE DI UNGHIA, MATRICE UNGUEALE O PLICA UNGUEALE"
  },
  {
    "code" : "86.24",
    "display" : "CHEMIOCHIRURGIA DELLA CUTE. Peeling chimico della cute"
  },
  {
    "code" : "86.27",
    "display" : "CURETTAGE DI UNGHIA, MATRICE UNGUEALE O PLICA UNGUEALE. Rimozione di: necrosi, massa di tessuto necrotico Escluso: Rimozione di unghia, matrice ungueale o plica ungueale (86.23)"
  },
  {
    "code" : "86.30.1",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO CUTANEO E SOTTOCUTANEO, MEDIANTE CRIOTERAPIA. Per seduta"
  },
  {
    "code" : "86.30.3",
    "display" : "ASPORTAZIONE O DEMOLIZIONE LOCALE DI LESIONE O TESSUTO CUTANEO E SOTTOCUTANEO, MEDIANTE CAUTERIZZAZIONE O FOLGORAZIONE. Per seduta"
  },
  {
    "code" : "86.30.4",
    "display" : "ASPORTAZIONE O DISTRUZIONE NEOFORMAZIONI CUTANEE MEDIANTE LASER"
  },
  {
    "code" : "86.30.5",
    "display" : "ASPORTAZIONE CHIRURGICA DI LESIONI O TESSUTO CUTANEO O SOTTOCUTANEO CON APPLICAZIONE DI PUNTI DI SUTURA"
  },
  {
    "code" : "86.4",
    "display" : "ASPORTAZIONE RADICALE DI LESIONE DELLA CUTE . Asportazione larga di lesione della cute coinvolgente le strutture sottostanti o adiacenti"
  },
  {
    "code" : "86.59.4",
    "display" : "CHIUSURA DI TRACHEOSTOMIA"
  },
  {
    "code" : "86.61",
    "display" : "INNESTO DI CUTE A PIENO SPESSORE NELLA MANO. Escluso: Innesto eterologo, Innesto omologo"
  },
  {
    "code" : "86.62",
    "display" : "ALTRO INNESTO DI CUTE NELLA MANO. Escluso: Innesto eterologo, Innesto omologo"
  },
  {
    "code" : "86.63",
    "display" : "INNESTO DI CUTE A TUTTO SPESSORE IN ALTRA SEDE. Escluso: Innesto eterologo (86.65), Innesto omologo"
  },
  {
    "code" : "86.65",
    "display" : "INNESTO ETEROLOGO SULLA CUTE"
  },
  {
    "code" : "86.69",
    "display" : "ALTRO INNESTO DI CUTE SU ALTRE SEDI. Escluso: Innesto eterologo, Innesto omologo"
  },
  {
    "code" : "86.71",
    "display" : "ALLESTIMENTO E PREPARAZIONE DI LEMBI PEDUNCOLATI. Allestimento di lembo dal suo letto (autonomizzazione) - Taglio parziale di peduncolo o lembo - Sezione di peduncolo di lembo"
  },
  {
    "code" : "86.72",
    "display" : "AVANZAMENTO DI LEMBO PEDUNCOLATO"
  },
  {
    "code" : "86.73",
    "display" : "TRASFERIMENTO DI LEMBO PEDUNCOLATO SULLA MANO. Escluso: Ricostruzione del pollice o trasferimento di dita"
  },
  {
    "code" : "86.74",
    "display" : "TRASFERIMENTO DI LEMBO PEDUNCOLATO IN ALTRE SEDI. Trasferimento di: lembo di avanzamento, lembo doppiamente peduncolato, lembo di rotazione, lembo di scorrimento, lembo a tubo"
  },
  {
    "code" : "86.75",
    "display" : "REVISIONE DI LEMBO PEDUNCOLATO. Distacco di lembo peduncolato. Assottigliamento di lembo peduncolato"
  },
  {
    "code" : "86.84",
    "display" : "CORREZIONE DI CICATRICE O BRIGLIA RETRATTILE DELLA CUTE. Plastica a “Z” della cute della mano e delle dita della mano"
  },
  {
    "code" : "86.85",
    "display" : "CORREZIONE DI SINDATTILIA"
  },
  {
    "code" : "86.86",
    "display" : "ONICOPLASTICA"
  },
  {
    "code" : "86.92",
    "display" : "ELETTROLISI E ALTRA DEPILAZIONE CUTANEA"
  },
  {
    "code" : "87.03",
    "display" : "TC CRANIO-ENCEFALO. Non associabile a TC Sella Turcica (87.03.A) e TC Orbite (87.03.C)"
  },
  {
    "code" : "87.03.1",
    "display" : "TC CRANIO-ENCEFALO SENZA E CON MDC. Non associabile a TC Sella Turcica con e senza MDC (87.03.B) e TC Orbite con e senza MCD (87.03.D)"
  },
  {
    "code" : "87.03.2",
    "display" : "TC MASSICCIO FACCIALE [mascellare, mandibolare, seni paranasali, etmoide, articolazioni temporo-mandibolari]"
  },
  {
    "code" : "87.03.3",
    "display" : "TC MASSICCIO FACCIALE SENZA E CON MDC [mascellare, mandibolare, seni paranasali, etmoide, articolazioni temporo-mandibolari]"
  },
  {
    "code" : "87.03.5",
    "display" : "TC DELL' ORECCHIO [orecchio medio e interno, rocche e mastoidi, base cranica e angolo ponto cerebellare]"
  },
  {
    "code" : "87.03.6",
    "display" : "TC DELL' ORECCHIO SENZA E CON MDC [orecchio medio e interno, rocche e mastoidi, base cranica e angolo ponto cerebellare]"
  },
  {
    "code" : "87.03.7",
    "display" : "TC DEL COLLO [ghiandole salivari, tiroide-paratiroidi, faringe, laringe, esofago cervicale]"
  },
  {
    "code" : "87.03.8",
    "display" : "TC DEL COLLO SENZA E CON MDC [ghiandole salivari, tiroide-paratiroidi, faringe, laringe, esofago cervicale]"
  },
  {
    "code" : "87.03.9",
    "display" : "TC DELLE GHIANDOLE SALIVARI [SCIALO TC]"
  },
  {
    "code" : "87.03.A",
    "display" : "TC SELLA TURCICA (studio selettivo)"
  },
  {
    "code" : "87.03.B",
    "display" : "TC DELLA SELLA TURCICA SENZA E CON MDC (studio selettivo)"
  },
  {
    "code" : "87.03.C",
    "display" : "TC ORBITE (studio selettivo)"
  },
  {
    "code" : "87.03.D",
    "display" : "TC ORBITE SENZA E CON MDC (studio selettivo)"
  },
  {
    "code" : "87.03.E",
    "display" : "TC DI SINGOLA ARCATA DENTARIA [DENTALSCAN]"
  },
  {
    "code" : "87.03.F",
    "display" : "TC DELLE ARCATE DENTARIE [DENTALSCAN]"
  },
  {
    "code" : "87.05",
    "display" : "DACRIOCISTOGRAFIA"
  },
  {
    "code" : "87.06",
    "display" : "FARINGOGRAFIA. Incluso: esame diretto"
  },
  {
    "code" : "87.06.1",
    "display" : "RX GHIANDOLE SALIVARI CON MDC, STUDIO MONOLATERALE. Incluso: esame diretto"
  },
  {
    "code" : "87.09.1",
    "display" : "RX DEI TESSUTI MOLLI DELLA FACCIA, DEL CAPO E DEL COLLO. Esame diretto di: laringe, rinofaringe, ghiandole salivari"
  },
  {
    "code" : "87.09.2",
    "display" : "RX DEL TRATTO FARINGO-CRICO-ESOFAGEO-CARDIALE. Studio funzionale della via digestiva superiore, con MDC baritato o idrosolubile. Incluso: videoregistrazione"
  },
  {
    "code" : "87.11.2",
    "display" : "RX CON OCCLUSALE DELLE ARCATE DENTARIE. Due arcate: superiore e inferiore"
  },
  {
    "code" : "87.11.3",
    "display" : "ORTOPANORAMICA DELLE ARCATE DENTARIE. Arcate dentarie complete superiore e inferiore (OPT)"
  },
  {
    "code" : "87.12.1",
    "display" : "TELERADIOGRAFIA DEL CRANIO. Per cefalometria ortodontica"
  },
  {
    "code" : "87.12.2",
    "display" : "RADIOGRAFIA ENDORALE. Non associabile a Prima visita odontostomatologica (89.7B.5)"
  },
  {
    "code" : "87.16.3",
    "display" : "STRATIGRAFIA DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE. Incluso: esame diretto ed eventuale stratigrafia dinamica"
  },
  {
    "code" : "87.16.4",
    "display" : "STRATIGRAFIA DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE BILATERALE. Incluso: esame diretto ed eventuale stratigrafia dinamica"
  },
  {
    "code" : "87.16.6",
    "display" : "RX ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE"
  },
  {
    "code" : "87.16.7",
    "display" : "RX EMIMANDIBOLA"
  },
  {
    "code" : "87.17.3",
    "display" : "CONTROLLO RADIOLOGICO DI DERIVAZIONI LIQUORALI"
  },
  {
    "code" : "87.17.4",
    "display" : "RX STANDARD DEL CRANIO. Studio in anteroposteriore, laterolaterale e occipito-naso-mento"
  },
  {
    "code" : "87.22",
    "display" : "RX DELLA COLONNA CERVICALE. Incluso: studio dinamico"
  },
  {
    "code" : "87.23",
    "display" : "RX DELLA COLONNA DORSALE. Incluso: studio dinamico"
  },
  {
    "code" : "87.23.6",
    "display" : "RX MORFOMETRIA VERTEBRALE DORSALE. Valutazione delle altezze dei somi vertebrali su radiografia in LL della colonna per definizione quantitativa di frattura benigna osteoporotica, con tecnica radiologica o DXA"
  },
  {
    "code" : "87.24",
    "display" : "RX DELLA COLONNA LOMBOSACRALE. Incluso: studio dinamico"
  },
  {
    "code" : "87.24.6",
    "display" : "RX STANDARD SACROCOCCIGE. Non associabile a RX MORFOMETRIA VERTEBRALE LOMBARE (87.24.7)"
  },
  {
    "code" : "87.24.7",
    "display" : "RX MORFOMETRIA VERTEBRALE LOMBARE.Valutazione delle altezze dei somi vertebrali su radiografia in LL della colonna per definizione quantitativa di frattura benigna osteoporotica, con tecnica radiologica o DXA. Non associabile a Rx standard sacrococcige (87.24.6)"
  },
  {
    "code" : "87.29",
    "display" : "RX COMPLETA DELLA COLONNA E DEL BACINO SOTTO CARICO. Non associabile a RX STANDARD SACROCOCCIGE (87.24.6); RX MORFOMETRIA VERTEBRALE LOMBARE (87.24.7)"
  },
  {
    "code" : "87.35",
    "display" : "GALATTOGRAFIA [ DUTTOGRAFIA, DUTTOGALATTOGRAFIA] MONOLATERALE"
  },
  {
    "code" : "87.37.1",
    "display" : "MAMMOGRAFIA BILATERALE"
  },
  {
    "code" : "87.37.2",
    "display" : "MAMMOGRAFIA MONOLATERALE"
  },
  {
    "code" : "87.41",
    "display" : "TC DEL TORACE [polmoni, aorta toracica, trachea, esofago, sterno, coste, mediastino]"
  },
  {
    "code" : "87.41.1",
    "display" : "TC DEL TORACE SENZA E CON MDC [polmoni, aorta toracica, trachea, esofago, sterno, coste, mediastino]"
  },
  {
    "code" : "87.42.4",
    "display" : "TC CUORE. Non associabile a TC del cuore senza e con mdc (87.42.5)"
  },
  {
    "code" : "87.42.5",
    "display" : "TC DEL CUORE SENZA E CON MDC. Non associabile a TC del cuore (87.42.4) e TC coronarografia (87.42.6)"
  },
  {
    "code" : "87.42.6",
    "display" : "TC CORONAROGRAFIA. Non associabile a TC del cuore senza e con mdc (87.42.5)"
  },
  {
    "code" : "87.43.1",
    "display" : "RX DELLO SCHELETRO COSTALE BILATERALE. Studio panoramico dello scheletro toracico. Escluso: colonna vertebrale"
  },
  {
    "code" : "87.43.3",
    "display" : "RX DELLO SCHELETRO COSTALE MONOLATERALE"
  },
  {
    "code" : "87.43.4",
    "display" : "RX DELLO STERNO"
  },
  {
    "code" : "87.43.5",
    "display" : "RX DELLA CLAVICOLA"
  },
  {
    "code" : "87.44.1",
    "display" : "RX DEL TORACE. Radiografia standard del torace in 2 proiezioni posteroanteriore e laterolaterale"
  },
  {
    "code" : "87.54.1",
    "display" : "COLANGIOGRAFIA TRANSCATETERE. Incluso: esame diretto"
  },
  {
    "code" : "87.61",
    "display" : "RX COMPLETA DEL TUBO DIGERENTE CON MDC BARITATO O IDROSOLUBILE"
  },
  {
    "code" : "87.62",
    "display" : "RX DEL TRATTO GASTROINTESTINALE SUPERIORE CON MDC SINGOLO BARITATO O IDROSOLUBILE. Studio seriato delle prime vie del tubo digerente (esofago stomaco e duodeno)"
  },
  {
    "code" : "87.62.1",
    "display" : "RX DELL'ESOFAGO CON MDC SINGOLO"
  },
  {
    "code" : "87.62.2",
    "display" : "RX DELL'ESOFAGO CON DOPPIO CONTRASTO. Non associabile a Rx dell'esofago, stomaco e duodeno con doppio MDC (87.62.3)"
  },
  {
    "code" : "87.62.3",
    "display" : "RX DELL'ESOFAGO, STOMACO E DUODENO CON DOPPIO MDC. Non associabile a: RX DELL'ESOFAGO CON DOPPIO CONTRASTO (87.62.2)"
  },
  {
    "code" : "87.63",
    "display" : "STUDIO SERIATO DELL' INTESTINO TENUE CON SINGOLO CONTRASTO"
  },
  {
    "code" : "87.64.1",
    "display" : "TEMPO DI TRANSITO INTESTINALE"
  },
  {
    "code" : "87.65.1",
    "display" : "CLISMA OPACO SEMPLICE CON MDC BARITATO O IDROSOLUBILE"
  },
  {
    "code" : "87.65.2",
    "display" : "CLISMA DEL COLON CON DOPPIO CONTRASTO"
  },
  {
    "code" : "87.65.3",
    "display" : "CLISMA DEL TENUE CON DOPPIO CONTRASTO (con enteroclisi)"
  },
  {
    "code" : "87.69.2",
    "display" : "ANSOGRAMMA COLICO PER ATRESIA ANORETTALE"
  },
  {
    "code" : "87.69.3",
    "display" : "DEFECOGRAFIA"
  },
  {
    "code" : "87.69.4",
    "display" : "ENTEROCOLPOCISTODEFECOGRAFIA"
  },
  {
    "code" : "87.73",
    "display" : "UROGRAFIA ENDOVENOSA. Incluso: esame diretto, cistografia ed eventuale tomografia renale"
  },
  {
    "code" : "87.74.1",
    "display" : "PIELOGRAFIA RETROGRADA MONOLATERALE. Incluso: esame diretto"
  },
  {
    "code" : "87.74.2",
    "display" : "PIELOGRAFIA RETROGRADA BILATERALE. Incluso: esame diretto"
  },
  {
    "code" : "87.75.1",
    "display" : "PIELOGRAFIA TRANSPIELOSTOMICA MONOLATERALE. Incluso: esame diretto"
  },
  {
    "code" : "87.76",
    "display" : "CISTOURETROGRAFIA RETROGRADA E MINZIONALE"
  },
  {
    "code" : "87.76.1",
    "display" : "CISTOURETROGRAFIA MINZIONALE"
  },
  {
    "code" : "87.79.1",
    "display" : "URETROGRAFIA RETROGRADA"
  },
  {
    "code" : "87.79.2",
    "display" : "ESAME UROVIDEODINAMICO [RX]"
  },
  {
    "code" : "87.83",
    "display" : "ISTEROSALPINGOGRAFIA. Incluso: esame diretto"
  },
  {
    "code" : "87.83.1",
    "display" : "ISTEROSALPINGOSONOGRAFIA. Non associabile a Isterosalpingografia (87.83) e Isterosonografia (87.83.2)"
  },
  {
    "code" : "87.83.2",
    "display" : "ISTEROSONOGRAFIA [idrosonografia]. Non associabile a Ecografia ginecologica (88.78.2)"
  },
  {
    "code" : "88.01.1",
    "display" : "TC DELL' ADDOME SUPERIORE. Incluso: Fegato e vie biliari, pancreas, milza, retroperitoneo, stomaco, duodeno, tenue, grandi vasi addominali, reni e surreni"
  },
  {
    "code" : "88.01.2",
    "display" : "TC DELL' ADDOME SUPERIORE SENZA E CON MDC . Incluso: Fegato e vie biliari, pancreas, milza, retroperitoneo, stomaco, duodeno, tenue, grandi vasi addominali, reni e surreni"
  },
  {
    "code" : "88.01.3",
    "display" : "TC DELL' ADDOME INFERIORE. Incluso: Pelvi, colon e retto, vescica, utero e annessi o prostata"
  },
  {
    "code" : "88.01.4",
    "display" : "TC DELL' ADDOME INFERIORE SENZA E CON MDC. Incluso: Pelvi, colon e retto, vescica, utero e annessi o prostata"
  },
  {
    "code" : "88.01.5",
    "display" : "TC DELL' ADDOME COMPLETO"
  },
  {
    "code" : "88.01.6",
    "display" : "TC DELL' ADDOME COMPLETO SENZA E CON MDC"
  },
  {
    "code" : "88.01.7",
    "display" : "TC FEGATO MULTIFASICA. Non associabile a TC DELL' ADDOME SUPERIORE (88.01.1) e TC DELL' ADDOME SUPERIORE SENZA E CON MDC (88.01.2)"
  },
  {
    "code" : "88.01.8",
    "display" : "TC [CLISMA TC] TENUE (con enteroclisi). Incluso: eventuale studio dell'addome extraintestinale. Non associabile a TC DELL' ADDOME SUPERIORE (88.01.1) e TC DELL' ADDOME SUPERIORE SENZA E CON MDC (88.01.2)"
  },
  {
    "code" : "88.01.9",
    "display" : "TC COLON. Incluso: eventuale studio dell'addome extraintestinale e Colonscopia virtuale. Non associabile a TC DELL' ADDOME SUPERIORE (88.01.1) e TC DELL' ADDOME SUPERIORE SENZA E CON MDC (88.01.2), TC DELL' ADDOME INFERIORE (88.01.3), TC DELL' ADDOME INFERIORE SENZA E CON MDC (88.01.4), TC DELL' ADDOME COMPLETO (88.01.5), TC DELL' ADDOME COMPLETO SENZA E CON MDC (88.01.6)"
  },
  {
    "code" : "88.02.1",
    "display" : "TC UROGRAFIA. Incluso: eventuale studio dell'addome extraurinario. Non associabile a TC DELL' ADDOME SUPERIORE (88.01.1) e TC DELL' ADDOME SUPERIORE SENZA E CON MDC (88.01.2), TC DELL' ADDOME INFERIORE (88.01.3), TC DELL' ADDOME INFERIORE SENZA E CON MDC (88.01.4), TC DELL' ADDOME COMPLETO (88.01.5), TC DELL' ADDOME COMPLETO SENZA E CON MDC (88.01.6)"
  },
  {
    "code" : "88.03.2",
    "display" : "FISTOLOGRAFIA"
  },
  {
    "code" : "88.19",
    "display" : "RX DIRETTA DELL' ADDOME [RX DELL'ADDOME] [RX APPARATO URINARIO A VUOTO]"
  },
  {
    "code" : "88.21.1",
    "display" : "RX DELLO STRETTO TORACICO SUPERIORE - STUDIO DELLA CLAVICOLA E DELL'ARTICOLAZIONE STERNOCLAVEARE"
  },
  {
    "code" : "88.21.2",
    "display" : "RX DELLA SPALLA"
  },
  {
    "code" : "88.21.3",
    "display" : "RX DEL BRACCIO"
  },
  {
    "code" : "88.22.1",
    "display" : "RX DEL GOMITO"
  },
  {
    "code" : "88.22.2",
    "display" : "RX DELL'AVAMBRACCIO"
  },
  {
    "code" : "88.23.1",
    "display" : "RX DEL POLSO"
  },
  {
    "code" : "88.23.2",
    "display" : "RX DELLA MANO comprese le dita"
  },
  {
    "code" : "88.26.1",
    "display" : "RX DI BACINO E ARTICOLAZIONI SACROILIACHE"
  },
  {
    "code" : "88.26.2",
    "display" : "RX DELL'ANCA"
  },
  {
    "code" : "88.27.1",
    "display" : "RX DEL FEMORE"
  },
  {
    "code" : "88.27.2",
    "display" : "RX DEL GINOCCHIO"
  },
  {
    "code" : "88.27.3",
    "display" : "RX DELLA GAMBA"
  },
  {
    "code" : "88.28.1",
    "display" : "RX DELLA CAVIGLIA"
  },
  {
    "code" : "88.28.2",
    "display" : "RX DEL PIEDE [CALCAGNO] comprese le dita"
  },
  {
    "code" : "88.29.1",
    "display" : "RX COMPLETA DEGLI ARTI INFERIORI E DEL BACINO SOTTO CARICO"
  },
  {
    "code" : "88.29.3",
    "display" : "STUDIO ARTICOLARE DINAMICO SOTTO STRESS E/O SOTTOCARICO. Per singola articolazione periferica"
  },
  {
    "code" : "88.31",
    "display" : "RX DELLO SCHELETRO IN TOTO [RX scheletro per patologia sistemica]"
  },
  {
    "code" : "88.31.1",
    "display" : "RX COMPLETA DEL LATTANTE"
  },
  {
    "code" : "88.32",
    "display" : "ARTROGRAFIA CON MDC"
  },
  {
    "code" : "88.33.1",
    "display" : "STUDIO DELL' ETA' OSSEA"
  },
  {
    "code" : "88.38.5",
    "display" : "TC DI BACINO E ARTICOLAZIONI SACROILIACHE"
  },
  {
    "code" : "88.38.8",
    "display" : "ARTRO TC. Spalla o gomito o ginocchio"
  },
  {
    "code" : "88.38.9",
    "display" : "TC TOTAL BODY PER STADIAZIONE ONCOLOGICA. Almeno tre distretti anatomici"
  },
  {
    "code" : "88.38.A",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE CERVICALE. Incluso: eventuale valutazione delle strutture del collo. Non associabile a: TC DEL COLLO (87.03.7) e TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.B",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE TORACICO. Incluso: eventuale valutazione delle strutture toraciche. Non associabile a TC DEL TORACE (87.41), TC DEL TORACE SENZA E CON MDC (87.41.1), TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.C",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE LOMBOSACRALE E DEL SACRO COCCIGE. Incluso: eventuale valutazione delle strutture addominali. Non associabile a TC DELL' ADDOME SUPERIORE (88.01.1), TC DELL' ADDOME INFERIORE (88.01.3), TC DELL' ADDOME COMPLETO (88.01.5), TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.D",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE CERVICALE SENZA E CON MDC. Incluso: eventuale valutazione delle strutture del collo. Non associabile a TC DEL COLLO SENZA E CON MDC (87.03.8) e TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.E",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE TORACICO SENZA E CON MDC. Incluso: eventuale valutazione delle strutture toraciche. Non associabile a TC DEL TORACE (87.41), TC DEL TORACE SENZA E CON MDC (87.41.1), TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.F",
    "display" : "TC DEL RACHIDE E DELLO SPECO VERTEBRALE LOMBOSACRALE E DEL SACRO COCCIGE SENZA E CON MDC. Incluso: eventuale valutazione delle strutture addominali. Non associabile a TC DELL' ADDOME SUPERIORE SENZA E CON MDC (88.01.2), TC DELL' ADDOME INFERIORE SENZA E CON MDC (88.01.4), TC DELL' ADDOME COMPLETO SENZA E CON MDC (88.01.6), TC TOTAL BODY PER STADIAZIONE ONCOLOGICA (88.38.9)"
  },
  {
    "code" : "88.38.G",
    "display" : "TC DELLA SPALLA. Non associabile a TC DEL BRACCIO (88.38.H) e TC DI SPALLA E BRACCIO (88.38.N)"
  },
  {
    "code" : "88.38.H",
    "display" : "TC DEL BRACCIO. Non associabile a TC DELLA SPALLA (88.38.G) e TC DI SPALLA E BRACCIO (88.38.N)"
  },
  {
    "code" : "88.38.J",
    "display" : "TC DEL GOMITO. Non associabile a TC DELL'AVAMBRACCIO (88.38.K) e TC DI GOMITO E AVAMBRACCIO (88.38.P)"
  },
  {
    "code" : "88.38.K",
    "display" : "TC DELL'AVAMBRACCIO. Non associabile a TC DEL GOMITO (88.38.J) e TC DI GOMITO E AVAMBRACCIO (88.38.P)"
  },
  {
    "code" : "88.38.L",
    "display" : "TC DEL POLSO. Non associabile a TC DELLA MANO (88.38.M) e TC DI POLSO E MANO (88.38.Q)"
  },
  {
    "code" : "88.38.M",
    "display" : "TC DELLA MANO. Non associabile a TC DEL POLSO (88.38.L) eTC DI POLSO E MANO (88.38.Q)"
  },
  {
    "code" : "88.38.N",
    "display" : "TC DI SPALLA E BRACCIO. Non associabile a TC DELLA SPALLA (88.38.G) e TC DEL BRACCIO (88.38.H)"
  },
  {
    "code" : "88.38.P",
    "display" : "TC DI GOMITO E AVAMBRACCIO. Non associabile a TC DEL GOMITO (88.38.J) e TC DELL'AVAMBRACCIO (88.38.K)"
  },
  {
    "code" : "88.38.Q",
    "display" : "TC DI POLSO E MANO. Non associabile a TC DEL POLSO (88.38.L) e TC DELLA MANO (88.38.M)"
  },
  {
    "code" : "88.38.R",
    "display" : "TC DELLA SPALLA SENZA E CON MDC. Non associabile a TC DEL BRACCIO SENZA E CON MDC (88.38.S) e TC DI SPALLA E BRACCIO SENZA E CON MDC (88.38.X)"
  },
  {
    "code" : "88.38.S",
    "display" : "TC DEL BRACCIO SENZA E CON MDC. Non associabile a TC DELLA SPALLA SENZA E CON MDC (88.38.R) e TC DI SPALLA E BRACCIO SENZA E CON MDC (88.38.X)"
  },
  {
    "code" : "88.38.T",
    "display" : "TC DEL GOMITO SENZA E CON MDC. Non associabile a TC DELL'AVAMBRACCIO SENZA E CON MDC (88.38.U) e TC DI GOMITO E AVAMBRACCIO SENZA E CON MDC (88.38.Y)"
  },
  {
    "code" : "88.38.U",
    "display" : "TC DELL'AVAMBRACCIO SENZA E CON MDC. Non associabile a TC DEL GOMITO SENZA E CON MDC (88.38.T) e TC DI GOMITO E AVAMBRACCIO SENZA E CON MDC (88.38.Y)"
  },
  {
    "code" : "88.38.V",
    "display" : "TC DEL POLSO SENZA E CON MDC. Non associabile a TC DELLA MANO SENZA E CON MDC (88.38.W) e TC DI POLSO E MANO SENZA E CON MDC (88.38.Z)"
  },
  {
    "code" : "88.38.W",
    "display" : "TC DELLA MANO SENZA E CON MDC. Non associabile a TC DEL POLSO SENZA E CON MDC (88.38.V) e TC DI POLSO E MANO SENZA E CON MDC (88.38.Z)"
  },
  {
    "code" : "88.38.X",
    "display" : "TC DI SPALLA E BRACCIO SENZA E CON MDC. Non associabile a TC DELLA SPALLA SENZA E CON MDC (88.38.R) e TC DEL BRACCIO SENZA E CON MDC (88.38.S)"
  },
  {
    "code" : "88.38.Y",
    "display" : "TC DI GOMITO E AVAMBRACCIO SENZA E CON MDC. Non associabile a TC DEL GOMITO SENZA E CON MDC (88.38.T) eTC DELL'AVAMBRACCIO SENZA E CON MDC (88.38.U)"
  },
  {
    "code" : "88.38.Z",
    "display" : "TC DI POLSO E MANO SENZA E CON MDC. Non associabile a TC DEL POLSO SENZA E CON MDC (88.38.V) e TC DELLA MANO SENZA E CON MDC (88.38.W)"
  },
  {
    "code" : "88.39.1",
    "display" : "LOCALIZZAZIONE RADIOLOGICA DI CORPO ESTRANEO"
  },
  {
    "code" : "88.39.2",
    "display" : "TC DELL'ARTICOLAZIONE COXOFEMORALE. Non associabile a TC DELLA COSCIA [TC DEL FEMORE] (88.39.3) e TC DI BACINO E ARTICOLAZIONI SACROILIACHE (88.38.5)"
  },
  {
    "code" : "88.39.3",
    "display" : "TC DELLA COSCIA [TC DEL FEMORE]. Non associabile a TC DELL'ARTICOLAZIONE COXOFEMORALE (88.39.2), TC DI BACINO E ARTICOLAZIONI SACROILIACHE (88.38.5) e TC DEL GINOCCHIO (88.39.4)"
  },
  {
    "code" : "88.39.4",
    "display" : "TC DEL GINOCCHIO. Non associabile a TC DELLA COSCIA [TC DEL FEMORE] (88.39.3) e TC DELLA GAMBA (88.39.5)"
  },
  {
    "code" : "88.39.5",
    "display" : "TC DELLA GAMBA. Non associabile a TC DEL GINOCCHIO (88.39.4) e TC DELLA CAVIGLIA (88.39.6)"
  },
  {
    "code" : "88.39.6",
    "display" : "TC DELLA CAVIGLIA. Non associabile a TC DEL PIEDE (88.39.7) e TC DELLA GAMBA (88.39.5)"
  },
  {
    "code" : "88.39.7",
    "display" : "TC DEL PIEDE. Non associabile a TC DELLA CAVIGLIA (88.39.6)"
  },
  {
    "code" : "88.39.8",
    "display" : "TC DI GINOCCHIO E GAMBA . Non associabile a TC DEL GINOCCHIO (88.39.4) e TC DELLA GAMBA (88.39.5)"
  },
  {
    "code" : "88.39.9",
    "display" : "TC DI CAVIGLIA E PIEDE. Non associabile a TC DEL PIEDE (88.39.7) e TC DELLA CAVIGLIA (88.39.6)"
  },
  {
    "code" : "88.39.A",
    "display" : "TC DELL'ARTICOLAZIONE COXOFEMORALE SENZA E CON MDC. Non associabile TC DELLA COSCIA [TC DEL FEMORE] SENZA E CON MDC (88.39.B) e TC DI BACINO E ARTICOLAZIONI SACROILIACHE (88.38.5)"
  },
  {
    "code" : "88.39.B",
    "display" : "TC DELLA COSCIA [TC DEL FEMORE] SENZA E CON MDC. Non associabile TC DELL'ARTICOLAZIONE COXOFEMORALE SENZA E CON MDC (88.39.A) e TC DEL GINOCCHIO SENZA E CON MDC (88.39.C)"
  },
  {
    "code" : "88.39.C",
    "display" : "TC DEL GINOCCHIO SENZA E CON MDC Non associabile a TC DELLA COSCIA [TC DEL FEMORE] SENZA E CON MDC (88.39.B) e TC DELLA GAMBA SENZA E CON MDC (88.39.D)"
  },
  {
    "code" : "88.39.D",
    "display" : "TC DELLA GAMBA SENZA E CON MDC. Non associabile a TC DEL GINOCCHIO SENZA E CON MDC (88.39.C) e TC DELLA CAVIGLIA SENZA E CON MDC (88.39.E)"
  },
  {
    "code" : "88.39.E",
    "display" : "TC DELLA CAVIGLIA SENZA E CON MDC. Non associabile a TC DELLA GAMBA SENZA E CON MDC (88.39.D) e TC DEL PIEDE SENZA E CON MDC (88.39.F)"
  },
  {
    "code" : "88.39.F",
    "display" : "TC DEL PIEDE SENZA E CON MDC. Non associabile a TC DELLA CAVIGLIA SENZA E CON MDC (88.39.E)"
  },
  {
    "code" : "88.39.G",
    "display" : "TC DI GINOCCHIO E GAMBA SENZA E CON MDC. Non associabile a TC DEL GINOCCHIO SENZA E CON MDC (88.39.C) e TC DELLA GAMBA SENZA E CON MDC (88.39.D)"
  },
  {
    "code" : "88.39.H",
    "display" : "TC DI CAVIGLIA E PIEDE SENZA E CON MDC. Non associabile a: TC DI CAVIGLIA E PIEDE (88.39.9), TC DELLA CAVIGLIA SENZA E CON MDC (88.39.E) e TC DEL PIEDE SENZA E CON MDC (88.39.F)"
  },
  {
    "code" : "88.41.1",
    "display" : "ANGIO TC DEI VASI INTRACRANICI. Non associabile a ANGIO TC DEI VASI DEL COLLO [CAROTIDI] (88.41.2) e ANGIO TC DEI VASI INTRACRANICI E DEL COLLO [CAROTIDI] (88.41.3)"
  },
  {
    "code" : "88.41.2",
    "display" : "ANGIO TC DEI VASI DEL COLLO [CAROTIDI]. Non associabile a ANGIO TC DEI VASI INTRACRANICI (88.41.1) e ANGIO TC DEI VASI INTRACRANICI E DEL COLLO [CAROTIDI] (88.41.3)"
  },
  {
    "code" : "88.41.3",
    "display" : "ANGIO TC DEI VASI INTRACRANICI E DEL COLLO [CAROTIDI]. Non associabile a 88.41.1 e 88.41.2"
  },
  {
    "code" : "88.42.1",
    "display" : "AORTOGRAFIA TORACICA. Angiografia digitale arteriosa dell'aorta e dell'arco aortico e origine dei vasi epiaortici"
  },
  {
    "code" : "88.42.2",
    "display" : "AORTOGRAFIA ADDOMINALE. Angiografia digitale dell' aorta addominale"
  },
  {
    "code" : "88.43",
    "display" : "ANGIO TC DEL CIRCOLO POLMONARE"
  },
  {
    "code" : "88.44.1",
    "display" : "ANGIO TC DELL'AORTA TORACICA. Non associabile a ANGIO TC DELL'AORTA TORACO ADDOMINALE (88.47.1) e ANGIO TC DELL'AORTA TORACO ADDOMINALE (88.47.2)"
  },
  {
    "code" : "88.45",
    "display" : "ANGIO TC DELLE ARTERIE RENALI. Non associabile a ANGIO TC DI AORTA ADDOMINALE E ARTERIE RENALI (88.45.1)"
  },
  {
    "code" : "88.45.1",
    "display" : "ANGIO TC DI AORTA ADDOMINALE E ARTERIE RENALI. Non associabile a ANGIO TC DELLE ARTERIE RENALI (88.45) e ANGIO TC DELL'AORTA TORACO ADDOMINALE (88.47.1)"
  },
  {
    "code" : "88.47.1",
    "display" : "ANGIO TC DELL'AORTA ADDOMINALE. Non associabile a ANGIO TC DELL'AORTA TORACICA (88.44.1) e ANGIO TC DELL'AORTA TORACO ADDOMINALE (88.47.2)"
  },
  {
    "code" : "88.47.2",
    "display" : "ANGIO TC DELL'AORTA TORACO ADDOMINALE. Non associabile a ANGIO TC DELL'AORTA TORACICA (88.44.1) e ANGIO TC DELL'AORTA ADDOMINALE (88.47.1)"
  },
  {
    "code" : "88.47.3",
    "display" : "ANGIO TC DI AORTA ADDOMINALE E ARTI INFERIORI. Non associabile a ANGIO TC [ARTERIOSA E VENOSA] DEGLI ARTI INFERIORI (88.48.1) e ANGIO TC DELL'AORTA ADDOMINALE (88.47.1)"
  },
  {
    "code" : "88.48",
    "display" : "ARTERIOGRAFIA MONOLATERALE DELL' ARTO INFERIORE"
  },
  {
    "code" : "88.48.1",
    "display" : "ANGIO TC [ARTERIOSA E VENOSA] DEGLI ARTI INFERIORI. Non associabile a ANGIO TC DELL'AORTA ADDOMINALE (88.47.1) e ANGIO TC DI AORTA ADDOMINALE E ARTI INFERIORI (88.47.3)"
  },
  {
    "code" : "88.49.1",
    "display" : "ARTERIOGRAFIA MONOLATERALE DELL' ARTO SUPERIORE"
  },
  {
    "code" : "88.49.2",
    "display" : "ANGIO TC [ARTERIOSA E VENOSA] DEGLI ARTI SUPERIORI"
  },
  {
    "code" : "88.63.1",
    "display" : "CAVOGRAFIA SUPERIORE"
  },
  {
    "code" : "88.63.2",
    "display" : "FLEBOGRAFIA MONOLATERALE DELL' ARTO SUPERIORE"
  },
  {
    "code" : "88.65.1",
    "display" : "CAVOGRAFIA INFERIORE"
  },
  {
    "code" : "88.65.2",
    "display" : "FLEBOGRAFIA RENALE"
  },
  {
    "code" : "88.65.4",
    "display" : "FLEBOGRAFIA SPERMATICA"
  },
  {
    "code" : "88.66.1",
    "display" : "FLEBOGRAFIA MONOLATERALE DELL'ARTO INFERIORE"
  },
  {
    "code" : "88.66.2",
    "display" : "FLEBOGRAFIA BILATERALE DEGLI ARTI INFERIORI"
  },
  {
    "code" : "88.71.1",
    "display" : "ECOENCEFALOGRAFIA. Ecografia transfontanellare"
  },
  {
    "code" : "88.71.2",
    "display" : "STUDIO DOPPLER TRANSCRANICO. Con analisi spettrale dopo prova fisica o farmacologica"
  },
  {
    "code" : "88.71.3",
    "display" : "ECOCOLORDOPPLER TRANSCRANICO"
  },
  {
    "code" : "88.71.4",
    "display" : "DIAGNOSTICA ECOGRAFICA DEL CAPO E DEL COLLO. Ecografia di: ghiandole salivari maggiori, tiroide, paratiroidi, strutture muscolari del collo, stazioni linfoghiandolari. Incluso: eventuale ecocolordoppler delle ghiandole salivari e della tiroide. Escluso Ecocolordoppler delle paratiroidi 88.73.7"
  },
  {
    "code" : "88.71.5",
    "display" : "ECOCOLORDOPPLER TRANSCRANICO CON E SENZA MEZZO DI CONTRASTO"
  },
  {
    "code" : "88.71.6",
    "display" : "MONITORAGGIO DOPPLER TRANSCRANICO PER IL MICROEMBOLISMO [MESh]"
  },
  {
    "code" : "88.72.2",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo. Non associabile a ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo e dopo prova fisica o farmacologica (88.72.3)"
  },
  {
    "code" : "88.72.3",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo e dopo prova fisica o farmacologica. Non associabile a ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo (88.72.2)"
  },
  {
    "code" : "88.72.4",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA TRANSESOFAGEA Ecocardiografia transesofagea Non associabile a ECOGRAFIA MEDIASTINICA TRANSESOFAGEA (88.73.8)"
  },
  {
    "code" : "88.72.5",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA FETALE"
  },
  {
    "code" : "88.72.6",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA SENZA e CON MDC A riposo. Non associabile a ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo (88.72.2) e ECO(COLOR)DOPPLERGRAFIA CARDIACA SENZA e CON MDC A riposo e dopo prova (88.72.7)"
  },
  {
    "code" : "88.72.7",
    "display" : "ECO(COLOR)DOPPLERGRAFIA CARDIACA SENZA e CON MDC A riposo e dopo prova fisica o farmacologica. Non associabile a ECO(COLOR)DOPPLERGRAFIA CARDIACA A riposo (88.72.2) e ECO(COLOR)DOPPLERGRAFIA CARDIACA SENZA e CON MDC A riposo. (88.72.6)"
  },
  {
    "code" : "88.73.1",
    "display" : "ECOGRAFIA BILATERALE DELLA MAMMELLA. Incluso ecografia del cavo ascellare ed eventuale integrazione Colordoppler. Incluso: eventuale valutazione clinica della mammella"
  },
  {
    "code" : "88.73.2",
    "display" : "ECOGRAFIA MONOLATERALE DELLA MAMMELLA. Incluso: ecografia del cavo ascellare ed eventuale integrazione Colordoppler"
  },
  {
    "code" : "88.73.3",
    "display" : "ECOGRAFIA TORACICA. Incluso: eventuale integrazione Colordoppler"
  },
  {
    "code" : "88.73.5",
    "display" : "ECO(COLOR)DOPPLERGRAFIA DEI TRONCHI SOVRAAORTICI. Incluso: carotidi, vertebrali, tronco anonimo e succlavia. A riposo o dopo prova fisica o farmacologica. Valutazione degli indici quantitativi e semiquantitativi"
  },
  {
    "code" : "88.73.6",
    "display" : "ECO(COLOR)DOPPLERGRAFIA DEI VASI VENOSI DEL COLLO. Incluso: giugulari,succlavie, vene anonime"
  },
  {
    "code" : "88.73.7",
    "display" : "ECOCOLORDOPPLER PARATIROIDI"
  },
  {
    "code" : "88.73.8",
    "display" : "ECOGRAFIA MEDIASTINICA TRANSESOFAGEA Non associabile a ECO(COLOR)DOPPLERGRAFIA CARDIACA TRANSESOFAGEA (88.72.4)"
  },
  {
    "code" : "88.74.1",
    "display" : "ECOGRAFIA DELL'ADDOME SUPERIORE. Incluso: fegato, vie biliari, colecisti, asse venoso spleno-portale, pancreas, milza, aorta addominale e grandi vasi a sede o sviluppo sovraombelicale, linfonodi, eventuali masse patologiche di origine peritoneale o retroperitoneale. Incluso eventuale integrazione colordoppler. Non associabile a 88.75.1, 88.76.1, 88.76.5"
  },
  {
    "code" : "88.74.6",
    "display" : "STUDIO ECOGRAFICO DEL TEMPO DI SVUOTAMENTO GASTRICO. Incluso: eventuale integrazione Colordoppler"
  },
  {
    "code" : "88.74.7",
    "display" : "STUDIO ECOGRAFICO DEL REFLUSSO GASTROESOFAGEO. Incluso: eventuale integrazione Colordoppler"
  },
  {
    "code" : "88.74.8",
    "display" : "ECOGRAFIA DELLE VIE DIGESTIVE. Incluso: eventuale integrazione Colordoppler"
  },
  {
    "code" : "88.74.9",
    "display" : "ECOCOLORDOPPLER ARTERIE RENALI. Studio ipertensione renovascolare. Incluso: indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.74.A",
    "display" : "ECOCOLORDOPPLER VASI SPLANCNICI. Incluso: valutazione morfologica ed indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.75.1",
    "display" : "ECOGRAFIA DELL'ADDOME INFERIORE. Incluso: reni e surreni, ureteri, vescica, prostata, pelvi maschile o femminile ed ecografia sovrapubica. Incluso eventuale integrazione colordoppler. Non associabile a 88.74.1, 88.76.1, 88.79.5, 88.79.6"
  },
  {
    "code" : "88.76.1",
    "display" : "ECOGRAFIA DELL'ADDOME COMPLETO. Incluso: eventuale integrazione colordoppler. Non associabile a 88.74.1, 88.75.1"
  },
  {
    "code" : "88.76.3",
    "display" : "ECOCOLOR DOPPLER DEI GROSSI VASI ADDOMINALI ARTERIOSI O VENOSI. Escluso: vasi viscerali"
  },
  {
    "code" : "88.76.4",
    "display" : "ECOCOLOR DOPPLER DEI GROSSI VASI ADDOMINALI ARTERIOSI O VENOSI CON O SENZA MEZZO DI CONTRASTO. Escluso: vasi viscerali"
  },
  {
    "code" : "88.76.5",
    "display" : "ECOCOLORDOPPLER VASI VISCERALI"
  },
  {
    "code" : "88.76.6",
    "display" : "ECOCOLORDOPPLER VASI VISCERALI CON MEZZO DI CONTRASTO"
  },
  {
    "code" : "88.77.4",
    "display" : "ECOCOLORDOPPLER DEGLI ARTI INFERIORI ARTERIOSO E/O VENOSO. A riposo. Inclusa valutazione degli indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.77.5",
    "display" : "ECOCOLORDOPPLER DEGLI ARTI INFERIORI ARTERIOSO E/O VENOSO. A riposo e dopo prova fisica o farmacologica.Inclusa valutazione degli indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.77.6",
    "display" : "ECOCOLORDOPPLER DEGLI ARTI SUPERIORI ARTERIOSO E/O VENOSO. A riposo. Inclusa valutazione degli indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.77.7",
    "display" : "ECOCOLORDOPPLER DEGLI ARTI SUPERIORI ARTERIOSO E/O VENOSO. A riposo e dopo prova fisica o farmacologica. Inclusa valutazione degli indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.78",
    "display" : "ECOGRAFIA OSTETRICA"
  },
  {
    "code" : "88.78.1",
    "display" : "MONITORAGGIO ECOGRAFICO DEL CICLO OVULATORIO. Minimo 4 sedute. Non associabile a: Ecografia dell'addome inferiore 88.75.1, Ecografia dell'addome completo 88.76.1"
  },
  {
    "code" : "88.78.2",
    "display" : "ECOGRAFIA GINECOLOGICA con sonda transvaginale o addominale. Incluso: eventuale Ecocolordoppler. Non associabile a ECOGRAFIA DELL'ADDOME INFERIORE (88.75.1) e MONITORAGGIO ECOGRAFICO E ORMONALE DEL CICLO OVULATORIO (88.76.1)"
  },
  {
    "code" : "88.78.3",
    "display" : "ECOGRAFIA OSTETRICA MORFOLOGICA. Non associabile a 88.75.1 ECOGRAFIA DELL'ADDOME INFERIORE"
  },
  {
    "code" : "88.78.4",
    "display" : "ECOGRAFIA OSTETRICA per studio della traslucenza nucale. Incluso: consulenza pre e post test combinato"
  },
  {
    "code" : "88.78.5",
    "display" : "FLUSSIMETRIA. [ECOCOLORDOPPLER FETOPLACENTARE] Incluso: valutazione indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.78.6",
    "display" : "ECOGRAFIA OSTETRICA. Incluso: studio della traslucenza nucale. Non associabile a ECOGRAFIA OSTETRICA per studio della traslucenza nucale (88.78.4)"
  },
  {
    "code" : "88.79.1",
    "display" : "ECOGRAFIA DELLA CUTE E DEL TESSUTO SOTTOCUTANEO. Studio delle parti molli. Incluso: eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.2",
    "display" : "ECOGRAFIA DELLE ANCHE NEL NEONATO"
  },
  {
    "code" : "88.79.3",
    "display" : "ECOGRAFIA MUSCOLOTENDINEA E OSTEOARTICOLARE. Per singola articolazione o distretto muscolare. Inclusa eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.5",
    "display" : "ECOGRAFIA DEL PENE. Non associabile a ECOCOLORDOPPLER PENIENO DINAMICO CON STIMOLAZIONE FARMACOLOGICA (88.79.D)"
  },
  {
    "code" : "88.79.6",
    "display" : "ECOGRAFIA SCROTALE. Incluso: testicoli e annessi testicolari. Incluso: eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.8",
    "display" : "ECOGRAFIA TRANSRETTALE. Incluso: ecografia dell'addome inferiore. Incluso: eventuale integrazione colordoppler. Non associabile a ECOGRAFIA DELL'ADDOME INFERIORE (88.75.1) e ECOGRAFIA DELL'ADDOME COMPLETO (88.76.1)"
  },
  {
    "code" : "88.79.9",
    "display" : "ECOGRAFIA REGIONE INGUINO-CRURALE. Incluso: eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.A",
    "display" : "ECOGRAFIA PARETE ADDOMINALE. Studio di ernia o di diastasi muscolare. Incluso: eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.B",
    "display" : "CISTOSONOGRAFIA CON MDC. Non associabile a ECOGRAFIA DELL'ADDOME INFERIORE (88.75.1)"
  },
  {
    "code" : "88.79.D",
    "display" : "ECOCOLORDOPPLER PENIENO DINAMICO CON STIMOLAZIONE FARMACOLOGICA. Incluso: valutazione morfologica ed indici qualitativi e semiquantitativi. Non associabile a ECOGRAFIA DEL PENE (88.79.5)"
  },
  {
    "code" : "88.79.E",
    "display" : "ECOCOLORDOPPLER SCROTALE. Studio di varicocele e torsione testicolare. Incluso: valutazione morfologica ed indici qualitativi e semiquantitativi"
  },
  {
    "code" : "88.79.F",
    "display" : "ECOGRAFIA ENDOANALE. Incluso: eventuale integrazione colordoppler"
  },
  {
    "code" : "88.79.H",
    "display" : "ECOGRAFIA ORGANO MIRATA CON MDC. Inclusa eventuale integrazione color doppler"
  },
  {
    "code" : "88.79.K",
    "display" : "ECOGRAFIA DELLE ANSE INTESTINALI. Non associabile a ECOGRAFIA DELL' ADDOME SUPERIORE (88.74.1), ECOGRAFIA DELL'ADDOME INFERIORE (88.75.1) e ECOGRAFIA DELL'ADDOME COMPLETO (88.76.1)"
  },
  {
    "code" : "88.79.L",
    "display" : "ECOGRAFIA STAZIONI LINFONODALI PLURIDISTRETTUALI (LATEROCERVICALE, SOVRACLAVEARE, ASCELLARE, INGUINALE)"
  },
  {
    "code" : "88.91.1",
    "display" : "RM DI ENCEFALO E TRONCO ENCEFALICO, GIUNZIONE CRANIO SPINALE E RELATIVO DISTRETTO VASCOLARE"
  },
  {
    "code" : "88.91.2",
    "display" : "RM DI ENCEFALO E TRONCO ENCEFALICO, GIUNZIONE CRANIO SPINALE E RELATIVO DISTRETTO VASCOLARE SENZA E CON MDC"
  },
  {
    "code" : "88.91.5",
    "display" : "ANGIO- RM DEL DISTRETTO VASCOLARE INTRACRANICO"
  },
  {
    "code" : "88.91.6",
    "display" : "RM DEL COLLO [faringe, laringe, parotidi-ghiandole salivari, tiroide- paratiroidi]. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.91.7",
    "display" : "RM DEL COLLO SENZA E CON MDC [faringe, laringe, parotidi-ghiandole salivari, tiroide-paratiroidi]. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.91.8",
    "display" : "ANGIO- RM DEI VASI DEL COLLO"
  },
  {
    "code" : "88.91.A",
    "display" : "RM DEL MASSICCIO FACCIALE [Mascella, mandibola, cavità nasali, seni paranasali, etmoide]. Incluso: relativo distretto vascolare. Non associabile a RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE (88.91.B), RM DELLA SELLA TURCICA (88.91.C), RM DELLE ROCCHE PETROSE (88.91.D), RM DELLE ORBITE (88.91.E), e RM DEL MASSICCIO FACCIALE COMPLESSIVO (88.91.F)"
  },
  {
    "code" : "88.91.B",
    "display" : "RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE. Incluso: relativo distretto vascolare. Incluso eventuale esame dinamico. Non associabile a RM DEL MASSICCIO FACCIALE (88.91.A), RM DELLA SELLA TURCICA (88.91.C), RM DELLE ROCCHE PETROSE (88.91.D), RM DELLE ORBITE (88.91.E), e RM DEL MASSICCIO FACCIALE COMPLESSIVO (88.91.F)"
  },
  {
    "code" : "88.91.C",
    "display" : "RM DELLA SELLA TURCICA. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE (88.91.A), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE (88.91.B), RM DELLE ROCCHE PETROSE (88.91.D), RM DELLE ORBITE (88.91.E), e RM DEL MASSICCIO FACCIALE COMPLESSIVO (88.91.F)"
  },
  {
    "code" : "88.91.D",
    "display" : "RM DELLE ROCCHE PETROSE. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE (88.91.A), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE (88.91.B), RM DELLA SELLA TURCICA (88.91.C), RM DELLE ORBITE (88.91.E), e RM DEL MASSICCIO FACCIALE COMPLESSIVO (88.91.F)"
  },
  {
    "code" : "88.91.E",
    "display" : "RM DELLE ORBITE. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE (88.91.A), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE (88.91.B), RM DELLA SELLA TURCICA (88.91.C), RM DELLE ROCCHE PETROSE (88.91.D) e RM DEL MASSICCIO FACCIALE COMPLESSIVO (88.91.F)"
  },
  {
    "code" : "88.91.F",
    "display" : "RM DEL MASSICCIO FACCIALE COMPLESSIVO. Studio multidistrettuale di due o più segmenti/distretti. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE (88.91.A), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE E/O BILATERALE (88.91.B), RM DELLA SELLA TURCICA (88.91.C), RM DELLE ROCCHE PETROSE (88.91.D) e RM DELLE ORBITE (88.91.E)"
  },
  {
    "code" : "88.91.G",
    "display" : "RM DEL MASSICCIO FACCIALE SENZA E CON MDC [Mascella, mandibola, cavità nasali, seniparanasali, etmoide]. Incluso: relativo distretto vascolare. Non associabile a RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC (88.91.H), RM DELLA SELLA TURCICA SENZA E CON MDC (88.91.J), RM DELLE ROCCHE PETROSE SENZA E CON MDC (88.91.K), RM DELLE ORBITE SENZA E CON MDC (88.91.L) e RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC (88.91.M)"
  },
  {
    "code" : "88.91.H",
    "display" : "RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC. Incluso: relativo distretto vascolare. Incluso eventuale esame dinamico. Non associabile a RM DEL MASSICCIO FACCIALE SENZA E CON MDC (88.91.G), RM DELLA SELLA TURCICA SENZA E CON MDC (88.91.J), RM DELLE ROCCHE PETROSE SENZA E CON MDC (88.91.K), RM DELLE ORBITE SENZA E CON MDC (88.91.L) e RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC (88.91.M)"
  },
  {
    "code" : "88.91.J",
    "display" : "RM DELLA SELLA TURCICA SENZA E CON MDC. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE SENZA E CON MDC (88.91.G), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC (88.91.H), RM DELLE ROCCHE PETROSE SENZA E CON MDC (88.91.K), RM DELLE ORBITE SENZA E CON MDC (88.91.L) e RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC (88.91.M)"
  },
  {
    "code" : "88.91.K",
    "display" : "RM DELLE ROCCHE PETROSE SENZA E CON MDC. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE SENZA E CON MDC (88.91.G), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC (88.91.H), RM DELLA SELLA TURCICA SENZA E CON MDC (88.91.J), RM DELLE ORBITE SENZA E CON MDC (88.91.L) e RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC (88.91.M)"
  },
  {
    "code" : "88.91.L",
    "display" : "RM DELLE ORBITE SENZA E CON MDC. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE SENZA E CON MDC (88.91.G), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC (88.91.H), RM DELLA SELLA TURCICA SENZA E CON MDC (88.91.J), RM DELLE ROCCHE PETROSE SENZA E CON MDC (88.91.K), RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC (88.91.M)"
  },
  {
    "code" : "88.91.M",
    "display" : "RM DEL MASSICCIO FACCIALE COMPLESSIVO SENZA E CON MDC. Studio multidistrettuale di due o più segmenti. Incluso: relativo distretto vascolare. Non associabile a RM DEL MASSICCIO FACCIALE SENZA E CON MDC (88.91.G), RM DELL'ARTICOLAZIONE TEMPOROMANDIBOLARE MONOLATERALE O BILATERALE SENZA E CON MDC (88.91.H), RM DELLA SELLA TURCICA SENZA E CON MDC (88.91.J), RM DELLE ROCCHE PETROSE SENZA E CON MDC (88.91.K), RM DELLE ORBITE SENZA E CON MDC (88.91.L)"
  },
  {
    "code" : "88.91.N",
    "display" : "ANGIO RM DEL DISTRETTO VASCOLARE INTRACRANICO SENZA E CON MDC"
  },
  {
    "code" : "88.91.P",
    "display" : "ANGIO RM DEI VASI DEL COLLO SENZA E CON MDC"
  },
  {
    "code" : "88.91.R",
    "display" : "RM FLUSSIMETRIA LIQUORALE QUANTITATIVA. Incluso: Esame di base"
  },
  {
    "code" : "88.91.T",
    "display" : "RM STUDI FUNZIONALI ATTIVAZIONE CORTICALE. Incluso: Esame di base"
  },
  {
    "code" : "88.91.U",
    "display" : "RM DI ENCEFALO E TRONCO ENCEFALICO, GIUNZIONE CRANIO SPINALE E RELATIVO DISTRETTO VASCOLARE SENZA E CON CONTRASTO. Inclusa Anestesia e Visita anestesiologica per pazienti pediatrici o non collaboranti"
  },
  {
    "code" : "88.92",
    "display" : "RM DEL TORACE [mediastino, esofago, polmoni, parete toracica]. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.92.1",
    "display" : "RM DEL TORACE SENZA E CON MDC [mediastino, esofago, polmoni, parete toracica]. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.92.2",
    "display" : "ANGIO- RM DEL DISTRETTO TORACICO"
  },
  {
    "code" : "88.92.3",
    "display" : "CINE RM DEL CUORE"
  },
  {
    "code" : "88.92.4",
    "display" : "CINE RM DEL CUORE SENZA E CON MDC"
  },
  {
    "code" : "88.92.5",
    "display" : "CINE RM DEL CUORE. Senza e con stress funzionale"
  },
  {
    "code" : "88.92.9",
    "display" : "RM MAMMARIA MONO E/O BILATERALE SENZA E CON MDC"
  },
  {
    "code" : "88.92.A",
    "display" : "ANGIO RM DEL DISTRETTO TORACICO SENZA E CON MDC"
  },
  {
    "code" : "88.92.B",
    "display" : "ANGIO RM CORONARICA"
  },
  {
    "code" : "88.93.2",
    "display" : "RM DEL RACHIDE CERVICALE. Non associabile a RM DELLA COLONNA IN TOTO (88.93.6)"
  },
  {
    "code" : "88.93.3",
    "display" : "RM DEL RACHIDE DORSALE. Non associabile a RM DELLA COLONNA IN TOTO (88.93.6)"
  },
  {
    "code" : "88.93.4",
    "display" : "RM DEL RACHIDE LOMBOSACRALE. Non associabile a RM DELLA COLONNA IN TOTO (88.93.6)"
  },
  {
    "code" : "88.93.5",
    "display" : "RM DEL RACHIDE SACROCOCCIGEO. Non associabile a RM DELLA COLONNA IN TOTO (88.93.6)"
  },
  {
    "code" : "88.93.6",
    "display" : "RM DELLA COLONNA IN TOTO. Non associabile a RM DEL RACHIDE CERVICALE (88.93.2), RM DEL RACHIDE DORSALE (88.93.3), RM DEL RACHIDE LOMBOSACRALE (88.93.4), RM DEL RACHIDE SACROCOCCIGEO (88.93.5)"
  },
  {
    "code" : "88.93.7",
    "display" : "RM DEL RACHIDE CERVICALE SENZA E CON MDC. Non associabile a RM DELLA COLONNA IN TOTO SENZA E CON MDC (88.93.B)"
  },
  {
    "code" : "88.93.8",
    "display" : "RM DEL RACHIDE DORSALE SENZA E CON MDC. Non associabile a RM DELLA COLONNA IN TOTO SENZA E CON MDC (88.93.B)"
  },
  {
    "code" : "88.93.9",
    "display" : "RM DEL RACHIDE LOMBO-SACRALE SENZA E CON MDC. Non associabile a RM DELLA COLONNA IN TOTO SENZA E CON MDC (88.93.B)"
  },
  {
    "code" : "88.93.A",
    "display" : "RM DEL RACHIDE SACROCOCCIGEO SENZA E CON MDC. Non associabile a RM DELLA COLONNA IN TOTO SENZA E CON MDC (88.93.B)"
  },
  {
    "code" : "88.93.B",
    "display" : "RM DELLA COLONNA IN TOTO SENZA E CON MDC. Non associabile a 88.93.7, 88.93.8, 88.93.9, 88.93.A"
  },
  {
    "code" : "88.93.C",
    "display" : "ANGIO RM MIDOLLO SPINALE CON MDC"
  },
  {
    "code" : "88.94",
    "display" : "ARTRO RM. Incluso: esame di base. Per distretto articolare. Non associabile a ARTROGRAFIA CON MDC (88.32) e a RM del distretto articolare interessato"
  },
  {
    "code" : "88.94.4",
    "display" : "RM DELLA SPALLA. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.5",
    "display" : "RM DEL BRACCIO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.6",
    "display" : "RM DEL GOMITO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.7",
    "display" : "RM DELL'AVAMBRACCIO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.8",
    "display" : "RM DEL POLSO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.9",
    "display" : "RM DELLA MANO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.A",
    "display" : "RM DEL BACINO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.B",
    "display" : "RM DELL'ARTICOLAZIONE COXOFEMORALE MONO E/O BILATERALE. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.C",
    "display" : "RM DELLA COSCIA [RM DEL FEMORE]. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.D",
    "display" : "RM DEL GINOCCHIO. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.E",
    "display" : "RM DELLA GAMBA. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.F",
    "display" : "RM DELLA CAVIGLIA. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.G",
    "display" : "RM DEL PIEDE. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.H",
    "display" : "RM DELLA SPALLA SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.J",
    "display" : "RM DEL BRACCIO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.K",
    "display" : "RM DEL GOMITO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.L",
    "display" : "RM DELL'AVAMBRACCIO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.M",
    "display" : "RM DEL POLSO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.N",
    "display" : "RM DELLA MANO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.P",
    "display" : "RM DEL BACINO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.Q",
    "display" : "RM DELL'ARTICOLAZIONE COXOFEMORALE MONO E/O BILATERALE SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.R",
    "display" : "RM DELLA COSCIA [RM DEL FEMORE] SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.S",
    "display" : "RM DEL GINOCCHIO SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.T",
    "display" : "RM DELLA GAMBA SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.U",
    "display" : "RM DELLA CAVIGLIA SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.V",
    "display" : "RM DEL PIEDE SENZA E CON MDC. Incluso: parti molli, distretto vascolare"
  },
  {
    "code" : "88.94.W",
    "display" : "ANGIO RM DELL'ARTO INFERIORE"
  },
  {
    "code" : "88.94.X",
    "display" : "ANGIO RM DELL'ARTO SUPERIORE"
  },
  {
    "code" : "88.94.Y",
    "display" : "ANGIO RM DELL'ARTO INFERIORE SENZA E CON MDC"
  },
  {
    "code" : "88.94.Z",
    "display" : "ANGIO RM DELL'ARTO SUPERIORE SENZA E CON MDC"
  },
  {
    "code" : "88.95.1",
    "display" : "RM DELL'ADDOME SUPERIORE. Incluso: Fegato e vie biliari, milza, pancreas, reni e surreni, retroperitoneo e relativo distretto vascolare"
  },
  {
    "code" : "88.95.2",
    "display" : "RM DELL'ADDOME SUPERIORE, SENZA E CON MDC. Incluso: Fegato e vie biliari, milza, pancreas, reni e surreni, retroperitoneo e relativo distretto vascolare"
  },
  {
    "code" : "88.95.3",
    "display" : "ANGIO RM DELL'ADDOME SUPERIORE"
  },
  {
    "code" : "88.95.4",
    "display" : "RM DI ADDOME INFERIORE E SCAVO PELVICO. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.95.5",
    "display" : "RM DI ADDOME INFERIORE E SCAVO PELVICO SENZA E CON MDC. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.95.6",
    "display" : "ANGIO RM DELL'ADDOME INFERIORE"
  },
  {
    "code" : "88.95.7",
    "display" : "ANGIO RM DELL'ADDOME SUPERIORE SENZA E CON MDC"
  },
  {
    "code" : "88.95.8",
    "display" : "RM DI INGUINE. SCROTO E/O PENE. Incluso: relativo distretto vascolare"
  },
  {
    "code" : "88.95.9",
    "display" : "RM DI INGUINE. SCROTO E/O PENE SENZA E CON MDC. Incluso: relativo distretto vascolare. Non associabile a RM DI ADDOME INFERIORE E SCAVO PELVICO SENZA E CON MDC (88.95.5)"
  },
  {
    "code" : "88.95.A",
    "display" : "ANGIO RM DELL'ADDOME INFERIORE SENZA E CON MDC"
  },
  {
    "code" : "88.95.B",
    "display" : "RM ENDOCAVITARIA"
  },
  {
    "code" : "88.95.C",
    "display" : "RM ENDOCAVITARIA SENZA E CON MDC"
  },
  {
    "code" : "88.95.D",
    "display" : "RM ADDOME INFERIORE CON STUDIO DINAMICO DEL PAVIMENTO PELVICO"
  },
  {
    "code" : "88.95.E",
    "display" : "RM UROGRAFIA"
  },
  {
    "code" : "88.95.F",
    "display" : "RM FETALE"
  },
  {
    "code" : "88.97.2",
    "display" : "RM DIFFUSIONE. Incluso tensore di diffusione. Incluso: Esame di base"
  },
  {
    "code" : "88.97.4",
    "display" : "RM SPETTROSCOPIA. Incluso: Esame di base"
  },
  {
    "code" : "88.97.6",
    "display" : "RM PERFUSIONE. Incluso: Esame di base"
  },
  {
    "code" : "88.97.8",
    "display" : "RM DIFFUSIONE. PERFUSIONE SENZA E CON MDC. Incluso: Esame di base"
  },
  {
    "code" : "88.97.9",
    "display" : "RM DELLE VIE DIGESTIVE CON MDC ORALE. Non associabile a RM DELL'ADDOME SUPERIORE (88.95.1), RM DELL'ADDOME SUPERIORE, SENZA E CON MDC (88.95.2), RM DI ADDOME INFERIORE E SCAVO PELVICO (88.95.4), RM DI ADDOME INFERIORE E SCAVO PELVICO SENZA E CON MDC (88.95.5)"
  },
  {
    "code" : "88.97.A",
    "display" : "COLANGIO RM"
  },
  {
    "code" : "88.97.B",
    "display" : "COLANGIO RM. Con stimolo farmacologico"
  },
  {
    "code" : "88.97.C",
    "display" : "RM DELLE VIE DIGESTIVE CON MDC ORALE SENZA E CON MDC VENOSO. Non associabile a RM DELL'ADDOME SUPERIORE (88.95.1), RM DELL'ADDOME SUPERIORE, SENZA E CON MDC (88.95.2), RM DI ADDOME INFERIORE E SCAVO PELVICO (88.95.4), RM DI ADDOME INFERIORE E SCAVO PELVICO SENZA E CON MDC (88.95.5)"
  },
  {
    "code" : "88.99.3",
    "display" : "DENSITOMETRIA OSSEA. DXA TOTAL BODY"
  },
  {
    "code" : "88.99.4",
    "display" : "DENSITOMETRIA OSSEA. TC MONODISTRETTUALE"
  },
  {
    "code" : "88.99.5",
    "display" : "DENSITOMETRIA OSSEA AD ULTRASUONI"
  },
  {
    "code" : "88.99.6",
    "display" : "DENSITOMETRIA OSSEA. DXA LOMBARE"
  },
  {
    "code" : "88.99.7",
    "display" : "DENSITOMETRIA OSSEA. DXA FEMORALE"
  },
  {
    "code" : "88.99.8",
    "display" : "DENSITOMETRIA OSSEA. DXA ULTRADISTALE"
  },
  {
    "code" : "89.01",
    "display" : "VISITA DI CONTROLLO (di routine o di follow up). Escluso: le visite di controllo specificamente codificate"
  },
  {
    "code" : "89.01.1",
    "display" : "VISITA ANESTESIOLOGICA/ALGOLOGICA DI CONTROLLO.Incluso: eventuale rimozione di catetere venoso centrale ad inserzione periferica (PICC). Incluso: eventuale controllo, programmazione e ricarica di pompa. Incluso farmaco"
  },
  {
    "code" : "89.01.2",
    "display" : "VISITA ANGIOLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.3",
    "display" : "VISITA CARDIOLOGICA DI CONTROLLO. Incluso eventuale ECG."
  },
  {
    "code" : "89.01.4",
    "display" : "VISITA CHIRURGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.5",
    "display" : "VISITA DI CHIRURGIA PLASTICA DI CONTROLLO"
  },
  {
    "code" : "89.01.6",
    "display" : "VISITA CHIRURGICA VASCOLARE DI CONTROLLO"
  },
  {
    "code" : "89.01.7",
    "display" : "VISITA DERMATOLOGICA/ALLERGOLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.8",
    "display" : "VISITA ENDOCRINOLOGICA DI CONTROLLO. Incluso: eventuale controllo di microinfusore"
  },
  {
    "code" : "89.01.9",
    "display" : "VISITA GASTROENTEROLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.A",
    "display" : "VISITA DI MEDICINA NUCLEARE DI CONTROLLO"
  },
  {
    "code" : "89.01.B",
    "display" : "VISITA NEFROLOGICA DI CONTROLLO. Incluso: verifica dell'adesione al trattamento conservativo (dietetico e farmacologico), sostitutivo (adeguatezza al trattamento dialitico) e funzione rene trapiantato. Con eventuale rimodulazione del piano di trattamento"
  },
  {
    "code" : "89.01.C",
    "display" : "VISITA NEUROLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.D",
    "display" : "VISITA OCULISTICA DI CONTROLLO. Incluso: Esame clinico parziale, mirato solo ad alcuni aspetti del sistema visivo"
  },
  {
    "code" : "89.01.E",
    "display" : "VISITA ODONTOSTOMATOLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.F",
    "display" : "VISITA ONCOLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.01.G",
    "display" : "VISITA ORTOPEDICA DI CONTROLLO"
  },
  {
    "code" : "89.01.H",
    "display" : "VISITA OTORINOLARINGOIATRICA DI CONTROLLO. Incluso: eventuale rimozione di cerume"
  },
  {
    "code" : "89.01.L",
    "display" : "VISITA PNEUMOLOGICA DI CONTROLLO. Incluso: eventuale rilevazione incruenta della saturazione arteriosa"
  },
  {
    "code" : "89.01.N",
    "display" : "VISITA DI RADIOLOGIA INTERVENTISTICA DI CONTROLLO"
  },
  {
    "code" : "89.01.P",
    "display" : "VISITA RADIOTERAPICA DI CONTROLLO"
  },
  {
    "code" : "89.01.Q",
    "display" : "VISITA UROLOGICA DI CONTROLLO. Incluso: eventuale rimozione e/o controllo del catetere vescicale e/o nefrostomico"
  },
  {
    "code" : "89.01.R",
    "display" : "VISITA DI CONTROLLO PER CURE PALLIATIVE. Incluso: rivalutazione del Piano Assistenziale Individuale (PAI)"
  },
  {
    "code" : "89.01.S",
    "display" : "VISITA DI CONTROLLO DI CHIRURGIA MAXILLLO FACCIALE"
  },
  {
    "code" : "89.01.W",
    "display" : "VISITA DI MEDICINA FISICA E RIABILITAZIONE DI CONTROLLO"
  },
  {
    "code" : "89.01.Y",
    "display" : "VISITA GENETICA DI CONTROLLO. Consulenza Genetica successiva alla prima in paziente ancora senza diagnosi. Visita specialistica genetica con esame obiettivo, rivalutazione della documentazione clinica recente e remota. Consultazione della letteratura scientifica e di database di genetica clinica specifici. Affinamento dell'ipotesi diagnostica pregressa e scelta di eventuale nuovo test genetico appropriato. Spiegazione di vantaggi e limiti del test genetico e somministrazione dei consensi informati. Scrittura della relazione"
  },
  {
    "code" : "89.02",
    "display" : "VISITA A COMPLETAMENTO DELLA PRIMA VISITA"
  },
  {
    "code" : "89.07",
    "display" : "VISITA MULTIDISCIPLINARE. Incluso: eventuale stesura di PROGETTO RIABILITATIVO INDIVIDUALE MULTIDISCIPLINARE"
  },
  {
    "code" : "89.07.A",
    "display" : "PRIMA VISITA MULTIDISCIPLINARE PER CURE PALLIATIVE. Incluso: stesura del Piano Assistenziale Individuale (PAI)"
  },
  {
    "code" : "89.12",
    "display" : "RINOMANOMETRIA"
  },
  {
    "code" : "89.12.1",
    "display" : "RINOMANOMETRIA CON TEST DI PROVOCAZIONE"
  },
  {
    "code" : "89.13",
    "display" : "PRIMA VISITA NEUROLOGICA [NEUROCHIRURGICA]. Incluso: eventuale fundus oculi e Minimental test (MMSE)"
  },
  {
    "code" : "89.14",
    "display" : "ELETTROENCEFALOGRAMMA. Escluso: EEG con polisonnogramma (89.17)"
  },
  {
    "code" : "89.14.1",
    "display" : "ELETTROENCEFALOGRAMMA CON SONNO"
  },
  {
    "code" : "89.14.2",
    "display" : "ELETTROENCEFALOGRAMMA CON PRIVAZIONE DEL SONNO"
  },
  {
    "code" : "89.14.3",
    "display" : "ELETTROENCEFALOGRAMMA DINAMICO [12-24 ORE]"
  },
  {
    "code" : "89.14.5",
    "display" : "ELETTROENCEFALOGRAMMA CON ANALISI SPETTRALE Con mappaggio"
  },
  {
    "code" : "89.15.1",
    "display" : "POTENZIALI EVOCATI ACUSTICI"
  },
  {
    "code" : "89.15.2",
    "display" : "POTENZIALI EVOCATI STIMOLO ED EVENTO CORRELATI. Potenziali evocati speciali (olfattivi, trigeminali)"
  },
  {
    "code" : "89.15.3",
    "display" : "POTENZIALI EVOCATI MOTORI. Arto superiore o inferiore"
  },
  {
    "code" : "89.15.4",
    "display" : "POTENZIALI EVOCATI SOMATO SENSORIALI. Per nervo o dermatomero"
  },
  {
    "code" : "89.15.5",
    "display" : "TEST NEUROFISIOLOGICI PER LA VALUTAZIONE DEL SISTEMA NERVOSO VEGETATIVO. Incluso: Analisi spettrale o registrazione poligrafica"
  },
  {
    "code" : "89.15.7",
    "display" : "POLIGRAFIA DINAMICA Incluso: Elettromiografia di superfice per disordini del movimentoEscluso: Test neurofisiologici per la valutazione del sistema nervoso vegetativo (89.15.5)"
  },
  {
    "code" : "89.15.A",
    "display" : "POTENZIALI EVOCATI VESTIBOLARI (VEMPS)"
  },
  {
    "code" : "89.15.B",
    "display" : "POTENZIALI EVOCATI DA STIMOLO LASER (LEP)"
  },
  {
    "code" : "89.17",
    "display" : "POLISONNOGRAFIA diurna o notturna e con metodi speciali Incluso EEG (89.14)"
  },
  {
    "code" : "89.17.3",
    "display" : "MONITORAGGIO CARDIORESPIRATORIO NOTTURNO COMPLETOPer studio apnee"
  },
  {
    "code" : "89.19.1",
    "display" : "ELETTROENCEFALOGRAMMA CON VIDEOREGISTRAZIONE"
  },
  {
    "code" : "89.19.2",
    "display" : "POLIGRAFIA CON VIDEOREGISTRAZIONE"
  },
  {
    "code" : "89.24",
    "display" : "ESAME URODINAMICO NON INVASIVO (UROFLUSSOMETRIA). Incluso: Controllo ecografico post minzionale. Non associabile a ECOGRAFIA DELL'ADDOME INFERIORE (88.75.1) e ECOGRAFIA DELL'ADDOME COMPLETO (88.76.1)"
  },
  {
    "code" : "89.26.1",
    "display" : "PRIMA VISITA GINECOLOGICA. Incluso: eventuale prelievo citologico, eventuali indicazioni in funzione anticoncezionale e preconcezionale. Non associabile a 89.26.3 PRIMA VISITA OSTETRICA"
  },
  {
    "code" : "89.26.2",
    "display" : "VISITA GINECOLOGICA DI CONTROLLO. Incluso: eventuale prelievo citologico, eventuale rimozione di dispositivo contraccettivo intrauterino, eventuale rimozione di corpo estraneo intraluminale dalla vagina senza incisione, eventuali indicazioni per la gravidanza"
  },
  {
    "code" : "89.26.3",
    "display" : "PRIMA VISITA OSTETRICA. Incluso: eventuale prelievo citologico. Non associabile a 89.26.1 PRIMA VISITA GINECOLOGICA"
  },
  {
    "code" : "89.26.4",
    "display" : "VISITA OSTETRICA DI CONTROLLO. Incluso: eventuale prelievo citologico. Non associabile al codice 89.26.2 VISITA GINECOLOGICA DI CONTROLLO"
  },
  {
    "code" : "89.26.5",
    "display" : "VERSIONE CEFALICA ESTERNA"
  },
  {
    "code" : "89.32",
    "display" : "MANOMETRIA ESOFAGEA"
  },
  {
    "code" : "89.32.1",
    "display" : "MANOMETRIA ESOFAGEA 24 Ore"
  },
  {
    "code" : "89.37.1",
    "display" : "SPIROMETRIA SEMPLICE. Non associabile a 89.37.4 TEST DI BRONCODILATAZIONE FARMACOLOGICA"
  },
  {
    "code" : "89.37.2",
    "display" : "SPIROMETRIA GLOBALE [con tecnica di diluizione, pletismografia o altra metodica]"
  },
  {
    "code" : "89.37.3",
    "display" : "SPIROMETRIA SEPARATA DEI DUE POLMONI (METODICA DI ARNAUD)"
  },
  {
    "code" : "89.37.4",
    "display" : "TEST DI BRONCODILATAZIONE FARMACOLOGICA. Spirometria basale e dopo somministrazione di farmaco. Non associabile a 89.37.1 SPIROMETRIA SEMPLICE e 89.37.2 SPIROMETRIA GLOBALE. Incluso farmaco"
  },
  {
    "code" : "89.37.5",
    "display" : "TEST DI PROVOCAZIONE BRONCHIALE CON AGENTE BRONCOCOSTRITTORE"
  },
  {
    "code" : "89.37.6",
    "display" : "TEST DI PROVOCAZIONE BRONCHIALE CON AGENTE BRONCOCOSTRITTORE. Singolo stimolo. Spirometria di base e spirometrie di controllo fino ad un massimo di 8"
  },
  {
    "code" : "89.38.1",
    "display" : "RESISTENZE DELLE VIE AEREE Escluso: Spirometria"
  },
  {
    "code" : "89.38.2",
    "display" : "SPIROMETRIA GLOBALE CON TECNICA PLETISMOGRAFICA"
  },
  {
    "code" : "89.38.3",
    "display" : "DIFFUSIONE ALVEOLO-CAPILLARE DEL CO"
  },
  {
    "code" : "89.38.4",
    "display" : "COMPLIANCE POLMONARE STATICA E DINAMICA"
  },
  {
    "code" : "89.38.5",
    "display" : "DETERMINAZIONE DEL PATTERN RESPIRATORIO A RIPOSO"
  },
  {
    "code" : "89.38.6",
    "display" : "VALUTAZIONE DELLA VENTILAZIONE E DEI GAS ESPIRATI E RELATIVI PARAMETRI. Incluso: Capnogramma"
  },
  {
    "code" : "89.38.7",
    "display" : "DETERMINAZIONE DELLE MASSIME PRESSIONI INSPIRATORIE ED ESPIRATORIE O TRANSDIAFRAMMATICHE"
  },
  {
    "code" : "89.38.8",
    "display" : "TEST DI DISTRIBUZIONE DELLA VENTILAZIONE CON GAS NON RADIOATTIVI"
  },
  {
    "code" : "89.38.9",
    "display" : "DETERMINAZIONE DELLA P 0.1"
  },
  {
    "code" : "89.39.3",
    "display" : "VALUTAZIONE DELLA SOGLIA DI SENSIBILITA' VIBRATORIA"
  },
  {
    "code" : "89.39.4",
    "display" : "GUSTOMETRIA [OLFATTOMETRIA]"
  },
  {
    "code" : "89.39.6",
    "display" : "OSSERVAZIONE DELLE LESIONI CUTANEE O ANNESSI CUTANEI CON VIDEODERMATOSCOPIO"
  },
  {
    "code" : "89.41",
    "display" : "TEST CARDIOVASCOLARE DA SFORZO CON CICLOERGOMETRO O CON PEDANA MOBILE. Escluso: Test da sforzo cardiopolmonare (89.44.1)"
  },
  {
    "code" : "89.44",
    "display" : "ALTRI TEST CARDIOVASCOLARI DA SFORZO"
  },
  {
    "code" : "89.44.1",
    "display" : "TEST DA SFORZO CARDIOPOLMONARE. Incluso: ECG (89.52) , Analisi dei gas respiratori, Determinazione della ventilazione, Emogasanalisi"
  },
  {
    "code" : "89.44.2",
    "display" : "TEST DEL CAMMINO CON VALUTAZIONE DELLA SATURAZIONE ARTERIOSA [WALKING TEST]"
  },
  {
    "code" : "89.48.1",
    "display" : "CONTROLLO E PROGRAMMAZIONE PACE-MAKER. Incluso: ECG (89.52)"
  },
  {
    "code" : "89.48.2",
    "display" : "CONTROLLO E PROGRAMMAZIONE DEFIBRILLATORE IMPIANTABILE Incluso: ECG (89.52). Il referto deve comprendere le risultanze dell'ECG"
  },
  {
    "code" : "89.50",
    "display" : "ELETTROCARDIOGRAMMA DINAMICO (secondo Holter)"
  },
  {
    "code" : "89.52",
    "display" : "ELETTROCARDIOGRAMMA"
  },
  {
    "code" : "89.52.1",
    "display" : "ELETTROCARDIOGRAMMA CON TEST PROVOCATIVI E/O PROVE FARMACOLOGICHE"
  },
  {
    "code" : "89.52.2",
    "display" : "ELETTROCARDIOGRAMMA TRANSESOFAGEO"
  },
  {
    "code" : "89.52.3",
    "display" : "ELETTROCARDIOGRAMMA TRANSESOFAGEO CON STUDIO ELETTROFISIOLOGICO"
  },
  {
    "code" : "89.54",
    "display" : "MONITORAGGIO ELETTROCARDIOGRAFICO Telemetria, ECG con studio dei potenziali tardivi, monitoraggio degli eventi tramite registrazione. Escluso: Elettrocardiogramma dinamico (89.50)"
  },
  {
    "code" : "89.58.1",
    "display" : "PLETISMOGRAFIA DEGLI ARTI SUPERIORI O INFERIORI ARTERIOSA O VENOSA. A riposo o dopo prova fisica o farmacologica"
  },
  {
    "code" : "89.58.9",
    "display" : "MISURAZIONE INDICE PRESSORIO CAVIGLIA/BRACCIO (ABI)"
  },
  {
    "code" : "89.59.1",
    "display" : "TEST CARDIOVASCOLARI PER VALUTAZIONE DI NEUROPATIA AUTONOMICA Escluso: HEAD UP TILT TEST (89.59.2)"
  },
  {
    "code" : "89.59.2",
    "display" : "HEAD UP TILT TEST"
  },
  {
    "code" : "89.61.1",
    "display" : "MONITORAGGIO CONTINUO [24 Ore] DELLA PRESSIONE ARTERIOSA"
  },
  {
    "code" : "89.61.2",
    "display" : "PULSOSSIMETRIA NOTTURNA"
  },
  {
    "code" : "89.65.1",
    "display" : "EMOGASANALISI ARTERIOSA SISTEMICA Emogasanalisi di sangue capillare o arterioso. Inclusa determinazione di pH ematico, Carbossiemoglobina e Metaemoglobina"
  },
  {
    "code" : "89.65.2",
    "display" : "EMOGASANALISI DURANTE RESPIRAZIONE DI O2 AD ALTA CONCENTRAZIONE. Test dell' iperossia"
  },
  {
    "code" : "89.65.3",
    "display" : "EMOGASANALISI DURANTE RESPIRAZIONE DI O2 A BASSA CONCENTRAZIONE Test dell' ipossia"
  },
  {
    "code" : "89.65.4",
    "display" : "MONITORAGGIO TRANSCUTANEO DI O2 E CO2"
  },
  {
    "code" : "89.65.5",
    "display" : "MONITORAGGIO INCRUENTO DELLA SATURAZIONE ARTERIOSA / PULSOSSIMETRIA"
  },
  {
    "code" : "89.65.7",
    "display" : "EMOGASANALISI ARTERIOSA PRIMA E DURANTE SOMMINISTRAZIONE DI OSSIGENO"
  },
  {
    "code" : "89.65.8",
    "display" : "MISURA TRANSCUTANEA DELLA PO2 E DELLA PCO2 CON UTILIZZO DI MEMBRANE MONOUSO"
  },
  {
    "code" : "89.66",
    "display" : "EMOGASANALISI DI SANGUE MISTO VENOSO"
  },
  {
    "code" : "89.7",
    "display" : "PRIMA VISITA. Escluso: le prime visite specificamente codificate"
  },
  {
    "code" : "89.7A.1",
    "display" : "PRIMA VISITA ANESTESIOLOGICA/ALGOLOGICA. Prima valutazione per terapia del dolore e programmazione della terapia specifica. Escluso: la visita preoperatoria. Incluso: eventuale stesura del piano nutrizionale"
  },
  {
    "code" : "89.7A.2",
    "display" : "PRIMA VISITA ANGIOLOGICA"
  },
  {
    "code" : "89.7A.3",
    "display" : "PRMA VISITA CARDIOLOGICA. Incluso: ECG (89.52)"
  },
  {
    "code" : "89.7A.4",
    "display" : "PRIMA VISITA CHIRURGICA GENERALE"
  },
  {
    "code" : "89.7A.5",
    "display" : "PRIMA VISITA CHIRURGICA PLASTICA"
  },
  {
    "code" : "89.7A.6",
    "display" : "PRIMA VISITA CHIRURGICA VASCOLARE"
  },
  {
    "code" : "89.7A.7",
    "display" : "PRIMA VISITA DERMATOLOGICA/ALLERGOLOGICA Incluso: Eventuale osservazione in epiluminescenza"
  },
  {
    "code" : "89.7A.8",
    "display" : "PRIMA VISITA ENDOCRINOLOGICA. Incluso: eventuale stesura del piano nutrizionale ed eventuale applicazione di microinfusore sottocute"
  },
  {
    "code" : "89.7A.9",
    "display" : "PRIMA VISITA GASTROENTEROLOGICA"
  },
  {
    "code" : "89.7B.1",
    "display" : "PRIMA VISITA DI GENETICA MEDICA. Visita specialistica genetica con esame obiettivo e valutazione della documentazione clinica recente e remota. Incluso: primo colloquio, anamnesi personale e familiare, costruzione di un albero genealogico familiare nei rami paterno e materno per almeno 3 generazioni. Consultazione della letteratura scientifica e di database di genetica clinica specifici. Formulazione dell'ipotesi diagnostica. Scelta del test genetico appropriato. Spiegazione vantaggi e limiti del test genetico e somministrazione consensi informati. Scrittura della relazione. Escluso: Visita multidisciplinare 89.07"
  },
  {
    "code" : "89.7B.2",
    "display" : "PRIMA VISITA DI CHIRURGIA MAXILLO FACCIALE"
  },
  {
    "code" : "89.7B.3",
    "display" : "PRIMA VISITA DI MEDICINA FISICA E RIABILITAZIONE"
  },
  {
    "code" : "89.7B.4",
    "display" : "PRIMA VISITA DI MEDICINA NUCLEARE Incluso: Valutazione pretrattamento e stesura del piano di trattamento"
  },
  {
    "code" : "89.7B.5",
    "display" : "PRIMA VISITA NEFROLOGICA. Incluso: stesura del piano di trattamento conservativo (dietetico e farmacologico), sostitutivo (dialisi extracorporea o peritoneale) o per trapianto"
  },
  {
    "code" : "89.7B.6",
    "display" : "PRIMA VISITA ODONTOSTOMATOLOGICA. Incluso: eventuale radiografia endorale ed eventuale rimozione di corpo estraneo intraluminale dalla bocca, senza incisione"
  },
  {
    "code" : "89.7B.7",
    "display" : "PRIMA VISITA ONCOLOGICA. Incluso: stesura del piano di trattamento"
  },
  {
    "code" : "89.7B.8",
    "display" : "PRIMA VISITA ORTOPEDICA. Incluso: eventuale podoscopia per prescrizione di plantare"
  },
  {
    "code" : "89.7B.9",
    "display" : "PRIMA VISITA OTORINOLARINGOIATRIA. Incluso, in base allo specifico problema clinico: eventuale otomicroscopia, esame funzionalità vestibolare, utilizzo di fibre ottiche, rimozione di cerume"
  },
  {
    "code" : "89.7C.1",
    "display" : "PRIMA VISITA PNEUMOLOGICA. Incluso: eventuale rilevazione incruenta della saturazione arteriosa"
  },
  {
    "code" : "89.7C.2",
    "display" : "PRIMA VISITA DI RADIOTERAPIA. Incluso: stesura del piano di trattamento"
  },
  {
    "code" : "89.7C.3",
    "display" : "PRIMA VISITA UROLOGICA/ANDROLOGICA. Incluso: esplorazione dei genitali esterni ed esplorazione rettale"
  },
  {
    "code" : "89.7C.4",
    "display" : "PRIMA VISITA DI RADIOLOGIA INTERVENTISTICA"
  },
  {
    "code" : "90.01.2",
    "display" : "17 ALFA IDROSSIPROGESTERONE (17 OH-P)"
  },
  {
    "code" : "90.01.5",
    "display" : "ACIDI BILIARI"
  },
  {
    "code" : "90.01.63",
    "display" : "3 METIL ISTIDINA"
  },
  {
    "code" : "90.02.1",
    "display" : "ACIDO 5 IDROSSI 3 INDOLACETICO"
  },
  {
    "code" : "90.02.2",
    "display" : "ACIDO CITRICO"
  },
  {
    "code" : "90.02.3",
    "display" : "ACIDO DELTA AMINOLEVULINICO (ALA)"
  },
  {
    "code" : "90.02.5",
    "display" : "ACIDO LATTICO"
  },
  {
    "code" : "90.03.2",
    "display" : "ACIDO PIRUVICO"
  },
  {
    "code" : "90.03.6",
    "display" : "ADRENALINA - NORADRENALINA"
  },
  {
    "code" : "90.03.7",
    "display" : "ACIDO FITANICO. DOSAGGIO"
  },
  {
    "code" : "90.03.8",
    "display" : "ACIDO GUANIDINO ACETICO. DOSAGGIO"
  },
  {
    "code" : "90.03.9",
    "display" : "ACIDO PIPECOLICO. DOSAGGIO"
  },
  {
    "code" : "90.03.A",
    "display" : "ACIDO PRISTANICO. DOSAGGIO"
  },
  {
    "code" : "90.03.B",
    "display" : "ACIDO SIALICO LIBERO. DOSAGGIO"
  },
  {
    "code" : "90.03.C",
    "display" : "ACIDO SIALICO TOTALE. DOSAGGIO"
  },
  {
    "code" : "90.03.D",
    "display" : "S-ADENOSILMETIONINA. DOSAGGIO"
  },
  {
    "code" : "90.03.E",
    "display" : "S-ADENOSILOMOCISTEINA. DOSAGGIO"
  },
  {
    "code" : "90.04.1",
    "display" : "ADIURETINA [VASOPRESSINA] (ADH)"
  },
  {
    "code" : "90.04.4",
    "display" : "ALA DEIDRASI ERITROCITARIA"
  },
  {
    "code" : "90.04.5",
    "display" : "ALANINA AMINOTRANSFERASI (ALT) (GPT)"
  },
  {
    "code" : "90.05.1",
    "display" : "ALBUMINA"
  },
  {
    "code" : "90.05.2",
    "display" : "ALDOLASI"
  },
  {
    "code" : "90.05.3",
    "display" : "ALDOSTERONE"
  },
  {
    "code" : "90.05.4",
    "display" : "ALFA 1 ANTITRIPSINA"
  },
  {
    "code" : "90.05.5",
    "display" : "ALFA 1 FETOPROTEINA"
  },
  {
    "code" : "90.06.1",
    "display" : "ALFA 1 GLICOPROTEINA ACIDA"
  },
  {
    "code" : "90.06.2",
    "display" : "ALFA 1 MICROGLOBULINA"
  },
  {
    "code" : "90.06.3",
    "display" : "ALFA 2 MACROGLOBULINA"
  },
  {
    "code" : "90.06.4",
    "display" : "ALFA AMILASI TOTALE"
  },
  {
    "code" : "90.06.5",
    "display" : "ALFA AMILASI ISOENZIMI (Frazione pancreatica)"
  },
  {
    "code" : "90.07.1",
    "display" : "ALLUMINIO"
  },
  {
    "code" : "90.07.2",
    "display" : "AMINOACIDI. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "90.07.3",
    "display" : "AMINOACIDI TOTALI, FRAZIONAMENTO CROMATOGRAFICO"
  },
  {
    "code" : "90.07.5",
    "display" : "AMMONIO"
  },
  {
    "code" : "90.08.1",
    "display" : "ANDROSTANEDIOLO GLUCURONIDE"
  },
  {
    "code" : "90.08.2",
    "display" : "ANGIOTENSINA II"
  },
  {
    "code" : "90.08.4",
    "display" : "APOLIPOPROTEINA -A1"
  },
  {
    "code" : "90.08.5",
    "display" : "APOLIPOPROTEINA B"
  },
  {
    "code" : "90.09.1",
    "display" : "APTOGLOBINA"
  },
  {
    "code" : "90.09.2",
    "display" : "ASPARTATO AMINOTRANSFERASI (AST) (GOT)"
  },
  {
    "code" : "90.10.1",
    "display" : "BETA2 MICROGLOBULINA"
  },
  {
    "code" : "90.10.2",
    "display" : "BICARBONATI (Idrogenocarbonato)"
  },
  {
    "code" : "90.10.5",
    "display" : "BILIRUBINA REFLEX (cut-off >1 mg/dL salvo definizione di cut-off più restrittivi a livello regionale. Incluso: Bilirubina Diretta ed Indiretta"
  },
  {
    "code" : "90.10.6",
    "display" : "DOSAGGIO BIOTINIDASI. DOSAGGIO"
  },
  {
    "code" : "90.10.7",
    "display" : "BILIRUBINA DIRETTA. Non associabile a 90.10.5"
  },
  {
    "code" : "90.11.1",
    "display" : "C PEPTIDE"
  },
  {
    "code" : "90.11.2",
    "display" : "C PEPTIDE. DOSAGGIO BASALE E DOPO STIMOLO"
  },
  {
    "code" : "90.11.4",
    "display" : "CALCIO TOTALE"
  },
  {
    "code" : "90.11.5",
    "display" : "CALCITONINA"
  },
  {
    "code" : "90.11.6",
    "display" : "CALCIO IONIZZATO (calcolo indiretto). Erogabile solo in associazione ai codici CALCIO TOTALE (90.11.4) e PROTEINE TOTALI (90.38.5)"
  },
  {
    "code" : "90.11.7",
    "display" : "CALCIO IONIZZATO determinazione diretta"
  },
  {
    "code" : "90.12.1",
    "display" : "CALCOLI E CONCREZIONI"
  },
  {
    "code" : "90.12.5",
    "display" : "CERULOPLASMINA"
  },
  {
    "code" : "90.12.A",
    "display" : "CALPROTECTINA FECALE"
  },
  {
    "code" : "90.13.1",
    "display" : "CHIMOTRIPSINA"
  },
  {
    "code" : "90.13.3",
    "display" : "CLORURO"
  },
  {
    "code" : "90.13.5",
    "display" : "COBALAMINA (VIT. B12)"
  },
  {
    "code" : "90.13.A",
    "display" : "CISTATINA C. Non associabile a Creatinina 90.16.3 e Creatinina clearance 90.16.4"
  },
  {
    "code" : "90.13.B",
    "display" : "COLESTEROLO LDL. Determinazione indiretta. Erogabile solo in associazione a Colesterolo HDL (90.14.1), Colesterolo totale (90.14.3) e Trigliceridi (90.43.2)"
  },
  {
    "code" : "90.13.C",
    "display" : "COLESTEROLO LDL. Determinazione diretta"
  },
  {
    "code" : "90.14.1",
    "display" : "COLESTEROLO HDL"
  },
  {
    "code" : "90.14.3",
    "display" : "COLESTEROLO TOTALE"
  },
  {
    "code" : "90.15.2",
    "display" : "CORTICOTROPINA (ACTH)"
  },
  {
    "code" : "90.15.3",
    "display" : "CORTISOLO"
  },
  {
    "code" : "90.15.4",
    "display" : "CREATINA CHINASI (CPK o CK)"
  },
  {
    "code" : "90.16.3",
    "display" : "CREATININA. Non associabile a 90.16.4"
  },
  {
    "code" : "90.16.4",
    "display" : "CREATININA CLEARANCE. Non associabile a CREATININA (90.16.3)"
  },
  {
    "code" : "90.16.5",
    "display" : "CROMO"
  },
  {
    "code" : "90.16.6",
    "display" : "CROMOGRANINA A"
  },
  {
    "code" : "90.16.8",
    "display" : "DECARBOSSIPROTROMBINA"
  },
  {
    "code" : "90.16.9",
    "display" : "CREATINA. DOSAGGIO"
  },
  {
    "code" : "90.17.2",
    "display" : "DEIDROEPIANDROSTERONE SOLFATO (DEA-S)"
  },
  {
    "code" : "90.17.3",
    "display" : "DELTA 4 ANDROSTENEDIONE"
  },
  {
    "code" : "90.17.5",
    "display" : "DIIDROTESTOSTERONE (DHT)"
  },
  {
    "code" : "90.17.6",
    "display" : "HCG FRAZIONE LIBERA E PAPP-A"
  },
  {
    "code" : "90.17.8",
    "display" : "TRI TEST: ALFAFETOPROTEINA (AFP), HCG TOTALE O FRAZIONE LIBERA, ESTRIOLO (E3). DETERMINAZIONI DI RISCHIO PRENATALE PER ANOMALIE CROMOSOMICHE E DIFETTI DEL TUBO NEURALE"
  },
  {
    "code" : "90.17.B",
    "display" : "FARMACI CON METODI CROMATOGRAFICI"
  },
  {
    "code" : "90.17.C",
    "display" : "FARMACI CON TECNICHE NON CROMATOGRAFICHE"
  },
  {
    "code" : "90.17.D",
    "display" : "ELASTASI 1 PANCREATICA"
  },
  {
    "code" : "90.17.E",
    "display" : "ENZIMA DI CONVERSIONE DELL'ANGIOTENSINA (ACE)"
  },
  {
    "code" : "90.17.F",
    "display" : "7-DEIDROCOLESTEROLO. DOSAGGIO"
  },
  {
    "code" : "90.17.G",
    "display" : "ORMONE ANTI-MULLERIANO (AMH). DOSAGGIO"
  },
  {
    "code" : "90.18.4",
    "display" : "ENOLASI NEURONESPECIFICA (NSE)"
  },
  {
    "code" : "90.18.5",
    "display" : "ERITROPOIETINA"
  },
  {
    "code" : "90.19.2",
    "display" : "ESTRADIOLO (E2)"
  },
  {
    "code" : "90.20.1",
    "display" : "ETANOLO"
  },
  {
    "code" : "90.21.2",
    "display" : "FATTORE NATRIURETICO ATRIALE (ANP)"
  },
  {
    "code" : "90.21.4",
    "display" : "FECI SANGUE OCCULTO"
  },
  {
    "code" : "90.22.3",
    "display" : "FERRITINA"
  },
  {
    "code" : "90.22.5",
    "display" : "FERRO"
  },
  {
    "code" : "90.23.2",
    "display" : "FOLATO"
  },
  {
    "code" : "90.23.3",
    "display" : "FOLLITROPINA (FSH)"
  },
  {
    "code" : "90.23.4",
    "display" : "FOSFATASI ACIDA"
  },
  {
    "code" : "90.23.5",
    "display" : "FOSFATASI ALCALINA"
  },
  {
    "code" : "90.24.1",
    "display" : "FOSFATASI ALCALINA ISOENZIMA OSSEO"
  },
  {
    "code" : "90.24.3",
    "display" : "FOSFATO INORGANICO (FOSFORO)"
  },
  {
    "code" : "90.25.5",
    "display" : "GAMMA-GLUTAMILTRANSFERASI (gamma GT)"
  },
  {
    "code" : "90.25.6",
    "display" : "GALATTOSIO 1-FOSFATO URIDIL TRANSFERASI (GALT)"
  },
  {
    "code" : "90.25.7",
    "display" : "GLOBULINA DI TRASPORTO ORMONI SESSUALI (SHBG)"
  },
  {
    "code" : "90.25.8",
    "display" : "GALATTOSIO-1-FOSFATO. DOSAGGIO"
  },
  {
    "code" : "90.26.1",
    "display" : "GASTRINA"
  },
  {
    "code" : "90.26.3",
    "display" : "GLUCAGONE"
  },
  {
    "code" : "90.26.5",
    "display" : "GLUCOSIO DOSAGGIO SERIALE DOPO CARICO (da 2 a 4 determinazioni). Inclusa Determinazione del Glucosio basale 90.27.1"
  },
  {
    "code" : "90.27.1",
    "display" : "GLUCOSIO"
  },
  {
    "code" : "90.27.2",
    "display" : "GLUCOSIO 6 FOSFATO DEIDROGENASI (G6PDH)"
  },
  {
    "code" : "90.27.3",
    "display" : "GONADOTROPINA CORIONICA (Prova immunologica di gravidanza)"
  },
  {
    "code" : "90.27.4",
    "display" : "GONADOTROPINA CORIONICA (Subunità beta, frazione libera)"
  },
  {
    "code" : "90.27.5",
    "display" : "GONADOTROPINA CORIONICA (Subunità beta, molecola intera)"
  },
  {
    "code" : "90.27.6",
    "display" : "IODURIA"
  },
  {
    "code" : "90.28.1",
    "display" : "Hb - EMOGLOBINA GLICATA"
  },
  {
    "code" : "90.28.4",
    "display" : "IMMUNOGLOBULINE: CATENE KAPPA E LAMBDA"
  },
  {
    "code" : "90.28.5",
    "display" : "INSULINA (Curva da carico o dopo test farmacologici, max. 5)"
  },
  {
    "code" : "90.28.7",
    "display" : "IMMUNOGLOBULINE: CATENE K E LAMBDA LIBERE"
  },
  {
    "code" : "90.28.C",
    "display" : "INIBINA B"
  },
  {
    "code" : "90.29.1",
    "display" : "INSULINA"
  },
  {
    "code" : "90.29.2",
    "display" : "LATTATO DEIDROGENASI (LDH)"
  },
  {
    "code" : "90.30.2",
    "display" : "LIPASI PANCREATICA"
  },
  {
    "code" : "90.30.3",
    "display" : "LIPOPROTEINA (a)"
  },
  {
    "code" : "90.30.4",
    "display" : "LIQUIDI DA VERSAMENTI ESAME CHIMICO FISICO E MICROSCOPICO"
  },
  {
    "code" : "90.30.5",
    "display" : "LIQUIDO AMNIOTICO ENZIMI (cellobiasi, lattasi, maltasi, palatinasi, saccarasi, trealasi, acetil-colinesterasi). Per ciascuna determinazione"
  },
  {
    "code" : "90.31.1",
    "display" : "LIQUIDO AMNIOTICO FOSFOLIPIDI (Cromatografia)"
  },
  {
    "code" : "90.31.2",
    "display" : "LIQUIDO AMNIOTICO RAPPORTO LECITINA/SFINGOMIELINA"
  },
  {
    "code" : "90.31.3",
    "display" : "LIQUIDO AMNIOTICO TEST ALLA SCHIUMA DI CLEMENTS"
  },
  {
    "code" : "90.31.6",
    "display" : "LIQUIDO SEMINALE [SPERMIOGRAMMA] ESAME MACROSCOPICO (volume, pH, aspetto, viscosità, fluidificazione) E MICROSCOPICO della componente nemaspermica (numero, motilità, morfologia previa colorazione specifica) e della componente cellulare non nemaspermica"
  },
  {
    "code" : "90.31.7",
    "display" : "LIQUIDO SEMINALE [SPERMIOGRAMMA] TEST DI VITALITA' previa colorazione con eosina"
  },
  {
    "code" : "90.31.8",
    "display" : "LIQUIDO SEMINALE PROFILO BIOCHIMICO (Fruttosio, Carnitina, Fosfatasi prostatica o Zinco o Acido citrico, Alfa Glucosidasi o Maltasi). Per ciascuna determinazione (Sono prescrivibili al massimo 4 determinazioni)"
  },
  {
    "code" : "90.31.9",
    "display" : "BRUSHING NASALE PER BATTITO CILIARE"
  },
  {
    "code" : "90.32.1",
    "display" : "LIQUIDO SINOVIALE ESAME CHIMICO FISICO E MICROSCOPICO"
  },
  {
    "code" : "90.32.2",
    "display" : "LITIO"
  },
  {
    "code" : "90.32.4",
    "display" : "LUTEOTROPINA (LH) E FOLLITROPINA (FSH): Dosaggi seriati dopo GNRH o altro stimolo (da 3 a 6). Per ciascuna curva"
  },
  {
    "code" : "90.32.5",
    "display" : "MAGNESIO TOTALE"
  },
  {
    "code" : "90.32.6",
    "display" : "LISOZIMA/S"
  },
  {
    "code" : "90.33.4",
    "display" : "ALBUMINURIA [MICROALBUMINURIA]"
  },
  {
    "code" : "90.33.5",
    "display" : "MIOGLOBINA"
  },
  {
    "code" : "90.33.6",
    "display" : "METANEFRINE FRAZIONATE"
  },
  {
    "code" : "90.33.A",
    "display" : "NEUROTRASMETTITORI. DOSAGGIO Liquor"
  },
  {
    "code" : "90.34.2",
    "display" : "NICHEL"
  },
  {
    "code" : "90.34.4",
    "display" : "OLIGOELEMENTI. DOSAGGIO PER CIASCUN OLIGOELEMENTO"
  },
  {
    "code" : "90.34.6",
    "display" : "OMOCISTEINA"
  },
  {
    "code" : "90.34.7",
    "display" : "OSMOLALITA'/OSMOLARITA'. Determinazione diretta"
  },
  {
    "code" : "90.34.8",
    "display" : "OSMOLALITA'. Determinazione indiretta nei casi in cui non è possibile la determinazione diretta. Non associabile a Glucosio (90.27.1),Sodio (90.40.4), Urea (90.44.1) e Potassio (90.37.4)"
  },
  {
    "code" : "90.34.A",
    "display" : "INSULIN-LIKE GROWTH FACTOR BINDING PROTEIN 3 [IGF - BP3]"
  },
  {
    "code" : "90.35.1",
    "display" : "ORMONE SOMATOTROPO (GH)"
  },
  {
    "code" : "90.35.2",
    "display" : "ORMONI: Dosaggi seriati dopo stimolo (da 3 a 6) (17 OH-P, FSH, LH, TSH, ACTH, CORTISOLO, GH, ALDOSTERONE, PRL, RENINA o altri ormoni). Inclusa determinazione del livello basale"
  },
  {
    "code" : "90.35.3",
    "display" : "OSSALATI [U]"
  },
  {
    "code" : "90.35.4",
    "display" : "OSTEOCALCINA (BGP)"
  },
  {
    "code" : "90.35.5",
    "display" : "PARATORMONE (PTH). Molecola intatta"
  },
  {
    "code" : "90.35.6",
    "display" : "SOMATOSTATINA"
  },
  {
    "code" : "90.36.3",
    "display" : "PIOMBO"
  },
  {
    "code" : "90.36.4",
    "display" : "PIRUVATOCHINASI (PK)"
  },
  {
    "code" : "90.36.5",
    "display" : "POLIPEPTIDE INTESTINALE VASOATTIVO (VIP)"
  },
  {
    "code" : "90.36.6",
    "display" : "PEPTIDE NATRIURETICO tipo b (BNP o NT-proBNP)"
  },
  {
    "code" : "90.37.1",
    "display" : "PORFIRINE TOTALI E FRAZIONATE"
  },
  {
    "code" : "90.37.2",
    "display" : "PORFOBILINOGENO"
  },
  {
    "code" : "90.37.3",
    "display" : "POST COITAL TEST"
  },
  {
    "code" : "90.37.4",
    "display" : "POTASSIO"
  },
  {
    "code" : "90.37.6",
    "display" : "PREALBUMINA"
  },
  {
    "code" : "90.37.7",
    "display" : "PROPEPTIDE AMINO-TERMINALE DEL PROCOLLAGENE Tipo 1 (P1NP)"
  },
  {
    "code" : "90.37.8",
    "display" : "PROTEINA LEGANTE IL RETINOLO"
  },
  {
    "code" : "90.38.1",
    "display" : "PROGESTERONE"
  },
  {
    "code" : "90.38.2",
    "display" : "PROLATTINA (PRL)"
  },
  {
    "code" : "90.38.4",
    "display" : "PROTEINE EMATICHE (ELETTROFORESI DELLE) Incluso: Dosaggio delle proteine totali 90.38.5"
  },
  {
    "code" : "90.38.5",
    "display" : "PROTEINE TOTALI"
  },
  {
    "code" : "90.38.8",
    "display" : "MACROPROLATTINA"
  },
  {
    "code" : "90.38.G",
    "display" : "ACIDO OMOVANILLICO"
  },
  {
    "code" : "90.38.M",
    "display" : "PEPSINOGENO A (I)"
  },
  {
    "code" : "90.38.N",
    "display" : "PEPSINOGENO C (II)"
  },
  {
    "code" : "90.39.1",
    "display" : "PROTEINE URINARIE (ELETTROFORESI DELLE). Incluso: Dosaggio proteine totali 90.38.5"
  },
  {
    "code" : "90.39.2",
    "display" : "PROTOPORFIRINA IX ERITROCITARIA"
  },
  {
    "code" : "90.39.3",
    "display" : "PURINE E LORO METABOLITI"
  },
  {
    "code" : "90.39.4",
    "display" : "RAME"
  },
  {
    "code" : "90.39.6",
    "display" : "RECETTORE SOLUBILE TRANSFERRINA"
  },
  {
    "code" : "90.39.7",
    "display" : "COBALTO"
  },
  {
    "code" : "90.40.2",
    "display" : "RENINA"
  },
  {
    "code" : "90.40.3",
    "display" : "SELENIO"
  },
  {
    "code" : "90.40.4",
    "display" : "SODIO"
  },
  {
    "code" : "90.40.6",
    "display" : "SELEZIONE NEMASPERMICA PER MIGRAZIONE O SU GRADIENTE"
  },
  {
    "code" : "90.40.7",
    "display" : "INSULIN-LIKE GROWTH FACTOR [IGF-1 o SOMATOMEDINA C ]"
  },
  {
    "code" : "90.40.8",
    "display" : "SOSTANZE D'ABUSO TEST DI SCREENING. Non associabile a 90.40.9"
  },
  {
    "code" : "90.40.9",
    "display" : "SOSTANZE D'ABUSO IDENTIFICAZIONE E/O DOSAGGIO DI SINGOLE SOSTANZE E RELATIVI METABOLITI. Incluso: test di screening (90.40.8)"
  },
  {
    "code" : "90.40.A",
    "display" : "SWELLING TEST"
  },
  {
    "code" : "90.40.B",
    "display" : "TEST DEL SUDORE: iontoforesi pilocarpinica con misura di Cloro o di Cloro e Sodio"
  },
  {
    "code" : "90.40.C",
    "display" : "TEST DEL SUDORE: iontoforesi pilocarpinica con misura conduttivimetrica"
  },
  {
    "code" : "90.40.D",
    "display" : "TEST DEL SUDORE: iontoforesi pilocarpinica con misura conduttivimetrica e con misura di Cloro o di Cloro e Sodio"
  },
  {
    "code" : "90.40.F",
    "display" : "SULFITI. SCREENING Urine mediante Sulfitest"
  },
  {
    "code" : "90.40.G",
    "display" : "STEROLI. DOSAGGIO Plasma"
  },
  {
    "code" : "90.41.3",
    "display" : "TESTOSTERONE"
  },
  {
    "code" : "90.41.4",
    "display" : "TESTOSTERONE LIBERO. Non associabile a 90.41.3"
  },
  {
    "code" : "90.41.5",
    "display" : "TIREOGLOBULINA (Tg)"
  },
  {
    "code" : "90.41.6",
    "display" : "TELOPEPTIDE C-TERMINALE DEL COLLAGENE TIPO 1"
  },
  {
    "code" : "90.41.8",
    "display" : "TIREOTROPINA [TSH] TEST REFLEX. Se TSH ≥ 0.45 mU/L e ≤ 3.5 mU/L: referto del solo TSH; Se TSH < 0.45 mU/L o > 3.5 mU/L: esecuzione automatica di FT4; Se FT4 ≥ 3.5, referto di TSH + FT4; Se FT4 < 3.5, esecuzione automatica di FT3 e referto di TSH + FT4 + FT3. Non associabile a: TSH, FT3, FT4. Salvo range o cut-off più restrittivi definiti a livello regionale"
  },
  {
    "code" : "90.42.1",
    "display" : "TIREOTROPINA (TSH). Non associabile a 90.41.8"
  },
  {
    "code" : "90.42.3",
    "display" : "TIROXINA LIBERA (FT4). Non associabile a 90.41.8"
  },
  {
    "code" : "90.42.4",
    "display" : "TRANSFERRINA (Capacità ferrolegante)"
  },
  {
    "code" : "90.42.5",
    "display" : "TRANSFERRINA"
  },
  {
    "code" : "90.42.6",
    "display" : "TRANSFERRINA DESIALATA (CDT)"
  },
  {
    "code" : "90.42.B",
    "display" : "TRIPTASI"
  },
  {
    "code" : "90.43.2",
    "display" : "TRIGLICERIDI"
  },
  {
    "code" : "90.43.3",
    "display" : "TRIODOTIRONINA LIBERA (FT3). Non associabile a 90.41.8"
  },
  {
    "code" : "90.43.4",
    "display" : "TRIPSINA"
  },
  {
    "code" : "90.43.5",
    "display" : "URATO"
  },
  {
    "code" : "90.43.7",
    "display" : "URINE RICERCA DI SPERMATOZOI"
  },
  {
    "code" : "90.43.8",
    "display" : "URINE ESAME MORFOLOGICO a FRESCO"
  },
  {
    "code" : "90.44.1",
    "display" : "UREA"
  },
  {
    "code" : "90.44.3",
    "display" : "URINE ESAME COMPLETO. Incluso: sedimento urinario"
  },
  {
    "code" : "90.44.5",
    "display" : "VITAMINA D (1,25 OH)"
  },
  {
    "code" : "90.44.6",
    "display" : "VITAMINA D (25 OH)"
  },
  {
    "code" : "90.45.1",
    "display" : "VITAMINE IDROSOLUBILI: DOSAGGIO PLASMATICO"
  },
  {
    "code" : "90.45.2",
    "display" : "VITAMINE LIPOSOLUBILI: DOSAGGIO PLASMATICO"
  },
  {
    "code" : "90.45.4",
    "display" : "ZINCO"
  },
  {
    "code" : "90.46.3",
    "display" : "ANTICORPI ANTIERITROCITARI A FREDDO RICERCA"
  },
  {
    "code" : "90.46.4",
    "display" : "ALFA 2 ANTIPLASMINA"
  },
  {
    "code" : "90.46.5",
    "display" : "LUPUS ANTICOAGULANT (LAC)"
  },
  {
    "code" : "90.47.1",
    "display" : "ANTICOAGULANTI ACQUISITI RICERCA"
  },
  {
    "code" : "90.47.2",
    "display" : "ANTICORPI ANTI A/B"
  },
  {
    "code" : "90.47.3",
    "display" : "ANTICORPI ANTI ANTIGENI NUCLEARI ESTRAIBILI (ENA). Test di screening"
  },
  {
    "code" : "90.47.5",
    "display" : "ANTICORPI ANTI CARDIOLIPINA [IgG, IgM ed eventuali IgA]"
  },
  {
    "code" : "90.47.7",
    "display" : "ANTICORPI ANTI JO1. Determinazione singola"
  },
  {
    "code" : "90.47.8",
    "display" : "ANTICORPI ANTI RNP. Determinazione singola"
  },
  {
    "code" : "90.47.9",
    "display" : "ANTICORPI ANTI Scl-70. Determinazione singola"
  },
  {
    "code" : "90.47.A",
    "display" : "ANTICORPI ANTI Sm. Determinazione singola"
  },
  {
    "code" : "90.47.B",
    "display" : "ANTICORPI ANTI SSA. Determinazione singola"
  },
  {
    "code" : "90.47.C",
    "display" : "ANTICORPI ANTI SSB. Determinazione singola"
  },
  {
    "code" : "90.47.D",
    "display" : "ANTICORPI ANTI CITRULLINA (peptide)"
  },
  {
    "code" : "90.47.E",
    "display" : "ANTICORPI ANTI ENDOMISIO"
  },
  {
    "code" : "90.47.F",
    "display" : "ANTICORPI ANTI CENTROMERO"
  },
  {
    "code" : "90.47.G",
    "display" : "ANTICORPI ANTI GM1 (MONOSIALOGANGLIOSIDE)"
  },
  {
    "code" : "90.48.1",
    "display" : "ANTICORPI ANTI CELLULE PARIETALI GASTRICHE (PCA)"
  },
  {
    "code" : "90.48.2",
    "display" : "ANTICORPI ANTI CITOPLASMA DEI NEUTROFILI (ANCA: P-ANCA e C- ANCA). Per ciascuna determinazione"
  },
  {
    "code" : "90.48.3",
    "display" : "ANTICORPI ANTI DNA NATIVO"
  },
  {
    "code" : "90.48.4",
    "display" : "ANTICORPI ANTI ERITROCITARI (Caratterizzazione del range termico)"
  },
  {
    "code" : "90.48.5",
    "display" : "ANTICORPI ANTI ERITROCITARI (Con mezzo potenziante)"
  },
  {
    "code" : "90.48.9",
    "display" : "ANTICORPI ANTI MEMBRANA BASALE GLOMERULARE"
  },
  {
    "code" : "90.49.1",
    "display" : "ANTICORPI ANTI ERITROCITARI (Titolazione)"
  },
  {
    "code" : "90.49.2",
    "display" : "ANTICORPI ANTI ERITROCITARI (Identificazione)"
  },
  {
    "code" : "90.49.3",
    "display" : "ANTICORPI ANTI ERITROCITI [Test di Coombs indiretto]"
  },
  {
    "code" : "90.49.5",
    "display" : "ANTICORPI ANTI GLIADINA DEAMIDATA (DPG-AGA) IgG"
  },
  {
    "code" : "90.49.6",
    "display" : "ANTICORPI ANTI FOSFOLIPIDI (IgG, IgM). Per ciascuna determinazione"
  },
  {
    "code" : "90.49.7",
    "display" : "ANTICORPI ANTI GLUTAMMICO DECARBOSSILASI (GAD)"
  },
  {
    "code" : "90.49.8",
    "display" : "ANTICORPI ANTI INTERFERONE"
  },
  {
    "code" : "90.49.9",
    "display" : "ANTICORPI ANTI ISTONI"
  },
  {
    "code" : "90.50.1",
    "display" : "ANTICORPI ANTI HLA (Cross-match, singolo individuo)"
  },
  {
    "code" : "90.50.5",
    "display" : "ANTICORPI ANTI INSULA PANCREATICA (ICA)"
  },
  {
    "code" : "90.50.A",
    "display" : "SCREENING IN FASE SOLIDA ANTICORPI ANTI-HLA CLASSE I e II. Isotipo IgG"
  },
  {
    "code" : "90.50.B",
    "display" : "SCREENING/IDENTIFICAZIONE MEDIANTE CITOTOSSICITA' DI ANTICORPI ANTI-HLA CON PANNELLO DI LINFOCITI T"
  },
  {
    "code" : "90.50.C",
    "display" : "SCREENING/IDENTIFICAZIONE MEDIANTE CITOTOSSICITA' DI ANTICORPI ANTI-HLA CON PANNELLO DI LINFOCITI B"
  },
  {
    "code" : "90.50.D",
    "display" : "SCREENING IN FASE SOLIDA ANTICORPI ANTI-HLA CLASSE I e II. Isotipo IgM"
  },
  {
    "code" : "90.50.E",
    "display" : "SCREENING IN FASE SOLIDA ANTICORPI ANTI-MICA"
  },
  {
    "code" : "90.50.F",
    "display" : "SCREENING IN FASE SOLIDA SPECIFICITA' ANTICORPI ANTI-MICA"
  },
  {
    "code" : "90.50.G",
    "display" : "ANTICORPI IN FASE SOLIDA ANTICORPI ANTI-AT1R"
  },
  {
    "code" : "90.51.1",
    "display" : "ANTICORPI ANTI INSULINA (AIAA)"
  },
  {
    "code" : "90.51.2",
    "display" : "ANTICORPI ANTI GRANULOCITI"
  },
  {
    "code" : "90.51.3",
    "display" : "ANTICORPI ANTI MAG"
  },
  {
    "code" : "90.51.4",
    "display" : "ANTICORPI ANTI TIREOPEROSSIDASI (AbTPO)"
  },
  {
    "code" : "90.51.5",
    "display" : "ANTICORPI ANTI MICROSOMI EPATICI E RENALI (LKMA)"
  },
  {
    "code" : "90.51.6",
    "display" : "ANTICORPI ANTI MIELOPEROSSIDASI (MPO)"
  },
  {
    "code" : "90.52.1",
    "display" : "ANTICORPI ANTI MITOCONDRI (AMA)"
  },
  {
    "code" : "90.52.2",
    "display" : "ANTICORPI ANTI MUSCOLO LISCIO (ASMA)"
  },
  {
    "code" : "90.52.3",
    "display" : "ANTICORPI ANTI MUSCOLO STRIATO (Cuore)"
  },
  {
    "code" : "90.52.4",
    "display" : "ANTICORPI ANTI NUCLEO (ANA)"
  },
  {
    "code" : "90.52.5",
    "display" : "RICERCA ALTRI AUTOANTICORPI NAS"
  },
  {
    "code" : "90.52.6",
    "display" : "RICERCA AUTOANTICORPI Immunoblotting NAS"
  },
  {
    "code" : "90.53.1",
    "display" : "ANTICORPI ANTI OVAIO"
  },
  {
    "code" : "90.53.3",
    "display" : "ANTICORPI ANTI PIASTRINE (Identificazione)"
  },
  {
    "code" : "90.53.4",
    "display" : "ANTICORPI ANTI RECETTORE NICOTINICO MUSCOLARE"
  },
  {
    "code" : "90.53.5",
    "display" : "ANTICORPI ANTI RECETTORE DEL TSH"
  },
  {
    "code" : "90.53.6",
    "display" : "ANTICORPI ANTI PIASTRINE ADESE (test diretto)"
  },
  {
    "code" : "90.53.7",
    "display" : "ANTICORPI ANTI PIASTRINE CIRCOLANTI (test indiretto)"
  },
  {
    "code" : "90.53.8",
    "display" : "ANTICORPI ANTI PROTEINASI 3 (PR3)"
  },
  {
    "code" : "90.53.9",
    "display" : "ANTICORPI ANTI RECETTORE ACETILCOLINA"
  },
  {
    "code" : "90.53.A",
    "display" : "ANTICORPI ANTI SACCAROMYCES CEREVISIAE. Per classe anticorpale"
  },
  {
    "code" : "90.53.B",
    "display" : "ANTICORPI ANTI SPERMATOZOI (ricerca ed eventuale titolazione)"
  },
  {
    "code" : "90.53.C",
    "display" : "ANTICORPI ANTI TESTICOLO (ATLA)"
  },
  {
    "code" : "90.53.D",
    "display" : "ANTICORPI ANTI TRANSGLUTAMINASI (IgG, IgA). Per ciascuna determinazione"
  },
  {
    "code" : "90.54.3",
    "display" : "ANTICORPI ANTI SURRENE"
  },
  {
    "code" : "90.54.4",
    "display" : "ANTICORPI ANTI TIREOGLOBULINA (AbTg)"
  },
  {
    "code" : "90.54.5",
    "display" : "ANTICORPI EMOLITICI ANTI ERITROCITARI MONOFASICI"
  },
  {
    "code" : "90.55.1",
    "display" : "ANTIGENE CARBOIDRATICO 125 (CA 125)"
  },
  {
    "code" : "90.55.2",
    "display" : "ANTIGENE CARBOIDRATICO 15.3 (CA 15.3)"
  },
  {
    "code" : "90.55.3",
    "display" : "ANTIGENE CARBOIDRATICO 19.9 (CA 19.9)"
  },
  {
    "code" : "90.56.3",
    "display" : "ANTIGENE CARCINOEMBRIONARIO (CEA)"
  },
  {
    "code" : "90.56.9",
    "display" : "ANTIGENE PROSTATICO SPECIFICO [PSA] REFLEX (cut-off ≤ 2,5 ng/ml - ≥ 10,0 ng/ml). Incluso: esecuzione automatica di fPSA, referto di PSA + fPSA con calcolo del rapporto fPSA/PSA se PSA > 2,5 ng/ml e < 10,0 ng/ml"
  },
  {
    "code" : "90.56.A",
    "display" : "PROTEINA 4 dell’epididimo umano (HE4). DOSAGGIO"
  },
  {
    "code" : "90.57.2",
    "display" : "ANTIGENI ERITROCITARI CD55/CD59"
  },
  {
    "code" : "90.57.5",
    "display" : "ANTITROMBINA FUNZIONALE (AT3)"
  },
  {
    "code" : "90.58.2",
    "display" : "ANTICORPI ANTI ERITROCITARI [Test di Coombs diretto]"
  },
  {
    "code" : "90.59.3",
    "display" : "CITOTOSSICITA' SPONTANEA NK"
  },
  {
    "code" : "90.59.5",
    "display" : "COFATTORE RISTOCETINICO"
  },
  {
    "code" : "90.60.1",
    "display" : "COMPLEMENTO (C1 Inibitore) quantitativo"
  },
  {
    "code" : "90.60.2",
    "display" : "COMPLEMENTO: C3, C3 Naf, C4, CH50 (Ciascuno)"
  },
  {
    "code" : "90.61.1",
    "display" : "CRIOGLOBULINE RICERCA"
  },
  {
    "code" : "90.61.2",
    "display" : "CRIOGLOBULINE TIPIZZAZIONE (ciascuna)"
  },
  {
    "code" : "90.61.3",
    "display" : "CYFRA 21-1"
  },
  {
    "code" : "90.61.4",
    "display" : "D-DIMERO. Dosaggio con metodo immunometrico"
  },
  {
    "code" : "90.62.2",
    "display" : "EMOCROMO: ESAME EMOCROMOCITOMETRICO E CONTEGGIO LEUCOCITARIO DIFFERENZIALE Hb, GR, GB, HCT, PLT, IND. DERIV. Compreso eventuale controllo microscopico"
  },
  {
    "code" : "90.62.3",
    "display" : "EMOLISINA BIFASICA"
  },
  {
    "code" : "90.62.4",
    "display" : "ENZIMI ERITROCITARI"
  },
  {
    "code" : "90.63.1",
    "display" : "DOSAGGIO ATTIVITA' ANTICOAGULANTE DEI FARMACI INIBITORI FATTORE X ATTIVATO (Eparina, Rivaroxaban, etc.)"
  },
  {
    "code" : "90.63.2",
    "display" : "ERITROCITI: ANTIGENI NON ABO E NON RH. Per ciascuno antigene"
  },
  {
    "code" : "90.63.3",
    "display" : "ESAME DEL MIDOLLO OSSEO PER APPOSIZIONE E/O STRISCIO. Caratterizzazione di cellule patologiche. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "90.63.5",
    "display" : "ESAME MICROSCOPICO DI STRISCIO O APPOSIZIONE DI CITOASPIRATO LINFOGHIANDOLARE"
  },
  {
    "code" : "90.63.6",
    "display" : "FATTORE vWF ANTIGENE (EIA)"
  },
  {
    "code" : "90.63.7",
    "display" : "FATTORE vWF CBA (EIA)"
  },
  {
    "code" : "90.63.8",
    "display" : "DOSAGGIO DELL'ATTIVITA' ANTICOAGULANTE FATTORE ANTI II A (Dabigatran, etc)"
  },
  {
    "code" : "90.64.1",
    "display" : "FATTORE VON WILLEBRAND"
  },
  {
    "code" : "90.64.2",
    "display" : "FATTORE REUMATOIDE"
  },
  {
    "code" : "90.64.3",
    "display" : "FATTORI DELLA COAGULAZIONE (II, V, VII, VIII, IX, X, XI, XII, XIII). Per ciascun fattore"
  },
  {
    "code" : "90.64.4",
    "display" : "FENOTIPO Rh"
  },
  {
    "code" : "90.64.6",
    "display" : "FIBRINOGENO CLAUSS"
  },
  {
    "code" : "90.65.3",
    "display" : "GRUPPO SANGUIGNO ABO (Agglutinogeni e Agglutinine) e Rh (D)"
  },
  {
    "code" : "90.65.5",
    "display" : "FIBRINOGENO IMMUNOLOGICO"
  },
  {
    "code" : "90.66.7",
    "display" : "Hb - EMOGLOBINE. Dosaggio frazioni (HbA2, HbF, Hb Anomale)"
  },
  {
    "code" : "90.67.4",
    "display" : "IDENTIFICAZIONE DI SPECIFICITA' ANTI HLA CONTRO PANNELLO LINFOCITARIO - (1 siero/30 cellule a antigenicità nota)"
  },
  {
    "code" : "90.67.5",
    "display" : "IgA SECRETORIE"
  },
  {
    "code" : "90.67.A",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA SPECIFICITA' ANTI-HLA CLASSE I. Isotipo IgG"
  },
  {
    "code" : "90.67.B",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA SPECIFICITA' ANTI-HLA CLASSE II. Isotipo IgG"
  },
  {
    "code" : "90.67.C",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA SPECIFICITA' ANTI-HLA CLASSE I. Isotipo IgM"
  },
  {
    "code" : "90.67.D",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA SPECIFICITA' ANTI-HLA CLASSE II. Isotipo IgM"
  },
  {
    "code" : "90.67.E",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA ANTICORPI ANTI-HLA FISSANTI IL COMPLEMENTO CLASSE I"
  },
  {
    "code" : "90.67.F",
    "display" : "IDENTIFICAZIONE IN FASE SOLIDA ANTICORPI ANTI-HLA FISSANTI IL COMPLEMENTO CLASSE II"
  },
  {
    "code" : "90.68.1",
    "display" : "IgE SPECIFICHE ALLERGOLOGICHE QUANTITATIVO. Per singolo allergene"
  },
  {
    "code" : "90.68.2",
    "display" : "IgE SPECIFICHE ALLERGOLOGICHE: SCREENING MULTIALLERGENICO QUALITATIVO. Per profilo di allergeni"
  },
  {
    "code" : "90.68.3",
    "display" : "IgE TOTALI"
  },
  {
    "code" : "90.68.4",
    "display" : "IgG, IgA SOTTOCLASSI. Per ciascuna determinazione"
  },
  {
    "code" : "90.68.5",
    "display" : "IgG SPECIFICHE ALLERGOLOGICHE. Per singolo allergene"
  },
  {
    "code" : "90.68.6",
    "display" : "PROTEINA CATIONICA EOSINOFILA (ECP)"
  },
  {
    "code" : "90.68.7",
    "display" : "Ig E SPECIFICHE PANNELLO PER ALIMENTI. Fino a 8 allergeni per pannello"
  },
  {
    "code" : "90.68.8",
    "display" : "IgE SPECIFICHE PANNELLO PER INALANTI. Fino a a 8 allergeni per pannello"
  },
  {
    "code" : "90.68.9",
    "display" : "TEST DI INIBIZIONE DELLE IgE SPECIFICHE CON ALLERGENE SPECIFICO. Pannelli di 4 allergeni a varie diluizioni"
  },
  {
    "code" : "90.68.A",
    "display" : "IgE SPECIFICHE per allergeni singoli ricombinanti molecolari"
  },
  {
    "code" : "90.68.B",
    "display" : "IgE SPECIFICHE ALLERGOLOGICHE QUANTITATIVO PER INALANTI E ALIMENTI. Fino a 12 allergeni"
  },
  {
    "code" : "90.68.C",
    "display" : "IgE SPECIFICHE ALLERGOLOGICHE QUANTITATIVO PER FARMACI E VELENI. Fino a 12 allergeni"
  },
  {
    "code" : "90.69.2",
    "display" : "IMMUNOFISSAZIONE"
  },
  {
    "code" : "90.69.4",
    "display" : "IMMUNOGLOBULINE IgA, IgD, IgG , IgM, (Ciascuna)"
  },
  {
    "code" : "90.70.3",
    "display" : "INTRADERMOREAZIONE CON PPD (Intradermoreazione con tubercolina secondo Mantoux)"
  },
  {
    "code" : "90.71.5",
    "display" : "PLASMINOGENO"
  },
  {
    "code" : "90.72.1",
    "display" : "PROTEINA C ANTICOAGULANTE ANTIGENE [P]"
  },
  {
    "code" : "90.72.2",
    "display" : "PROTEINA C ANTICOAGULANTE FUNZIONALE [P]"
  },
  {
    "code" : "90.72.3",
    "display" : "PROTEINA C REATTIVA (Quantitativa)"
  },
  {
    "code" : "90.72.4",
    "display" : "PROTEINA S LIBERA"
  },
  {
    "code" : "90.72.5",
    "display" : "PROTEINA S TOTALE"
  },
  {
    "code" : "90.72.6",
    "display" : "PROTEINA S 100"
  },
  {
    "code" : "90.73.2",
    "display" : "PROVA CROCIATA DI COMPATIBILITA' TRASFUSIONALE"
  },
  {
    "code" : "90.73.5",
    "display" : "CROSS-MATCH CITOFLUORIMETRICO LINFOCITI T IgG"
  },
  {
    "code" : "90.73.A",
    "display" : "CROSS-MATCH CITOFLUORIMETRICO LINFOCITI B IgG"
  },
  {
    "code" : "90.73.B",
    "display" : "CROSS-MATCH CITOFLUORIETRICO LINFOCITI T IgM"
  },
  {
    "code" : "90.74.1",
    "display" : "CROSS-MATCH CITOTOSSICO CON LINFOCITI T"
  },
  {
    "code" : "90.74.5",
    "display" : "RETICOLOCITI. Conteggio"
  },
  {
    "code" : "90.74.8",
    "display" : "TEMPO DI BOTROXINA (Reptilase)"
  },
  {
    "code" : "90.74.A",
    "display" : "CROSS-MATCH CITOTOSSICO CON LINFOCITI B"
  },
  {
    "code" : "90.75.4",
    "display" : "TEMPO DI PROTROMBINA (PT)"
  },
  {
    "code" : "90.75.5",
    "display" : "TEMPO DI TROMBINA (TT)"
  },
  {
    "code" : "90.76.1",
    "display" : "TEMPO DI TROMBOPLASTINA PARZIALE ATTIVATA (APTT)"
  },
  {
    "code" : "90.76.2",
    "display" : "TEST DI AGGREGAZIONE PIASTRINICA. Per ciascun attivatore"
  },
  {
    "code" : "90.76.7",
    "display" : "TEST DI FUNZIONALTA' PIASTRINICA (PFA)"
  },
  {
    "code" : "90.77.2",
    "display" : "TEST DI RESISTENZA ALLA PROTEINA C ATTIVATA"
  },
  {
    "code" : "90.77.6",
    "display" : "TIPIZZAZIONE ERITROCITARIA PER D VARIANT"
  },
  {
    "code" : "90.78.2",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS A. Bassa risoluzione"
  },
  {
    "code" : "90.78.4",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS B. Bassa risoluzione"
  },
  {
    "code" : "90.78.A",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS A. Alta risoluzione"
  },
  {
    "code" : "90.78.B",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS B. Alta risoluzione"
  },
  {
    "code" : "90.79.1",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS C. Bassa risoluzione"
  },
  {
    "code" : "90.79.4",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DPA1. Alta risoluzione"
  },
  {
    "code" : "90.79.5",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DPB1. Alta risoluzione"
  },
  {
    "code" : "90.79.A",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS C. Alta risoluzione"
  },
  {
    "code" : "90.79.B",
    "display" : "TIPIZZAZIONE GENI KIR. In trapianto mismatch"
  },
  {
    "code" : "90.80.2",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DQA1. Alta risoluzione"
  },
  {
    "code" : "90.80.3",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DQ. Bassa risoluzione"
  },
  {
    "code" : "90.80.4",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DQB1. Alta risoluzione"
  },
  {
    "code" : "90.81.1",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DR. Bassa risoluzione"
  },
  {
    "code" : "90.81.3",
    "display" : "TIPIZZAZIONE SIEROLOGICA HLA CLASSE I"
  },
  {
    "code" : "90.81.4",
    "display" : "TIPIZZAZIONE SIEROLOGICA HLA CLASSE II"
  },
  {
    "code" : "90.81.A",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DRB1. Alta risoluzione"
  },
  {
    "code" : "90.81.B",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DRB3. Alta risoluzione"
  },
  {
    "code" : "90.81.C",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DRB4. Alta risoluzione"
  },
  {
    "code" : "90.81.D",
    "display" : "TIPIZZAZIONE GENOMICA LOCUS DRB5. Alta risoluzione"
  },
  {
    "code" : "90.82.1",
    "display" : "TROMBINA - ANTITROMBINA COMPLESSO (TAT)"
  },
  {
    "code" : "90.82.3",
    "display" : "TROPONINA I, T"
  },
  {
    "code" : "90.82.5",
    "display" : "VELOCITA' DI SEDIMENTAZIONE DELLE EMAZIE (VES)"
  },
  {
    "code" : "90.83.A",
    "display" : "ACIDI NUCLEICI DI MICRORGANISMI (BATTERI, VIRUS, MICETI, PROTOZOI) RICERCA IN MATERIALI BIOLOGICI VARI MULTIPLEX. Almeno cinque microrganismi di uno o più gruppi di microganismi. Incluso: estrazione, amplificazione, rilevazione. NAS"
  },
  {
    "code" : "90.84.8",
    "display" : "BATTERI ANTIGENI CELLULARI ED EXTRACELLULARI RICERCA DIRETTA IN MATERIALI BIOLOGICI NAS"
  },
  {
    "code" : "90.87.6",
    "display" : "BATTERI ACIDI NUCLEICI IN MATERIALI BIOLOGICI RICERCA QUALITATIVA/QUANTITATIVA NAS. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.87.7",
    "display" : "AEROMONAS NELLE FECI ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.87.8",
    "display" : "AMEBE A VITA LIBERA ESAME COLTURALE. Incluso: esame microscopico previa colorazione specifica"
  },
  {
    "code" : "90.87.F",
    "display" : "BORDETELLA ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.87.G",
    "display" : "BORRELIA ANALISI QUALITATIVA DNA o RNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.87.P",
    "display" : "BATTERI RESPIRATORI RICERCA ACIDI NUCLEICI MULTIPLEX. Almeno tre MICRORGANISMI. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.87.R",
    "display" : "BARTONELLA RICERCA ANTICORPI IgG e IgM"
  },
  {
    "code" : "90.87.S",
    "display" : "BORDETELLA ANTICORPI IgG e IgM. Incluso: IgA se IgM negative"
  },
  {
    "code" : "90.87.T",
    "display" : "BORRELIA ANTICORPI IgG e IgM. Incluso: eventuale Immunoblotting"
  },
  {
    "code" : "90.88.2",
    "display" : "BRUCELLE ANTICORPI (Titolazione mediante agglutinazione) [WRIGHT]"
  },
  {
    "code" : "90.88.E",
    "display" : "CAMPYLOBACTER ESAME COLTURALE. In caso di coprocoltura positiva per Campylobacter. Se positivo, identificazione ed eventuale antibiogramma"
  },
  {
    "code" : "90.88.G",
    "display" : "CHLAMYDIA PNEUMONIAE ANTICORPI IgG e IgM. Incluso: IgA se IgM negative"
  },
  {
    "code" : "90.88.H",
    "display" : "CHLAMYDIA PSITTACI ANTICORPI IgG e IgM. Incluso: IgA se IgM negative"
  },
  {
    "code" : "90.88.J",
    "display" : "CHLAMYDIA TRACHOMATIS ANTICORPI IgG e IgM. Incluso: IgA se IgM negative"
  },
  {
    "code" : "90.89.6",
    "display" : "CHLAMYDIE RICERCA DIRETTA"
  },
  {
    "code" : "90.90.3",
    "display" : "CHLAMYDIE RICERCA QUALITATIVA DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.90.6",
    "display" : "CLOSTRIDIUM DIFFICILE TOSSINE NELLE FECI RICERCA DIRETTA (Metodi immunologici o molecolari). Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.90.7",
    "display" : "CORYNEBACTERIUM DIPHTERIAE ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.90.A",
    "display" : "CRIPTOCOCCO RICERCA DIRETTA"
  },
  {
    "code" : "90.90.B",
    "display" : "CRYPTOSPORIDIUM RICERCA DIRETTA NELLE FECI (antigeni fecali e/o colorazioni alcool acido resistenti). Non associabile a 91.06.C PROTOZOI ENTERICI RICERCA DIRETTA MULTIPLA ANTIGENI FECALI"
  },
  {
    "code" : "90.90.E",
    "display" : "ECHINOCOCCO [IDATIDOSI] ANTICORPI. Incluso: eventuale immunoblotting"
  },
  {
    "code" : "90.90.G",
    "display" : "COXIELLA BURNETI ANTICORPI Ig e IgM"
  },
  {
    "code" : "90.91.4",
    "display" : "ESCHERICHIA COLI ENTEROEMORRAGICO [EHEC] NELLE FECI ESAME COLTURALE. Incluso: identificazione"
  },
  {
    "code" : "90.92.6",
    "display" : "ENTAMOEBA HISTOLYTICA ANTICORPI"
  },
  {
    "code" : "90.92.7",
    "display" : "ENTAMOEBA HISTOLYTICA/DISPAR ANTIGENI RICERCA DIRETTA NELLE FECI. Non associabile a 91.06.C PROTOZOI ENTERICI RICERCA RICERCA DIRETTA MULTIPLA ANTIGENI FECALI"
  },
  {
    "code" : "90.93.1",
    "display" : "ENTAMOEBA HISTOLYTICA NELLE FECI ESAME COLTURALE (Coltura xenica)"
  },
  {
    "code" : "90.93.2",
    "display" : "ENTEROBIUS VERMICULARIS [OSSIURI] RICERCA MICROSCOPICA SU MATERIALE PERIANALE. Scotch test o tampone perianale"
  },
  {
    "code" : "90.93.3",
    "display" : "ESAME COLTURALE CAMPIONI BIOLOGICI DIVERSI NAS. Ricerca completa batteri e lieviti patogeni. Se positivo, incluso: identificazione e antibiogramma sui patogeni"
  },
  {
    "code" : "90.93.5",
    "display" : "ESAME COLTURALE ESSUDATO ORO-FARINGEO. Ricerca Streptococcus pyogenes [Streptococco beta emolitico gruppo A] ed altri Streptococchi beta emolitici. Se positivo, incluso: identificazione e eventuale antibiogramma"
  },
  {
    "code" : "90.93.6",
    "display" : "ESAME COLTURALE ESPETTORATO. Ricerca Streptococcus pneumoniae, Haemophilus influenzae, Moraxella catharralis e altri batteri e lieviti patogeni. incluso: esame microscopico di idoneità del campione. incluso: eventuale valutazione quantitativa/semiquantitativa della carica batterica. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.93.7",
    "display" : "ESAME COLTURALE BRONCOLAVAGGIO [PRELIEVO PROTETTO DI SECREZIONI RESPIRATORIE]. Ricerca batteri e lieviti patogeni. Incluso: esame microscopico ed eventuale valutazione quantitativa/semiquantitativa della carica batterica. Se positivo, incluso identificazione e antibiogramma"
  },
  {
    "code" : "90.93.8",
    "display" : "ESAME COLTURALE ESSUDATO AURICOLARE Otite esterna MONOLATERALE. Ricerca batteri e miceti [Lieviti, Funghi Filamentosi] patogeni. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.93.9",
    "display" : "ESAME COLTURALE ESSUDATO AURICOLARE Otite media acuta MONOLATERALE. Ricerca Streptococcus pneumoniae, Haemophilus influenzae e altri batteri patogeni. Se positivo, incluso: identificazione e antibiogramma sui patogeni"
  },
  {
    "code" : "90.93.A",
    "display" : "ESAME COLTURALE ESSUDATO OCULARE MONOLATERALE. Ricerca Streptococcus pneumoniae, Haemophilus influenzae e altri batteri e lieviti patogeni. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.93.B",
    "display" : "ESAME MICROBIOLOGICO DEL SECRETO VAGINALE. Ricerca Lieviti e Trichomonas (colturale o ricerca antigene). Incluso: esame microscopico (Colorazione di Gram). Se positivo, inclusa identificazione per lieviti. Non associabile a 91.10.A TRICHOMONAS VAGINALIS, ESAME COLTURALE E/O RICERCA DIRETTA ANTIGENI"
  },
  {
    "code" : "90.93.C",
    "display" : "ESAME MICROBIOLOGICO DEL SECRETO ENDOCERVICALE. Ricerca Neisseria gonorrhoeae (esame colturale), Chlamydia trachomatis (esame molecolare incluso: estr. amplific. rilevaz), Micoplasmi urogenitali. Se positivo, incluso: identificazione e antibiogramma per Neisseria.Non associabile a: 91.03.5 NEISSERIA GONORRHOEAE IN MATERIALI BIOLOGICI VARI ESAME COLTURALE, 91.02.A MYCOPLASMA/UREAPLASMA UROGENITALI ESAME COLTURALE NAS, 90.89.6 CHLAMYDIE RICERCA DIRETTA e 90.90.3 CHLAMYDIE RICERCA QUALITATIVA DNA"
  },
  {
    "code" : "90.93.D",
    "display" : "ESAME MICROBIOLOGICO DEL SECRETO URETRALE / URINE PRIMO MITTO. Ricerca Neisseria gonorrhoeae (esame colturale), Chlamydia trachomatis (esame molecolare incluso estr. amplific. rilevaz), Micoplasmi urogenitali. Incluso: esame microscopico (colorazione di Gram). Se positivo, incluso: identificazione e antibiogramma per NeisseriaNon associabile a: 91.03.5 NEISSERIA GONORRHOEAE IN MATERIALI BIOLOGICI VARI ESAME COLTURALE, 91.02.A MYCOPLASMA/UREAPLASMA UROGENITALI ESAME COLTURALE NAS, 90.89.6 CHLAMYDIE RICERCA DIRETTA e 90.90.3 CHLAMYDIE RICERCA QUALITATIVA DNA"
  },
  {
    "code" : "90.93.E",
    "display" : "ESAME COLTURALE SERIATO DI: URINE PRIMO MITTO, URINE MITTO INTERMEDIO, LIQUIDO PROSTATICO E/O URINE DOPO MASSAGGIO PROSTATICO [TEST DI STAMEY] Ricerca batteri patogeni. Incluso: conta batterica. Se positivo, incluso: identificazione ed eventuale antibiogramma"
  },
  {
    "code" : "90.93.J",
    "display" : "ESAME COLTURALE ESSUDATI PURULENTI [PUS] DA LESIONI PROFONDE. Ricerca Ricerca batteri aerobi ed anaerobi e lieviti. Incluso: esame microscopico. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.93.K",
    "display" : "ESAME COLTURALE ESSUDATI PURULENTI [PUS] DA LESIONI SUPERFICIALI Ricerca batteri aerobi e lieviti. Incluso: esame microscopico. Se positivo, incluso identificazione e antibiogramma"
  },
  {
    "code" : "90.93.L",
    "display" : "ESAME COLTURALE ESSUDATI [pleurico, peritoneale, articolare, pericardico]. Ricerca batteri aerobi ed anaerobi e lieviti. Incluso: esame microscopico. Se positivo, Incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.94.1",
    "display" : "ESAME COLTURALE DEL SANGUE [EMOCOLTURA]. Ricerca batteri aerobi, batteri anaerobi e lieviti. Per prelievo. Se positivo, incluso: identificazione e antibiogramma/antimicogramma"
  },
  {
    "code" : "90.94.2",
    "display" : "ESAME COLTURALE DELL' URINA [URINOCOLTURA]. Ricerca batteri e lieviti patogeni. Incluso: conta batterica. Se positivo, incluso identificazione e antibiogramma"
  },
  {
    "code" : "90.94.3",
    "display" : "ESAME COLTURALE DELLE FECI [COPROCOLTURA]. Ricerca Salmonelle, Shigelle e Campylobacter. Se positivo, incluso identificazione ed eventuale antibiogramma. Escluso: Aeromonas, E. coli enteropatogeni, Yersinia, Vibrio. Non associabile a: 90.88.E Campylobacter esame colturale, 91.07.6 Salmonella nelle feci esame colturale, 91.07.7 Shigella nelle feci esame colturale"
  },
  {
    "code" : "90.94.5",
    "display" : "HELICOBACTER PYLORI IN MATERIALI BIOLOGICI ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.94.6",
    "display" : "FRANCISELLA TULARENSIS [TULAREMIA] ANTICORPI"
  },
  {
    "code" : "90.94.7",
    "display" : "GIARDIA ANTIGENI RICERCA DIRETTA NELLE FECI. Non associabile a 91.06.C PROTOZOI ENTERICI RICERCA RICERCA DIRETTA MULTIPLA ANTIGENI FECALI"
  },
  {
    "code" : "90.94.C",
    "display" : "HELICOBACTER PYLORI ANTIGENE NELLE FECI RICERCA DIRETTA"
  },
  {
    "code" : "90.95.1",
    "display" : "HELICOBACTER PYLORI UREASI NEL MATERIALE BIOPTICO (Saggio mediante prova biochimica)"
  },
  {
    "code" : "90.95.4",
    "display" : "LEGIONELLE IN MATERIALI BIOLOGICI ESAME COLTURALE. Se positivo, incluso. identificazione e antibiogramma"
  },
  {
    "code" : "90.95.5",
    "display" : "LEGIONELLA PNEUMOPHILA ANTIGENE URINARIO RICERCA DIRETTA (EIA o Immunocromatografico)"
  },
  {
    "code" : "90.95.8",
    "display" : "LEISHMANIA ESAME COLTURALE. Se positivo, incluso: identificazione"
  },
  {
    "code" : "90.96.1",
    "display" : "LEISHMANIA ANTICORPI"
  },
  {
    "code" : "90.96.2",
    "display" : "LEISHMANIA RICERCA MICROSCOPICA previa colorazione specifica"
  },
  {
    "code" : "90.96.6",
    "display" : "LEPTOSPIRE ANTICORPI"
  },
  {
    "code" : "90.96.7",
    "display" : "LEPTOSPIRE ESAME COLTURALE. Se positivo, incluso: identificazione"
  },
  {
    "code" : "90.96.8",
    "display" : "LISTERIA IN MATERIALI BIOLOGICI ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "90.96.9",
    "display" : "LEISHMANIA ACIDI NUCLEICI. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.97.6",
    "display" : "MICETI ANTIGENI CELLULARI ED EXTRACELLULARI IN MATERIALI BIOLOGICI DIVERSI"
  },
  {
    "code" : "90.98.4",
    "display" : "MICETI RICERCA IN MATERIALI BIOLOGICI DIVERSI. Incluso: esame microscopico ed esame colturale. Se positivo, incluso identificazione"
  },
  {
    "code" : "90.98.9",
    "display" : "MICETI RICERCA ACIDI NUCLEICI IN MATERIALI BIOLOGICI RICERCA QUALITATIVA/QUANTITATIVA NAS. Incluso: estrazione, amplificazione e rivelazione."
  },
  {
    "code" : "90.99.1",
    "display" : "MICOBATTERI DIAGNOSI IMMUNOLOGICA DI INFEZIONE TUBERCOLARE LATENTE [IGRA]"
  },
  {
    "code" : "90.99.2",
    "display" : "MICOBATTERI RICERCA ACIDI NUCLEICI DI M. TUBERCULOSIS COMPLEX IN MATERIALI BIOLOGICI. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "90.99.4",
    "display" : "MICOBATTERI ANTIBIOGRAMMA DA COLTURA. Almeno 4 antibiotici"
  },
  {
    "code" : "91.01.9",
    "display" : "MICOBATTERI RICERCA IN CAMPIONI BIOLOGICI VARI. Incluso: ESAME MICROSCOPICO (previa colorazione per microrganismi alcool acido resistenti). Incluso: ESAME COLTURALE IN TERRENO LIQUIDO E SOLIDO. Incluso: eventuale identificazione preliminare per M. tuberculosis complex"
  },
  {
    "code" : "91.01.A",
    "display" : "MICOBATTERI DA COLTURA IDENTIFICAZIONE DI SPECIE"
  },
  {
    "code" : "91.02.6",
    "display" : "MICROFILARIE [W. BANCROFTI] ANTIGENI RICERCA DIRETTA"
  },
  {
    "code" : "91.02.7",
    "display" : "MICROFILARIE NEL SANGUE (Giemsa) dopo concentrazione o arricchimento"
  },
  {
    "code" : "91.02.8",
    "display" : "MICROSPORIDI ESAME COLTURALE SU LINEE CELLULARI"
  },
  {
    "code" : "91.02.9",
    "display" : "MICROSPORIDI ESAME MICROSCOPICO dopo concentrazione (Colorazioni specifiche)"
  },
  {
    "code" : "91.02.A",
    "display" : "MYCOPLASMA/UREAPLASMA UROGENITALI ESAME COLTURALE NAS. Se positivo, incluso: identificazione"
  },
  {
    "code" : "91.02.D",
    "display" : "MYCOPLASMA PNEUMONIAE ANTICORPI IgG e IgM. Incluso: IgA se IgM negative"
  },
  {
    "code" : "91.03.5",
    "display" : "NEISSERIA GONORRHOEAE IN MATERIALI BIOLOGICI VARI ESAME COLTURALE. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "91.04.1",
    "display" : "NEISSERIA MENINGITIDIS ESAME COLTURALE IN MATERIALI BIOLOGICI VARI. Se positivo, incluso: identificazione e antibiogramma"
  },
  {
    "code" : "91.04.5",
    "display" : "PARASSITI [ELMINTI, PROTOZOI, ECTOPARASSITI] IN MATERIALI BIOLOGICI DIVERSI ESAME MACROSCOPICO E MICROSCOPICO NAS"
  },
  {
    "code" : "91.04.6",
    "display" : "PARASSITI INTESTINALI [ELMINTI, PROTOZOI] RICERCA MACROSCOPICA E MICROSCOPICA (Esame diretto e dopo concentrazione o arricchimento)"
  },
  {
    "code" : "91.04.8",
    "display" : "PARASSITI [ELMINTI, PROTOZOI] ANTICORPI NAS. Incluso: eventuale Immunoblotting"
  },
  {
    "code" : "91.05.2",
    "display" : "PARASSITI INTESTINALI [PROTOZOI] RICERCA MICROSCOPICA (Colorazione tricromica o Ematossilina ferrica o Giemsa)"
  },
  {
    "code" : "91.05.A",
    "display" : "PARASSITI [ELMINTI, PROTOZOI] ACIDI NUCLEICI IN MATERIALI BIOLOGICI NAS RICERCA QUALITATIVA/QUANTITATIVA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.05.B",
    "display" : "ANISAKIS ANTICORPI"
  },
  {
    "code" : "91.05.C",
    "display" : "PLASMODI DELLA MALARIA NEL SANGUE RICERCA MICROSCOPICA (striscio sottile e goccia spessa previa colorazione specifica) E RICERCA DIRETTA ANTIGENI (metodi immunologici)"
  },
  {
    "code" : "91.05.D",
    "display" : "PROTOZOI ENTERICI RICERCA ACIDI NUCLEICI MULTIPLEX. Almeno E. histolytica, Cryprtospridium, Giardia. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.06.6",
    "display" : "RICKETTSIE CONORII ANTICORPI IgG e IgM"
  },
  {
    "code" : "91.06.A",
    "display" : "PNEUMOCYSTIS JIROVECII IN SECREZIONI RESPIRATORIE ESAME MICROSCOPICO (dopo concentrazione o arricchimento) E/O RICERCA DIRETTA (Metodi immunologici)"
  },
  {
    "code" : "91.06.B",
    "display" : "PNEUMOCYSTIS JIROVECII IN SECREZIONI RESPIRATORIE ACIDI NUCLEICI. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.06.C",
    "display" : "PROTOZOI ENTERICI RICERCA DIRETTA MULTIPLA ANTIGENI FECALI. Almeno due microrganismi"
  },
  {
    "code" : "91.07.6",
    "display" : "SALMONELLA NELLE FECI ESAME COLTURALE. In caso di coprocoltura positiva per Salmonella. Se positivo incluso: identificazione e eventuale antibiogramma."
  },
  {
    "code" : "91.07.7",
    "display" : "SHIGELLA NELLE FECI ESAME COLTURALE. In caso di coprocoltura positiva per Shigella. Se positivo, incluso: identificazione e antibiogramma."
  },
  {
    "code" : "91.07.8",
    "display" : "SCHISTOSOMA HAEMATOBIUM IN CAMPIONI URINARI, dopo concentrazione o filtrazione, esame microscopico"
  },
  {
    "code" : "91.08.2",
    "display" : "SCHISTOSOMA ANTICORPI O RICERCA URINARIA DEGLI ANTIGENI CIRCOLANTI"
  },
  {
    "code" : "91.08.4",
    "display" : "STREPTOCOCCO AGALACTIAE NEL TAMPONE VAGINO-RETTALE ESAME COLTURALE. Incluso: Identificazione"
  },
  {
    "code" : "91.08.5",
    "display" : "STREPTOCOCCO ANTICORPI ANTI ANTISTREPTOLISINA-O [T.A.S.]"
  },
  {
    "code" : "91.08.6",
    "display" : "STREPTOCOCCUS PNEUMONIAE ANTIGENI NELLE URINE RICERCA DIRETTA (Metodi immunologici)"
  },
  {
    "code" : "91.08.7",
    "display" : "STRONGYLOIDES STERCORALIS RICERCA LARVE NELLE FECI (Esame colurale o Baermann)"
  },
  {
    "code" : "91.08.8",
    "display" : "TAENIA SOLIUM [CISTICERCOSI] ANTICORPI. Incluso: eventuale immunoblotting"
  },
  {
    "code" : "91.08.A",
    "display" : "TOSSINA DIFTERICA ANTICORPI"
  },
  {
    "code" : "91.08.B",
    "display" : "TOSSINA TETANICA ANTICORPI"
  },
  {
    "code" : "91.08.C",
    "display" : "STRONGYLOIDES STERCORALIS ANTICORPI"
  },
  {
    "code" : "91.09.3",
    "display" : "TOXOCARA ANTICORPI"
  },
  {
    "code" : "91.09.B",
    "display" : "TOXOPLASMA ACIDI NUCLEICI IN MATERIALI BIOLOGICI RICERCA QUALITATIVA/QUANTITATIVA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.09.D",
    "display" : "TOXOPLASMA ANTICORPI IgG e IgM. Incluso: Test di Avidità delle IgG se IgG positive e IgM positive o dubbie. Incluso: eventuali IgA e Immunoblotting"
  },
  {
    "code" : "91.10.7",
    "display" : "TRICHINELLA ANTICORPI"
  },
  {
    "code" : "91.10.8",
    "display" : "TRIPANOSOMA CRUZI ANTICORPI"
  },
  {
    "code" : "91.10.9",
    "display" : "TRIPANOSOMI NEL SANGUE RICERCA MICROSCOPICA (con colorazione specifiche), dopo concentrazione o arricchimento"
  },
  {
    "code" : "91.10.A",
    "display" : "TRICHOMONAS VAGINALIS, ESAME COLTURALE E/O RICERCA DIRETTA ANTIGENI"
  },
  {
    "code" : "91.10.B",
    "display" : "TREPONEMA PALLIDUM sierologia della sifilide. Anticorpi EIA/CLIA e/o TPHA [TPPA] più VDRL [RPR]. Incluso: eventuale titolazione ed eventuale Immunoblotting"
  },
  {
    "code" : "91.11.3",
    "display" : "VIBRIO NELLE FECI ESAME COLTURALE. Incluso: eventuale identificazione e antibiogramma"
  },
  {
    "code" : "91.12.2",
    "display" : "VIRUS ACIDI NUCLEICI IN MATERIALI BIOLOGICI IBRIDAZIONE DIRETTA NAS"
  },
  {
    "code" : "91.12.5",
    "display" : "VIRUS ADENOVIRUS IN MATERIALI BIOLOGICI ESAME COLTURALE. Incluso: eventuale identificazione"
  },
  {
    "code" : "91.12.8",
    "display" : "VIRUS ADENOVIRUS ANTIGENI RICERCA DIRETTA NELLE FECI"
  },
  {
    "code" : "91.12.9",
    "display" : "VIRUS RESPIRATORI RICERCA ACIDI NUCLEICI MULTIPLEX. Almeno cinque microrganismi. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.12.A",
    "display" : "VIRUS ENTERICI RICERCA ACIDI NUCLEICI MULTIPLEX. Almeno tre microrganismi. Incluso: estrazione, amplificazione, rilevazione."
  },
  {
    "code" : "91.12.B",
    "display" : "VIRUS ACIDI NUCLEICI IN MATERIALI BIOLOGICI. RICERCA QUALITATIVA/QUANTITATIVA. Incluso: estrazione, eventuale retrotrascrizione, amplificazione e rivelazione"
  },
  {
    "code" : "91.13.1",
    "display" : "VIRUS ANTICORPI NAS"
  },
  {
    "code" : "91.13.2",
    "display" : "VIRUS ANTICORPI IMMUNOBLOTTING NAS (Saggio di conferma)"
  },
  {
    "code" : "91.13.6",
    "display" : "VIRUS ANTIGENI RICERCA DIRETTA IN MATERIALI BIOLOGICI NAS (Metodi immunologici). Per antigene"
  },
  {
    "code" : "91.13.7",
    "display" : "VIRUS ASTROVIRUS RICERCA ANTIGENE DIRETTA NELLE FECI"
  },
  {
    "code" : "91.15.A",
    "display" : "VIRUS CITOMEGALOVIRUS IN MATERIALI BIOLOGICI DIVERSI RICERCA MEDIANTE ESAME COLTURALE. Incluso: identificazione"
  },
  {
    "code" : "91.15.B",
    "display" : "VIRUS CITOMEGALOVIRUS: ANALISI QUALITATIVA DEL DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.15.C",
    "display" : "VIRUS CITOMEGALOVIRUS: ANALISI QUANTITATIVA DEL DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.15.D",
    "display" : "VIRUS CITOMEGALOVIRUS. Ricerca antigeni su granulociti (antigenemia) (IF o EIA)"
  },
  {
    "code" : "91.15.F",
    "display" : "VIRUS CITOMEGALOVIRUS ANTICORPI IgG e IgM. Incluso: Test di Avidità delle IgG se IgG positive e IgM positive o dubbie ed eventuale Immunoblotting. Non associabile a 91.13.2 Virus Anticorpi Immunoblotting (Saggio di conferma) NAS"
  },
  {
    "code" : "91.16.A",
    "display" : "VIRUS EPATITE B [HBV] ANALISI DI MUTAZIONE DEL DNA per rilevamento resistenze ai farmaci antivirali. Incluso: estrazione, amplificazione, sequenziamento o altro metodo"
  },
  {
    "code" : "91.16.B",
    "display" : "VIRUS EPATITE B [HBV] ANALISI QUALITATIVA DI HBV DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.16.C",
    "display" : "VIRUS EPATITE B [HBV] TIPIZZAZIONE GENOMICA. Incluso: estrazione, amplificazione, sequenziamento"
  },
  {
    "code" : "91.16.D",
    "display" : "VIRUS [ECHO, POLIO, COXSACKIE, ENTEROVIRUS] ANTICORPI IgG e IgM"
  },
  {
    "code" : "91.17.4",
    "display" : "VIRUS EPATITE B [HBV] ACIDI NUCLEICI IBRIDAZIONE DIRETTA"
  },
  {
    "code" : "91.17.6",
    "display" : "VIRUS EPATITE A [HAV] ANTICORPI IgG e IgM per sospetta infezione acuta"
  },
  {
    "code" : "91.17.8",
    "display" : "VIRUS EPATITE A [HAV] ANTICORPI IgG per controllo stato immunitario"
  },
  {
    "code" : "91.18.2",
    "display" : "VIRUS EPATITE B [HBV] ANTICORPI HBeAg. Non associabile a 91.18.6 VIRUS HBV [HBV] REFLEX"
  },
  {
    "code" : "91.18.3",
    "display" : "VIRUS EPATITE B [HBV] ANTICORPI HBsAg. Non associabile a 91.18.6 VIRUS HBV [HBV] REFLEX"
  },
  {
    "code" : "91.18.4",
    "display" : "VIRUS EPATITE B [HBV] ANTIGENE HBeAg. Non associabile a 91.18.6 VIRUS HBV [HBV] REFLEX"
  },
  {
    "code" : "91.18.5",
    "display" : "VIRUS EPATITE B [HBV] ANTIGENE HBsAg. Non associabile a 91.18.6 VIRUS HBV [HBV] REFLEX"
  },
  {
    "code" : "91.18.6",
    "display" : "VIRUS HBV [HBV] REFLEX. ANTIGENE HBsAg + ANTICORPI anti HBsAg + ANTICORPI anti HBcAg]. Incluso: ANTICORPI anti HBcAg IgM se HBsAg e anti HBcAg positivi. Incluso: ANTIGENE HBeAg se HBsAg positivo. Incluso: ANTICORPI anti HBeAg se HBeAg negativo"
  },
  {
    "code" : "91.19.3",
    "display" : "VIRUS EPATITE C [HCV] ANALISI QUALITATIVA DI HCV RNA. Incluso: estrazione, retrotrascrizione, amplificazione, rilevazione"
  },
  {
    "code" : "91.19.4",
    "display" : "VIRUS EPATITE C [HCV] ANALISI QUANTITATIVA DI HCV RNA . Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.19.5",
    "display" : "VIRUS EPATITE C [HCV] ANTICORPI. Incluso: eventuale Immunoblotting. Non associabile a 91.13.2 Virus Anticorpi Immunoblotting (Saggio di conferma) NAS"
  },
  {
    "code" : "91.19.6",
    "display" : "VIRUS EPATITE C ANTIGENE"
  },
  {
    "code" : "91.19.7",
    "display" : "VIRUS EPATITE C [HCV] ANALISI DI MUTAZIONE DEL DNA per rilevamento resistenze ai farmaci antivirali. Incluso: estrazione, amplificazione, sequenziamento o altro metodo"
  },
  {
    "code" : "91.20.2",
    "display" : "VIRUS EPATITE C [HCV] TIPIZZAZIONE GENOMICA. Incluso:, estrazione, retrotrascrizione, amplificazione, ibridazione inversa o sequenziamento"
  },
  {
    "code" : "91.20.5",
    "display" : "VIRUS EPATITE DELTA [HDV] ANTIGENE HDVAg."
  },
  {
    "code" : "91.20.6",
    "display" : "VIRUS EPATITE E [HEV] ANTICORPI"
  },
  {
    "code" : "91.20.7",
    "display" : "VIRUS EPATITE DELTA [HDV] ANTICORPI IgG e IgM."
  },
  {
    "code" : "91.21.6",
    "display" : "VIRUS EPSTEIN BARR [EBV] ANTICORPI EBNA + VCA IgG + VCA IgM. Incluso: EA in caso di VCA IgM positivo o dubbio"
  },
  {
    "code" : "91.21.9",
    "display" : "VIRUS GENOTIPIZZAZIONE NAS. Incluso: estrazione, amplificazione, ibridazione inversa o altro metodo"
  },
  {
    "code" : "91.21.B",
    "display" : "VIRUS HERPES SIMPLEX (TIPO 1 e 2) ANTICORPI IgG"
  },
  {
    "code" : "91.21.D",
    "display" : "VIRUS EPSTEIN BARR [EBV] ANALISI QUALITATIVA/QUANTITATIVA del DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.22.2",
    "display" : "VIRUS IMMUNODEFICENZA ACQUISITA [HIV ] ANALISI QUALITATIVA DI DNA provirale. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.22.3",
    "display" : "VIRUS IMMUNODEFICENZA ACQUISITA [HIV ] ANALISI QUANTITATIVA DI RNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.23.7",
    "display" : "VIRUS IMMUNODEF. ACQUISITA [HIV] ANALISI DI MUTAZIONE DELL'ACIDO NUCLEICO per rilevamento resistenze ai farmaci antivirali. Incluso: estrazione, retrotrascrizione, amplificazione, sequenziamento o altro metodo"
  },
  {
    "code" : "91.23.9",
    "display" : "VIRUS IN MATERIALI BIOLOGICI ESAME COLTURALE NAS. Incluso: eventuale identificazione"
  },
  {
    "code" : "91.23.F",
    "display" : "VIRUS IMMUNODEFICENZA ACQUISITA [HIV 1-2] .TEST COMBINATO ANTICORPI E ANTIGENE P24. Incluso: eventuale Immunoblotting. Non associabile a 91.13.2 Virus Anticorpi Immunoblotting (Saggio di conferma) NAS"
  },
  {
    "code" : "91.24.8",
    "display" : "VIRUS NOROVIRUS ANTIGENI RICERCA DIRETTA NELLE FECI"
  },
  {
    "code" : "91.24.9",
    "display" : "VIRUS PAPILLOMAVIRUS [HPV]. QUALITATIVA/QUANTITATIVA DNA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.24.C",
    "display" : "VIRUS PAPILLOMAVIRUS [HPV] TIPIZZAZIONE GENOMICA. Incluso: estrazione, amplificazione, rilevazione"
  },
  {
    "code" : "91.24.F",
    "display" : "VIRUS MORBILLO ANTICORPI IgG e IgM"
  },
  {
    "code" : "91.24.G",
    "display" : "VIRUS PAROTITE ANTICORPI IgG e IgM"
  },
  {
    "code" : "91.25.8",
    "display" : "VIRUS PARVOVIRUS B19 ANTICORPI IgG e IgM"
  },
  {
    "code" : "91.25.D",
    "display" : "VIRUS RESPIRATORIO SINCIZIALE RICERCA DIRETTA IN MATERIALI BIOLOGICI"
  },
  {
    "code" : "91.26.3",
    "display" : "VIRUS RETROVIRUS ANTICORPI ANTI HTLV1-HTLV2"
  },
  {
    "code" : "91.26.9",
    "display" : "VIRUS ROTAVIRUS ANTIGENI RICERCA DIRETTA NELLE FECI"
  },
  {
    "code" : "91.26.C",
    "display" : "VIRUS VARICELLA ZOSTER ANTICORPI IgG ed eventuali IgM"
  },
  {
    "code" : "91.26.D",
    "display" : "VIRUS ROSOLIA IgG e IgM per sospetta infezione acuta . Incluso: Test di Avidità delle IgG se IgG positive e IgM positive o dubbie"
  },
  {
    "code" : "91.26.E",
    "display" : "VIRUS ROSOLIA ANTICORPI IgG per controllo stato immunitario"
  },
  {
    "code" : "91.27.5",
    "display" : "YERSINIA NELLE FECI ESAME COLTURALE. Incluso: eventuale identificazione e antibiogramma"
  },
  {
    "code" : "91.30.2",
    "display" : "ANALISI DI POLIMORFISMI STR PER CHIMERISMO POST TRAPIANTO"
  },
  {
    "code" : "91.35.6",
    "display" : "CONSULENZA COLLEGATA AL TEST GENETICO"
  },
  {
    "code" : "91.38.5",
    "display" : "ES. CITOLOGICO CERVICO VAGINALE [PAP test]"
  },
  {
    "code" : "91.38.L",
    "display" : "CONSULENZA ANATOMOPATOLOGICA PER REVISIONE DIAGNOSTICA DI PREPARATI ALLESTITI IN ALTRA SEDE (Prescrivibile una sola volta per lo stesso episodio patologico)"
  },
  {
    "code" : "91.39.2",
    "display" : "ES. CITOLOGICO DI ESPETTORATO. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Su 3 campioni successivi"
  },
  {
    "code" : "91.39.4",
    "display" : "ES. CITOLOGICO URINE PER RICERCA CELLULE NEOPLASTICHE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Su 3 campioni in giorni successivi"
  },
  {
    "code" : "91.39.B",
    "display" : "ES. CITOLOGICO ESFOLIATIVO APPARATO RESPIRATORIO. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.C",
    "display" : "ESAME CITOLOGICO DA AGOASPIRATO APPARATO RESPIRATORIO. Incluso: eventuali analisi supplementari Istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.D",
    "display" : "ES. CITOLOGICO ESFOLIATIVO SIEROSE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.E",
    "display" : "ESAME CITOLOGICO ESFOLIATIVO APPARATO DIGERENTE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.F",
    "display" : "ES. CITOLOGICO DA AGOASPIRATO APPARATO DIGERENTE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.G",
    "display" : "ESAME CITOLOGICO DA AGOASPIRATO DI ALTRI ORGANI O SEDI. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.H",
    "display" : "ESAME CITOLOGICO ESFOLIATIVO CUTE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.J",
    "display" : "ESAME CITOLOGICO ESFOLIATIVO MAMMELLA. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.L",
    "display" : "ESAME CITOLOGICO DA AGOASPIRATO DI TESSUTO EMOPOIETICO. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.39.N",
    "display" : "ESAME CITOLOGICO DA AGOASPIRATO DELLA TIROIDE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.40.A",
    "display" : "ES. ISTOPATOLOGICO ARTICOLAZIONI. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.40.B",
    "display" : "ES. ISTOPATOLOGICO BULBO OCULARE. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.40.C",
    "display" : "ES. ISTOPATOLOGICO CAVO ORALE. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.40.D",
    "display" : "ES. ISTOPATOLOGICO CAVO ORALE. ESCISSIONE DI NEOFORMAZIONE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.40.E",
    "display" : "ES. ISTOPATOLOGICO SISTEMA CIRCOLATORIO. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Biopsia semplice. Per campione"
  },
  {
    "code" : "91.40.G",
    "display" : "ES. ISTOPATOLOGICO CUTE E/O TESSUTI MOLLI. Con biopsia o escissione di neoformazione. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.40.H",
    "display" : "ES. ISTOPATOLOGICO DI CUTE E/O TESSUTI MOLLI. Escissione allargata di neoplasia maligna. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.8",
    "display" : "ES. ISTOPATOLOGICO APPARATO DIGERENTE. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.B",
    "display" : "ES. ISTOPATOLOGICO ALTRI ORGANI DA AGOBIOPSIA. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.C",
    "display" : "ES. ISTOPATOLOGICO APPARATO DIGERENTE. BIOPSIA ENDOSCOPICA PER CELIACHIA. Incluso: valutazione immunoistochimica per CD3"
  },
  {
    "code" : "91.41.D",
    "display" : "ES. ISTOPATOLOGICO APPARATO DIGERENTE. MAPPING PER MALATTIA INFIAMMATORIA CRONICA INTESTINALE (IBD). Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Su almeno 6 campioni"
  },
  {
    "code" : "91.41.E",
    "display" : "ES. ISTOPATOLOGICO DELL'APPARATO DIGERENTE. MUCOSECTOMIA. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.41.F",
    "display" : "ES. ISTOPATOLOGICO APPARATO DIGERENTE ESCISSIONE DI NEOFORMAZIONE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.G",
    "display" : "ES. ISTOPATOLOGICO SISTEMA EMOPOIETICO. ASPORTAZIONE DI LINFONODO UNICO SUPERFICIALE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.J",
    "display" : "ES. ISTOPATOLOGICO SISTEMA EMOPOIETICO. BIOPSIA OSTEO- MIDOLLARE (B.O.M.). Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi."
  },
  {
    "code" : "91.41.K",
    "display" : "ES. ISTOPATOLOGICO SISTEMA ENDOCRINO. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.41.L",
    "display" : "ES. ISTOPATOLOGICO APPARATO DIGERENTE. BIOPSIA ENDOSCOPICA PER STUDIO GASTRITE CRONICA. Mapping su almeno 3 campioni. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.42.C",
    "display" : "ES. ISTOPATOLOGICO APPARATO MUSCOLO SCHELETRICO. Biopsia semplice ossea. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.42.D",
    "display" : "ES. ISTOPATOLOGICO APPARATO MUSCOLO SCHELETRICO. BIOPSIA INCISIONALE O PUNCH. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.42.E",
    "display" : "ES. ISTOPATOLOGICO ORECCHIO. Biopsia semplice. Incluse eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.42.F",
    "display" : "ES. ISTOPATOLOGICO APPARATO RESPIRATORIO da Polipectomia endoscopica. Incluso:eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.42.G",
    "display" : "ES. ISTOPATOLOGICO APPARATO RESPIRATORIO - Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.42.H",
    "display" : "ES. ISTOPATOLOGICO NASO E CAVITÀ NASALI. ESCISSIONE DI NEOFORMAZIONE. Incluse eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.A",
    "display" : "ES. ISTOPATOLOGICO SIEROSE. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.B",
    "display" : "ES. ISTOPATOLOGICO SIEROSE. ESCISSIONE DI NEOFORMAZIONE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.D",
    "display" : "ES. ISTOPATOLOGICO APPARATO GENITALE ESCISSIONE DI NEOFORMAZIONE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.E",
    "display" : "ES. ISTOPATOLOGICO APPARATO GENITALE DA CONIZZAZIONE CERVICE UTERINA (chirurgica, con ansa a radiofrequenza o altre metodiche). Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi"
  },
  {
    "code" : "91.43.G",
    "display" : "ES. ISTOPATOLOGICO APPARATO URINARIO. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.H",
    "display" : "ES. ISTOPATOLOGICO APPARATO URINARIO PER LESIONE FOCALE. BIOPSIA RENALE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.43.K",
    "display" : "ES. ISTOPATOLOGICO APPARATO URINARIO. BIOPSIA RENALE per lesione diffusa. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Inclusa Immunofluorescenza. Per campione e almeno 7 marcatori"
  },
  {
    "code" : "91.43.L",
    "display" : "ES. ISTOPATOLOGICO APPARATO GENITALE. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.44.1",
    "display" : "ES. ISTOPATOLOGICO APPARATO GENITALE MASCHILE. Agobiopsia prostatica su prelievi multipli. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Almeno 12 campioni"
  },
  {
    "code" : "91.45.8",
    "display" : "ES. ISTOPATOLOGICO APPARATO URINARIO. Mapping da Biopsia endoscopica vescicale. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Almeno 6 campioni"
  },
  {
    "code" : "91.46.8",
    "display" : "ES. ISTOPATOLOGICO DELLA MAMMELLA. BIOPSIA VACUUM ASSISTED. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per almeno 8 campioni"
  },
  {
    "code" : "91.46.A",
    "display" : "ES. ISTOPATOLOGICO MAMMELLA. Biopsia semplice. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.46.B",
    "display" : "ES. ISTOPATOLOGICO MAMMELLA. ESCISSIONE DI NEOFORMAZIONE. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.47.6",
    "display" : "ES. ISTOPATOLOGICO SISTEMA LINFOEMOPOIETICO: da Agobiopsia linfonodale. Incluso: eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.47.8",
    "display" : "PANNELLO DI IMMUNOFENOTIPIZZAZIONE DI FATTORI PROGNOSTICI E PREDITTIVI PER PATOLOGIA TUMORALE MALIGNA DELLA MAMMELLA. Almeno 4 marcatori"
  },
  {
    "code" : "91.47.C",
    "display" : "IMMUNOFENOTIPIZZAZIONE LEUCO/LINFOCITARIA. Fino a 8 antigeni"
  },
  {
    "code" : "91.47.L",
    "display" : "PANNELLO DI IMMUNOFENOTIPIZZAZIONE DI FATTORI PROGNOSTICI E PREDITTIVI PER PATOLOGIA TUMORALE MALIGNA DEL SISTEMA NERVOSO CENTRALE. Almeno 2 marcatori"
  },
  {
    "code" : "91.47.M",
    "display" : "PANNELLO DI IMMUNOFENOTIPIZZAZIONE DI FATTORI PROGNOSTICI E PREDITTIVI PER MELANOMA Almeno 2 marcatori"
  },
  {
    "code" : "91.47.N",
    "display" : "PANNELLO DI IMMUNOFENOTIPIZZAZIONE DI FATTORI PROGNOSTICI E PREDITTIVI PER PATOLOGIA TUMORALE MALIGNA DEL POLMONE. Almeno 2 marcatori"
  },
  {
    "code" : "91.47.P",
    "display" : "PANNELLO DI IMMUNOFENOTIPIZZAZIONE DI FATTORI PROGNOSTICI E PREDITTIVI PER PATOLOGIA TUMORALE MALIGNA DELL'APPARATO GASTROENTERICO. Almeno 2 marcatori"
  },
  {
    "code" : "91.48.2",
    "display" : "ES. ISTOPATOLOGICO S.N.P. Incluse eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Da Biopsia di nervo periferico. Per campione"
  },
  {
    "code" : "91.48.3",
    "display" : "ES. ISTOCITOPATOLOGICO ULTRASTRUTTURALE (S.E.M., T.E.M.). Per campione"
  },
  {
    "code" : "91.48.4",
    "display" : "PRELIEVO CITOLOGICO"
  },
  {
    "code" : "91.48.5",
    "display" : "PRELIEVO DI SANGUE ARTERIOSO"
  },
  {
    "code" : "91.49.1",
    "display" : "PRELIEVO DI SANGUE CAPILLARE"
  },
  {
    "code" : "91.49.2",
    "display" : "PRELIEVO DI SANGUE VENOSO"
  },
  {
    "code" : "91.49.3",
    "display" : "PRELIEVO MICROBIOLOGICO"
  },
  {
    "code" : "91.49.4",
    "display" : "ES. ISTOPATOLOGICO NAS da agobiopsia di organo/tessuto superficiale o profondo. Incluse eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.49.5",
    "display" : "ES. ISTOPATOLOGICO NAS. Biopsia semplice di organo/tessuto superficiale o profondo. Incluse eventuali analisi supplementari istochimiche e/o immunoistochimiche necessarie al completamento della diagnosi. Per campione"
  },
  {
    "code" : "91.5R.1",
    "display" : "SCREENING URINARI ERRORI CONGENITI DEL METABOLISMO Incluso: pH urinario, ricerca glucosio e altri zuccheri urinari, ricerca chetoni urinari"
  },
  {
    "code" : "91.5R.2",
    "display" : "ACIDI ORGANICI URINARI (NAS) IN GC/MS. DOSAGGIO"
  },
  {
    "code" : "91.5R.3",
    "display" : "DOSAGGIO QUANTITATIVO DI UN SINGOLO ACIDO ORGANICO IN LIQUIDI BIOLOGICI MEDIANTE GC/MS CON ISOTOPI STABILI"
  },
  {
    "code" : "91.5R.4",
    "display" : "ACIDO OROTICO URINARIO. DOSAGGIO"
  },
  {
    "code" : "91.5R.5",
    "display" : "BETA-IDROSSIBUTIRRATO"
  },
  {
    "code" : "91.5R.6",
    "display" : "ACIDO ACETOACETICO"
  },
  {
    "code" : "91.5R.7",
    "display" : "NEFA (acidi grassi non esterificati)"
  },
  {
    "code" : "91.5R.8",
    "display" : "CARNITINA LIBERA"
  },
  {
    "code" : "91.5R.9",
    "display" : "CARNITINA ESTERIFICATA"
  },
  {
    "code" : "91.5R.A",
    "display" : "PROFILO ACILCARNITINE PLASMATICHE CON MS/MS"
  },
  {
    "code" : "91.5R.B",
    "display" : "SUCCINILACETONE URINARIO"
  },
  {
    "code" : "91.5R.C",
    "display" : "N-ACETILASPARTATO"
  },
  {
    "code" : "91.5R.D",
    "display" : "PTERINE PLASMATICHE E URINARIE"
  },
  {
    "code" : "91.5R.E",
    "display" : "OLIGOSACCARIDI URINARI"
  },
  {
    "code" : "91.5R.F",
    "display" : "CROMATOGRAFIA ZUCCHERI URINARI"
  },
  {
    "code" : "91.5R.G",
    "display" : "ACIDI GRASSI A CATENA MOLTO LUNGA (VLCFA)"
  },
  {
    "code" : "91.5R.H",
    "display" : "ISOLELETTROFOCUSING DELLA TRANSFERRINA SIERICA"
  },
  {
    "code" : "91.5R.J",
    "display" : "CISTINA INTRALEUCOCITARIA"
  },
  {
    "code" : "91.5R.K",
    "display" : "ENZIMI DEL METABOLISMO GLICIDICO. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.L",
    "display" : "ENZIMI METABOLISMO DEGLI AMMINOACIDI. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.M",
    "display" : "ENZIMI GLICOSILAZIONE DELLE PROTEINE. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.N",
    "display" : "ENZIMI METABOLISMO PURINICO. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.P",
    "display" : "ENZIMI METABOLISMO PIRIMIDINICO. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.Q",
    "display" : "ENZIMI LISOSOMIALI. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.R",
    "display" : "ENZIMI DELLA BETA-OSSIDAZIONE. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.S",
    "display" : "ENZIMI MITOCONDRIALI. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.T",
    "display" : "ENZIMI METABOLISMO LIPIDICO. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.U",
    "display" : "ENZIMI METABOLISMO DELLE PORFIRINE. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.W",
    "display" : "RAME TISSUTALE. DOSAGGIO. Per singolo dosaggio"
  },
  {
    "code" : "91.5R.X",
    "display" : "MUCOPOLISACCARIDI URINARI TEST DI SCREENING"
  },
  {
    "code" : "91.5R.Y",
    "display" : "MUCOPOLISACCARIDI URINARI TOTALI. DOSAGGIO"
  },
  {
    "code" : "91.5R.Z",
    "display" : "N-ACETILGLUCOSAMINIDASI"
  },
  {
    "code" : "91.60.1",
    "display" : "STATO MUTAZIONALE EGFR"
  },
  {
    "code" : "91.60.2",
    "display" : "RIARRANGIAMENTO ALK. In caso di negatività incluso: ROS1"
  },
  {
    "code" : "91.60.3",
    "display" : "STATO MUTAZIONALE K-RAS, N-RAS"
  },
  {
    "code" : "91.60.4",
    "display" : "STATO MUTAZIONALE H-RAS"
  },
  {
    "code" : "91.60.5",
    "display" : "STATO MUTAZIONALE K-RAS"
  },
  {
    "code" : "91.60.6",
    "display" : "STATO MUTAZIONALE B-RAF"
  },
  {
    "code" : "91.60.7",
    "display" : "INSTABILITA' MICROSATELLITARE"
  },
  {
    "code" : "91.60.8",
    "display" : "STATO MUTAZIONALE C-Kit"
  },
  {
    "code" : "91.60.9",
    "display" : "STATO MUTAZIONALE PDGFRA"
  },
  {
    "code" : "91.60.A",
    "display" : "STATO HER2-neu"
  },
  {
    "code" : "91.60.B",
    "display" : "METILAZIONE PROMOTORE MGMT"
  },
  {
    "code" : "91.60.C",
    "display" : "MUTAZIONI IDH1-2"
  },
  {
    "code" : "91.60.D",
    "display" : "CODELEZIONE 1p/19q"
  },
  {
    "code" : "91.60.E",
    "display" : "STATO MUTAZIONALE RET"
  },
  {
    "code" : "91.60.F",
    "display" : "AMPLIFICAZIONE GENE N-MYC"
  },
  {
    "code" : "91.60.G",
    "display" : "RIARRANGIAMENTO EWSR1"
  },
  {
    "code" : "91.60.H",
    "display" : "RIARRANGIAMENTO gene DDIT3"
  },
  {
    "code" : "91.60.J",
    "display" : "RIARRANGIAMENTO gene FOX01"
  },
  {
    "code" : "91.60.K",
    "display" : "AMPLIFICAZIONE MDM2"
  },
  {
    "code" : "91.60.L",
    "display" : "TRASLOCAZIONE (X;18)"
  },
  {
    "code" : "91.60.M",
    "display" : "TRASLOCAZIONE (7;16)"
  },
  {
    "code" : "91.60.N",
    "display" : "TRASLOCAZIONE der (17) t (X;17)"
  },
  {
    "code" : "91.60.P",
    "display" : "TRASLOCAZIONE t (12;15)"
  },
  {
    "code" : "91.60.Q",
    "display" : "TRASLOCAZIONE (11;14)"
  },
  {
    "code" : "91.60.R",
    "display" : "TRASLOCAZIONE (9;14)"
  },
  {
    "code" : "91.60.S",
    "display" : "TRASLOCAZIONE t (11;18), t (1;14), t (3:14)"
  },
  {
    "code" : "91.60.T",
    "display" : "TRASLOCAZIONE t (2;12)"
  },
  {
    "code" : "91.60.U",
    "display" : "TRASLOCAZIONE t ( 14;18)"
  },
  {
    "code" : "91.60.V",
    "display" : "TRASLOCAZIONE (2;17)"
  },
  {
    "code" : "91.60.W",
    "display" : "TRASLOCAZIONE (8;14) , (2;8), (8;22), (8;9), (3;8)"
  },
  {
    "code" : "91.60.X",
    "display" : "TRASLOCAZIONE (2;5), (1;2)"
  },
  {
    "code" : "91.60.Z",
    "display" : "RIARRANGIAMENTO GENI DELLE IMMUNOGLOBULINE"
  },
  {
    "code" : "91.61.1",
    "display" : "RIARRANGIAMENTO DEL RECETTORE DELLE CELLULE T (TCR)"
  },
  {
    "code" : "91.61.2",
    "display" : "FISH Bcl6"
  },
  {
    "code" : "91.6R.1",
    "display" : "GALATTOSIO 1-FOSFATO URIDIL TRANSFERASI (GALT)"
  },
  {
    "code" : "91.90.1",
    "display" : "ESAME ALLERGOLOGICO STRUMENTALE PER ORTICARIE DA AGENTI FISICI"
  },
  {
    "code" : "91.90.4",
    "display" : "SCREENING ALLERGOLOGICO PER INALANTI E ALIMENTI [Prick test]. Fino a 18 allergeni"
  },
  {
    "code" : "91.90.5",
    "display" : "TEST EPICUTANEI A LETTURA RITARDATA [PATCH TEST]. Fino a 30 allergeni. Inclusa visita allergologica di controllo"
  },
  {
    "code" : "91.90.6",
    "display" : "TEST PERCUTANEI E INTRACUTANEI A LETTURA IMMEDIATA E RITARDATA PER FARMACI. Per classe di farmaci"
  },
  {
    "code" : "91.90.7",
    "display" : "TEST DI TOLLERANZA/PROVOCAZIONE CON FARMACI, ALIMENTI ED ADDITIVI. Indipendentemente dal numero di sedute"
  },
  {
    "code" : "91.90.8",
    "display" : "PRICK BY PRICK CON ALLERGENI FRESCHI. Fino a 7 allergeni"
  },
  {
    "code" : "91.90.9",
    "display" : "TEST EPICUTANEO IN APERTO [Open test]. Per singolo allergene."
  },
  {
    "code" : "91.90.A",
    "display" : "TEST DEL SIERO AUTOLOGO"
  },
  {
    "code" : "91.90.B",
    "display" : "TEST PERCUTANEI E INTRACUTANEI A LETTURA IMMEDIATA PER VELENO DI IMENOTTERI. Fino a 7 allergeni"
  },
  {
    "code" : "91.90.C",
    "display" : "TEST DI INTOLLERANZE O ALLERGIE SULLA CONGIUNTIVA. Per singolo allergene"
  },
  {
    "code" : "92.01.1",
    "display" : "CAPTAZIONE TIROIDEA"
  },
  {
    "code" : "92.01.3",
    "display" : "SCINTIGRAFIA TIROIDEA"
  },
  {
    "code" : "92.01.5",
    "display" : "SCINTIGRAFIA TIROIDEA CON IODIO-123"
  },
  {
    "code" : "92.02.2",
    "display" : "SCINTIGRAFIA EPATICA PER RICERCA DI LESIONI ANGIOMATOSE CON INDAGINE TOMOGRAFICA"
  },
  {
    "code" : "92.02.3",
    "display" : "SCINTIGRAFIA SEQUENZIALE EPATOBILIARE INCLUSA VALUTAZIONE DELLA FUNZIONE COLECISTICA E/O DEL REFLUSSO DUODENO-GASTRICO"
  },
  {
    "code" : "92.03.1",
    "display" : "SCINTIGRAFIA RENALE STATICA. Non associabile a SCINTIGRAFIA RENALE STATICA CON INDAGINE TOMOGRAFICA (92.03.8)"
  },
  {
    "code" : "92.03.3",
    "display" : "SCINTIGRAFIA SEQUENZIALE RENALE. Studio sequenziale della funzione renale senza o con prove farmacologiche Incluso: misura contestuale della funzionalità renale separata (in vivo)"
  },
  {
    "code" : "92.03.4",
    "display" : "STUDIO DEL REFLUSSO VESCICO-URETERALE. Mediante cistoscintigrafia minzionale diretta. Incluso: posizionamento di catetere"
  },
  {
    "code" : "92.03.8",
    "display" : "SCINTIGRAFIA RENALE STATICA CON INDAGINE TOMOGRAFICA. Non associabile a SCINTIGRAFIA RENALE STATICA (92.03.1)"
  },
  {
    "code" : "92.04.1",
    "display" : "SCINTIGRAFIA SEQUENZIALE DELLE GHIANDOLE SALIVARI CON STUDIO FUNZIONALE"
  },
  {
    "code" : "92.04.2",
    "display" : "STUDIO DEL TRANSITO ESOFAGEO Non associabile a 92.04.6"
  },
  {
    "code" : "92.04.3",
    "display" : "STUDIO DEL REFLUSSO GASTRO-ESOFAGEO"
  },
  {
    "code" : "92.04.4",
    "display" : "VALUTAZIONE DELLE GASTROENTERORRAGIE"
  },
  {
    "code" : "92.04.6",
    "display" : "SVUOTAMENTO GASTRICO: VALUTAZIONE DELLA FUNZIONE MOTORIA GASTRICA"
  },
  {
    "code" : "92.04.7",
    "display" : "RICERCA DI MUCOSA GASTRICA ECTOPICA"
  },
  {
    "code" : "92.05.4",
    "display" : "ANGIOCARDIOSCINTIGRAFIA ALL'EQUILIBRIO a riposo e dopo test provocativo da stimolo (fisico o farmacologico). Incluso: test cardiovascolare provocativo da sforzo o farmacologico ed eventuale SPET. Non associabile a ANGIOCARDIOSCINTIGRAFIA ALL'EQUILIBRIO a riposo ( 92.05.A)"
  },
  {
    "code" : "92.05.6",
    "display" : "SCINTIGRAFIA DEL MIDOLLO OSSEO GLOBALE CORPOREA. Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.05.7",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET TC] MIOCARDICA CON FDG"
  },
  {
    "code" : "92.05.A",
    "display" : "ANGIOCARDIOSCINTIGRAFIA ALL'EQUILIBRIO a riposo. Non associabile a 92.05.4"
  },
  {
    "code" : "92.05.C",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET TC] MIOCARDICA DI PERFUSIONE CON AMMONIA"
  },
  {
    "code" : "92.05.D",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET TC] MIOCARDICA CON ALTRI RADIOFARMACI"
  },
  {
    "code" : "92.05.E",
    "display" : "TOMOSCINTIGRAFIA MIOCARDICA [G-SPET] DI PERFUSIONE A RIPOSO. Incluso: valutazione quantitativa della funzione e dei volumi ventricolari. Non associabile a 92.09.2"
  },
  {
    "code" : "92.05.F",
    "display" : "TOMOSCINTIGRAFIA MIOCARDICA [G-SPET] DI PERFUSIONE DA STIMOLO FISICO O FARMACOLOGICO. Incluso: valutazione quantitativa della funzione e dei volumi ventricolari. Incluso test cardiovascolare provocativo da sforzo o farmacologico. Non associabile a ECG da sforzo"
  },
  {
    "code" : "92.09.1",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET TC] MIOCARDICA DI PERFUSIONE A RIPOSO E DA STIMOLO: STUDIO QUALITATIVO. Incluso: test cardiovascolare provocativo da sforzo o farmacologico. Non associabile a ECG da sforzo"
  },
  {
    "code" : "92.09.2",
    "display" : "TOMOSCINTIGRAFIA MIOCARDICA [SPET] DI PERFUSIONE A RIPOSO"
  },
  {
    "code" : "92.09.9",
    "display" : "TOMOSCINTIGRAFIA MIOCARDICA [SPET] DI PERFUSIONE DA STIMOLO FISICO O FARMACOLOGICO. Incluso: test cardiovascolare provocativo da sforzo o farmacologico. Non associabile a ECG da sforzo"
  },
  {
    "code" : "92.09.B",
    "display" : "SCINTIGRAFIA [SPET] MIOCARDICA CON TRACCIANTE DI INNERVAZIONE O RECETTORIALE O NEURORECETTORIALE O DI METABOLISMO."
  },
  {
    "code" : "92.11.5",
    "display" : "TOMOSCINTIGRAFIA [SPET] CEREBRALE CON TRACCIANTE DI PERFUSIONE. In condizioni basali, sotto stimolo farmacologico o di attivazione"
  },
  {
    "code" : "92.11.6",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET] CEREBRALE CON FDG"
  },
  {
    "code" : "92.11.9",
    "display" : "TOMOSCINTIGRAFIA [SPET] CEREBRALE CON TRACCIANTI RECETTORIALI O INDICATORI POSITIVI DI NEOPLASIA"
  },
  {
    "code" : "92.11.A",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET] CEREBRALE CON ALTRI RADIOFARMACI"
  },
  {
    "code" : "92.13",
    "display" : "SCINTIGRAFIA DELLE PARATIROIDI. Non associabile a 92.13.2"
  },
  {
    "code" : "92.13.2",
    "display" : "SCINTIGRAFIA DELLE PARATIROIDI CON INDAGINE TOMOGRAFICA"
  },
  {
    "code" : "92.15.1",
    "display" : "SCINTIGRAFIA POLMONARE PERFUSIONALE, INCLUSO EVENTUALE STUDIO QUANTITATIVO DIFFERENZIALE DELLA FUNZIONE POLMONARE. Incluso: eventuale indagine tomoscintigrafica"
  },
  {
    "code" : "92.15.2",
    "display" : "SCINTIGRAFIA POLMONARE VENTILATORIA INCLUSO EVENTUALE STUDIO QUANTITATIVO DIFFERENZIALE DELLA FUNZIONE POLMONARE. Incluso: eventuale indagine tomoscintigrafica"
  },
  {
    "code" : "92.15.4",
    "display" : "SCINTIGRAFIA POLMONARE CON INDICATORE POSITIVO DI NEOPLASIA. Incluso: eventuale indagine tomoscintigrafica"
  },
  {
    "code" : "92.15.6",
    "display" : "VALUTAZIONE DELLA CLEARANCE POLMONARE CON TECNICA SCINTIGRAFICA"
  },
  {
    "code" : "92.16.1",
    "display" : "SCINTIGRAFIA LINFATICA E LINFOGHIANDOLARE SEGMENTARIA. Incluso: eventuale indagine tomoscintigrafica."
  },
  {
    "code" : "92.16.2",
    "display" : "SCINTIGRAFIA MAMMARIA CON INDICATORI POSITIVI DI NEOPLASIA"
  },
  {
    "code" : "92.18.1",
    "display" : "SCINTIGRAFIA GLOBALE CORPOREA CON INDICATORI POSITIVI DI NEOPLASIA O DI FLOGOSI. Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.2",
    "display" : "SCINTIGRAFIA OSSEA O ARTICOLARE GLOBALE CORPOREA. Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.7",
    "display" : "SCINTIGRAFIA OSSEA O ARTICOLARE O SEGMENTARIA TRIFASICA. Incluso: eventuale indagine tomoscintigrafica. Non associabile a 92.18.2"
  },
  {
    "code" : "92.18.8",
    "display" : "SCINTIGRAFIA GLOBALE CORPOREA CON IODIO-131 Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.9",
    "display" : "SCINTIGRAFIA GLOBALE CORPOREA CON IODIO-131 con stimolazione farmacologica (Tireotropina alfa). Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.A",
    "display" : "SCINTIGRAFIA GLOBALE CORPOREA CON LEUCOCITI RADIOMARCATI Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.B",
    "display" : "SCINTIGRAFIA GLOBALE CORPOREA CON TRACCIANTI IMMUNOLOGICI O RECETTORIALI. Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.18.C",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET] GLOBALE CORPOREA CON FDG"
  },
  {
    "code" : "92.18.D",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET] GLOBALE CORPOREA CON ALTRI FARMACI. Incluso: eventuale indagine tomoscintigrafica segmentaria a completamento della prestazione"
  },
  {
    "code" : "92.19.1",
    "display" : "SCINTIGRAFIA SURRENALICA CORTICALE"
  },
  {
    "code" : "92.19.2",
    "display" : "SCINTIGRAFIA SURRENALICA MIDOLLARE"
  },
  {
    "code" : "92.19.5",
    "display" : "ANGIOSCINTIGRAFIA [ANGIOGRAFIA, VENOGRAFIA RADIOISOTOPICA]"
  },
  {
    "code" : "92.19.8",
    "display" : "SCINTIGRAFIA SEGMENTARIA CON INDICATORI POSITIVI DI NEOPLASIA O DI FLOGOSI. Non associabile a 92.15.4, 92.16.2, 92.18.1"
  },
  {
    "code" : "92.19.A",
    "display" : "TOMOSCINTIGRAFIA [SPET] SEGMENTARIA AI FINI DI PIANO DOSIMETRICO"
  },
  {
    "code" : "92.19.B",
    "display" : "TOMOGRAFIA AD EMISSIONE DI POSITRONI [PET] SEGMENTARIA AI FINI DI PIANO DOSIMETRICO"
  },
  {
    "code" : "92.21.1",
    "display" : "ROENTGENTERAPIA [PLESIOTERAPIA]. Per seduta"
  },
  {
    "code" : "92.23.1",
    "display" : "TELECOBALTOTERAPIA. Per seduta e per focolaio trattato"
  },
  {
    "code" : "92.24.1",
    "display" : "TELETERAPIA CON ACCELERATORE LINEARE CON TECNICHE 2D. Per seduta e per focolaio trattato. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.24.2",
    "display" : "TELETERAPIA CON ACCELERATORE LINEARE CON CAMPI MULTIPLI, DI MOVIMENTO CON TECNICHE 2D. Per seduta e per focolaio trattato. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.24.4",
    "display" : "RADIOCHIRURGIA IN UNICA SEDUTA. Dose per frazione uguale o superiore a 5 Gy."
  },
  {
    "code" : "92.24.6",
    "display" : "TELETERAPIA CON ACCELERATORE LINEARE CON CAMPI MULTIPLI O DI MOVIMENTO CON TECNICHE 3D. Per seduta e per focolaio trattato. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.24.7",
    "display" : "TELETERAPIA CON ACCELERATORE LINEARE CON CAMPI MULTIPLI O DI MOVIMENTO. Per tecniche con modulazione di intensità. Per seduta e per focolaio trattato. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.24.A",
    "display" : "RADIOTERAPIA STEREOTASSICA CON RIPOSIZIONAMENTO ON LINE DEL BERSAGLIO. Dose per frazione uguale o superiore a 5 Gy. Per seduta. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.24.C",
    "display" : "RADIOTERAPIA STEREOTASSICA CON E SENZA CASCO CON PIANIFICAZIONE TRAMITE RM CON SORGENTE DI COBALTO"
  },
  {
    "code" : "92.24.D",
    "display" : "RADIOTERAPIA STEREOTASSICA CON E SENZA CASCO CON BRACCIO ROBOTICO PER RIPOSIZIONAMENTO ON LINE DEL BERSAGLIO. Per seduta. Ciclo fino a 5 sedute"
  },
  {
    "code" : "92.25.1",
    "display" : "TELETERAPIA CON ELETTRONI A UNO O PIU' CAMPI FISSI. Per seduta e per focolaio trattato. Ciclo fino a 10 sedute"
  },
  {
    "code" : "92.25.2",
    "display" : "IRRADIAZIONE CUTANEA TOTALE CON ELETTRONI (TSEI/TSEBI). Incluse le fasi propedeutiche alla prestazione"
  },
  {
    "code" : "92.25.6",
    "display" : "IRRADIAZIONE CORPOREA TOTALE CON FOTONI (TBI) TOTAL BODY. Prima o unica seduta"
  },
  {
    "code" : "92.25.7",
    "display" : "IRRADIAZIONE CORPOREA TOTALE (TBI) TOTAL BODY CON FOTONI. Sedute successive"
  },
  {
    "code" : "92.27.1",
    "display" : "BRACHITERAPIA ENDOLUMINALE, ENDOCAVITARIA, INTERSTIZIALE E DI SUPERFICIE CON VETTORI MULTIPLI. Per seduta e per focolaio trattato"
  },
  {
    "code" : "92.27.3",
    "display" : "BRACHITERAPIA ENDOLUMINALE, ENDOCAVITARIA, INTERSTIZIALE E DI SUPERFICIE CON VETTORE SINGOLO. Per seduta e per focolaio trattato"
  },
  {
    "code" : "92.27.5",
    "display" : "BETATERAPIA DI CONTATTO. Per seduta e per focolaio trattato"
  },
  {
    "code" : "92.28.1",
    "display" : "TERAPIA PER IPERTIROIDISMO con Iodio-131"
  },
  {
    "code" : "92.28.3",
    "display" : "TERAPIA ENDOARTICOLARE (RADIOSINOVIORTESI) DI AFFEZIONI NON NEOPLASTICHE"
  },
  {
    "code" : "92.28.4",
    "display" : "TERAPIA CON ANTICORPI MONOCLONALI"
  },
  {
    "code" : "92.28.6",
    "display" : "TERAPIA DELLE METASTASI SCHELETRICHE"
  },
  {
    "code" : "92.28.7",
    "display" : "TERAPIA ENDOCAVITARIA DI AFFEZIONI NEOPLASTICHE"
  },
  {
    "code" : "92.28.9",
    "display" : "STUDIO FISICO-DOSIMETRICO CON ELABORATORE PER CALCOLO PER IMRT E STEREOTASSI. DOSE DA SOMMINISTRARE"
  },
  {
    "code" : "92.29.1",
    "display" : "INDIVIDUAZIONE DEL VOLUME BERSAGLIO E ORGANI CRITICI. Con simulatore radiologico"
  },
  {
    "code" : "92.29.2",
    "display" : "INDIVIDUAZIONE DEL VOLUME BERSAGLIO E ORGANI CRITICI. Con TC simulatore o TC"
  },
  {
    "code" : "92.29.3",
    "display" : "INDIVIDUAZIONE DEL VOLUME BERSAGLIO E ORGANI CRITICI. Con RM DI SIMULAZIONE. Non associabile a 92.29.A"
  },
  {
    "code" : "92.29.4",
    "display" : "STUDIO FISICO-DOSIMETRICO. Calcolo della dose in punti"
  },
  {
    "code" : "92.29.5",
    "display" : "STUDIO FISICO-DOSIMETRICO CON ELABORATORE SU SCANSIONI TC"
  },
  {
    "code" : "92.29.6",
    "display" : "DOSIMETRIA IN VIVO"
  },
  {
    "code" : "92.29.8",
    "display" : "SISTEMA DI IMMOBILIZZAZIONE PERSONALIZZATO. Intero trattamento"
  },
  {
    "code" : "92.29.9",
    "display" : "PREPARAZIONE COMPENSATORI/MODIFICATORI DEL FASCIO. Intero trattamento"
  },
  {
    "code" : "92.29.A",
    "display" : "INDIVIDUAZIONE DEL VOLUME BERSAGLIO E SIMULAZIONE CON PET-TC. Individuazione del volume bersaglio attraverso l'utilizzazione di PET TC. Non associabile a 92.29.3"
  },
  {
    "code" : "92.29.G",
    "display" : "CONTROLLO DEL SET-UP INIZIALE PER I^ SEDUTA, CONTROLLO PORTALE E/O DELLA RIPETIBILITÀ DEL SET UP DEL PAZIENTE. Per singola seduta"
  },
  {
    "code" : "92.29.H",
    "display" : "GESTIONE DEL MOVIMENTO RESPIRATORIO ASSOCIATO A TRATTAMENTO RADIOTERAPICO. Per seduta o focolaio trattato"
  },
  {
    "code" : "92.29.L",
    "display" : "CONTROLLO DEL POSIZIONAMENTO MEDIANTE TC (IGRT) IN CORSO DI TRATTAMENTO RADIOTERAPICO. Per seduta"
  },
  {
    "code" : "92.29.Q",
    "display" : "DELINEAZIONE DEL VOLUME BERSAGLIO E ORGANI CRITICI SU IMMAGINI TC. Senza e con mezzo di contrasto"
  },
  {
    "code" : "92.29.R",
    "display" : "DELINEAZIONE DEL VOLUME BERSAGLIO E ORGANI CRITICI CON FUSIONE DI IMMAGINI RM, PET, ALTRO. Senza e con mezzo di contrasto"
  },
  {
    "code" : "92.29.S",
    "display" : "INDIVIDUAZIONE DEL VOLUME BERSAGLIO in 4D"
  },
  {
    "code" : "92.29.T",
    "display" : "INSERIMENTO DI REPERI FIDUCIALI. Intero trattamento"
  },
  {
    "code" : "92.29.U",
    "display" : "ADROTERAPIA - Ciclo intero."
  },
  {
    "code" : "92.29.V",
    "display" : "ADROTERAPIA - Boost (sino a 6 frazioni)."
  },
  {
    "code" : "92.29.W",
    "display" : "ADROTERAPIA - Stereotassi (1-3 frazioni)."
  },
  {
    "code" : "92.47.8",
    "display" : "TELETERAPIA PER TECNICHE CON MODULAZIONE DI INTENSITA’ (IMRT) AD ARCHI MULTIPLI O DI TIPO ELICALE E CON CONTROLLO DEL POSIZIONAMENTO MEDIANTE TC/RM/US (IGRT). Inclusa TOMOTERAPIA. Per seduta. Ciclo breve: fino a 5 sedute"
  },
  {
    "code" : "92.47.9",
    "display" : "TELETERAPIA PER TECNICHE CON MODULAZIONE DI INTENSITA’ (IMRT) AD ARCHI MULTIPLI O DI TIPO ELICALE E CON CONTROLLO DEL POSIZIONAMENTO MEDIANTE TC/RM/US (IGRT). Inclusa TOMOTERAPIA. Per seduta. Ciclo lungo: superiore a 5 sedute"
  },
  {
    "code" : "93.01.1",
    "display" : "VALUTAZIONE FUNZIONALE GLOBALE Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF [Valutazione di 3 o più delle funzioni di seguito elencate: funzioni mentali globali, mentali specifiche, funzioni sensoriali e dolore, voce ed eloquio (compresa disartria), viscerali (compresa disfagia), genito urinarie, neuromuscolo scheletriche correlate al movimento]. Non associabile a PRIMA VISITA (89.7B.2). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.3",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLE FUNZIONI MENTALI GLOBALI Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b110-b139). Non associabile a: PRIMA VISITA (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1), SOMMINISTRAZIONE DI TEST DI DETERIORAMENTO O SVILUPPO INTELLETTIVO M.D.B., MODA, WAIS, STANFORD BINET (94.01.2). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.4",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLE FUNZIONI MENTALI SPECIFICHE Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b140-b189). Non associabile a: PRIMA VISITA (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.5",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLE FUNZIONI VESTIBOLARI - EQUILIBRIO. Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b235). Non associabile a: PRIMA VISITA  (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.6",
    "display" : "VALUTAZIONE MONOFUNZIONALE DEL DOLORE Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b280- b289). Non associabile a: PRIMA VISITA (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1)"
  },
  {
    "code" : "93.01.7",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLA VOCE E DELL' ELOQUIO [AFASIA - DISARTRIA] Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b310-b399). Non associabile a PRIMA VISITA (89.7B.2). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.8",
    "display" : "VALUTAZIONE MONOFUNZIONALE DEL SISTEMA CARDIOVASCOLARE E DELL'APPARATO RESPIRATORIO Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b410-b429 e b440- b449). Non associabile a PRIMA VISITA (89.7B.2)"
  },
  {
    "code" : "93.01.9",
    "display" : "VALUTAZIONE MONOFUNZIONALE DEL APPARATO DIGERENTE [DISFAGIA - TURBE DELLA DEFECAZIONE] Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b510 e b525). Non associabile a PRIMA VISITA (89.7B.2)"
  },
  {
    "code" : "93.01.A",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLE FUNZIONI GENITO URINARIE [TURBE VESCICO MINZIONALI - PERINEALI] Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b610-b639). Non associabile a: PRIMA VISITA (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.B",
    "display" : "VALUTAZIONE MONOFUNZIONALE DELLE FUNZIONI DELLE ARTICOLAZIONI E DELLE OSSA Con l'utilizzo strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b710-b729). Non associabile a: PRIMA VISITA (89.7B.2), VALUTAZIONE FUNZIONALE GLOBALE (93.01.1). Non ripetibile entro un mese"
  },
  {
    "code" : "93.01.C",
    "display" : "VALUTAZIONdi E MONOFUNZIONALE DELLE FUNZIONI MUSCOLARI [FORZA - TONO - RESISTENZA] Con l'utilizzo strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b730-b749). Non associabile a: PRIMA VISITA (89.7B.2) e VALUTAZIONE FUNZIONALE GLOBALE (93.01.1)"
  },
  {
    "code" : "93.01.D",
    "display" : "VALUTAZIONE MONOFUNZIONALE DEL MOVIMENTO Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione. Valutazione delle funzioni corporee secondo ICF (b750- b789). Non associabile a: PRIMA VISITA (89.7B.2) e VALUTAZIONE FUNZIONALE GLOBALE (93.01.1)"
  },
  {
    "code" : "93.02",
    "display" : "VALUTAZIONE ORTOTTICA CON STUDIO COMPLETO DELLA MOTILITA' OCULARE"
  },
  {
    "code" : "93.03",
    "display" : "VALUTAZIONE PROTESICA. Finalizzata al collaudo"
  },
  {
    "code" : "93.03.1",
    "display" : "VALUTAZIONE PROTESICA. Finalizzata alla prescrizione di presidi protesici"
  },
  {
    "code" : "93.03.2",
    "display" : "VALUTAZIONE ORTESICA. Finalizzata al collaudo"
  },
  {
    "code" : "93.03.3",
    "display" : "VALUTAZIONE ORTESICA. Finalizzata alla prescrizione di ortesi e di ausili tecnologici"
  },
  {
    "code" : "93.05.3",
    "display" : "ANALISI DINAMOMETRICA ISOCINETICA SEGMENTALE. Non associabile a ANALISI DELLA CINEMATICA E DELLA DINAMICA DEL PASSO (93.05.7) e GAIT ANALYSIS (93.05.8)"
  },
  {
    "code" : "93.05.4",
    "display" : "TEST POSTUROGRAFICO Eseguito con apposito strumentario e refertato. Non associabile a 93.05.5"
  },
  {
    "code" : "93.05.5",
    "display" : "TEST STABILOMETRICO STATICO E/O DINAMICO SU PEDANA Eseguito con apposito strumentario. Non associabile a 93.05.4., 93.05.7, 93.05.8"
  },
  {
    "code" : "93.05.6",
    "display" : "ANALISI DELLA CINEMATICA DELL'ARTO SUPERIORE. Valutazione della cinematica di una o più articolazioni dell'arto superiore inclusa la misurazione di parametri della velocità e linearità del movimento durante l'esecuzione di movimenti standardizzati"
  },
  {
    "code" : "93.05.7",
    "display" : "ANALISI DELLA CINEMATICA E DELLA DINAMICA DEL PASSO. Valutazione quantitativa e qualitativa dei parametri spazio-temporali del passo, della cinematica e della dinamica del cammino con l'utilizzo di sistemi optoelettrici e pedane dinamometriche. Non associabile GAIT ANALYSIS (93.05.8)"
  },
  {
    "code" : "93.05.8",
    "display" : "GAIT ANALYSIS Valutazione clinica della menomazione degli arti inferiori, EMG dinamica del cammino, valutazione dei parametri spazio- temporali del passo, della cinematica e della dinamica del cammino con l'utilizzo di sistemi optoelettronici e pedane dinamometriche. Non associabile a ANALISI DELLA CINEMATICA E DELLA DINAMICA DEL PASSO (93.05.7); VALUTAZIONE EMG DINAMICA DEL CAMMINO (93.08.E); EMG DINAMICA DELL'ARTO SUPERIORE (93.08.F). Non ripetibile entro 12 mesi eccetto dopo intervento chirurgico"
  },
  {
    "code" : "93.07.1",
    "display" : "BIOIMPEDENZIOMETRIA, VALUTAZIONE DELLO STATO DI IDRATAZIONE"
  },
  {
    "code" : "93.07.2",
    "display" : "PLICOMETRIA, VALUTAZIONE DELLO STATO NUTRIZIONALE"
  },
  {
    "code" : "93.08.2",
    "display" : "ELETTROMIOGRAFIA DI UNA SINGOLA FIBRA. Non associabile a 93.08.A e 93.08.B. Prescrivibile una sola volta sulla ricetta"
  },
  {
    "code" : "93.08.3",
    "display" : "ELETTROMIOGRAFIA DI UNITA' MOTORIA Analisi quantitativa. Con esame ad ago"
  },
  {
    "code" : "93.08.4",
    "display" : "ELETTROMIOGRAFIA DI MUSCOLI SPECIALI [Laringei, faringei, diaframma, perineali]. Escluso: EMG dell' occhio (95.25)"
  },
  {
    "code" : "93.08.5",
    "display" : "RISPOSTE RIFLESSE. H, F, Blink reflex, Riflesso bulbocavernoso, Riflessi esterocettivi agli arti"
  },
  {
    "code" : "93.08.6",
    "display" : "STIMOLAZIONE RIPETITIVA. Stimolazione ripetitiva per nervo e frequenza di stimolo"
  },
  {
    "code" : "93.08.7",
    "display" : "TEST PER TETANIA LATENTE"
  },
  {
    "code" : "93.08.8",
    "display" : "TEST DI ISCHEMIA PROLUNGATA"
  },
  {
    "code" : "93.08.A",
    "display" : "ELETTROMIOGRAFIA SEMPLICE [EMG] PER ARTO SUPERIORE. Analisi qualitativa fino a 6 muscoli. Incluse tutte le fibre indagabili. Non associabile a 93.09.1 e 93.09.2. Non associabile a 93.08.2"
  },
  {
    "code" : "93.08.B",
    "display" : "ELETTROMIOGRAFIA SEMPLICE [EMG] PER ARTO INFERIORE fino a 4 muscoli. Incluse tutte le fibre indagabili. Analisi qualitativa. Non associabile a 93.09.1 e 93.09.2. Non associabile a 93.08.2"
  },
  {
    "code" : "93.08.C",
    "display" : "ELETTROMIOGRAFIA SEMPLICE [EMG] DEL CAPO fino a 4 muscoli. Analisi qualitativa. Incluse tutte le fibre indagabili. Escluso: EMG dell' occhio (95.25) e POLISONNOGRAFIA (89.17)."
  },
  {
    "code" : "93.08.D",
    "display" : "ELETTROMIOGRAFIA SEMPLICE [EMG] DEL TRONCO. Analisi qualitativa. Fino a 4 muscoli. Incluse tutte le fibre indagabili."
  },
  {
    "code" : "93.08.E",
    "display" : "VALUTAZIONE EMG DINAMICA DEL CAMMINO. Valutazione EMG di superficie o con elettrodi a filo (4 muscoli), associato ad esame basografico per la definizione delle fasi del passo. Non associabile a ANALISI DELLA CINEMATICA E DELLA DINAMICA DEL PASSO (93.05.7)"
  },
  {
    "code" : "93.08.F",
    "display" : "EMG DINAMICA DELL'ARTO SUPERIORE. Valutazione EMG di superficie o con elettrodi a filo (4 muscoli)"
  },
  {
    "code" : "93.09.1",
    "display" : "VELOCITA' DI CONDUZIONE NERVOSA MOTORIA. Per nervo principale. Fino a 6 segmenti"
  },
  {
    "code" : "93.09.2",
    "display" : "VELOCITA' DI CONDUZIONE NERVOSA SENSITIVA. Per nervo principale. Fino a 4 segmenti"
  },
  {
    "code" : "93.09.3",
    "display" : "VALUTAZIONE GLOBALE DEL LIVELLO DI AUTONOMIA (ADL primarie o di base e ADL secondarie e/o IADL). Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione secondo attività e partecipazione ICF. Non associabile a PRIMA VISITA (89.7B.2); VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLA CURA DELLA PROPRIA PERSONA (93.09.5); VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLE ATTIVITA' DI VITA DOMESTICA E AREE DI VITA PRINCIPALE (93.09.4)"
  },
  {
    "code" : "93.09.4",
    "display" : "VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLE ATTIVITA' DI VITA DOMESTICA E AREE DI VITA PRINCIPALE (ADL secondarie e/o IADL). Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione secondo attività e partecipazione ICF (d510- d699). Non associabile a: PRIMA VISITA (89.7B.2); VALUTAZIONE GLOBALE DEL LIVELLO DI AUTONOMIA (93.09.3); VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLA CURA DELLA PROPRIA PERSONA (93.09.5)"
  },
  {
    "code" : "93.09.5",
    "display" : "VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLA CURA DELLA PROPRIA PERSONA (ADL primarie o di base). Con l'utilizzo di strumenti di misura validati e/o condivisi a livello scientifico e relativa refertazione secondo attività e partecipazione ICF (d510-d599 e d350- d499). Non associabile a PRIMA VISITA (89.7B.2); VALUTAZIONE GLOBALE DEL LIVELLO DI AUTONOMIA (93.09.3); VALUTAZIONE DEL LIVELLO DI AUTONOMIA NELLE ATTIVITA' DI VITA DOMESTICA E AREE DI VITA PRINCIPALE (93.09.4). Non ripetibile entro un mese"
  },
  {
    "code" : "93.11.1",
    "display" : "RIEDUCAZIONE MOTORIA INDIVIDUALE relativa alle “funzioni delle articolazioni, delle ossa e del movimento” secondo ICF dell’OMS e caratterizzata prevalentemente dall’esercizio terapeutico motorio, indipendentemente dalla tecnica utilizzata, dal mezzo in cui viene realizzato e dalle protesi, ortesi ed ausili utilizzati e dalle attività terapeutiche manuali. Per seduta di trattamento di 30 minuti. Ciclo massimo di 10 sedute"
  },
  {
    "code" : "93.11.2",
    "display" : "RIEDUCAZIONE MOTORIA INDIVIDUALE IN DISABILITA' COMPLESSE CON USO DI TERAPIE FISICHE STRUMENTALI DI SUPPORTO relativa alle “funzioni delle articolazioni, delle ossa e del movimento” secondo ICF dell’OMS e caratterizzata prevalentemente dall’esercizio terapeutico motorio, indipendentemente dalla tecnica utilizzata, dal mezzo in cui viene realizzato e dalle protesi, ortesi ed ausili utilizzati e dalle attività terapeutiche manuali. Per seduta di trattamento di 60 minuti con almeno 40 minuti di esercizio terapeutico. Ciclo massimo di 10 sedute"
  },
  {
    "code" : "93.11.5",
    "display" : "RIEDUCAZIONE MOTORIA IN GRUPPO relativa alle funzioni delle articolazioni, delle ossa, del movimento, secondo ICF. Per seduta di 60 minuti e massimo 6 pazienti per gruppi omogenei di patologia. Ciclo di 10 sedute"
  },
  {
    "code" : "93.11.6",
    "display" : "RIEDUCAZIONE INDIVIDUALE DEL LINGUAGGIO relativa alle “funzioni della voce e dell’eloquio” secondo ICF dell’OMS. Per seduta della durata di almeno 30 minuti e caratterizzata prevalentemente dall’esercizio terapeutico logopedico. Compreso il trattamento delle disartrie. Le attività terapeutiche possono essere effettuate con varie tipologie di ausili manuali e/o elettronici. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.7",
    "display" : "ADDESTRAMENTO ALLA RESPIRAZIONE DIAFRAMMATICA, ESERCIZI CALISTENICI Per seduta individuale. Ciclo di 5 sedute"
  },
  {
    "code" : "93.11.8",
    "display" : "RIEDUCAZIONE DELLA DISFAGIA relativa alle “funzioni dell’apparato digerente” secondo ICF dell’OMS. Per seduta della durata di 30 minuti. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.9",
    "display" : "RIEDUCAZIONE DEL PAVIMENTO PELVICO relativa alle “funzioni genito- urinarie”, incontinenza urinaria, secondo ICF dell’OMS. Per seduta della durata di 30 minuti. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.A",
    "display" : "RIEDUCAZIONE INDIVIDUALE DELLE FUNZIONI MENTALI GLOBALI secondo l'ICF. Per seduta della durata di 30 min. e caratterizzata prevalentemente dall'esercizio terapeutico cognitivo e logopedico. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.B",
    "display" : "RIEDUCAZIONE INDIVIDUALE DELLE FUNZIONI MENTALI SPECIFICHE secondo l'ICF. Per seduta della durata di 30 min. e caratterizzata prevalentemente dall'esercizio terapeutico cognitivo. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.C",
    "display" : "RIEDUCAZIONE IN GRUPPO DELLE FUNZIONI MENTALI GLOBALI secondo l'ICF. Per seduta della durata di 60 min. e caratterizzata prevalentemente dall'esercizio terapeutico cognitivo e logopedico. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.D",
    "display" : "RIEDUCAZIONE DI GRUPPO DEL LINGUAGGIO relativa alle “funzioni della voce e dell’eloquio” secondo ICF dell’OMS della durata di 60 minuti e caratterizzata prevalentemente dall’esercizio terapeutico logopedico. Compreso il trattamento dell disartrie. Le attività terapeutiche possono essere effettuate con varie tipologie di ausili manuali ed/od elettronici. Per seduta. Ciclo fino a 5 sedute"
  },
  {
    "code" : "93.11.E",
    "display" : "RIEDUCAZIONE INDIVIDUALE ALL'AUTONOMIA NELLE ATTIVITA' DELLA VITA QUOTIDIANA Relative a mobilità, alla cura della propria persona, alla vita domestica secondo ICF. Incluso: ergonomia articolare ed eventuale addestramento del Care Giver. Per seduta della durata di 30 min. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.F",
    "display" : "RIEDUCAZIONE IN GRUPPO ALL'AUTONOMIA NELLE ATTIVITA' DELLA VITA QUOTIDIANA Relative a mobilità, alla cura della propria persona, alla vita domestica secondo ICF. Incluso: ergonomia articolare. Per seduta della durata di 60 min. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.11.G",
    "display" : "RIEDUCAZIONE MOTORIA MEDIANTE APPARECCHI DI ASSISTENZA ROBOTIZZATI AD ALTA TECNOLOGIA. Rieducazione motoria di gravi patologie secondarie a lesioni del SNC, con l'esclusione delle patologie neurodegenerative. Per seduta di 45 minuti. Ciclo di 10 sedute."
  },
  {
    "code" : "93.11.H",
    "display" : "RIEDUCAZIONE MOTORIA INDIVIDUALE CON USO DI TERAPIE FISICHE STRUMENTALI DI SUPPORTO relativa alle “funzioni delle articolazioni, delle ossa e del movimento” secondo ICF dell’OMS e caratterizzata dall’esercizio terapeutico motorio, indipendentemente dalla tecnica utilizzata, dal mezzo in cui viene realizzato e dalle protesi, ortesi ed ausili utilizzati e dalle attività terapeutiche manuali. Per seduta di trattamento di 45 minuti con almeno 30 minuti di esercizio terapeutico. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.15",
    "display" : "MANIPOLAZIONE DELLA COLONNA VERTEBRALE. Per seduta. Ciclo fino a 4 sedute"
  },
  {
    "code" : "93.16",
    "display" : "MOBILIZZAZIONE DI ALTRE ARTICOLAZIONI Manipolazione incruenta di rigidità di piccole articolazioni. Escluso: Manipolazione di articolazione temporo-mandibolare"
  },
  {
    "code" : "93.18.1",
    "display" : "RIEDUCAZIONE MOTORIA CARDIO-RESPIRATORIA INDIVIDUALE relativa alle “funzioni dell'apparato cardiovascolare, ematologico, immunologico e respiratorio secondo ICF dell’OMS. Per seduta di 30 minuti caratterizzata prevalentemente dall’esercizio terapeutico motorio, indipendentemente dalla tecnica utilizzata, dal mezzo in cui viene realizzato e dalle ortesi ed ausili utilizzati. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.18.2",
    "display" : "RIEDUCAZIONE MOTORIA CARDIO-RESPIRATORIA DI GRUPPO relativa alle “funzioni dell'apparato cardiovascolare, ematologico, immunologico e respiratorio secondo ICF dell’OMS. Per seduta di 60 minuti caratterizzata prevalentemente dall’esercizio terapeutico motorio, indipendentemente dalla tecnica utilizzata, dal mezzo in cui viene realizzato e dalle ortesi ed ausili utilizzati. Max 6 pazienti. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.19.3",
    "display" : "TEST DI VALUTAZIONE DELLA RISPOSTA MOTORIA ALLA LEVODOPA /APOMORFINAIncluso farmaco"
  },
  {
    "code" : "93.22.1",
    "display" : "REALIZZAZIONE E APPLICAZIONE DI ORTESI STATICA e/o dinamica e di cast compreso il materiale di realizzazione"
  },
  {
    "code" : "93.22.2",
    "display" : "REALIZZAZIONE E APPLICAZIONE DI ORTESI DINAMICA"
  },
  {
    "code" : "93.29",
    "display" : "CORREZIONI FORZATE DI DEFORMITA'. Correzione manuale di piede torto congenito"
  },
  {
    "code" : "93.37",
    "display" : "TRAINING PRENATALE. Training psico-fisico per il parto naturale. Per seduta collettiva. Ciclo di 12 sedute"
  },
  {
    "code" : "93.39.2",
    "display" : "MASSOTERAPIA PER DRENAGGIO LINFATICO. Per seduta di 45 minuti ciascuna e per arto. Escluso: linfedema da insufficienza venosa primitiva e linfedema cronico non responsivo"
  },
  {
    "code" : "93.39.6",
    "display" : "ELETTROTERAPIA DI MUSCOLI DENERVATI. Escluso: Viso"
  },
  {
    "code" : "93.46",
    "display" : "TRAZIONI CUTANEE DEGLI ARTI. Trazione con nastro adesivo, a stivale, di Buck, con forcella"
  },
  {
    "code" : "93.51",
    "display" : "APPLICAZIONE DI CORSETTO GESSATO Escluso: Minerva gessata (93.52)"
  },
  {
    "code" : "93.52",
    "display" : "APPLICAZIONE DI MINERVA GESSATA"
  },
  {
    "code" : "93.53",
    "display" : "APPLICAZIONE DI ALTRO CORSETTO GESSATO. Busto gessato"
  },
  {
    "code" : "93.54.1",
    "display" : "BENDAGGIO CON DOCCIA DI IMMOBILIZZAZIONE antibrachio- metacarpale e femoro-podalico"
  },
  {
    "code" : "93.54.2",
    "display" : "BENDAGGIO DESAULT AMIDATO O GESSATO"
  },
  {
    "code" : "93.54.3",
    "display" : "APPARECCHIO GESSATO: toraco brachiale, femoro-podalico"
  },
  {
    "code" : "93.54.4",
    "display" : "APPARECCHIO GESSATO: brachio-antibrachio-metacarpale, tibio- podalico"
  },
  {
    "code" : "93.54.5",
    "display" : "APPARECCHIO GESSATO: antibrachio-metacarpale"
  },
  {
    "code" : "93.54.6",
    "display" : "APPARECCHIO GESSATO: femoro-tibiale"
  },
  {
    "code" : "93.54.8",
    "display" : "APPLICAZIONE DI STECCA DI ZIMMER per dito della mano o del piede"
  },
  {
    "code" : "93.54.9",
    "display" : "COSTRUZIONE DI SPLINT STATICO. Compreso materiale"
  },
  {
    "code" : "93.56.1",
    "display" : "FASCIATURA SEMPLICE"
  },
  {
    "code" : "93.56.2",
    "display" : "BENDAGGIO ALLA COLLA DI ZINCO femoro-podalico"
  },
  {
    "code" : "93.56.3",
    "display" : "BENDAGGIO ALLA COLLA DI ZINCO TIBIO-PODALICO"
  },
  {
    "code" : "93.56.4",
    "display" : "BENDAGGIO ADESIVO ELASTICO per linfedema"
  },
  {
    "code" : "93.56.5",
    "display" : "BENDAGGIO PER CLAVICOLA/SPALLA"
  },
  {
    "code" : "93.78.1",
    "display" : "RIABILITAZIONE DEL CIECO O DELL'IPOVEDENTE GRAVE. Terapia delle attività della vita quotidiana. Per seduta individuale di 30 minuti. Ciclo di 10 sedute"
  },
  {
    "code" : "93.78.3",
    "display" : "RIABILITAZIONE DELLA FUNZIONE VISIVA NEGLI IPOVEDENTI. Per seduta individuale. Ciclo di 10 sedute"
  },
  {
    "code" : "93.82.1",
    "display" : "TERAPIA EDUCAZIONALE DEL DIABETICO E DELL'OBESO Per seduta individuale. Ciclo di 10 sedute"
  },
  {
    "code" : "93.82.2",
    "display" : "TERAPIA EDUCAZIONALE DEL DIABETICO E DELL'OBESO Per seduta collettiva. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.82.3",
    "display" : "TERAPIA EDUCAZIONALE DEL PAZIENTE ASMATICO/ ALLERGICO CON RISCHIO ANAFILATTICO. Seduta individuale"
  },
  {
    "code" : "93.89.1",
    "display" : "TRAINING CONDIZIONAMENTO AUDIOMETRICO INFANTILE. intero training (minimo 3 sedute)"
  },
  {
    "code" : "93.89.2",
    "display" : "TRAINING PER DISTURBI COGNITIVI Riabilitazione funzioni mnesiche, gnosiche e prassiche Per seduta individuale. Ciclo di 10 sedute"
  },
  {
    "code" : "93.89.3",
    "display" : "TRAINING PER DISTURBI COGNITIVI Riabilitazione funzioni mnesiche, gnosiche e prassiche Per seduta collettiva. Ciclo fino a 10 sedute"
  },
  {
    "code" : "93.89.4",
    "display" : "TRAINING PER DISTURBI AUDIOFONOLOGICI"
  },
  {
    "code" : "93.94",
    "display" : "SOMMINISTRAZIONE DI FARMACI (BRONCODILATATORI O ANTIBIOTICI) PER MEZZO DI NEBULIZZATORE Per seduta. Incluso farmaco"
  },
  {
    "code" : "93.95",
    "display" : "OSSIGENAZIONE IPERBARICA. Per seduta"
  },
  {
    "code" : "93.99.1",
    "display" : "BRONCOINSTILLAZIONI. Per seduta"
  },
  {
    "code" : "93.99.2",
    "display" : "ADDESTRAMENTO E ADATTAMENTO ALLA PROTESI VENTILATORIA NON INVASIVA E ALL' EROGATORE DI PRESSIONE POSITIVA [CPAP]. Per seduta individuale"
  },
  {
    "code" : "93.99.3",
    "display" : "DRENAGGIO DELLE SECREZIONI BRONCHIALI Per seduta. Ciclo di 5 sedute"
  },
  {
    "code" : "93.99.4",
    "display" : "MISURA OSSIDO NITRICO ESALATO"
  },
  {
    "code" : "94.01.1",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DI INTELLIGENZA"
  },
  {
    "code" : "94.01.2",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DI DETERIORAMENTO O SVILUPPO INTELLETTIVO, M.D.B., MODA, WAIS, STANFORD BINET, Test di sviluppo psicomotorio"
  },
  {
    "code" : "94.02.1",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DELLA MEMORIA. Memoria implicita, esplicita, a breve e lungo termine, test di attenzione, test di abilità di lettura"
  },
  {
    "code" : "94.02.2",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DELLA SCALA DI MEMORIA DI WECHSLER [WMS]"
  },
  {
    "code" : "94.08.1",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DELLE FUNZIONI ESECUTIVE"
  },
  {
    "code" : "94.08.2",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DELLE ABILITA' VISUO SPAZIALI"
  },
  {
    "code" : "94.08.3",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST PROIETTIVI E DELLA PERSONALITA'"
  },
  {
    "code" : "94.08.4",
    "display" : "ESAME DELL' AFASIA Con batteria standardizzata (Boston A.B., Aachen A.B., ENPA)"
  },
  {
    "code" : "94.08.5",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DI VALUTAZIONE DELLA DISABILITA' SOCIALE"
  },
  {
    "code" : "94.08.6",
    "display" : "SOMMINISTRAZIONE E INTERPRETAZIONE DI TEST DI VALUTAZIONE DEL CARICO FAMILIARE E DELLE STRATEGIE DI COPING"
  },
  {
    "code" : "94.09",
    "display" : "COLLOQUIO PSICOLOGICO CLINICO"
  },
  {
    "code" : "94.12.1",
    "display" : "VISITA PSICHIATRICA DI CONTROLLO"
  },
  {
    "code" : "94.19.1",
    "display" : "PRIMA VISITA PSICHIATRICA"
  },
  {
    "code" : "94.3",
    "display" : "PSICOTERAPIA INDIVIDUALE (per seduta)"
  },
  {
    "code" : "94.42",
    "display" : "PSICOTERAPIA FAMILIARE Per seduta"
  },
  {
    "code" : "94.42.1",
    "display" : "PSICOTERAPIA DI COPPIA Per seduta"
  },
  {
    "code" : "94.44",
    "display" : "PSICOTERAPIA DI GRUPPO. Per seduta e per partecipante (Max 10 partecipanti)"
  },
  {
    "code" : "95.02",
    "display" : "PRIMA VISITA OCULISTICA. Incluso: ESAME DEL VISUS, REFRAZIONE CON EVENTUALE PRESCRIZIONE DI LENTI, TONOMETRIA, BIOMICROSCOPIA, FUNDUS OCULI CON O SENZA MIDRIASI FARMACOLOGICA"
  },
  {
    "code" : "95.03.1",
    "display" : "STUDIO DELLA TOPOGRAFIA CORNEALE"
  },
  {
    "code" : "95.03.2",
    "display" : "PUPILLOMETRIA"
  },
  {
    "code" : "95.03.3",
    "display" : "TOMOGRAFIA RETINICA (OCT) a luce coerente. Non associabile a 95.09.4"
  },
  {
    "code" : "95.05",
    "display" : "STUDIO DEL CAMPO VISIVO. Campimetria, perimetria statica/cinetica, FDT"
  },
  {
    "code" : "95.06",
    "display" : "STUDIO DELLA SENSIBILITA' AL COLORE. Test di acuità visiva e di discriminazione cromatica"
  },
  {
    "code" : "95.07",
    "display" : "STUDIO DELL'ADATTABILITA' AL BUIO"
  },
  {
    "code" : "95.07.1",
    "display" : "STUDIO DELLA SENSIBILITA' AL CONTRASTO"
  },
  {
    "code" : "95.09.2",
    "display" : "ESOFTALMOMETRIA"
  },
  {
    "code" : "95.09.3",
    "display" : "CHERATOESTESIOMETRIA"
  },
  {
    "code" : "95.09.4",
    "display" : "STUDIO STRUMENTALE DELLA CONFORMAZIONE DELLA PAPILLA OTTICA [HRT o GDX o OCT] Non associabile a Tomografia retinica (OCT) 95.03.3"
  },
  {
    "code" : "95.09.5",
    "display" : "ABERROMETRIA OCULARE"
  },
  {
    "code" : "95.11",
    "display" : "FOTOGRAFIA DEL FUNDUS"
  },
  {
    "code" : "95.11.1",
    "display" : "FOTOGRAFIA DEL SEGMENTO ANTERIORE"
  },
  {
    "code" : "95.12",
    "display" : "ANGIOGRAFIA CON FLUORESCEINA"
  },
  {
    "code" : "95.12.1",
    "display" : "ANGIOGRAFIA OCULISTICA CON VERDE INDOCIANINA"
  },
  {
    "code" : "95.13",
    "display" : "ECOGRAFIA OCULARE"
  },
  {
    "code" : "95.13.1",
    "display" : "PACHIMETRIA CORNEALE"
  },
  {
    "code" : "95.13.2",
    "display" : "BIOMICROSCOPIA CORNEALE CON CONTA CELLULE ENDOTELIALI"
  },
  {
    "code" : "95.13.3",
    "display" : "ECOBIOMETRIA, ESAME BIOMETRICO INTERFEROMETRICO"
  },
  {
    "code" : "95.2",
    "display" : "TEST DI HESS - LANCASTER"
  },
  {
    "code" : "95.21",
    "display" : "ELETTRORETINOGRAFIA (ERG, FLASH-PATTERN)"
  },
  {
    "code" : "95.22",
    "display" : "ELETTROOCULOGRAFIA (EOG)"
  },
  {
    "code" : "95.23",
    "display" : "POTENZIALI EVOCATI VISIVI (VEP). Potenziali evocati da pattern o da flash o da pattern ad emicampi"
  },
  {
    "code" : "95.24.1",
    "display" : "STUDIO REGISTRATO DEL NISTAGMO [spontaneo, posizionale, provocato (elettronistagmografia,videoculografia)]"
  },
  {
    "code" : "95.25",
    "display" : "ELETTROMIOGRAFIA DELL'OCCHIO (EMG)"
  },
  {
    "code" : "95.26",
    "display" : "TEST DI PROVOCAZIONE E CURVA TONOMETRICA PER GLAUCOMA"
  },
  {
    "code" : "95.35",
    "display" : "TRAINING ORTOTTICO. Per seduta"
  },
  {
    "code" : "95.41.1",
    "display" : "ESAME AUDIOMETRICO TONALE"
  },
  {
    "code" : "95.41.2",
    "display" : "ESAME AUDIOMETRICO VOCALE"
  },
  {
    "code" : "95.41.4",
    "display" : "ESAME AUDIOMETRICO CONDIZIONATO INFANTILE"
  },
  {
    "code" : "95.42",
    "display" : "IMPEDENZOMETRIA"
  },
  {
    "code" : "95.43",
    "display" : "VISITA AUDIOLOGICA, VISITA FONIATRICA"
  },
  {
    "code" : "95.44.1",
    "display" : "TEST CLINICO DELLA FUNZIONALITA' VESTIBOLARE 'Esame clinico con prove caloriche e rilievo di segni spontanei non assocciabile a STUDIO REGISTRATO DEL NISTAGMO (95.24.1)"
  },
  {
    "code" : "95.45",
    "display" : "STIMOLAZIONI VESTIBOLARI ROTATORIE. Prove rotatorie, Prove pendolari a smorzamento meccanico"
  },
  {
    "code" : "95.46",
    "display" : "ACUFENOMETRIA, PROVE AUDIOMETRICHE SOPRALIMINARI"
  },
  {
    "code" : "95.48.1",
    "display" : "VERIFICA BENEFICIO PROTESICO. Audiometria tonale protesica. Audiometria vocale protesica. Escluso: Impianto di strumenti elettromagnetici per l'udito"
  },
  {
    "code" : "95.48.2",
    "display" : "CONTROLLO PROTESICO ELETTROACUSTICO"
  },
  {
    "code" : "95.48.3",
    "display" : "MISURE PROTESICHE IN SITU"
  },
  {
    "code" : "95.48.4",
    "display" : "TEST DI STIMOLAZIONE ELETTRICA AL PROMONTORIO"
  },
  {
    "code" : "95.49",
    "display" : "ADATTAMENTO IMPIANTI COCLEARI"
  },
  {
    "code" : "96.18",
    "display" : "INSERZIONE/RIMOZIONE DI PESSARIO VAGINALE"
  },
  {
    "code" : "96.22",
    "display" : "DILATAZIONE DELL'ANO- RETTO (senza endoscopia)"
  },
  {
    "code" : "96.26",
    "display" : "RIDUZIONE MANUALE DI PROLASSO RETTALE"
  },
  {
    "code" : "96.27",
    "display" : "RIDUZIONE MANUALE DI ERNIA"
  },
  {
    "code" : "96.38",
    "display" : "RIMOZIONE DI FECALOMA"
  },
  {
    "code" : "96.49",
    "display" : "INSTILLAZIONI ENDOVESCICALI. Incluso farmaco"
  },
  {
    "code" : "96.51",
    "display" : "IRRIGAZIONE O MEDICAZIONE DELL'OCCHIO"
  },
  {
    "code" : "96.52",
    "display" : "RIMOZIONE DI CERUME Non associabile alla visita ORL (89.7B.8)"
  },
  {
    "code" : "96.54.1",
    "display" : "ABLAZIONE TARTARO COMPLETA"
  },
  {
    "code" : "96.54.2",
    "display" : "SIGILLATURA DEI SOLCHI E DELLE FOSSETTE. Per elemento"
  },
  {
    "code" : "96.55",
    "display" : "TOILETTE DI TRACHEOSTOMIA"
  },
  {
    "code" : "96.57",
    "display" : "IRRIGAZIONE DI CATETERE VASCOLARE. Irrigazione o infusione di urokinasi o r-TPA per disostruzione"
  },
  {
    "code" : "96.59",
    "display" : "MEDICAZIONE DI FERITA. Incluso: eventuale anestesia locale per contatto e detersione e rimozione di punti di sutura"
  },
  {
    "code" : "96.59.1",
    "display" : "MEDICAZIONE AVANZATA SEMPLICE di ferita con estensione < 10 cm2 e/o superficiale. Incluso: anestesia locale per contatto e detersione. Fino a sedici medicazioni per ferita"
  },
  {
    "code" : "96.59.2",
    "display" : "MEDICAZIONE AVANZATA COMPLESSA di ferita con estensione 10-25 cm2 e/o profondità limitata al derma. Incluso: anestesia locale per contatto, detersione, sbrigliamento. Fino a 40 medicazioni per ferita"
  },
  {
    "code" : "96.59.3",
    "display" : "MEDICAZIONE AVANZATA COMPLESSA di ferita con estensione 25-80 cm2 e/o interessamento fascia muscolare. Incluso: anestesia locale per contatto, detersione, sbrigliamento. Fino a 60 medicazioni per ferita"
  },
  {
    "code" : "96.59.4",
    "display" : "MEDICAZIONE AVANZATA COMPLESSA di ferita con estensione > 80 cm2 e/o interessamento di muscoli e piani profondi. Incluso: anestesia locale per contatto, detersione, sbrigliamento. Fino a 80 medicazioni per ferita"
  },
  {
    "code" : "96.59.5",
    "display" : "MEDICAZIONE AVANZATA DI FERITA COMPLICATA con involuzione fagedenica, infezione severa con coinvolgimento dei tessuti profondi. Incluso: anestesia per infiltrazione locale, detersione, antisepsi, sbrigliamento, medicazioni. Con documentazione fotografica. Fino a 20 medicazioni per ferita"
  },
  {
    "code" : "96.59.6",
    "display" : "MEDICAZIONE AVANZATA DI FERITA COMPLICATA CON TECNICHE STRUMENTALI. Per lesione che richiede particolare impegno per cronologia e/o infezione tessuti profondi e/o esposizione segmenti ossei e/o tendinei. Incluso: Anestesia tronculare, sedazione farmacologica, detersione, sbrigliamento chirurgico, medicazioni speciali con tecniche strumentali quali: medicazioni cavitarie, vacuum- terapia, toilette chirurgica ad ultrasuoni, sostituti della pelle, prodotti stimolanti neoangiogenesi e rivascolarizzazione periferica (es. prostanoidi, inibitori metalloproteasi). Fino a 20 medicazioni per ferita (Per le vasculiti: 60 medicazioni per ferita)"
  },
  {
    "code" : "96.59.7",
    "display" : "MEDICAZIONE AVANZATA COMPLESSA di ferite croniche e/o coinvolgenti almeno un terzo della superficie cutanea. Incluso: antidolorifico sistemico e/o locale, detersione, sbrigliamento, uso di garze avanzate. Per seduta di almeno 1 ora"
  },
  {
    "code" : "96.6A",
    "display" : "POSIZIONAMENTO DI SONDINO NASO-GASTRICO PER NUTRIZIONE ENTERALE"
  },
  {
    "code" : "97.1",
    "display" : "RIPARAZIONE APPARECCHI GESSATI"
  },
  {
    "code" : "97.23",
    "display" : "SOSTITUZIONE DI CANNULA TRACHEOSTOMICA. Escluso il costo della cannula"
  },
  {
    "code" : "97.35",
    "display" : "RIMOZIONE O CEMENTAZIONE DI PROTESI DENTALE FISSA. Rimozione di corona isolata, rimozione di elemento protesico. Escluso: in corso di trattamento protesico"
  },
  {
    "code" : "97.35.1",
    "display" : "RIMOZIONE DI IMPIANTI OSTEOINTEGRATI CON LEMBO MUCOSO E OSTEOPLASTICA"
  },
  {
    "code" : "97.61",
    "display" : "RIMOZIONE O SOSTITUZIONE DI PIELOSTOMIA PERCUTANEA"
  },
  {
    "code" : "97.82",
    "display" : "RIMOZIONE DI DISPOSITIVO DI DRENAGGIO PERITONEALE"
  },
  {
    "code" : "97.88",
    "display" : "RIMOZIONE DI SUPPORTO, GESSO, STECCA"
  },
  {
    "code" : "98.0",
    "display" : "RIMOZIONE DI CORPO ESTRANEO INTRALUMINALE DAL TUBO DIGERENTE, SENZA INCISIONE"
  },
  {
    "code" : "98.11",
    "display" : "RIMOZIONE DI CORPO ESTRANEO INTRALUMINALE DALL'ORECCHIO, NASO SENZA INCISIONE"
  },
  {
    "code" : "98.13",
    "display" : "RIMOZIONE DI CORPO ESTRANEO INTRALUMINALE DALLA FARINGE LARINGE,SENZA INCISIONE. Incluso: Laringoscopia"
  },
  {
    "code" : "98.18",
    "display" : "RIMOZIONE DI CORPO ESTRANEO INTRALUMINALE DA STOMA ARTIFICIALE, SENZA INCISIONE"
  },
  {
    "code" : "98.20",
    "display" : "RIMOZIONE DI CORPO ESTRANEO SUPERFICIALE SENZA INCISIONE IN QUALSIASI SEDE"
  },
  {
    "code" : "98.21",
    "display" : "RIMOZIONE DI CORPO ESTRANEO SUPERFICIALE DALL'OCCHIO, SENZA INCISIONE"
  },
  {
    "code" : "98.24",
    "display" : "RIMOZIONE DI CORPO ESTRANEO DA SCROTO E PENE, SENZA INCISIONE"
  },
  {
    "code" : "98.51.1",
    "display" : "LITOTRIPSIA EXTRACORPOREA DEL RENE, URETERE CON CATETERISMO URETERALE. Prima seduta. Incluso: Visita anestesiologica, anestesia, esami ematochimici, cistoscopia, Ecografia dell'addome inferiore, Visita urologica di controllo. Non associabile a 98.51.2"
  },
  {
    "code" : "98.51.2",
    "display" : "LITOTRIPSIA EXTRACORPOREA DEL RENE, URETERE CON CATETERISMO URETERALE. Per seduta successiva alla prima. Incluso: Ecografia dell'addome inferiore, Visita urologica di controllo. Non associabile a 98.51.1"
  },
  {
    "code" : "98.51.3",
    "display" : "LITOTRIPSIA EXTRACORPOREA DEL RENE, URETERE E/O VESCICA. Per seduta. Incluso: Ecografia dell'addome inferiore, Visita urologica di controllo"
  },
  {
    "code" : "98.59.4",
    "display" : "TERAPIA CON ONDE D'URTO dell'induratio penis plastica . Per seduta. Fino ad un massimo di 10 sedute"
  },
  {
    "code" : "98.59.5",
    "display" : "TERAPIA CON ONDE D'URTO [FOCALI] MEDIANTE APPARECCHIO DI LITOTRIPSIA per trattamento di fasciti plantari, pseudoartrosi, presenza di calcificazioni delle strutture periarticolari della spalla. Per seduta. Fino ad un massimo di 3 sedute, non ripetibili per la stessa patologia entro 12 mesi"
  },
  {
    "code" : "99.06.1",
    "display" : "INFUSIONE DI FATTORI DELLA COAGULAZIONE"
  },
  {
    "code" : "99.06.A",
    "display" : "INIBITORI DEI FATTORI DELLA COAGULAZIONE"
  },
  {
    "code" : "99.07.1",
    "display" : "TRASFUSIONE DI SANGUE O EMOCOMPONENTI"
  },
  {
    "code" : "99.07.2",
    "display" : "SOMMINISTRAZIONE TERAPEUTICA NON TRASFUSIONALE DI EMOCOMPONENTE. Applicazione su superfice cutanea o mucosa. Escluso: Emocomponente"
  },
  {
    "code" : "99.07.3",
    "display" : "SOMMINISTRAZIONE TERAPEUTICA NON TRASFUSIONALE DI EMOCOMPONENTE. Infiltrazione intratissutale, intraarticolare o in sede chirurgica. Escluso: Emocomponente"
  },
  {
    "code" : "99.12.1",
    "display" : "IMMUNOTERAPIA SPECIFICA PER ALLERGENI INALATORI. Ciclo fino a 12 somministrazioni nel corso di un anno. Escluso: il costo del vaccino"
  },
  {
    "code" : "99.12.2",
    "display" : "IMMUNOTERAPIA SPECIFICA PER VELENO DI IMENOTTERI. Ciclo fino a 12 somministrazioni nel corso di un anno. Escluso: il costo del vaccino"
  },
  {
    "code" : "99.12.3",
    "display" : "SOMMINISTRAZIONE DI FARMACI PER MALATTIE AUTOIMMUNI o IMMUNOMEDIATE. Incluso: per via sottocutanea, intramuscolare, endovenosa. Escluso farmaco"
  },
  {
    "code" : "99.12.4",
    "display" : "DESENSIBILIZZAZIONE PER FARMACI ED ALIMENTI. Per seduta"
  },
  {
    "code" : "99.14.1",
    "display" : "INFUSIONE DI IMMUNOGLOBULINE ENDOVENA"
  },
  {
    "code" : "99.21",
    "display" : "INIEZIONE DI ALTRE SOSTANZE TERAPEUTICHE. Incluso: per via sottocutanea, intramuscolare, endovenosa. Escluso: steroidi, sostanze ormonali, chemioterapici e farmaci biologici. Incluso farmaco"
  },
  {
    "code" : "99.23",
    "display" : "INIEZIONE DI STEROIDI. Iniezione di cortisone. Impianto sottodermico di progesterone. Impianto sottodermico di altri ormoni o antiormoni. Incluso farmaco"
  },
  {
    "code" : "99.24.1",
    "display" : "INFUSIONE DI SOSTANZE ORMONALI. Incluso farmaco"
  },
  {
    "code" : "99.25",
    "display" : "INIEZIONE O INFUSIONE DI ANTITUMORALI. Escluso farmaco"
  },
  {
    "code" : "99.29.5",
    "display" : "INIEZIONE ENDOCAVERNOSA DI FARMACI. Incluso:eventuale training per la somministrazione"
  },
  {
    "code" : "99.29.9",
    "display" : "INIEZIONE DI TOSSINA BOTULINICA"
  },
  {
    "code" : "99.29.A",
    "display" : "SEDAZIONE COSCIENTE. In corso di biopsie e in corso di endoscopie"
  },
  {
    "code" : "99.71",
    "display" : "PLASMAFERESI TERAPEUTICA [PLASMA EXCHANGE]"
  },
  {
    "code" : "99.71.1",
    "display" : "AFERESI SELETTIVA SU PLASMA"
  },
  {
    "code" : "99.71.A",
    "display" : "AFERESI SELETTIVA SU SANGUE INTERO [granulocito-monocito aferesi terapeutica]"
  },
  {
    "code" : "99.71.B",
    "display" : "AFERESI TERAPEUTICA DELLE LIPOPROTEINE"
  },
  {
    "code" : "99.72",
    "display" : "LEUCOAFERESI TERAPEUTICA"
  },
  {
    "code" : "99.73",
    "display" : "ERITROAFERESI TERAPEUTICA [ERITRO EXCHANGE]"
  },
  {
    "code" : "99.74",
    "display" : "PIASTRINOAFERESI TERAPEUTICA"
  },
  {
    "code" : "99.76",
    "display" : "SALASSO TERAPEUTICO"
  },
  {
    "code" : "99.82",
    "display" : "TERAPIA A LUCE ULTRAVIOLETTA. Attinoterapia Fototerapia selettiva UV (UVA, UVB). Per seduta. Ciclo fino a 6 sedute"
  },
  {
    "code" : "99.82.1",
    "display" : "FOTOCHEMIOTERAPIA. Puva terapia. Per seduta. Ciclo fino a 6 sedute"
  },
  {
    "code" : "99.83",
    "display" : "FOTOCHEMIOTERAPIA EXTRACORPOREA [Raccolta, fotoattivazione e reinfusione linfocitaria] Non associabile a 99.72"
  },
  {
    "code" : "99.91",
    "display" : "AGOPUNTURA PER ANALGESIA"
  },
  {
    "code" : "99.92",
    "display" : "ALTRA AGOPUNTURA. Escluso: quella con Moxa revulsivante"
  },
  {
    "code" : "99.97.1",
    "display" : "SPLINTAGGIO PER GRUPPO DI DENTI"
  },
  {
    "code" : "99.97.2",
    "display" : "TRATTAMENTI PER APPLICAZIONE DI PROTESI RIMOVIBILE. Ribasamento con metodo diretto o indiretto, aggiunta di elementi e/o ganci, riparazione di protesi fratturata"
  },
  {
    "code" : "99.97.3",
    "display" : "MANTENITORE DI SPAZIO. Non associabile al codice 99.97.1"
  },
  {
    "code" : "99.99.2",
    "display" : "MONITORAGGIO DINAMICO DELLA GLICEMIA (HOLTER GLICEMICO). Incluso: addestramento del paziente all'uso dell'apparecchio"
  },
  {
    "code" : "G1.01",
    "display" : "Analisi mutazionale di malattia che necessita di un solo gene per la diagnosi.Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.01.D",
    "display" : "Analisi mutazionale di malattia che necessita di un solo gene per la diagnosi. Disomia uniparentale (UPD)"
  },
  {
    "code" : "G1.01.M",
    "display" : "Analisi mutazionale di malattia che necessita di un solo gene per la diagnosi. Analisi di metilazione"
  },
  {
    "code" : "G1.01.T",
    "display" : "Analisi mutazionale di malattia che necessita di un solo gene per la diagnosi. Ricerca espansione triplette"
  },
  {
    "code" : "G1.02",
    "display" : "Analisi mutazionale di malattia che necessita di massimo due geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.03",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 3 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.04",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 4 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.05",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 5 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.06",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 6 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.07",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 7 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.08",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 8 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.09",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 9 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.10",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 10 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.11",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 11 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.12",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 12 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.13",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 13 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.14",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 14 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.15",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 15 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.16",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 16 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.17",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 17 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.18",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 18 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.19",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 19 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.20",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 20 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.21",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 21 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.22",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 22 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.23",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 23 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.24",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 24 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.25",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 25 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.26",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 26 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.27",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 27 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.28",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 28 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.29",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 29 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.30",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 30 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.31",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 31geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.32",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 32 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.33",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 33 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.34",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 34 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.35",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 35 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.36",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 36 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.37",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 37 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.38",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 38 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.39",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 39 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.40",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 40 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.41",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 41 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.42",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 42 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.43",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 43 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.44",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 44 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.45",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 45 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.46",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 46 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.47",
    "display" : "Analisi mutazionale di malattia che necessita di massimo 47 geni per la diagnosi. Sequenziamento ed eventuale metodica quantitativa, qualunque metodo"
  },
  {
    "code" : "G1.91",
    "display" : "Analisi di mutazione nota. Ricerca di mutazione identificata in caso di familiarità. Sequenziamento qualunque metodo"
  },
  {
    "code" : "G1.92",
    "display" : "Analisi di regione cromosomica mediante Southern blot (Blotting)"
  },
  {
    "code" : "G1.93",
    "display" : "Analisi mutazionale di malattia che necessita del Sequenziamento del DNA mitocondriale per la diagnosi"
  },
  {
    "code" : "G1.94",
    "display" : "Analisi di Contaminazione Materna. Zigosità. PCR qualitativa (Real-time PCR)"
  },
  {
    "code" : "G2.01",
    "display" : "ANALISI CITOGENETICA POSTNATALE.Analisi del cariotipo. Incluso: coltura di linfociti con mitogeni, colorazioni differenziali ed eventuale analisi per mosaicismo"
  },
  {
    "code" : "G2.02",
    "display" : "ANALISI CITOGENETICA POSTNATALE. Analisi del cariotipo. Incluso: coltura di materiale biologico con mitogeni, colorazioni differenziali ed eventuale analisi per mosaicismo"
  },
  {
    "code" : "G2.03",
    "display" : "ANALISI CITOGENETICA PRENATALE.Analisi del cariotipo. Incluso: coltura amniociti, colorazioni differenziali"
  },
  {
    "code" : "G2.04",
    "display" : "ANALISI CITOGENETICA PRENATALE.Analisi del cariotipo. Incluso: coltura villi coriali, coltura di villi coriali a breve e a medio termine, colorazioni differenziali."
  },
  {
    "code" : "G2.05",
    "display" : "ANALISI CITOGENETICA PRENATALE. Analisi del cariotipo. Incluso: coltura dei linfociti fetali con mitogeni, colorazioni differenziali ed eventuale studio per mosaicismo"
  },
  {
    "code" : "G2.06",
    "display" : "ANALISI CITOGENETICA PRENATALE.Analisi del cariotipo. Incluso: Coltura di materiale abortivo, colorazioni differenziali ed eventuale studio per mosaicismo"
  },
  {
    "code" : "G2.07",
    "display" : "ANALISI CITOGENETICA PRENATALE.Ricerca aneuploidie dei cromosomi 13, 18, 21, X e Y. Qualunque metodo"
  },
  {
    "code" : "G2.08",
    "display" : "Analisi citogenetica molecolare. Incluso: FISH con sonda di DNA su metafasi/nuclei interfasici/MLPA e coltura del materiale biologico da analizzare"
  },
  {
    "code" : "G2.09",
    "display" : "IBRIDAZIONE GENOMICA COMPARATIVA SU MICROARRAY. Incluso: estrazione DNA, CGH-array, SNPs-array, e coltura del materiale biologico da analizzare"
  },
  {
    "code" : "G2.10",
    "display" : "ANALISI CITOGENETICA PRENATALE.Ricerca aneuploidie dei cromosomi 15, 16, 22. Qualunque metodo"
  },
  {
    "code" : "G3.01",
    "display" : "RICERCA DI MUTAZIONI NOTE/POLIMORFISMI NOTI. Farmacogenetica dei geni del metabolismo dei farmaci: CYP2D6"
  },
  {
    "code" : "G3.02",
    "display" : "RICERCA DI MUTAZIONI NOTE/POLIMORFISMI NOTI. Farmacogenetica dei geni del metabolismo dei farmaci: CYP2C19"
  },
  {
    "code" : "G3.03",
    "display" : "RICERCA DI MUTAZIONI NOTE/POLIMORFISMI NOTI. FARMACOGENETICA IN ONCOLOGIA: UGT1A1"
  },
  {
    "code" : "G9.01",
    "display" : "CONSULENZA GENETICA ASSOCIATA AL TEST. Consulenza Genetica in paziente con ipotesi diagnostica specifica già formulata e con prescrizione di test genetico. Consulenza pre-test: spiegazione dei vantaggi e dei limiti del test genetico e somministrazione dei consensi informati (se non effettuati nell'ambito della visita). Consulenza post- test: spiegazione del risultato del test genetico"
  }]
}

```
