# ServiceRequest Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ServiceRequest Televisita**

## Resource Profile: ServiceRequest Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ServiceRequestTelevisita |

 
Profilo della risorsa ServiceRequest utilizzata per rappresentare la richiesta o prescrizione specialistica associata al servizio di televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [AppointmentTelevisita](StructureDefinition-AppointmentTelevisita.md) and [Encounter Televisita](StructureDefinition-EncounterTelevisita.md)
* Examples for this Profile: [ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-ServiceRequestTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ServiceRequestTelevisita.csv), [Excel](StructureDefinition-ServiceRequestTelevisita.xlsx), [Schematron](StructureDefinition-ServiceRequestTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ServiceRequestTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita",
  "version" : "0.2.0",
  "name" : "ServiceRequestTelevisita",
  "title" : "ServiceRequest Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa ServiceRequest utilizzata per rappresentare la richiesta o prescrizione specialistica associata al servizio di televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "quick",
    "uri" : "http://siframework.org/cqf",
    "name" : "Quality Improvement and Clinical Knowledge (QUICK)"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ServiceRequest",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ServiceRequest",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ServiceRequest.identifier",
      "path" : "ServiceRequest.identifier",
      "short" : "Identificativo della richiesta o prescrizione",
      "definition" : "Identificativo associato alla richiesta o prescrizione della prestazione, ad esempio identificativo aziendale, regionale o numero ricetta medica.",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.requisition",
      "path" : "ServiceRequest.requisition",
      "short" : "Identificativo della richiesta composita",
      "definition" : "Identificativo comune a più richieste generate contestualmente dallo stesso autore. Nei casi di prescrizione può rappresentare l'NRE o il numero di ricetta cartacea."
    },
    {
      "id" : "ServiceRequest.requisition.type",
      "path" : "ServiceRequest.requisition.type",
      "short" : "Tipologia di identificativo",
      "definition" : "Codice che specifica la tipologia dell'identificativo della richiesta composita."
    },
    {
      "id" : "ServiceRequest.requisition.type.coding",
      "path" : "ServiceRequest.requisition.type.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "ServiceRequest.requisition.type.coding:tipoRicetta",
      "path" : "ServiceRequest.requisition.type.coding",
      "sliceName" : "tipoRicetta",
      "short" : "Tipo ricetta",
      "definition" : "Codice che identifica la tipologia di ricetta, ove applicabile.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ServiceRequest.requisition.type.coding:tipoRicetta.code",
      "path" : "ServiceRequest.requisition.type.coding.code",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vs-tipo-ricetta"
      }
    },
    {
      "id" : "ServiceRequest.requisition.system",
      "path" : "ServiceRequest.requisition.system",
      "constraint" : [{
        "key" : "requisition-system",
        "severity" : "error",
        "human" : "Il system deve seguire questa struttura: 'http://www.[nome prodotto o fornitore].it/identifiers/requisition'",
        "expression" : "matches('^http://www\\\\..+\\\\.it/identifiers/requisition$')",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"
      }]
    },
    {
      "id" : "ServiceRequest.status",
      "path" : "ServiceRequest.status",
      "short" : "Stato della richiesta",
      "definition" : "Stato della richiesta o prescrizione di televisita.",
      "comment" : "Nel caso di una richiesta/prescrizione attiva il valore atteso è generalmente 'active'. Gli stati relativi all'esecuzione della prestazione sono rappresentati dalle risorse di evento, quali Appointment, Encounter o Task."
    },
    {
      "id" : "ServiceRequest.intent",
      "path" : "ServiceRequest.intent",
      "short" : "Intento della richiesta",
      "definition" : "Intento della ServiceRequest. Nel caso di prescrizione o richiesta specialistica il valore atteso è generalmente 'order'.",
      "comment" : "L'intento qualifica il significato della richiesta e ne modifica l'interpretazione."
    },
    {
      "id" : "ServiceRequest.category",
      "path" : "ServiceRequest.category",
      "short" : "Classificazione della richiesta",
      "definition" : "Classificazione della prestazione richiesta, ad esempio branca specialistica, ambito clinico o servizio di telemedicina.",
      "min" : 1,
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/specialita-mediche"
      }
    },
    {
      "id" : "ServiceRequest.priority",
      "path" : "ServiceRequest.priority",
      "short" : "Priorità della richiesta",
      "definition" : "Priorità associata alla richiesta o prescrizione della prestazione.",
      "comment" : "Può essere utilizzata per rappresentare la priorità clinico-organizzativa della richiesta, ove disponibile."
    },
    {
      "id" : "ServiceRequest.code",
      "path" : "ServiceRequest.code",
      "short" : "Prestazione richiesta",
      "definition" : "Codice della prestazione richiesta o prescritta. Nel contesto della televisita rappresenta la prestazione specialistica richiesta, eventualmente erogabile in modalità televisita."
    },
    {
      "id" : "ServiceRequest.code.coding",
      "path" : "ServiceRequest.code.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "short" : "Codifica della prestazione richiesta",
      "definition" : "Codice della prestazione secondo il sistema terminologico di riferimento.",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.code.coding:codiceNomenclatoreTariffario",
      "path" : "ServiceRequest.code.coding",
      "sliceName" : "codiceNomenclatoreTariffario",
      "short" : "Codice del nomenclatore tariffario nazionale",
      "definition" : "Codifica della prestazione secondo il catalogo o nomenclatore nazionale delle prestazioni.",
      "min" : 0,
      "max" : "1",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VsCatalogoNazionalePrestazioni"
      }
    },
    {
      "id" : "ServiceRequest.code.coding:codiceNomenclatoreTariffario.system",
      "path" : "ServiceRequest.code.coding.system",
      "short" : "Sistema di codifica nazionale",
      "min" : 1,
      "fixedUri" : "http://hl7.it/fhir/televisita/CodeSystem/CsCatalogoNazionalePrestazioni"
    },
    {
      "id" : "ServiceRequest.code.coding:codiceNomenclatoreTariffario.code",
      "path" : "ServiceRequest.code.coding.code",
      "short" : "Codice nazionale della prestazione",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.code.coding:codiceNomenclatoreTariffario.display",
      "path" : "ServiceRequest.code.coding.display",
      "short" : "Descrizione della prestazione"
    },
    {
      "id" : "ServiceRequest.code.coding:codiceCatalogoRegionalePrestazione",
      "path" : "ServiceRequest.code.coding",
      "sliceName" : "codiceCatalogoRegionalePrestazione",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ServiceRequest.orderDetail",
      "path" : "ServiceRequest.orderDetail",
      "short" : "Dettagli aggiuntivi della richiesta",
      "definition" : "Ulteriori dettagli relativi alla prestazione richiesta, incluse eventuali indicazioni organizzative o cliniche."
    },
    {
      "id" : "ServiceRequest.quantity[x]",
      "path" : "ServiceRequest.quantity[x]",
      "short" : "Quantità della prestazione",
      "definition" : "Quantità o molteplicità della prestazione richiesta."
    },
    {
      "id" : "ServiceRequest.subject",
      "path" : "ServiceRequest.subject",
      "short" : "Assistito",
      "definition" : "Riferimento al paziente/assistito per cui viene richiesta o prescritta la prestazione di televisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "ServiceRequest.encounter",
      "path" : "ServiceRequest.encounter",
      "short" : "Incontro associato alla richiesta",
      "definition" : "Riferimento all'Encounter nel cui contesto è stata generata o documentata la richiesta, ove disponibile."
    },
    {
      "id" : "ServiceRequest.occurrence[x]",
      "path" : "ServiceRequest.occurrence[x]",
      "short" : "Periodo o data di erogazione richiesta",
      "definition" : "Data, periodo o timing entro cui la prestazione dovrebbe essere erogata."
    },
    {
      "id" : "ServiceRequest.authoredOn",
      "path" : "ServiceRequest.authoredOn",
      "short" : "Data della richiesta o prescrizione",
      "definition" : "Data di compilazione o emissione della richiesta/prescrizione della prestazione.",
      "min" : 1
    },
    {
      "id" : "ServiceRequest.requester",
      "path" : "ServiceRequest.requester",
      "short" : "Medico richiedente o prescrittore",
      "definition" : "Professionista sanitario o ruolo professionale che ha richiesto o prescritto la prestazione.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "ServiceRequest.performer",
      "path" : "ServiceRequest.performer",
      "short" : "Erogatore previsto",
      "definition" : "Riferimento al soggetto che dovrebbe erogare la prestazione.",
      "comment" : "Può riferirsi  a un professionista o a un ruolo professionale. Nel contesto della televisita può essere utilizzato per indicare lo specialista responsabile dell'erogazione.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "ServiceRequest.reasonCode",
      "path" : "ServiceRequest.reasonCode",
      "short" : "Quesito diagnostico o motivo della richiesta",
      "definition" : "Motivazione clinica, quesito diagnostico o giustificazione della richiesta della prestazione, in forma codificata o testuale."
    },
    {
      "id" : "ServiceRequest.reasonReference",
      "path" : "ServiceRequest.reasonReference",
      "short" : "Riferimento alla motivazione clinica",
      "definition" : "Riferimento a condizioni cliniche, osservazioni, referti o altri elementi clinici che motivano la richiesta della prestazione."
    },
    {
      "id" : "ServiceRequest.insurance",
      "path" : "ServiceRequest.insurance",
      "short" : "Copertura o esenzione associata",
      "definition" : "Riferimento alla copertura amministrativa o assicurativa associata alla richiesta. Può essere utilizzato per rappresentare eventuali esenzioni."
    },
    {
      "id" : "ServiceRequest.supportingInfo",
      "path" : "ServiceRequest.supportingInfo",
      "short" : "Informazioni cliniche di supporto",
      "definition" : "Informazioni aggiuntive utili alla valutazione o all'esecuzione della prestazione richiesta, come documenti clinici, referti precedenti, osservazioni o altre evidenze disponibili."
    },
    {
      "id" : "ServiceRequest.note",
      "path" : "ServiceRequest.note",
      "short" : "Note sulla richiesta",
      "definition" : "Note o commenti relativi alla richiesta o prescrizione della prestazione.",
      "comment" : "Le note non devono essere utilizzate per veicolare informazioni strutturate che possono essere rappresentate tramite elementi FHIR dedicati."
    }]
  }
}

```
