# Codici Assistenza per Stranieri - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Codici Assistenza per Stranieri**

## CodeSystem: Codici Assistenza per Stranieri (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/cs-tipo-ricetta | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:CsTipoRicetta |

 
Codici identificativi per tipologie di assistenza a stranieri in temporaneo soggiorno, secondo classificazioni italiane ed europee. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VsTipoRicetta](ValueSet-vs-tipo-ricetta.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "cs-tipo-ricetta",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/cs-tipo-ricetta",
  "version" : "0.2.0",
  "name" : "CsTipoRicetta",
  "title" : "Codici Assistenza per Stranieri",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Codici identificativi per tipologie di assistenza a stranieri in temporaneo soggiorno, secondo classificazioni italiane ed europee.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "EE",
    "display" : "Assicurati extra-europei in temporaneo soggiorno"
  },
  {
    "code" : "UE",
    "display" : "Assicurati europei in temporaneo soggiorno"
  },
  {
    "code" : "NA",
    "display" : "Assistiti SASN con visita ambulatoriale"
  },
  {
    "code" : "ND",
    "display" : "Assistiti SASN con visita domiciliare"
  },
  {
    "code" : "NE",
    "display" : "Assistiti da istituzioni europee"
  },
  {
    "code" : "NX",
    "display" : "Assistiti SASN extraeuropei"
  },
  {
    "code" : "ST",
    "display" : "Stranieri in temporaneo soggiorno"
  }]
}

```
