# HL7 Italia - Tipo di Entità - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7 Italia - Tipo di Entità**

## CodeSystem: HL7 Italia - Tipo di Entità 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/it-tipoEntita | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:CSItTipoEntita |

 
Codifica delle diverse entità che hanno compiuto, compiono od intendono compiere un certo atto. Per esempio la certificazione di un record Paziente 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VsTipoCertificatore](ValueSet-tipoCertificatore.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "it-tipoEntita",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/it-tipoEntita",
  "version" : "0.2.0",
  "name" : "CSItTipoEntita",
  "title" : "HL7 Italia - Tipo di Entità",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Codifica delle diverse entità che hanno compiuto, compiono od intendono compiere un certo atto. Per esempio la certificazione di un record Paziente",
  "caseSensitive" : true,
  "hierarchyMeaning" : "is-a",
  "content" : "complete",
  "concept" : [{
    "code" : "gov",
    "display" : "Ministero od Agenzia governativa",
    "definition" : "Ministero od Agenzia governativa",
    "concept" : [{
      "code" : "mef",
      "display" : "Ministero Economia e Finanze",
      "definition" : "Ministero dell'Economia e Finanze",
      "concept" : [{
        "code" : "mef-ae",
        "display" : "Agenzia delle Entrate",
        "definition" : "Agenzia delle Entrate"
      },
      {
        "code" : "mef-ad",
        "display" : "Agenzia del Demanio",
        "definition" : "Agenzia del Demanio"
      },
      {
        "code" : "mef-dm",
        "display" : "Agenzia delle Dogane e dei Monopoli",
        "definition" : "Agenzia delle Dogane e dei Monopoli"
      },
      {
        "code" : "mef-er",
        "display" : "Agenzia delle entrate-Riscossione",
        "definition" : "Agenzia delle entrate-Riscossione"
      }]
    },
    {
      "code" : "minsan",
      "display" : "Ministero della Salute",
      "definition" : "Ministero della Salute"
    }]
  },
  {
    "code" : "regione",
    "display" : "Regione",
    "definition" : "Regione"
  },
  {
    "code" : "comune",
    "display" : "Comune",
    "definition" : "Comune"
  },
  {
    "code" : "as",
    "display" : "Azienda Sanitaria",
    "definition" : "Azienda Sanitaria. In dipendenza dell'organizzazione regionale della sanità la dizione e le finalità dei 'Azienda Sanitaria' può variare; ed includere delle sue specializzazioni e.g. Azienda Sanitaria Locale vs Azienda Ospedaliera; ASST vs ATS eccetera.",
    "concept" : [{
      "code" : "asl",
      "display" : "Azienda Sanitaria Locale",
      "definition" : "Azienda Sanitaria Locale. In dipendenza dell'organizzazione regionale della sanità la dizione per  'Azienda Sanitaria Locale' può variare: e.g. Azienda Sanitaria Locale (ASL); Azienda Unità Locale Socio Sanitaria (ULSS);... Sono identificate dal Ministero della Salute dall'anagrafe delle ASL (FLS 11)."
    },
    {
      "code" : "ric-hsp",
      "display" : "Strutture di Ricovero (HSP)",
      "definition" : "Strutture che erogano assistenza ospedaliera. L’assistenza ospedaliera garantisce il ricovero presso gli ospedali pubblici e privati accreditati per la diagnosi e la cura delle malattie acute o di lunga durata che non possono essere affrontate ambulatorialmente o a domicilio. Sono identificate dal Ministero della Salute dall'anagrafe delle Strutture di Ricovero (HSP 11).",
      "concept" : [{
        "code" : "osp-dir",
        "display" : "Ospedale a gestione diretta",
        "definition" : "Ospedale a gestione diretta. Codice HSP 1"
      },
      {
        "code" : "ao",
        "display" : "Azienda Opedaliera",
        "definition" : "Azienda Opedaliera. In dipendenza dell'organizzazione regionale della sanità la dizione e le finalità dei 'Azienda Opedaliera' può variare."
      },
      {
        "code" : "aou",
        "display" : "Azienda Ospedaliera Universitaria",
        "definition" : "Azienda Ospedaliera integrata con l'Università. Le Azienda Ospedaliera Universitaria si articolano in due tipologie organizzative: a) aziende ospedaliere costituite in seguito alla trasformazione dei policlinici universitari a gestione diretta, denominate aziende ospedaliere universitarie integrate con il Servizio sanitario nazionale; b) aziende ospedaliere costituite mediante trasformazione dei presidi ospedalieri nei quali insiste la prevalenza del corso di laurea in medicina e chirurgia, anche operanti in strutture di pertinenza dell'università, denominate aziende ospedaliere integrate con l'università."
      },
      {
        "code" : "pol-univ",
        "display" : "Policlinico universitario privato",
        "definition" : "Policlinico universitario privato. Codice HSP 2.3"
      },
      {
        "code" : "cc-priv",
        "display" : "Casa di cura privata",
        "definition" : "Casa di cura privata",
        "concept" : [{
          "code" : "cc-priv-a",
          "display" : "Casa di cura privata accreditata",
          "definition" : "Casa di cura privata accreditata. Codice HSP 5.1"
        },
        {
          "code" : "cc-priv-na",
          "display" : "Casa di cura privata non accreditata",
          "definition" : "Casa di cura privata non accreditata.Codice HSP 5.2"
        }]
      },
      {
        "code" : "irccs",
        "display" : "Istituti di Ricovero e Cura a Carattere Scientifico",
        "definition" : "Gli Istituti di Ricovero e Cura a Carattere Scientifico sono ospedali di eccellenza che perseguono finalità di ricerca, prevalentemente clinica e traslazionale, nel campo biomedico ed in quello della organizzazione e gestione dei servizi sanitari ed effettuano prestazioni di ricovero e cura di alta specialità o svolgono altre attività aventi i caratteri di eccellenza",
        "concept" : [{
          "code" : "irccs-pub",
          "display" : "IRCCS pubblico",
          "definition" : "Istituti di Ricovero e Cura a Carattere Scientifico di diritto pubblico. Gli IRCCS pubblici sono  enti pubblici a rilevanza nazionale sottoposti al controllo regionale e alla vigilanza del Ministero della salute."
        },
        {
          "code" : "irccs-priv",
          "display" : "IRCCS privato",
          "definition" : "Istituti di Ricovero e Cura a Carattere Scientifico di diritto privato. Gli IRCCS privati hanno una maggiore libertà di azione ed il controllo su di essi viene effettuato soltanto sulla valenza delle ricerche effettuate."
        },
        {
          "code" : "irccs-fond",
          "display" : "Fondazione IRCCS",
          "definition" : "Istituti di Ricovero e Cura a Carattere Scientifico di diritto pubblico trasformati in fondazione. Gli IRCCS di diritto pubblico, su istanza della Regione in cui l'Istituto ha la sede prevalente di attività clinica e di ricerca, possono essere trasformati in Fondazioni di rilievo nazionale, aperte alla partecipazione di soggetti pubblici e privati e sottoposte alla vigilanza del Ministero della salute e del Ministero dell'economia e delle finanze. Gli enti trasformati assumono la denominazione di Fondazione IRCCS."
        }]
      },
      {
        "code" : "ente-ric-hsp",
        "display" : "Ente di Ricerca",
        "definition" : "Ente di Ricerca. Codice HSP 9"
      }]
    },
    {
      "code" : "dist-san",
      "display" : "Distretto Socio Sanitario",
      "definition" : "Distretto Socio Sanitario. In dipendenza dell'organizzazione regionale della sanità la dizione e le finalità dei 'distretti' può variare"
    }]
  },
  {
    "code" : "self",
    "display" : "Soggetto stesso",
    "definition" : "L'entità che compie l'atto è il soggetto stesso. Per esempio autocertificazione dei dati"
  }]
}

```
