# CodeSystem per specialita PractitionerRole - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CodeSystem per specialita PractitionerRole**

## CodeSystem: CodeSystem per specialita PractitionerRole 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/csspecialityPractitionerRole | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CodeSystem_per_specialita_PractitionerRole |

 
Definisce il sistema di terminologie da usare per i codici delle specialità cliniche e delle discipline ospedaliere. (19A00915) (GU Serie Generale n.38 del 14-02-2019) 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSet_per_specialita_PractitionerRole](ValueSet-vsspecialityPractitionerRole.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "csspecialityPractitionerRole",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/csspecialityPractitionerRole",
  "version" : "0.2.0",
  "name" : "CodeSystem_per_specialita_PractitionerRole",
  "title" : "CodeSystem per specialita PractitionerRole",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definisce il sistema di terminologie da usare per i codici delle specialità cliniche e delle discipline ospedaliere. (19A00915) (GU Serie Generale n.38 del 14-02-2019)",
  "caseSensitive" : true,
  "versionNeeded" : false,
  "content" : "complete",
  "count" : 71,
  "concept" : [{
    "code" : "01",
    "display" : "Allergologia",
    "definition" : "Allergologia"
  },
  {
    "code" : "02",
    "display" : "Day hospital",
    "definition" : "Day hospital - Identifica reparti esclusivamente dedicati ad attività di day hospital multispecialistico"
  },
  {
    "code" : "03",
    "display" : "Anatomia ed istologia patologica",
    "definition" : "Anatomia ed istologia patologica"
  },
  {
    "code" : "05",
    "display" : "Angiologia",
    "definition" : "Angiologia"
  },
  {
    "code" : "06",
    "display" : "Cardiochirurgia pediatrica",
    "definition" : "Cardiochirurgia pediatrica"
  },
  {
    "code" : "07",
    "display" : "Cardiochirurgia",
    "definition" : "Cardiochirurgia"
  },
  {
    "code" : "08",
    "display" : "Cardiologia",
    "definition" : "Cardiologia - Non include i posti letto di unità coronarica, che sono invece attribuiti alla disciplina 50 - 'Unità coronarica' anche se localizzati in un reparto di cardiologia"
  },
  {
    "code" : "09",
    "display" : "Chirurgia generale",
    "definition" : "Chirurgia generale"
  },
  {
    "code" : "10",
    "display" : "Chirurgia maxillo facciale",
    "definition" : "Chirurgia maxillo facciale"
  },
  {
    "code" : "11",
    "display" : "Chirurgia pediatrica",
    "definition" : "Chirurgia pediatrica"
  },
  {
    "code" : "12",
    "display" : "Chirurgia plastica",
    "definition" : "Chirurgia plastica"
  },
  {
    "code" : "13",
    "display" : "Chirurgia toracica",
    "definition" : "Chirurgia toracica"
  },
  {
    "code" : "14",
    "display" : "Chirurgia vascolare",
    "definition" : "Chirurgia vascolare"
  },
  {
    "code" : "15",
    "display" : "Chirurgia sportiva",
    "definition" : "Chirurgia sportiva"
  },
  {
    "code" : "18",
    "display" : "Ematologia",
    "definition" : "Ematologia - Include i posti letto di immunoematologia"
  },
  {
    "code" : "19",
    "display" : "Malattie endocrine, del ricambio e della nutrizione",
    "definition" : "Malattie endocrine, del ricambio e della nutrizione"
  },
  {
    "code" : "20",
    "display" : "Immunologia",
    "definition" : "Immunologia - Non include i posti letto di immunoematologia, che sono invece attribuiti alla disciplina 18 - Ematologia"
  },
  {
    "code" : "21",
    "display" : "Geriatria",
    "definition" : "Geriatria"
  },
  {
    "code" : "24",
    "display" : "Malattie infettive e tropicali",
    "definition" : "Malattie infettive e tropicali"
  },
  {
    "code" : "25",
    "display" : "Medicina del lavoro",
    "definition" : "Medicina del lavoro"
  },
  {
    "code" : "26",
    "display" : "Medicina generale",
    "definition" : "Medicina generale"
  },
  {
    "code" : "27",
    "display" : "Medicina legale",
    "definition" : "Medicina legale"
  },
  {
    "code" : "28",
    "display" : "Unità spinale",
    "definition" : "Unità spinale"
  },
  {
    "code" : "29",
    "display" : "Nefrologia",
    "definition" : "Nefrologia"
  },
  {
    "code" : "30",
    "display" : "Neurochirurgia",
    "definition" : "Neurochirurgia"
  },
  {
    "code" : "31",
    "display" : "Nido",
    "definition" : "Nido"
  },
  {
    "code" : "32",
    "display" : "Neurologia",
    "definition" : "Neurologia - Non include la psichiatria, a cui è attribuito il codice specifico '40', e la neuropsichiatria infantile, a cui è attribuito il codice specifico '33'."
  },
  {
    "code" : "33",
    "display" : "Neuropsichiatria infantile",
    "definition" : "Neuropsichiatria infantile"
  },
  {
    "code" : "34",
    "display" : "Oculistica",
    "definition" : "Oculistica"
  },
  {
    "code" : "35",
    "display" : "Odontoiatria e stomatologia",
    "definition" : "Odontoiatria e stomatologia"
  },
  {
    "code" : "36",
    "display" : "Ortopedia e traumatologia",
    "definition" : "Ortopedia e traumatologia"
  },
  {
    "code" : "37",
    "display" : "Ostetricia e ginecologia",
    "definition" : "Ostetricia e ginecologia"
  },
  {
    "code" : "38",
    "display" : "Otorinolaringoiatra",
    "definition" : "Otorinolaringoiatra"
  },
  {
    "code" : "39",
    "display" : "Pediatria",
    "definition" : "Pediatria - Non include la neonatologia, a cui è attribuito il codice specifico '62'"
  },
  {
    "code" : "40",
    "display" : "Psichiatria",
    "definition" : "Psichiatria - Non include la neuropsichiatria infantile, a cui è attribuito il codice specifico '33'"
  },
  {
    "code" : "41",
    "display" : "Medicina termale",
    "definition" : "Medicina termale"
  },
  {
    "code" : "42",
    "display" : "Tossicologia",
    "definition" : "Tossicologia"
  },
  {
    "code" : "43",
    "display" : "Urologia",
    "definition" : "Urologia"
  },
  {
    "code" : "46",
    "display" : "Grandi ustioni pediatriche",
    "definition" : "Grandi ustioni pediatriche"
  },
  {
    "code" : "47",
    "display" : "Grandi ustioni",
    "definition" : "Grandi ustioni"
  },
  {
    "code" : "48",
    "display" : "Nefrologia",
    "definition" : "Nefrologia"
  },
  {
    "code" : "49",
    "display" : "Terapia intensiva",
    "definition" : "Terapia intensiva - Non include i posti letto di unità intensiva cardiologica, che sono invece attribuiti alla disciplina '50' - Unità coronarica"
  },
  {
    "code" : "50",
    "display" : "Unità coronarica",
    "definition" : "Unità coronarica - Include i posti letto di unità intensiva cardiologica"
  },
  {
    "code" : "51",
    "display" : "Astanteria",
    "definition" : "Astanteria"
  },
  {
    "code" : "52",
    "display" : "Dermatologia",
    "definition" : "Dermatologia"
  },
  {
    "code" : "54",
    "display" : "Emodialisi",
    "definition" : "Emodialisi"
  },
  {
    "code" : "55",
    "display" : "Farmacologia clinica",
    "definition" : "Farmacologia clinica"
  },
  {
    "code" : "56",
    "display" : "Recupero e riabilitazione funzionale",
    "definition" : "Recupero e riabilitazione funzionale - Non include l'unità spinale, a cui è attribuito il codice specifico '28', e la neuro-riabilitazione, a cui è attribuito il codice specifico '75'."
  },
  {
    "code" : "57",
    "display" : "Fisiopatologia della riproduzione umana",
    "definition" : "Fisiopatologia della riproduzione umana"
  },
  {
    "code" : "58",
    "display" : "Gastroenterolgia",
    "definition" : "Gastroenterolgia"
  },
  {
    "code" : "60",
    "display" : "Lungodegenti",
    "definition" : "Lungodegenti"
  },
  {
    "code" : "61",
    "display" : "Medicina nucleare",
    "definition" : "Medicina nucleare"
  },
  {
    "code" : "62",
    "display" : "Neatologia",
    "definition" : "Neatologia"
  },
  {
    "code" : "64",
    "display" : "Oncologia",
    "definition" : "Oncologia"
  },
  {
    "code" : "65",
    "display" : "Oncoematologia pediatrica",
    "definition" : "Oncoematologia pediatrica"
  },
  {
    "code" : "66",
    "display" : "Oncoematologia",
    "definition" : "Oncoematologia"
  },
  {
    "code" : "67",
    "display" : "Pensionati",
    "definition" : "Pensionati"
  },
  {
    "code" : "68",
    "display" : "Pneumologia",
    "definition" : "Pneumologia"
  },
  {
    "code" : "69",
    "display" : "Radiologia",
    "definition" : "Radiologia"
  },
  {
    "code" : "70",
    "display" : "Radioterapia",
    "definition" : "Radioterapia"
  },
  {
    "code" : "71",
    "display" : "Reumatologia",
    "definition" : "Reumatologia"
  },
  {
    "code" : "73",
    "display" : "Terapia intensiva neonatale",
    "definition" : "Terapia intensiva neonatale"
  },
  {
    "code" : "74",
    "display" : "Radioterpia oncologica",
    "definition" : "Radioterpia oncologica"
  },
  {
    "code" : "75",
    "display" : "Neuro-riabilitazione",
    "definition" : "Neuro-riabilitazione"
  },
  {
    "code" : "76",
    "display" : "Neurochirurgia pediatrica",
    "definition" : "Neurochirurgia pediatrica)"
  },
  {
    "code" : "77",
    "display" : "Nefrologia pediatrica",
    "definition" : "Nefrologia pediatrica"
  },
  {
    "code" : "78",
    "display" : "Urologia pediatrica",
    "definition" : "Urologia pediatrica"
  },
  {
    "code" : "96",
    "display" : "Terapia del dolore",
    "definition" : "Terapia del dolore"
  },
  {
    "code" : "97",
    "display" : "Detenuti",
    "definition" : "Detenuti"
  },
  {
    "code" : "98",
    "display" : "Day surgery",
    "definition" : "Day surgery - Identifica reparti esclusivamente dedicati ad attività di day surgery multispecialistico"
  },
  {
    "code" : "99",
    "display" : "Cure palliative - Identifica i reparti utilizzati per i ricoveri in regime diurno per cure palliative, in conformità alle indicazioni contenute nel “Documento sui requisiti minimi e le modalità organizzative necessari per l’accreditamento delle strutture di assistenza ai malati in fase terminale e delle unità di cure palliative e della terapia del dolore” allegato all’Intesa Stato-Regioni del 25 luglio 2012",
    "definition" : "Cure palliative"
  }]
}

```
