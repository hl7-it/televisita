# AllergyIntolerance - Allergie - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **AllergyIntolerance - Allergie**

## AllergyIntolerance - Allergie

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR.

Allegato 1 Telemedicina → Allergie dell'assistito

 Questa pagina illustra come gli elementi informativi relativi alle allergie dell'assistito, previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina", siano rappresentati nel corrispondente profilo FHIR. 

| | | | |
| :--- | :--- | :--- | :--- |
| Allergie | Eventuali allergie e fonti dichiarate | AllergyIntolerance | AllergyIntolerance.note.text |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

