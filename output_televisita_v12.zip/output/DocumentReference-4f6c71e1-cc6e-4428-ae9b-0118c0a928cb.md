# Allegato - TC Torace 10/05/2025 (Maria Rossi) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Allegato - TC Torace 10/05/2025 (Maria Rossi)**

## Example DocumentReference: Allegato - TC Torace 10/05/2025 (Maria Rossi)

**status**: Current

**type**: Addendum Document

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**date**: 2025-06-16 10:00:00+0200

> **content**

### Attachments

| | | | |
| :--- | :--- | :--- | :--- |
| - | **ContentType** | **Data** | **Title** |
| * | application/pdf | (base64 data - 5.976 base64 chars) | TC Torace 10/05/2025 |




## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "4f6c71e1-cc6e-4428-ae9b-0118c0a928cb",
  "status" : "current",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "55107-7",
      "display" : "Addendum Document"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "date" : "2025-06-16T10:00:00+02:00",
  "content" : [{
    "attachment" : {
      "contentType" : "application/pdf",
      "data" : "iVBORw0KGgoAAAANSUhEUgAAAOsAAADWCAMAAAAHMIWUAAAAjVBMVEX///9AQEIhISW/v7+fn6DU1NT09PQoKCoxMTMtLTA2NjmWlpfLy8s9PT/8/Pz5+fljY2RZWVqurq4qKi3a2trq6upDQ0Xi4uKQkJGCgoN7e3ycnJ2BgYJSUlTv7+9ubm92dnfFxcaysrKnp6gdHSFLS02KiothYWO4uLkAAAlUVFYODhMWFhsMDBEAAABGUJqfAAAQsElEQVR4nO1d6ZqiuhZVEBMiQWVwLEdEOVad+/6Pd8kECVpCcEA8tX70120Xslcl2dnZUzqdl2JoebPFZrPdbBYDz3Jf+/JXYrg/GRAhzICQbYySpmV6DvozAHFXBYZgMGxasMejB1D3GhCImhbtwZhO4FWmBHAVNi3eI5EYxdmrzGSwa1rAx6EHbjAlMLymRXwUln4J1W4XfAjZfdmo0pE1mxbzEQiMClRTsp+goPAttZQDx00Lej9m17fVS8Be06Lei7DaDCYA/aaFvRNfVYc1taBmTQt7H/rVhzUd2Hafe6Lqw5qu2Hafes7VlDAD3jQt7j3QmsLpJG5a3nvg2Fpc7aBpge+A1nJt+YI96nFFy6YFvgMLTa7HpgW+AxsdNZxynTct8B3YanJt87jqrtdB0wLfgaWmHm6zdyL53Xt4lWubfWz/JVtiWu5Vk+Gvmxb4DvSruNVytNoe7mitVzxpWtzacMxOZ6x5pnMTq2mx6yD8htA86nBFg8S3f9rodTLT+XsRhCwZWPKI07TgNbDX21sFYBsDAP8lrmY9rnYb57BTk2sbbSdNm0mglbbTUM9mEmin7VQxQKcCn5sWuxY0Qjk5WhrU0Ty8MtjtPMJqOv0Z2hq/0vSsEbTWk1gxU0JGe7Mm5rorFrbYkTjW9K2Nmhb4HhyN6myh0eJRJXB3VcnarfRIKAiquk391qqlDH9c/7i2HdW5TpsW9W78cf3MORxWdcW0PvUyRcVxxbhpQR+ASinwn5IEP6gyiz+lIqlC1gT6EKpVVPEHKGGGCqr4E5QwhVuunfymZXwYSo+wLc4eKCIucyjiU9MiPgyjUq7bpkV8GEodxa1OulRRGtlpaRTnGv5LXEtTptFX0yI+DJNS3TRuWsRHYV1uS4BP6bzQK7f94b5pIR+DdZUzHfyMgV1VCcN+xIrtx9XSJtC49SNr2lWD6xi1M1VCYDrSSegCm/ae2KeLm61Rrgyt8dVOttbml84+t4CMbevyEd0k9uukraVj659bVRk6PfqaGeEKWwhnLYntDPerGpNXBQLj5P2TupzFZaexeoML5m+dQBEukX3vkOZAdrf3pmrZTcYAPWJIc2AETm8Y5gnuUkc36EL7zRRVcr5bHf2OVFG9zeD2l/ApQ5oDQxS9w8kgnBvPG9IcCMyaLnoIFy9hStka8ybZ9l8zpjnbWWMz2XuiQvqFrd2MrbzWTA5+DOxRA5Fap+Y55l7g1xehmXWKNB5D1nhxdeGuMaopDi89FGh0AnwG/Feu2Uou3+fhlWF4T68dyONhv8xAdpummh72XsVVs3vPMwBflOdWs4j3sYCPYDI1vdvYazZRew7QfF8iZ1Jmc3hdoxQ+fAeACoLeujsgjIGx8czPwH5uA/9XEyu0wbbpA/FD0TMOv5yL3M+7QiHwD9dX7RF8TpaRgGNcbUPeNz6huqCIrXEtgr3/uBlMEBjbK59+Ge/lc34Q7Gvm5Ml4BxfswzE2rgT8rn7YfoyuDeEf19bjj6vMdfdj34XvU0BMNPsXs+U63IkPNp3O+vjPfS83ZJuonGvNBmIC9Oof4lbFfnWfX5+Ue0DSEKZyzewv5z25T0UFrne9jaW0swzpyg0yeDbfYX3/61/JlVWMcb8qwlViMM6Yv9Gns760oudtuLKKMZHljyEc3DbJ1l6cpWiyZxet4coaTk0P+dv97mx3/Wg8tHpyTglgCeKnlnDFkLd22UmplxhBgLc9UyHsRPMY2HLyDD9WDieVU3Eb5QonZsBLAQOkuOEwRoZylsJQTRLCBk/7P0aBVjauipdxBb1OB9n8sgn3WAi8q/XLai0LBiOeumUZ6ZlrVzvh5FVcgZPOXbsLRBCikFCh1mvInZgRGAtHWAjprrXu1iT7Iq70phQPym0F1gMpcU9tDjIQn2MIvjILK0wnNi2cDGs63V/DFa/Iw7RDLZCuYHO+bK6B1IMzfQvRWpskF4gG7FnhZOX73vS5FqWo8RZKkDVGhBv5JdZyDGwIF8orhwdkg8lxJ//ggD7MWkJaNaVQuao0zV4URTFK/xTWa02u/LIfdg0HKkQOXcv7KpRXLSJHDRsHMTXE+SWElfur/MJ1mtJaEVrRnr+mP7ERIrtD+gfY3jeuTM26fCuxx3p5HP0vviMb7LmaZwDB1TuQ26EJLQQNNoobeVX4+3u4ipvIRBdIDDbV2a5nIl9KeDS9u9arZLeR9Bk6CEruAx7dNa6iT4QjvhSDU7USo+ArywzzxRysmUHFuaqXbdHe3A/k6n+ZQvlYQGyOqXE0KBvcMIr9TDJDaPBk5mkW+DBwrr1Lruoctr36XEHSiQ2h3cJu/rXIx7Pdb7krrtVbScZ/fnnzEBn9aZ2GzdfmMD8/yfYJ4guuDldgdaYAo4zTQjIFyCY6+Yp2gZzA7waOdzyrxr90KfcJp1ZWv4bxJHRTJJEQ0Ukrs9XwdmfV5eqbdEPEcWaS7Aqmf6oOgdwie/qvfWH85xbIF6R3uNXYdzjXYDfLPoqZyh2OpcxCDP24nhOEqmDS+x2tMrLurLjesNydtUgjN/47rMcttZ49bQXFuG4NKP2qISTW6bag2NG4FleWEkm+C0/yQ2q4VdmqzRUUrtheSVHwDbUzqfVcj+uywICkCbmH4o+CsA5XlpgSQSq15DycbuWDjnoDhdSLAftniel6RX9pbBJo+2Mo1wullgp12dWbnEW0uYoabPYKQ74sMZzZ2VEUKMVFYgdMz/Bb2be6Y6uKBw6106ko1wsCxMQuuuwwrDOH2Qkns5jgSjm8mSOD0VXTkvg5B8SRvCENuQL3ufU0qMW1uDS7h/QdU0PWhRgdnDpcs25TPLEYF/zC/WTrp1pXvakgfbUNTpHqZEy4SoGiTbrmRY2c61oppElpUcNhvVx0J5NJl/5xXk6z37gWsjWaCL8wKvqFA2+uNsmebiKncLq0zvzNtmib4mpvOkwPD6NNTms04OLtZFfIxq3HFWYXEAv3IYaxbrV9sBGmZZ6nstfOVeb7q7zOhXkRKJoYjepwxWCWG71TLHSOPdGpu3BGgik2sufc7V63soARi5T54DMjpZBfSFvsa3LFOOiAPLvG3Yr3lPv8Bfpe7hOGca6ujwdreKpzBWehZpNpxUKHMLrw9LjieJjOGPnOBTN3pyEw9srKWIfmJi8RVtSaCchuppfuybgWpv6Bft1SNUyoL0qPK+xT/6ctudPSjSM/ukCwWlq/Zp4E3kiqhcb2WZoIlsEE0rrnjnFVH+F31QxxNtwYY+aZ1+KKiDonfm0lQyo4S3EKnG4u8TwyA7lS2bEcb3YqnHMU7W2RnZb0xNS6ZIlxDQ4ot52QCHoPB/zKd3w+j5jq1OJKnRF0JfiKubtTozLknGP/SP+fHGDhnINsJS7AKmOoL1enmkKcX7erMf9kMs/mSiS+aCI2Cb1xpd9BV0K+81CYcSEGpVRgFAYr1WORkrLRo1SZVTzXWLGZHzEU8xhnPc6kwqLDtC5XfiUo6qpq1zkpBYbqreLy/6T7k+pQHY6YDICeCXQuWcq45pPGFhNOcq+LW4T157AoZJGP22z0ZlIlu3oRRUYAQ2NbSGvecVORe0pqzOHONHeMYLEhRrkiBk4NrvygJvxWMC660swNN/0LfdXY1YSp8b/yCt6o/pbLiTGd1lqhHcG1LwW7s7UV25BYyiSw0qnBVZxxxJaPja+iIy01/Ym+xcV4TqqfjVN0sf1GYuJjyM79WpGdbA5HB0YLQimv1PT2SQw9L5tHevurqMDdiAmCwPIyMcyKNvBb+WT3fRrsLvfdBGXfgxlVvYhdHs8J9skKensvKfzu74ld2fy7ZplMyF9eMx7Wyq/gqhs1kWzFE/8OLVPiduyKc60fk8xu0NvJtuFRv8PJMEKSrSi03FHP5fTk+Gu29ofb3DZEYKR3qAvmklMcxmKNRZon2CdzxXmqudPNRwHb9qxqkl7Ym/hyqMAT/xH91DrTPYsrRoGfuxw82TGLbDQrL7oOerHcOAcZx0zCwY8zqnOmexZXP3QBijO3sNuz5RWW7mWjSJxzLvVRsF/Yiv2PjHm+0rfQdjRT9p7KlXw57GKposuVdAwBPecsemawk6Z0EOyiI0ktUH9S1mlhjIhHXF+cp3Ellh/JGwByK2yz2IqMnHN82ZiwvmncW/kZW+lyk6SKjvaIr7m/PoPrlJfro4lsHqZqtZiPdSuXi7jEN7Li7m+IFCQmVvWylhdwpXei0wggNo6yteAmI5Wu2gjjKA08Rn4cKdmKzKdGfX165cVPX69Ei9C/Q9V1uPbGEl37l1wu5E+W6mEwWFER8MStKc6TuPIULW4O26vClrpmhj+R3FdjVzRClarpccH33wm5SYK7VG/r3a76XK48zfCLGTjYP10kSFi9E/Dt80g53I7GCID4Mr1gPefudLSigmom6z3ZboLsWZHLgcHoirl0zVEcXu63eacvn2ealN778FKuaMvpTLgRgf1zvX4XQRavRT5f+XtdYZ6ce5mZrwMRSE+3yp52RXiyEgENDDZ8yKe66aZPzzPNOg1NR5m4hf2yDHKPRTgR39fXbjD5/JxakOkjJ/eUpgedebV2S8Gymx9zIMxOOcPSixAa4Iq/c3W0W+WxNWT721KmPeTnwQcoWVd9pBtVfwVX30SSNrI2eUpIhRtjzOx9qfkkGSNT39QvS3o613QKG0B+SZjlvgOx2QQ7x8mDedPE2VninewnSS68kiQCfMfVzlx7NlcydisMR8oXO18+cZRyP3QCfWhDI1vWRwBhVtM4Q6l1aYwS5fkZ6Bp9llL/TlzhjibSIljQRM6s+8NsJY8njQg3XMC2Eh4Bsr7thanaFeEK0gvX+7oJE6/g2lmmUoFF8bundJfNWrShMZ3S2QplJrJ7YVX20o2aHnL677a/MtW5BETvepdfLp/fcKpyJ7mT5vp9bQ4xwNjd8tqZ8M/myhdlQqwmOLk0Dwv38cnq5ko5cEDtEe7m0K5ceboeZlUmnSkpxMB2XMx/uXGl/MWWZNF8GMS/UXsKP58r7vJHl2RoMYRLxet/K36qBLSGe3oLAgZbrqkuku2a59pFItU/ZAlZav7LrX0jLzzr83yYdGIIfZ7UzpV+IlcpDcY6UxMRI9Cd76mCDW5JTHNLOqE5WHFvDURZiN2q0WHzFfV0UhqMww1ijJgxHN2aiKyqZ89zQFNzOFfkQZ3ywVdwxbKHxRkx9zAT/LZnAVBazJempPU5mh6J13FFkSHfqTc9kilJMyRKboBltTOAHnhlu2v/fXM+NMnVthA6y64Icg3JoYLPkwl3Aqigu30Y1Km8egVXv7/C2Fd31ildw8fbw8NMJ1M1pYMJ6gJX/6T+It1EOfmbSy9T2Uz0L12MpNwl3bPrNF94DVeWwA+Wha8urdlFxSdM6o5Iha6jnF7Ctd9hhi6CqvlfmmCH1RZ+zoo5rIywc35TrnbQ2XGFq16gUW76+NKRLktiJIZyrf1Aj+vuX6CPn1QPLQ7iH//Lsu6Cfyo9yn529vNtsM+MSaVHL3HQ69/k9mshfTL/x1rEL4YVHyU/Gq7zj9yKj15AZvfXg+yPa9txleuH9r28Smvxmf1M0bUu6h74kDuTFUyNzZVPw8PVtsQtxxFcrXJbfGAD4uCXBtJ926gX9n9fhOi3y3Yso3LjxnYg8YtFJTkCBOyZaX0Gdr0JONxQt+6gwnUIrcFhW5KEb3m9z0B0kSL2fwvKQYAxIGFOAAAAAElFTkSuQmCC",
      "title" : "TC Torace 10/05/2025"
    }
  }]
}

```
