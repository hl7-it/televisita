# Artifacts Summary - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Profili Core Referto Televisita 

Profili utilizzati nel contesto del Referto di Televisita

| | |
| :--- | :--- |
| [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md) | Bundle FHIR utilizzato per rappresentare il referto di televisita. Contiene la Composition e tutte le risorse cliniche, amministrative e organizzative necessarie alla completa rappresentazione della prestazione erogata in telemedicina. |
| [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) | Bundle FHIR di tipo transaction per il Referto di Televisita. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) utilizzano PUT con URL basato sull'identificatore per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment, DocumentReference) utilizzano POST. |
| [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md) | Profilo della Composition utilizzata nel contesto della Televisita. Rappresenta il documento clinico strutturato prodotto al termine di una sessione di televisita, includendo tutte le sezioni cliniche e amministrative previste dal D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina. |
| [ServiceRequest Televisita](StructureDefinition-ServiceRequestTelevisita.md) | Profilo della risorsa ServiceRequest utilizzata per rappresentare la richiesta o prescrizione specialistica associata al servizio di televisita. |

### Profili Correlati Referto Televisita 

Profili correlati utilizzati a supporto del Referto di Televisita

| | |
| :--- | :--- |
| [Patient Televisita](StructureDefinition-PatientTelevisita.md) | Profilo della risorsa Patient utilizzato per rappresentare l'assistito coinvolto nel servizio di televisita. |
| [Practitioner Televisita](StructureDefinition-PractitionerTelevisita.md) | Profilo della risorsa Practitioner utilizzato per rappresentare il professionista sanitario coinvolto nell'erogazione della televisita, inclusi medico specialista, medico prescrittore e altri operatori sanitari. |
| [PractitionerRoleTelevisita](StructureDefinition-PractitionerRoleTelevisita.md) | Profilo della risorsa PractitionerRole utilizzato per rappresentare il ruolo professionale del medico specialista o di altro operatore sanitario nell'ambito dell'erogazione della televisita. |
| [Encounter Televisita](StructureDefinition-EncounterTelevisita.md) | Profilo della risorsa Encounter utilizzato per rappresentare la visita di telemedicina, incluse informazioni sulla modalità, la disciplina specialistica, i partecipanti e i riferimenti all'appuntamento e alla richiesta di servizio. |
| [AppointmentTelevisita](StructureDefinition-AppointmentTelevisita.md) | Profilo base del Appointment condiviso in tutti i documenti di Telemedicina |
| [AllergyIntolerance Televisita](StructureDefinition-AllergyIntoleranceTelevisita.md) | Profilo della risorsa AllergyIntolerance utilizzato per rappresentare le allergie e le intolleranze dell'assistito rilevate o comunicate nel contesto della televisita. |
| [MedicationRequest Televisita](StructureDefinition-MedicationRequestTelevisita.md) | Profilo della risorsa MedicationRequest utilizzato per rappresentare la terapia farmacologica consigliata al termine della televisita. |
| [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md) | Profilo della risorsa MedicationStatement utilizzato per rappresentare la terapia farmacologica in atto nel paziente al momento della televisita, ovvero farmaci già assunti indipendentemente da una prescrizione corrente. |
| [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md) | Profilo della risorsa Procedure utilizzato per rappresentare le prestazioni e le procedure cliniche erogate nel corso della televisita, inclusi codici, periodi di erogazione, modalità esecutive e strumentazione utilizzata. |
| [Observation Televisita](StructureDefinition-ObservationTelevisita.md) | Profilo della risorsa Observation utilizzato per rappresentare parametri clinici, misurazioni e osservazioni rilevate nel contesto della televisita. |
| [Observation Televisita Narrative](StructureDefinition-ObservationTelevisitaNarrative.md) | Profilo della risorsa Observation utilizzato per rappresentare osservazioni cliniche espresse in forma testuale (narrativa) nel contesto della televisita, come referti di esame obiettivo, descrizioni di sintomi o annotazioni cliniche. |
| [Organization T1 - Azienda Sanitaria](StructureDefinition-OrganizationT1.md) | Profilo della risorsa Organization di tipo 1, utilizzato per rappresentare le aziende sanitarie locali (ASL), aziende ospedaliere (AO) e IRCCS nel contesto della telemedicina. |
| [Organization T2 - Presidio / Ospedale](StructureDefinition-OrganizationT2.md) | Profilo della risorsa Organization di tipo 2, utilizzato per rappresentare i presidi ospedalieri, i distretti sanitari e le strutture di secondo livello nel contesto della telemedicina. |
| [Organization T3 - Unità Operativa / Ambulatorio](StructureDefinition-OrganizationT3.md) | Profilo della risorsa Organization di tipo 3, utilizzato per rappresentare le unità operative, i reparti e gli ambulatori nel contesto della telemedicina. |
| [Address - ITA](StructureDefinition-AddressItTelemedicina.md) | Descrizione di Address con parti addizionali specifiche per gli indirizzi italiani. Questo profilo struttura l'elemento Address.line in più parti, consente la codifica di alcune di queste parti e supporta la caratterizzazine degli indirizzi di tipo Residenza. Questa prima versione è ispirata al data type Address Olandese. |

### Estensioni 

Estensioni FHIR definite nella guida di Televisita

| | |
| :--- | :--- |
| [Certificazione del Record](StructureDefinition-recordCertification.md) | Estensione utilizzata per indicare che un'informazione associata (es. codice fiscale, indirizzo di residenza, dati anagrafici) è stata certificata o autocertificata da una specifica entità (persona od organizzazione). Nel contesto della televisita è impiegata per attestare l'autenticità degli identificativi dell'assistito e degli indirizzi riportati nel referto. |
| [Luogo di Nascita - ITA](StructureDefinition-birth-place-ita.md) | Estensione utilizzata per rappresentare il luogo di nascita dell'assistito secondo il formato italiano, strutturato come un indirizzo conforme al profilo AddressItTelemedicina. Nel contesto della televisita è rilevante per l'identificazione anagrafica dell'assistito. |
| [DUG (Denominazione Urbanistica Generica)](StructureDefinition-address-dug.md) | Denominazione Urbanistica Ufficiale. |
| [IndirizzoUfficiale](StructureDefinition-address-official.md) | Definizione dell'indirizzo inteso come indirizzo 'ufficiale' di quella persona. Il significato di indirizzo 'ufficiale' dipende dal Paese. Questa estensione consente di specificare se questo indirizzo è o non è l'indirizzo ufficiale, oppure di indicare che si tratta dell'indirizzo ufficiale di quel Paese. |

### Value Set 

Value Set definiti nella guida di Televisita

| | |
| :--- | :--- |
| [Tipo Bundle Referto di Televisita](ValueSet-VsBundleTipoTelevisita.md) | Tipi di Bundle ammessi per il Referto di Televisita: document o transaction. |
| [Classe Encounter Televisita](ValueSet-VsClassEncounterTelevisita.md) | ValueSet che limita la classificazione dell'incontro (Encounter.class) ai soli valori ammessi nel contesto della telemedicina: VR (visita virtuale/remota) e HH (assistenza domiciliare). |
| [ValueSet per gli ambiti di telemedicina](ValueSet-vsAmbitoTelemedicina.md) | Contiene la lista di codici da utilizzare per la tipologia di referto |
| [ValueSet per specialita PractitionerRole](ValueSet-vsspecialityPractitionerRole.md) | Contiene la lista di codici da utilizzare per le specialità del PractitionerRole |
| [ValueSet Specialità Mediche](ValueSet-specialita-mediche.md) | Insieme di valori che include tutte le specialità mediche definite nel CodeSystem. |
| [ValueSet for Codesystem catalogo nazionale prestazioni](ValueSet-VsCatalogoNazionalePrestazioni.md) | Includes all codes from Codesystem catalogo nazionale prestazioni |
| [ValueSet per Catalogo Nazionale Prestazioni](ValueSet-ValueSetCatalogoNazionalePrestazioni.md) | Contiene la lista di codici da utilizzare per le prestazioni secondo il catalogo nazionale |
| [Diagnosi ICD-9-CM - Tutti i codici](ValueSet-diagnosi-icd9cm.md) | ValueSet contenente tutti i codici dal CodeSystem ICD-9-CM delle Diagnosi. |
| [ISTAT - DUG](ValueSet-istat-dug.md) | ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG) |
| [Tipo identificatore](ValueSet-VstipoIdentificatore.md) | Value set che descrivie i diversi tipi di identificatori. Include i codici della tabella http://terminology.hl7.org/CodeSystem/v2-0203 piu' 'STP' ed 'ENI' |
| [VS - Tipologia documentale](ValueSet-vsTipologiaDocumentale.md) | Codici LOINC dei documenti |
| [ValueSet_TipologiaPiano](ValueSet-tipologia-piano.md) | ValueSet contenente tutti i codici per definire la tipologia del piano. |
| [Tipologia di attività nel Piano di Telemonitoraggio](ValueSet-TipologiaAttivitaPianoDiTelemonitoraggio.md) | ValueSet contenente la tipologia di attività inserite nel piano di Telemonitoraggio. |
| [ValueSet per Codici Assistenza Stranieri](ValueSet-vs-tipo-ricetta.md) | Contiene tutti i codici dal sistema di classificazione per l’assistenza a stranieri in temporaneo soggiorno. |
| [MDS - ASL](ValueSet-minsan-asl.md) | MDS - ASL |
| [Ministero della Salute - ID Strutture Ricovero](ValueSet-minsan-idStrutture.md) | Ministero della Salute - Identificativi Strutture Ricovero (HSP11) |
| [Ministero della Salute - ID Aziende Ospedaliere](ValueSet-minsan-idAziendeOspedaliere.md) | Ministero della Salute - Aziende Ospedaliere (HSP11) |
| [Ministero della Salute - ID Strutture Interne di Ricovero](ValueSet-minsan-idStruttureInterne.md) | Ministero della Salute - Identificativi Strutture Interne di Ricovero |
| [VS-Anagrafi Regionali](ValueSet-vs-anagrafi-regionali.md) | VS-Anagrafi Regionali |
| [Valueset Ministero della Salute - ID ASL](ValueSet-ValuesetMinisteroSaluteidASL.md) | Ministero della Salute - Identificativi ASL (FLS11) [attivi e ritirati] ereditati da Hl7.it |
| [Tipo certificatore](ValueSet-tipoCertificatore.md) | Tipo di Entità (organizzazione o persona) che ha certificato un certo record |
| [VS - URI Identificativo ENI](ValueSet-vs-uri-id-eni.md) | ValueSet dei sistemi di identificazione (URI) utilizzabili per il codice ENI (Europeo Non Iscritto al SSN). |

### Code System 

Code System definiti nella guida di Televisita

| | |
| :--- | :--- |
| [CodeSystem per gli ambiti della telemedicina](CodeSystem-csAmbitoTelemedicina.md) | Definisce il sistema di terminologie da usare per i codici degli ambiti di telemedicina |
| [CodeSystem per specialita PractitionerRole](CodeSystem-csspecialityPractitionerRole.md) | Definisce il sistema di terminologie da usare per i codici delle specialità cliniche e delle discipline ospedaliere. (19A00915) (GU Serie Generale n.38 del 14-02-2019) |
| [Branca Prestazione](CodeSystem-branca-prestazione.md) | CodeSystem contenente le branche. |
| [Codesystem catalogo nazionale prestazioni](CodeSystem-CsCatalogoNazionalePrestazioni.md) | Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale |
| [Codesystem catalogo nazionale prestazioni](CodeSystem-CodesystemCatalogoNazionalePrestazioni.md) | Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale |
| [Codesystem diagnosi ICD-9-CM](CodeSystem-diagnosi-icd9cm.md) | Definisce il sistema di terminologie da usare per le diagnosi secondo ICD-9-CM. |
| [ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG)](CodeSystem-dug.md) | ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG) |
| [MDS - ID Strutture Interne di Ricovero](CodeSystem-cs-mds-idStruttureInterne.md) | MDS - Identificativi Strutture Interne di Ricovero |
| [Ministero della Salute - ASL](CodeSystem-CodesystemMinisteroSaluteASL.md) | Definisce il sistema di terminologie da usare per il codice ASL ereditato da Hl7.it |
| [CodeSystem per la tipologia del piano](CodeSystem-csTipologiaPiano.md) | Definisce il sistema di terminologie da usare per i codici delle tipologie di piano |
| [Codici Assistenza per Stranieri](CodeSystem-cs-tipo-ricetta.md) | Codici identificativi per tipologie di assistenza a stranieri in temporaneo soggiorno, secondo classificazioni italiane ed europee. |
| [Ministero della Salute - ASL](CodeSystem-cs-asl.md) | Ministero della Salute - ASL |
| [MDS - Strutture di Ricovero](CodeSystem-minsan-hsp.md) | Ministero della Salute - Strutture di Ricovero |
| [HL7 Italia - Tipi di identificatore](CodeSystem-it-identifier-type.md) | Estensione (codici addizionali) alla tabella per i tipi di identificatore |
| [HL7 Italia - Tipo di Entità](CodeSystem-it-tipoEntita.md) | Codifica delle diverse entità che hanno compiuto, compiono od intendono compiere un certo atto. Per esempio la certificazione di un record Paziente |

### Esempi 

Caso d'uso esemplificativo: televisita pneumologica virtuale (classe VR) erogata il 16/06/2025 dalla U.O. Pneumologia dell'Ospedale Sandro Pertini (ASL Roma 1). La paziente Maria Rossi (bronchite cronica nota, non fumatrice) viene visitata dal Dr. Marco Ferrari, Pneumologo, su richiesta del suo Medico di Medicina Generale per follow-up della sintomatologia respiratoria post-COVID. La visita include raccolta anamnestica, esame obiettivo remoto, confronto con TC torace del 10/05/2025, diagnosi ICD-9 491.1 (bronchite cronica mucopurulenta in fase stabile) e proposta terapeutica con Acetilcisteina 600 mg.

| | |
| :--- | :--- |
| [Referto di Televisita Pneumologica - Maria Rossi](Bundle-RefertoDiTelevisita.md) | Bundle di tipo document contenente il referto completo della televisita pneumologica di Maria Rossi del 16/06/2025. Include tutte le risorse cliniche e amministrative: composition, paziente, professionista, encounter, allergie, terapie, osservazioni, prestazioni e allegati. |
| [Referto di Televisita Pneumologica - Maria Rossi (Transaction)](Bundle-RefertoDiTelevisitaTransaction.md) | Bundle di tipo transaction contenente il referto completo della televisita pneumologica di Maria Rossi del 16/06/2025. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) sono inviate con PUT e identifier-based URL per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment) sono inviate con POST. |
| [Referto di Televisita Pneumologica - Maria Rossi](Composition-aa011502-6ad2-430b-a439-01dddc36fd4e.md) | Compositiondel referto clinico della televisita pneumologica di Maria Rossi del 16/06/2025, condotta dal Dr. Marco Ferrari (Pneumologo) presso la U.O. Pneumologia dell'Ospedale Sandro Pertini, ASL Roma 1. Firmata digitalmente dallo stesso specialista. |
| [Paziente - Maria Rossi](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md) | Maria Rossi, paziente di sesso femminile nata il 01/05/1971, residente a Milano (CF: RSSMRA71E41F205E). Affetta da bronchite cronica nota e allergia alla penicillina. Soggetto della televisita pneumologica del 16/06/2025. |
| [Specialista - Dr. Marco Ferrari](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md) | Dr. Marco Ferrari, medico specialista in Pneumologia (CF: FRRMRC75T10H501K). Erogatore della televisita pneumologica del 16/06/2025 presso la U.O. Pneumologia dell'Ospedale Sandro Pertini. |
| [Ruolo - Dr. Marco Ferrari, Pneumologo ASL Roma 1](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md) | Ruolo professionale del Dr. Marco Ferrari come Pneumologo (specialità #38) presso la U.O. Pneumologia dell'Ospedale Sandro Pertini, ASL Roma 1. Autore e firmatario del referto di televisita. |
| [Televisita Pneumologica - Maria Rossi 16/06/2025](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md) | Incontro virtuale (classe VR) di natura pneumologica erogato il 16/06/2025 dalle 09:00 alle 09:45. Basato sulla richiesta del MMG (ServiceRequest AAZ123456789) e prenotato tramite Appointment. Struttura erogatrice: ASL Roma 1. |
| [Appuntamento Televisita Pneumologica - Maria Rossi](Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.md) | Prenotazione della televisita pneumologica per Maria Rossi, schedulata il 16/06/2025 dalle 09:00 alle 09:45, erogata dal Dr. Marco Ferrari. Creata il 02/06/2025 su richiesta del MMG. |
| [Richiesta Televisita Pneumologica - Maria Rossi](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md) | Richiesta di televisita pneumologica (NRE: AAZ123456789) inviata dal Medico di Medicina Generale per Maria Rossi, motivata da follow-up per bronchite cronica (SNOMED 13645005). Redatta il 02/06/2025, con data prevista di erogazione 16/06/2025. |
| [Allergia - Penicillina (Maria Rossi)](AllergyIntolerance-1360bd6a-3855-48d3-aa33-96a9d961bb94.md) | Allergia alla penicillina (SNOMED 91936005) documentata per Maria Rossi, clinicamente attiva e verificata. Rilevata in fase di inquadramento clinico iniziale durante la televisita. |
| [Terapia in atto - Beclometasone 100 mcg (Maria Rossi)](MedicationStatement-e62c9f1d-9c0b-4433-853b-06ec5074f19a.md) | Terapia farmacologica in atto di Maria Rossi al momento della televisita: Beclometasone dipropionato 100 mcg spray inalatorio (ATC R03BA01), assunto come terapia inalatoria di mantenimento per bronchite cronica dall'01/01/2025. |
| [Proposta Terapeutica - Acetilcisteina 600 mg](MedicationRequest-9282eb8d-b153-451a-bd0d-437efd13b45f.md) | Proposta terapeutica del Dr. Marco Ferrari al termine della televisita: Acetilcisteina 600 mg granulato effervescente (ATC R05CB01), mucolitico indicato a supporto della gestione della bronchite cronica di Maria Rossi. |
| [Esempio di Televisita Pneumologica](Procedure-b81d2c4e-5a9f-4c97-90fb-2a3b726b123f.md) | Esempio di istanza ProcedureTelevisita per una televisita pneumologica di controllo (codice 89.01.L). Include tutti gli elementi previsti dal profilo: stato, codice, soggetto, incontro, periodo, operatore, estensione modalità, motivazione, esito, referto e note. |
| [Quesito Diagnostico - Tosse persistente post-COVID](Observation-7cbbe77d-dcdb-409b-a215-6361ad7873d5.md) | Quesito diagnostico formulato dal MMG: tosse persistente post-COVID (ICD-9 786.2). Motivo clinico della richiesta di televisita pneumologica per Maria Rossi. |
| [Anamnesi - Maria Rossi](Observation-84f911ee-b09d-4325-a3f3-a973a0c5ad8f.md) | Anamnesi raccolta durante la televisita pneumologica del 16/06/2025: bronchite cronica nota, non fumatrice. Raccolta dal Dr. Marco Ferrari in modalità remota. |
| [Esame Obiettivo Remoto - Maria Rossi](Observation-c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865.md) | Esame obiettivo rilevato durante la televisita pneumologica del 16/06/2025: tosse secca intermittente segnalata dalla paziente durante la videochiamata con il Dr. Marco Ferrari. |
| [Esami Precedenti - TC Torace 10/05/2025](Observation-9dfdf0c9-a837-42d5-987c-6170c75cc476.md) | TC torace eseguita il 10/05/2025, precedente alla televisita. Risultato: negativa per lesioni polmonari evolutive, con lieve ispessimento peribronchiale compatibile con bronchite cronica. Portata in rassegna dal Dr. Marco Ferrari. |
| [Confronto Esami - Miglioramento quadro bronchiolitico](Observation-ecc5c95f-a1c0-483c-b48e-5fd84762c393.md) | Confronto con i precedenti esami del paziente effettuato dal Dr. Marco Ferrari: lieve miglioramento del quadro bronchiolitico rispetto al controllo precedente, senza segni di progressione. |
| [Referto Televisita Pneumologica - Maria Rossi](Observation-a465cf01-05e6-4f38-8f6a-b5d6c4168c94.md) | Referto clinico redatto dal Dr. Marco Ferrari al termine della televisita pneumologica: sintomi respiratori in lieve miglioramento, assenza di complicanze, terapia inalatoria confermata. |
| [Diagnosi - Bronchite Cronica Mucopurulenta (ICD-9 491.1)](Observation-1729dcef-ac19-434b-82e7-b6e6e51e74b3.md) | Diagnosi formulata dal Dr. Marco Ferrari: bronchite cronica mucopurulenta (ICD-9 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente) e buona risposta alla terapia inalatoria in corso. |
| [Conclusioni Televisita - Monitoraggio consigliato](Observation-1611ed98-7577-48ab-9587-7ab4fc96e191.md) | Conclusioni della televisita pneumologica del 16/06/2025: buona risposta al trattamento inalatorio. Il Dr. Marco Ferrari raccomanda monitoraggio periodico e spirometria di controllo tra 3 mesi. |
| [Suggerimenti al MMG - Spirometria di controllo](Observation-2054e65c-2012-4286-aac7-ce2f23e8be31.md) | Suggerimenti del Dr. Marco Ferrari per il Medico di Medicina Generale di Maria Rossi: valutare spirometria di controllo entro 3 mesi per monitoraggio della funzionalità respiratoria. |
| [Accertamenti Consigliati - Emogasanalisi domiciliare](Observation-1b401b53-f564-4730-bb13-45d5620596f0.md) | Accertamenti diagnostici consigliati dal Dr. Marco Ferrari a seguito della televisita: controllo emogasanalisi a domicilio per monitoraggio dei parametri respiratori di Maria Rossi. |
| [Allegato - TC Torace 10/05/2025 (Maria Rossi)](DocumentReference-4f6c71e1-cc6e-4428-ae9b-0118c0a928cb.md) | Referto della TC torace eseguita il 10/05/2025 allegato alla televisita pneumologica come documento di riferimento clinico, in formato PDF. |
| [ASL Roma 1](Organization-asl-roma-1.md) | Esempio di Azienda Sanitaria Locale (ASL) |
| [Presidio Sandro Pertini](Organization-osp-pertini.md) | Presidio ospedaliero facente parte di ASL Roma 1 |
| [U.O. Pneumologia - Ospedale Pertini](Organization-uo-cardiologia-pertini.md) | Unità Operativa di Pneumologia afferente all'Ospedale Pertini |

