# Downloads - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

Questa pagina raccoglie tutti gli artefatti scaricabili della Implementation Guide: il pacchetto completo, i file di definizione (profili, ValueSet, estensioni) nei formati XML, JSON e TTL, i package NPM per le versioni FHIR R4 e R4B e gli esempi inclusi nella guida.

### IG Televisita

Download l'intera Implementation Guide [qui](full-ig.zip).

### NPM Package and Definitions

Il seguente file è comprensivo di tutti i valueSet, profili ed estensioni previsti dalla Implementation Guide di Televisita:

* [NPM Package](package.tgz)

In aggiunta sono disponibili gli stessi nei rispettivi formati:

* [XML](definitions.xml.zip)
* [JSON](definitions.json.zip)
* [TTL](definitions.ttl.zip)

Questi file, contengono tutte le regole che descrivono la validità dei profili e possono essere utilizzati per validare ogni artefatto generato dalla impementation guide di Televisita.

Inoltre, in funzione della versione FHIR (R4-R4B), vengono forniti i seguenti package:

#### R4 NPM Package and Definitions

* [R4 NPM Package](package.r4.tgz)

#### R4B NPM Package and Definitions

* [R4B NPM Package](package.r4b.tgz)

### Esempi

Tutti gli esempi utilizzati in questa Implementation Guide sono disponibili per il download:

* [XML](examples.xml.zip)
* [JSON](examples.json.zip)
* [TTL](examples.ttl.zip)

### Global Profile Definitions

*There are no Global profiles defined*

