# Observation Televisita Narrative - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation Televisita Narrative**

## Resource Profile: Observation Televisita Narrative ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ObservationTelevisitaNarrative |

 
Profilo della risorsa Observation utilizzato per rappresentare osservazioni cliniche espresse in forma testuale (narrativa) nel contesto della televisita, come referti di esame obiettivo, descrizioni di sintomi o annotazioni cliniche. 

**Usages:**

* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)
* Examples for this Profile: [Observation/1611ed98-7577-48ab-9587-7ab4fc96e191](Observation-1611ed98-7577-48ab-9587-7ab4fc96e191.md), [Observation/2054e65c-2012-4286-aac7-ce2f23e8be31](Observation-2054e65c-2012-4286-aac7-ce2f23e8be31.md), [Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f](Observation-84f911ee-b09d-4325-a3f3-a973a0c5ad8f.md), [Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476](Observation-9dfdf0c9-a837-42d5-987c-6170c75cc476.md)... Show 2 more, [Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865](Observation-c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865.md) and [Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393](Observation-ecc5c95f-a1c0-483c-b48e-5fd84762c393.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-ObservationTelevisitaNarrative.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ObservationTelevisitaNarrative.csv), [Excel](StructureDefinition-ObservationTelevisitaNarrative.xlsx), [Schematron](StructureDefinition-ObservationTelevisitaNarrative.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ObservationTelevisitaNarrative",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
  "version" : "0.2.0",
  "name" : "ObservationTelevisitaNarrative",
  "title" : "Observation Televisita Narrative",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Observation utilizzato per rappresentare osservazioni cliniche espresse in forma testuale (narrativa) nel contesto della televisita, come referti di esame obiettivo, descrizioni di sintomi o annotazioni cliniche.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "short" : "Osservazione testuale rilevata durante la televisita.",
      "definition" : "Rappresenta un'osservazione clinica espressa in forma narrativa, non codificabile con un valore strutturato. Utilizzata tipicamente per sezioni descrittive del referto di televisita."
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "short" : "Stato dell'osservazione narrativa.",
      "definition" : "Stato attuale dell'osservazione. I valori possibili includono: registered, preliminary, final, amended, corrected, cancelled, entered-in-error, unknown."
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "short" : "Categoria dell'osservazione narrativa.",
      "definition" : "Classifica l'osservazione in una categoria clinica. Nel contesto della televisita può indicare note di esame obiettivo, anamnesi o altri contenuti descrittivi."
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Codice che identifica il tipo di osservazione narrativa.",
      "definition" : "Codice LOINC, SNOMED CT o altro sistema che identifica la tipologia del contenuto narrativo (es. esame obiettivo, anamnesi, note cliniche)."
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "short" : "Assistito oggetto dell'osservazione.",
      "definition" : "Riferimento all'assistito coinvolto nella televisita per il quale è stata prodotta l'osservazione narrativa."
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "short" : "Data e ora di rilevazione o produzione dell'osservazione.",
      "definition" : "Data e ora in cui l'osservazione narrativa è stata prodotta o a cui si riferisce clinicamente."
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "short" : "Autore dell'osservazione narrativa.",
      "definition" : "Riferimento al professionista sanitario che ha redatto o validato il contenuto narrativo dell'osservazione."
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "short" : "Testo libero dell'osservazione clinica.",
      "definition" : "Contenuto testuale dell'osservazione clinica in forma narrativa. Utilizzato per esprimere informazioni cliniche non strutturabili in formato codificato, quali descrizioni di sintomi, esame obiettivo, anamnesi o valutazioni del professionista.",
      "min" : 1,
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "short" : "Note aggiuntive.",
      "definition" : "Annotazioni o commenti aggiuntivi in testo libero che integrano il contenuto principale dell'osservazione narrativa."
    }]
  }
}

```
