# Suggerimenti al MMG - Spirometria di controllo - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Suggerimenti al MMG - Spirometria di controllo**

## Example Observation: Suggerimenti al MMG - Spirometria di controllo

Profile: [Observation Televisita Narrative](StructureDefinition-ObservationTelevisitaNarrative.md)

**status**: Final

**code**: Recommendation [Interpretation] Document

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**effective**: 2025-06-16 10:30:00+0200

**performer**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

**value**: Valutare spirometria di controllo tra 3 mesi.



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "2054e65c-2012-4286-aac7-ce2f23e8be31",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
  },
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "62385-0"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "effectiveDateTime" : "2025-06-16T10:30:00+02:00",
  "performer" : [{
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  }],
  "valueString" : "Valutare spirometria di controllo tra 3 mesi."
}

```
