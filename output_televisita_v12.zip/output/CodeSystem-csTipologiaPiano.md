# CodeSystem per la tipologia del piano - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CodeSystem per la tipologia del piano**

## CodeSystem: CodeSystem per la tipologia del piano (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/csTipologiaPiano | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CodeSystem_tipologia_piano |

 
Definisce il sistema di terminologie da usare per i codici delle tipologie di piano 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSet_TipologiaPiano](ValueSet-tipologia-piano.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "csTipologiaPiano",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/csTipologiaPiano",
  "version" : "0.2.0",
  "name" : "CodeSystem_tipologia_piano",
  "title" : "CodeSystem per la tipologia del piano",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definisce il sistema di terminologie da usare per i codici delle tipologie di piano",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "01",
    "display" : "Piano di Telemonitoraggio",
    "definition" : "Piano di Telemonitoraggio"
  },
  {
    "code" : "02",
    "display" : "Piano di Teleassistenza",
    "definition" : "Piano di Teleassistenza"
  },
  {
    "code" : "03",
    "display" : "Piano di Teleriabilitazione",
    "definition" : "Piano di Teleriabilitazione"
  }]
}

```
