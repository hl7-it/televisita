# Bundle Referto di televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle Referto di televisita**

## Resource Profile: Bundle Referto di televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertodiTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:BundleRefertodiTelevisita |

 
Bundle FHIR utilizzato per rappresentare il referto di televisita. Contiene la Composition e tutte le risorse cliniche, amministrative e organizzative necessarie alla completa rappresentazione della prestazione erogata in telemedicina. 

**Usages:**

* Examples for this Profile: [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-BundleRefertodiTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleRefertodiTelevisita.csv), [Excel](StructureDefinition-BundleRefertodiTelevisita.xlsx), [Schematron](StructureDefinition-BundleRefertodiTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleRefertodiTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertodiTelevisita",
  "version" : "0.2.0",
  "name" : "BundleRefertodiTelevisita",
  "title" : "Bundle Referto di televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Bundle FHIR utilizzato per rappresentare il referto di televisita. Contiene la Composition e tutte le risorse cliniche, amministrative e organizzative necessarie alla completa rappresentazione della prestazione erogata in telemedicina.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Bundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.type",
      "path" : "Bundle.type",
      "short" : "Tipologia del Bundle.",
      "definition" : "Indica la tipologia del Bundle. Nel contesto del referto di televisita identifica un Bundle di tipo document.",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VsBundleTipoTelevisita"
      }
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "resource"
        },
        {
          "type" : "profile",
          "path" : "resource"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Risorse che compongono il documento clinico.",
      "definition" : "Collezione delle risorse FHIR che costituiscono il referto di televisita. La prima entry contiene la Composition, seguita dalle risorse cliniche, amministrative e organizzative referenziate nel documento.",
      "min" : 2
    },
    {
      "id" : "Bundle.entry:composition",
      "path" : "Bundle.entry",
      "sliceName" : "composition",
      "short" : "Documento clinico della televisita.",
      "definition" : "Composition che rappresenta il referto di televisita e costituisce la risorsa principale del Bundle document.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:composition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Composition",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:patient",
      "path" : "Bundle.entry",
      "sliceName" : "patient",
      "short" : "Assistito.",
      "definition" : "Risorsa Patient che identifica l'assistito a cui si riferisce il referto di televisita.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:patient.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Patient",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:serviceRequest",
      "path" : "Bundle.entry",
      "sliceName" : "serviceRequest",
      "short" : "Richiesta o prescrizione della televisita.",
      "definition" : "Richiesta o prescrizione specialistica che ha originato l'erogazione della televisita, ove disponibile.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:serviceRequest.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "ServiceRequest",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:appointment",
      "path" : "Bundle.entry",
      "sliceName" : "appointment",
      "short" : "Appuntamento della televisita.",
      "definition" : "Informazioni relative alla prenotazione o pianificazione dell'appuntamento per l'erogazione della televisita.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Bundle.entry:appointment.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Appointment"
      }]
    },
    {
      "id" : "Bundle.entry:practitionerRole",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerRole",
      "short" : "Ruoli dei professionisti sanitari.",
      "definition" : "Ruoli professionali dei soggetti coinvolti nella richiesta, erogazione, refertazione o validazione della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitionerRole.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "PractitionerRole",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:practitioner",
      "path" : "Bundle.entry",
      "sliceName" : "practitioner",
      "short" : "Professionisti sanitari.",
      "definition" : "Professionisti sanitari coinvolti nel processo di televisita, quali medico richiedente, medico erogatore o medico refertante.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:practitioner.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Practitioner",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:organization",
      "path" : "Bundle.entry",
      "sliceName" : "organization",
      "short" : "Organizzazioni sanitarie.",
      "definition" : "Organizzazioni coinvolte nella richiesta, erogazione, presa in carico o refertazione della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:organization.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Organization",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3"]
      }]
    },
    {
      "id" : "Bundle.entry:observation",
      "path" : "Bundle.entry",
      "sliceName" : "observation",
      "short" : "Osservazioni cliniche.",
      "definition" : "Osservazioni cliniche rilevate o documentate nell'ambito della televisita, comprese anamnesi, esame obiettivo, valutazioni narrative e altre informazioni cliniche.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:observation.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Observation",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:condition",
      "path" : "Bundle.entry",
      "sliceName" : "condition",
      "short" : "Diagnosi e condizioni cliniche.",
      "definition" : "Condizioni cliniche, problemi o diagnosi formulate, confermate o considerate nel corso della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:condition.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Condition"
      }]
    },
    {
      "id" : "Bundle.entry:medicationRequest",
      "path" : "Bundle.entry",
      "sliceName" : "medicationRequest",
      "short" : "Prescrizioni farmacologiche.",
      "definition" : "Prescrizioni o raccomandazioni farmacologiche formulate come esito della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:medicationRequest.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "MedicationRequest",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:medicationStatement",
      "path" : "Bundle.entry",
      "sliceName" : "medicationStatement",
      "short" : "Terapia farmacologica in corso.",
      "definition" : "Informazioni sui farmaci assunti dall'assistito al momento della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:medicationStatement.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "MedicationStatement"
      }]
    },
    {
      "id" : "Bundle.entry:allergyIntolerance",
      "path" : "Bundle.entry",
      "sliceName" : "allergyIntolerance",
      "short" : "Allergie e intolleranze.",
      "definition" : "Allergie, intolleranze o reazioni avverse rilevanti ai fini della valutazione clinica effettuata durante la televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:allergyIntolerance.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "AllergyIntolerance",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:familyMemberHistory",
      "path" : "Bundle.entry",
      "sliceName" : "familyMemberHistory",
      "short" : "Anamnesi familiare.",
      "definition" : "Informazioni relative alla storia clinica familiare dell'assistito, ove rilevanti per la valutazione svolta in televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:familyMemberHistory.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "FamilyMemberHistory"
      }]
    },
    {
      "id" : "Bundle.entry:encounter",
      "path" : "Bundle.entry",
      "sliceName" : "encounter",
      "short" : "Incontro di televisita.",
      "definition" : "Encounter che rappresenta il contesto assistenziale e l'effettiva erogazione della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:encounter.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Encounter",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:procedure",
      "path" : "Bundle.entry",
      "sliceName" : "procedure",
      "short" : "Prestazioni eseguite.",
      "definition" : "Prestazioni sanitarie effettuate o documentate nell'ambito della televisita.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:procedure.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "Procedure",
        "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
      }]
    },
    {
      "id" : "Bundle.entry:documentReference",
      "path" : "Bundle.entry",
      "sliceName" : "documentReference",
      "short" : "Documenti allegati.",
      "definition" : "Documenti allegati o referenziati nell'ambito del referto di televisita, quali referti precedenti, immagini diagnostiche o altri allegati clinici.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Bundle.entry:documentReference.resource",
      "path" : "Bundle.entry.resource",
      "type" : [{
        "code" : "DocumentReference"
      }]
    }]
  }
}

```
