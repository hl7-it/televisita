# AllergyIntolerance Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AllergyIntolerance Televisita**

## Resource Profile: AllergyIntolerance Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:AllergyIntoleranceTelevisita |

 
Profilo della risorsa AllergyIntolerance utilizzato per rappresentare le allergie e le intolleranze dell'assistito rilevate o comunicate nel contesto della televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)
* Examples for this Profile: [AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94](AllergyIntolerance-1360bd6a-3855-48d3-aa33-96a9d961bb94.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-AllergyIntoleranceTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-AllergyIntoleranceTelevisita.csv), [Excel](StructureDefinition-AllergyIntoleranceTelevisita.xlsx), [Schematron](StructureDefinition-AllergyIntoleranceTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "AllergyIntoleranceTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita",
  "version" : "0.2.0",
  "name" : "AllergyIntoleranceTelevisita",
  "title" : "AllergyIntolerance Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa AllergyIntolerance utilizzato per rappresentare le allergie e le intolleranze dell'assistito rilevate o comunicate nel contesto della televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "AllergyIntolerance",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/AllergyIntolerance",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "AllergyIntolerance",
      "path" : "AllergyIntolerance",
      "short" : "Allergie e intolleranze dell'assistito",
      "definition" : "Descrive le allergie e le intolleranze dell'assistito, incluse reazioni a farmaci, alimenti o altre sostanze, rilevanti ai fini della televisita."
    },
    {
      "id" : "AllergyIntolerance.clinicalStatus",
      "path" : "AllergyIntolerance.clinicalStatus",
      "short" : "Stato clinico dell'allergia o intolleranza.",
      "definition" : "Indica se l'allergia o intolleranza è attualmente attiva, inattiva o risolta."
    },
    {
      "id" : "AllergyIntolerance.verificationStatus",
      "path" : "AllergyIntolerance.verificationStatus",
      "short" : "Stato di verifica dell'allergia o intolleranza.",
      "definition" : "Indica il grado di certezza con cui l'allergia o intolleranza è stata confermata (non confermata, confermata, refutata, ecc.)."
    },
    {
      "id" : "AllergyIntolerance.type",
      "path" : "AllergyIntolerance.type",
      "short" : "Tipo: allergia o intolleranza.",
      "definition" : "Distingue tra allergia vera (reazione immuno-mediata) e intolleranza (reazione non immuno-mediata)."
    },
    {
      "id" : "AllergyIntolerance.category",
      "path" : "AllergyIntolerance.category",
      "short" : "Categoria della sostanza (cibo, farmaco, ambiente, altro).",
      "definition" : "Indica la categoria della sostanza responsabile dell'allergia o intolleranza (ad es. cibo, farmaco, agente ambientale, altro)."
    },
    {
      "id" : "AllergyIntolerance.criticality",
      "path" : "AllergyIntolerance.criticality",
      "short" : "Criticità stimata dell'allergia o intolleranza.",
      "definition" : "Valutazione del rischio potenziale di una reazione futura. I valori possibili sono: low (bassa), high (alta), unable-to-assess (non valutabile)."
    },
    {
      "id" : "AllergyIntolerance.code",
      "path" : "AllergyIntolerance.code",
      "short" : "Codice dell'allergia o intolleranza.",
      "definition" : "Codice che identifica la sostanza, il gruppo di sostanze o l'agente responsabile dell'allergia o intolleranza. Può essere espresso con coding standardizzato (es. SNOMED CT) o come testo libero.",
      "min" : 1
    },
    {
      "id" : "AllergyIntolerance.patient",
      "path" : "AllergyIntolerance.patient",
      "short" : "Assistito cui si riferisce l'allergia o intolleranza.",
      "definition" : "Riferimento all'assistito coinvolto nella televisita per il quale è registrata l'allergia o intolleranza.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "AllergyIntolerance.onset[x]",
      "path" : "AllergyIntolerance.onset[x]",
      "short" : "Data di insorgenza dell'allergia o intolleranza.",
      "definition" : "Data o periodo in cui l'allergia o intolleranza è stata identificata per la prima volta."
    },
    {
      "id" : "AllergyIntolerance.recorder",
      "path" : "AllergyIntolerance.recorder",
      "short" : "Chi ha registrato l'allergia o intolleranza.",
      "definition" : "Riferimento al professionista sanitario che ha inserito o validato la segnalazione dell'allergia o intolleranza."
    },
    {
      "id" : "AllergyIntolerance.note",
      "path" : "AllergyIntolerance.note",
      "short" : "Note sull'allergia o intolleranza.",
      "definition" : "Informazioni aggiuntive in testo libero relative all'allergia o intolleranza, non altrimenti codificabili negli altri elementi della risorsa."
    },
    {
      "id" : "AllergyIntolerance.reaction",
      "path" : "AllergyIntolerance.reaction",
      "short" : "Dettagli della reazione avversa.",
      "definition" : "Descrive gli eventi di reazione avversa osservati o riferiti correlati all'esposizione alla sostanza."
    },
    {
      "id" : "AllergyIntolerance.reaction.substance",
      "path" : "AllergyIntolerance.reaction.substance",
      "short" : "Sostanza specifica che ha causato la reazione.",
      "definition" : "Sostanza specifica — che può essere diversa dalla sostanza identificata nel codice dell'allergia — che ha effettivamente scatenato la reazione."
    },
    {
      "id" : "AllergyIntolerance.reaction.manifestation",
      "path" : "AllergyIntolerance.reaction.manifestation",
      "short" : "Sintomi e segni della reazione.",
      "definition" : "Segni e sintomi clinici osservati o riferiti durante la reazione avversa."
    },
    {
      "id" : "AllergyIntolerance.reaction.severity",
      "path" : "AllergyIntolerance.reaction.severity",
      "short" : "Gravità della reazione avversa.",
      "definition" : "Valutazione clinica della gravità della reazione: mild (lieve), moderate (moderata), severe (grave)."
    },
    {
      "id" : "AllergyIntolerance.reaction.note",
      "path" : "AllergyIntolerance.reaction.note",
      "short" : "Note sulla reazione.",
      "definition" : "Informazioni aggiuntive in testo libero relative alla specifica reazione avversa."
    }]
  }
}

```
