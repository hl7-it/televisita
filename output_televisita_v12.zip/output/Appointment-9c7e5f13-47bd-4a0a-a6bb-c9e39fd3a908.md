# Appuntamento Televisita Pneumologica - Maria Rossi - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Appuntamento Televisita Pneumologica - Maria Rossi**

## Example Appointment: Appuntamento Televisita Pneumologica - Maria Rossi

Profile: [AppointmentTelevisita](StructureDefinition-AppointmentTelevisita.md)

**identifier**: TV-20250616-001

**status**: Booked

**serviceCategory**: Counselling

**reasonCode**: Televisita pneumologica per follow-up bronchite cronica

**start**: 2025-06-16 09:00:00+0200

**end**: 2025-06-16 09:45:00+0200

**created**: 2025-06-02 09:00:00+0200

**basedOn**: [ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md)

> **participant****actor**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)**status**: Accepted

> **participant****actor**: [PractitionerRole: specialty = Pneumologia](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md)**status**: Accepted



## Resource Content

```json
{
  "resourceType" : "Appointment",
  "id" : "9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita"]
  },
  "identifier" : [{
    "value" : "TV-20250616-001"
  }],
  "status" : "booked",
  "serviceCategory" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/service-category",
      "version" : "1.1.1",
      "code" : "8",
      "display" : "Counselling"
    }]
  }],
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "13645005",
      "display" : "Chronic obstructive lung disease"
    }],
    "text" : "Televisita pneumologica per follow-up bronchite cronica"
  }],
  "start" : "2025-06-16T09:00:00+02:00",
  "end" : "2025-06-16T09:45:00+02:00",
  "created" : "2025-06-02T09:00:00+02:00",
  "basedOn" : [{
    "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
  }],
  "participant" : [{
    "actor" : {
      "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
    },
    "status" : "accepted"
  },
  {
    "actor" : {
      "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
    },
    "status" : "accepted"
  }]
}

```
