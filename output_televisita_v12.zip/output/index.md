# Home - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ImplementationGuide/televisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:Televisita |

### Contesto e scenario di riferimento Nazionale

La Telemedicina sta assumendo un ruolo sempre più centrale nell’evoluzione del sistema sanitario, rappresentando un’opportunità per migliorare l’accesso alle cure, ridurre i tempi di attesa e garantire una maggiore continuità assistenziale, in particolare per i pazienti con patologie croniche o residenti in aree geograficamente svantaggiate.

L’integrazione della Telemedicina nel Sistema Sanitario Nazionale (SSN) prevede la creazione di infrastrutture digitali interoperabili, capaci di gestire in modo efficiente la raccolta, l’elaborazione e la trasmissione dei dati clinici tra i diversi attori e setting coinvolti: pazienti, medici di medicina generale, medici specialisti, ospedali, farmacie e servizi di emergenza.

### Il dominio della Televisita

Secondo le **Indicazioni nazionali per l'erogazione di prestazioni in telemedicina** approvate con l' Accordo Stato, Regioni e Province Autonome del 17 dicembre 2020, Rep. Atti n. 215/CSR (Rep. Atti n. 215/CSR del 17 dicembre 2020), la televisita è un atto medico in cui il professionista interagisce a distanza in tempo reale con il paziente, eventualmente con il supporto di un caregiver o di un altro operatore sanitario.

La televisita è una visita medica a distanza, durante la quale il medico interagisce in tempo reale tramite videochiamata con il paziente (se necessario con il caregiver). La televisita consente al medico di raccogliere dati clinici, inclusi referti, immagini e altre informazioni sanitarie, assicurando il rispetto della normativa vigente in materia di protezione dei dati personali e sicurezza delle informazioni sanitarie. La televisita consente di confermare una diagnosi o formulare una diagnosi differenziale, prescrivere terapie e rilasciare documentazione con pieno valore clinico e medico - legale (referto; certificato; altre prescrizioni), che può essere trasmessa al Fascicolo Sanitario Elettronico (FSE) per garantirne tracciabilità e accessibilità.

Il medico, in qualità di responsabile clinico della prestazione, valuta l’appropriatezza della televisita caso per caso, in base alle condizioni cliniche del paziente e alla disponibilità di informazioni sanitarie rilevanti. In linea generale, la televisita non sostituisce la prima visita in presenza, che resta raccomandata per una valutazione completa e diretta del paziente. Tuttavia, in specifici casi clinici selezionati, la televisita può essere utilizzata anche per la prima valutazione del paziente, quando il medico ritiene, sotto la propria responsabilità, che la modalità a distanza consenta comunque una valutazione clinica completa e sicura.

Fonte: Accordo Stato-regioni del 18 novembre 2021 (Rep. atti n. 231/ CSR), sul documento recante “Indicazioni nazionali per l’erogazione di prestazioni e servizi di teleriabilitazione da parte delle professioni sanitarie”.

DM 21 settembre 2022 pubblicato in GURI n.256 il 02 novembre 2022 “Approvazione delle Linee guida per i servizi di Telemedicina - Requisiti funzionali e livelli di servizio”.

DM 30 settembre 2022 pubblicato in GURI n.298 il 22 dicembre 2022 “Procedure di selezione delle soluzioni di Telemedicina e diffusione sul territorio nazionale, nonché i meccanismi di valutazione delle proposte di fabbisogno regionale per i servizi minimi di Telemedicina e l'adozione delle Linee di indirizzo per i servizi di Telemedicina”.

Decreto Ministeriale 19 novembre 2025 pubblicato in GURI n. 301 del 30 dicembre 2025 “Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina”;

Glossario Nazionale di Telemedicina: Definizioni e termini chiave per i servizi e le componenti della Telemedicina” pubblicato a gennaio 2026 nella sezione “Linee di indirizzo, PDTA e Protocolli” nell’ambito della Piattaforma Nazionale di Telemedicina (PNT).

### Integrazione con i sistemi Regionali e Nazionali

L'integrazione con i sistemi sanitari regionali e nazionali è fondamentale per garantire un flusso di informazioni omogeneo e sicuro tra la Piattaforma di Telemedicina e le infrastrutture sanitarie esistenti.

Di seguito è riportato uno schema esemplificativo che illustra il flusso dei dati tra i diversi sistemi, evidenziando come le informazioni vengano trasferite e integrate all'interno della Piattaforma Nazionale di Telemedicina.

![](Flusso_Dati_PNT_IRT_v6.png)

I referti prodotti vengono prima validati dal Gateway, che assicura l'integrità e la conformità dei dati. Successivamente, i dati validati vengono archiviati e indicizzati nei registri nazionali e regionali. Il Gateway invia quindi le informazioni all'EDS, che a sua volta notifica la Piattaforma Nazionale di Telemedicina, garantendo una gestione centralizzata e conforme del flusso informativo.

### Scelte di design

La soluzione adottata da questa guida bilancia l'esigenza di rappresentare il referto di televisita come documento clinico completo con la necessità di rendere disponibili in modo strutturato e interoperabile i dati clinici e amministrativi che lo compongono.

A tal fine, è stato scelto di prevedere due differenti modalità di rappresentazione e scambio delle informazioni associate alla televisita:

* Bundle di tipo document, finalizzato alla condivisione e alla conservazione del referto di televisita come documento clinico unitario.
* Bundle di tipo transaction, finalizzato alla fruizione, all'elaborazione e al riutilizzo delle singole risorse FHIR che descrivono la prestazione e il relativo contenuto clinico.

Il bundle di tipo document consente di rappresentare il referto di televisita come un insieme coerente di informazioni cliniche organizzate secondo il paradigma documentale di FHIR, favorendone la visualizzazione, la conservazione e la condivisione tra i diversi attori del processo assistenziale. Il bundle di tipo transaction, invece, consente di accedere alle singole informazioni in forma strutturata, permettendo ai sistemi informativi di ricercare, elaborare e riutilizzare i dati clinici e amministrativi associati alla televisita senza la necessità di interpretare l'intero documento. Questa scelta progettuale consente di soddisfare contemporaneamente due esigenze complementari:

* garantire la disponibilità del referto di televisita come documento clinico formalmente condivisibile e conservabile;
* favorire l'interoperabilità applicativa e la valorizzazione del patrimonio informativo attraverso la fruizione granulare delle risorse FHIR che compongono il referto.

L'adozione di entrambe le rappresentazioni permette quindi di supportare sia gli scenari orientati al documento sia gli scenari orientati ai dati, favorendo la continuità assistenziale, l'integrazione tra sistemi e il riutilizzo delle informazioni cliniche nel contesto dei servizi di telemedicina. ![](design_televisita.png)

### Autori e contributori

| | | | |
| :--- | :--- | :--- | :--- |
| Autore | Leonardo Alcaro | HL7 Italia | leonardo.alcaro@regione.calabria.it |
| Autore | Mario Sicuranza | HL7 Italia | mario.sicuranza@icar.cnr.it |
| Autore | Sara Marceglia | Agenas | marceglia@agenas.it |
| Autore | Federica Dessì | Deloitte S.B. S.r.l. | fdessi@deloitte.it |
| Autore | Sonia Biasi | Deloitte S.B. S.r.l. | sbiasi@deloitte.it |
| Autore | Davide Spanu | Deloitte S.B. S.r.l. | dspanu@deloitte.it |
| Autore | William Tasinazzo | Deloitte S.B. S.r.l. | wtasinazzo@deloitte.it |
| Autore | Maria Giovanna Antida Preziosi | SOGEI | mpreziosi@sogei.it |

### Intellectual Property Statements

This publication includes IP covered under the following statements.

* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://tx.fhir.org/r4/ValueSet/x-loinc2.82): [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)... Show 14 more, [Composition/aa011502-6ad2-430b-a439-01dddc36fd4e](Composition-aa011502-6ad2-430b-a439-01dddc36fd4e.md), [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [DocumentReference/4f6c71e1-cc6e-4428-ae9b-0118c0a928cb](DocumentReference-4f6c71e1-cc6e-4428-ae9b-0118c0a928cb.md), [Observation/1611ed98-7577-48ab-9587-7ab4fc96e191](Observation-1611ed98-7577-48ab-9587-7ab4fc96e191.md), [Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3](Observation-1729dcef-ac19-434b-82e7-b6e6e51e74b3.md), [Observation/1b401b53-f564-4730-bb13-45d5620596f0](Observation-1b401b53-f564-4730-bb13-45d5620596f0.md), [Observation/2054e65c-2012-4286-aac7-ce2f23e8be31](Observation-2054e65c-2012-4286-aac7-ce2f23e8be31.md), [Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5](Observation-7cbbe77d-dcdb-409b-a215-6361ad7873d5.md), [Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f](Observation-84f911ee-b09d-4325-a3f3-a973a0c5ad8f.md), [Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476](Observation-9dfdf0c9-a837-42d5-987c-6170c75cc476.md), [Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94](Observation-a465cf01-05e6-4f38-8f6a-b5d6c4168c94.md), [Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865](Observation-c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865.md), [Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393](Observation-ecc5c95f-a1c0-483c-b48e-5fd84762c393.md) and [VsTipologiaDocumentale](ValueSet-vsTipologiaDocumentale.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94](AllergyIntolerance-1360bd6a-3855-48d3-aa33-96a9d961bb94.md), [Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908](Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.md)... Show 6 more, [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md), [MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a](MedicationStatement-e62c9f1d-9c0b-4433-853b-06ec5074f19a.md), [Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f](Procedure-b81d2c4e-5a9f-4c97-90fb-2a3b726b123f.md), [ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md) and [TipologiaAttivitaPianoDiTelemonitoraggio](ValueSet-TipologiaAttivitaPianoDiTelemonitoraggio.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.2.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94](AllergyIntolerance-1360bd6a-3855-48d3-aa33-96a9d961bb94.md), [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md) and [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.2.0/CodeSystem-allergyintolerance-verification.html): [AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94](AllergyIntolerance-1360bd6a-3855-48d3-aa33-96a9d961bb94.md), [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md) and [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)
* [Organization type](http://terminology.hl7.org/7.2.0/CodeSystem-organization-type.html): [OrganizationT2](StructureDefinition-OrganizationT2.md)
* [Service category](http://terminology.hl7.org/7.2.0/CodeSystem-service-category.html): [Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908](Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.md), [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md) and [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)
* [contactRole2](http://terminology.hl7.org/7.2.0/CodeSystem-v2-0131.html): [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)
* [identifierType](http://terminology.hl7.org/7.2.0/CodeSystem-v2-0203.html): [PatientTelevisita](StructureDefinition-PatientTelevisita.md) and [VstipoIdentificatore](ValueSet-VstipoIdentificatore.md)
* [ActCode](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActCode.html): [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md)... Show 4 more, [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md), [EncounterTelevisita](StructureDefinition-EncounterTelevisita.md) and [VsClassEncounterTelevisita](ValueSet-VsClassEncounterTelevisita.md)
* [ActPriority](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActPriority.html): [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)
* [RoleCode](http://terminology.hl7.org/7.2.0/CodeSystem-v3-RoleCode.html): [ExtRecordCertification](StructureDefinition-recordCertification.md) and [VsTipoCertificatore](ValueSet-tipoCertificatore.md)


* WHO Collaborating Centre for Drug Statistics Methodology, Oslo, Norway. Use of all or parts of the material requires reference to the WHO Collaborating Centre for Drug Statistics Methodology. Copying and distribution for commercial purposes is not allowed. Changing or manipulating the material is not allowed.

* [ATC classification system](http://tx.hl7europe.eu/r4/ValueSet/965): [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md), [MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f](MedicationRequest-9282eb8d-b153-451a-bd0d-437efd13b45f.md) and [MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a](MedicationStatement-e62c9f1d-9c0b-4433-853b-06ec5074f19a.md)


### Dependenciy table



#### Cross-Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (televisita.r4)](package.r4.tgz) and [R4B (televisita.r4b)](package.r4b.tgz) are available.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "televisita",
  "url" : "http://hl7.it/fhir/televisita/ImplementationGuide/televisita",
  "version" : "0.2.0",
  "name" : "Televisita",
  "title" : "Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "packageId" : "televisita",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.2.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "trial-use"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.it/fhir/televisita/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "trial-use"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.it/fhir/televisita/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "grouping" : [{
      "id" : "GroupA",
      "name" : "Profili Core Referto Televisita",
      "description" : "Profili utilizzati nel contesto del Referto di Televisita"
    },
    {
      "id" : "GroupB",
      "name" : "Profili Correlati Referto Televisita",
      "description" : "Profili correlati utilizzati a supporto del Referto di Televisita"
    },
    {
      "id" : "GroupC",
      "name" : "Estensioni",
      "description" : "Estensioni FHIR definite nella guida di Televisita"
    },
    {
      "id" : "GroupD",
      "name" : "Value Set",
      "description" : "Value Set definiti nella guida di Televisita"
    },
    {
      "id" : "GroupE",
      "name" : "Code System",
      "description" : "Code System definiti nella guida di Televisita"
    },
    {
      "id" : "GroupF",
      "name" : "Esempi",
      "description" : "Caso d'uso esemplificativo: televisita pneumologica virtuale (classe VR) erogata il 16/06/2025 dalla U.O. Pneumologia dell'Ospedale Sandro Pertini (ASL Roma 1). La paziente Maria Rossi (bronchite cronica nota, non fumatrice) viene visitata dal Dr. Marco Ferrari, Pneumologo, su richiesta del suo Medico di Medicina Generale per follow-up della sintomatologia respiratoria post-COVID. La visita include raccolta anamnestica, esame obiettivo remoto, confronto con TC torace del 10/05/2025, diagnosi ICD-9 491.1 (bronchite cronica mucopurulenta in fase stabile) e proposta terapeutica con Acetilcisteina 600 mg."
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleRefertodiTelevisita"
      },
      "name" : "Bundle Referto di televisita",
      "description" : "Bundle FHIR utilizzato per rappresentare il referto di televisita. Contiene la Composition e tutte le risorse cliniche, amministrative e organizzative necessarie alla completa rappresentazione della prestazione erogata in telemedicina.",
      "exampleBoolean" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BundleRefertoDiTelevisitaTransaction"
      },
      "name" : "Bundle Referto di Televisita - Transaction",
      "description" : "Bundle FHIR di tipo transaction per il Referto di Televisita. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) utilizzano PUT con URL basato sull'identificatore per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment, DocumentReference) utilizzano POST.",
      "exampleBoolean" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionRefertoTelevisita"
      },
      "name" : "CompositionRefertoTelevisita",
      "description" : "Profilo della Composition utilizzata nel contesto della Televisita. Rappresenta il documento clinico strutturato prodotto al termine di una sessione di televisita, includendo tutte le sezioni cliniche e amministrative previste dal D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina.",
      "exampleBoolean" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ServiceRequestTelevisita"
      },
      "name" : "ServiceRequest Televisita",
      "description" : "Profilo della risorsa ServiceRequest utilizzata per rappresentare la richiesta o prescrizione specialistica associata al servizio di televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PatientTelevisita"
      },
      "name" : "Patient Televisita",
      "description" : "Profilo della risorsa Patient utilizzato per rappresentare l'assistito coinvolto nel servizio di televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PractitionerTelevisita"
      },
      "name" : "Practitioner Televisita",
      "description" : "Profilo della risorsa Practitioner utilizzato per rappresentare il professionista sanitario coinvolto nell'erogazione della televisita, inclusi medico specialista, medico prescrittore e altri operatori sanitari.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PractitionerRoleTelevisita"
      },
      "name" : "PractitionerRoleTelevisita",
      "description" : "Profilo della risorsa PractitionerRole utilizzato per rappresentare il ruolo professionale del medico specialista o di altro operatore sanitario nell'ambito dell'erogazione della televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/EncounterTelevisita"
      },
      "name" : "Encounter Televisita",
      "description" : "Profilo della risorsa Encounter utilizzato per rappresentare la visita di telemedicina, incluse informazioni sulla modalità, la disciplina specialistica, i partecipanti e i riferimenti all'appuntamento e alla richiesta di servizio.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/AppointmentTelevisita"
      },
      "name" : "AppointmentTelevisita",
      "description" : "Profilo base del Appointment condiviso in tutti i documenti di Telemedicina",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/AllergyIntoleranceTelevisita"
      },
      "name" : "AllergyIntolerance Televisita",
      "description" : "Profilo della risorsa AllergyIntolerance utilizzato per rappresentare le allergie e le intolleranze dell'assistito rilevate o comunicate nel contesto della televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MedicationRequestTelevisita"
      },
      "name" : "MedicationRequest Televisita",
      "description" : "Profilo della risorsa MedicationRequest utilizzato per rappresentare la terapia farmacologica consigliata al termine della televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MedicationStatementTelevisita"
      },
      "name" : "MedicationStatement Televisita",
      "description" : "Profilo della risorsa MedicationStatement utilizzato per rappresentare la terapia farmacologica in atto nel paziente al momento della televisita, ovvero farmaci già assunti indipendentemente da una prescrizione corrente.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ProcedureTelevisita"
      },
      "name" : "Procedure Televisita",
      "description" : "Profilo della risorsa Procedure utilizzato per rappresentare le prestazioni e le procedure cliniche erogate nel corso della televisita, inclusi codici, periodi di erogazione, modalità esecutive e strumentazione utilizzata.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationTelevisita"
      },
      "name" : "Observation Televisita",
      "description" : "Profilo della risorsa Observation utilizzato per rappresentare parametri clinici, misurazioni e osservazioni rilevate nel contesto della televisita.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationTelevisitaNarrative"
      },
      "name" : "Observation Televisita Narrative",
      "description" : "Profilo della risorsa Observation utilizzato per rappresentare osservazioni cliniche espresse in forma testuale (narrativa) nel contesto della televisita, come referti di esame obiettivo, descrizioni di sintomi o annotazioni cliniche.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationT1"
      },
      "name" : "Organization T1 - Azienda Sanitaria",
      "description" : "Profilo della risorsa Organization di tipo 1, utilizzato per rappresentare le aziende sanitarie locali (ASL), aziende ospedaliere (AO) e IRCCS nel contesto della telemedicina.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationT2"
      },
      "name" : "Organization T2 - Presidio / Ospedale",
      "description" : "Profilo della risorsa Organization di tipo 2, utilizzato per rappresentare i presidi ospedalieri, i distretti sanitari e le strutture di secondo livello nel contesto della telemedicina.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationT3"
      },
      "name" : "Organization T3 - Unità Operativa / Ambulatorio",
      "description" : "Profilo della risorsa Organization di tipo 3, utilizzato per rappresentare le unità operative, i reparti e gli ambulatori nel contesto della telemedicina.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/AddressItTelemedicina"
      },
      "name" : "Address - ITA",
      "description" : "Descrizione di Address con parti addizionali specifiche per gli indirizzi italiani. Questo profilo struttura l'elemento  Address.line in più parti, consente la codifica di alcune di queste parti e supporta la caratterizzazine degli indirizzi di tipo Residenza. Questa prima versione è ispirata al data type Address Olandese.",
      "exampleBoolean" : false,
      "groupingId" : "GroupB"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/recordCertification"
      },
      "name" : "Certificazione del Record",
      "description" : "Estensione utilizzata per indicare che un'informazione associata (es. codice fiscale, indirizzo di residenza, dati anagrafici) è stata certificata o autocertificata da una specifica entità (persona od organizzazione). Nel contesto della televisita è impiegata per attestare l'autenticità degli identificativi dell'assistito e degli indirizzi riportati nel referto.",
      "exampleBoolean" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/birth-place-ita"
      },
      "name" : "Luogo di Nascita - ITA",
      "description" : "Estensione utilizzata per rappresentare il luogo di nascita dell'assistito secondo il formato italiano, strutturato come un indirizzo conforme al profilo AddressItTelemedicina. Nel contesto della televisita è rilevante per l'identificazione anagrafica dell'assistito.",
      "exampleBoolean" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/address-dug"
      },
      "name" : "DUG (Denominazione Urbanistica Generica)",
      "description" : "Denominazione Urbanistica Ufficiale.",
      "exampleBoolean" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/address-official"
      },
      "name" : "IndirizzoUfficiale",
      "description" : "Definizione dell'indirizzo inteso come indirizzo 'ufficiale' di quella persona. Il significato di indirizzo 'ufficiale' dipende dal Paese. Questa estensione consente di specificare se questo indirizzo è o non è l'indirizzo ufficiale, oppure di indicare che si tratta dell'indirizzo ufficiale di quel Paese.",
      "exampleBoolean" : false,
      "groupingId" : "GroupC"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/VsBundleTipoTelevisita"
      },
      "name" : "Tipo Bundle Referto di Televisita",
      "description" : "Tipi di Bundle ammessi per il Referto di Televisita: document o transaction.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/VsClassEncounterTelevisita"
      },
      "name" : "Classe Encounter Televisita",
      "description" : "ValueSet che limita la classificazione dell'incontro (Encounter.class) ai soli valori ammessi nel contesto della telemedicina: VR (visita virtuale/remota) e HH (assistenza domiciliare).",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vsAmbitoTelemedicina"
      },
      "name" : "ValueSet per gli ambiti di telemedicina",
      "description" : "Contiene la lista di codici da utilizzare per la tipologia di referto",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vsspecialityPractitionerRole"
      },
      "name" : "ValueSet per  specialita PractitionerRole",
      "description" : "Contiene la lista di codici da utilizzare per le specialità del PractitionerRole",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/specialita-mediche"
      },
      "name" : "ValueSet Specialità Mediche",
      "description" : "Insieme di valori che include tutte le specialità mediche definite nel CodeSystem.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/VsCatalogoNazionalePrestazioni"
      },
      "name" : "ValueSet for Codesystem catalogo nazionale prestazioni",
      "description" : "Includes all codes from Codesystem catalogo nazionale prestazioni",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ValueSetCatalogoNazionalePrestazioni"
      },
      "name" : "ValueSet per Catalogo Nazionale Prestazioni",
      "description" : "Contiene la lista di codici da utilizzare per le prestazioni secondo il catalogo nazionale",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/diagnosi-icd9cm"
      },
      "name" : "Diagnosi ICD-9-CM - Tutti i codici",
      "description" : "ValueSet contenente tutti i codici dal CodeSystem ICD-9-CM delle Diagnosi.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/istat-dug"
      },
      "name" : "ISTAT - DUG",
      "description" : "ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG)",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/VstipoIdentificatore"
      },
      "name" : "Tipo identificatore",
      "description" : "Value set che descrivie i diversi tipi di identificatori. Include i codici della tabella http://terminology.hl7.org/CodeSystem/v2-0203 piu' 'STP' ed 'ENI'",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vsTipologiaDocumentale"
      },
      "name" : "VS - Tipologia documentale",
      "description" : "Codici LOINC dei documenti",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/tipologia-piano"
      },
      "name" : "ValueSet_TipologiaPiano",
      "description" : "ValueSet contenente tutti i codici per definire la tipologia del piano.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/TipologiaAttivitaPianoDiTelemonitoraggio"
      },
      "name" : "Tipologia di attività nel Piano di Telemonitoraggio",
      "description" : "ValueSet contenente la tipologia di attività inserite nel piano di Telemonitoraggio.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vs-tipo-ricetta"
      },
      "name" : "ValueSet per Codici Assistenza Stranieri",
      "description" : "Contiene tutti i codici dal sistema di classificazione per l’assistenza a stranieri in temporaneo soggiorno.",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/minsan-asl"
      },
      "name" : "MDS - ASL",
      "description" : "MDS - ASL",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/minsan-idStrutture"
      },
      "name" : "Ministero della Salute - ID Strutture Ricovero",
      "description" : "Ministero della Salute - Identificativi Strutture Ricovero (HSP11)",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/minsan-idAziendeOspedaliere"
      },
      "name" : "Ministero della Salute - ID Aziende Ospedaliere",
      "description" : "Ministero della Salute - Aziende Ospedaliere (HSP11)",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/minsan-idStruttureInterne"
      },
      "name" : "Ministero della Salute - ID Strutture Interne di Ricovero",
      "description" : "Ministero della Salute - Identificativi Strutture Interne di Ricovero",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vs-anagrafi-regionali"
      },
      "name" : "VS-Anagrafi Regionali",
      "description" : "VS-Anagrafi Regionali",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/ValuesetMinisteroSaluteidASL"
      },
      "name" : "Valueset Ministero della Salute - ID ASL",
      "description" : "Ministero della Salute - Identificativi ASL (FLS11) [attivi e ritirati] ereditati da Hl7.it",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/tipoCertificatore"
      },
      "name" : "Tipo certificatore",
      "description" : "Tipo di Entità (organizzazione o persona) che ha certificato un certo record",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/vs-uri-id-eni"
      },
      "name" : "VS - URI Identificativo ENI",
      "description" : "ValueSet dei sistemi di identificazione (URI) utilizzabili per il codice ENI (Europeo Non Iscritto al SSN).",
      "exampleBoolean" : false,
      "groupingId" : "GroupD"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/csAmbitoTelemedicina"
      },
      "name" : "CodeSystem per gli ambiti della telemedicina",
      "description" : "Definisce il sistema di terminologie da usare per i codici degli ambiti di telemedicina",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/csspecialityPractitionerRole"
      },
      "name" : "CodeSystem per specialita PractitionerRole",
      "description" : "Definisce il sistema di terminologie da usare per i codici delle specialità cliniche e delle discipline ospedaliere. (19A00915) (GU Serie Generale n.38 del 14-02-2019)",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/branca-prestazione"
      },
      "name" : "Branca Prestazione",
      "description" : "CodeSystem contenente le branche.",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/CsCatalogoNazionalePrestazioni"
      },
      "name" : "Codesystem catalogo nazionale prestazioni",
      "description" : "Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/CodesystemCatalogoNazionalePrestazioni"
      },
      "name" : "Codesystem catalogo nazionale prestazioni",
      "description" : "Definisce il sistema di terminologie da usare per i codici prestazione definiti dal catalogo nazionale",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/diagnosi-icd9cm"
      },
      "name" : "Codesystem diagnosi ICD-9-CM",
      "description" : "Definisce il sistema di terminologie da usare per le diagnosi secondo ICD-9-CM.",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/dug"
      },
      "name" : "ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG)",
      "description" : "ISTAT - Registro delle Denominazioni Urbanistiche Generiche (DUG)",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/cs-mds-idStruttureInterne"
      },
      "name" : "MDS - ID Strutture Interne di Ricovero",
      "description" : "MDS - Identificativi Strutture Interne di Ricovero",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/CodesystemMinisteroSaluteASL"
      },
      "name" : "Ministero della Salute - ASL",
      "description" : "Definisce il sistema di terminologie da usare per il codice ASL ereditato da Hl7.it",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/csTipologiaPiano"
      },
      "name" : "CodeSystem per la tipologia del piano",
      "description" : "Definisce il sistema di terminologie da usare per i codici delle tipologie di piano",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/cs-tipo-ricetta"
      },
      "name" : "Codici Assistenza per Stranieri",
      "description" : "Codici identificativi per tipologie di assistenza a stranieri in temporaneo soggiorno, secondo classificazioni italiane ed europee.",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/cs-asl"
      },
      "name" : "Ministero della Salute - ASL",
      "description" : "Ministero della Salute - ASL",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/minsan-hsp"
      },
      "name" : "MDS - Strutture di Ricovero",
      "description" : "Ministero della Salute - Strutture di Ricovero",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/it-identifier-type"
      },
      "name" : "HL7 Italia - Tipi di identificatore",
      "description" : "Estensione (codici addizionali) alla tabella  per i tipi di identificatore",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/it-tipoEntita"
      },
      "name" : "HL7 Italia - Tipo di Entità",
      "description" : "Codifica delle diverse entità che hanno compiuto, compiono od intendono compiere un certo atto. Per esempio la certificazione di un record Paziente",
      "exampleBoolean" : false,
      "groupingId" : "GroupE"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/RefertoDiTelevisita"
      },
      "name" : "Referto di Televisita Pneumologica - Maria Rossi",
      "description" : "Bundle di tipo document contenente il referto completo della televisita pneumologica di Maria Rossi del 16/06/2025. Include tutte le risorse cliniche e amministrative: composition, paziente, professionista, encounter, allergie, terapie, osservazioni, prestazioni e allegati.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertodiTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/RefertoDiTelevisitaTransaction"
      },
      "name" : "Referto di Televisita Pneumologica - Maria Rossi (Transaction)",
      "description" : "Bundle di tipo transaction contenente il referto completo della televisita pneumologica di Maria Rossi del 16/06/2025. Le risorse amministrative (Patient, Practitioner, PractitionerRole, Organization) sono inviate con PUT e identifier-based URL per garantire idempotenza; le risorse cliniche (Composition, Encounter, Observation, Procedure, AllergyIntolerance, MedicationStatement, MedicationRequest, ServiceRequest, Appointment) sono inviate con POST.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/BundleRefertoDiTelevisitaTransaction",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/aa011502-6ad2-430b-a439-01dddc36fd4e"
      },
      "name" : "Referto di Televisita Pneumologica - Maria Rossi",
      "description" : "Compositiondel referto clinico della televisita pneumologica di Maria Rossi del 16/06/2025, condotta dal Dr. Marco Ferrari (Pneumologo) presso la U.O. Pneumologia dell'Ospedale Sandro Pertini, ASL Roma 1. Firmata digitalmente dallo stesso specialista.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
      },
      "name" : "Paziente - Maria Rossi",
      "description" : "Maria Rossi, paziente di sesso femminile nata il 01/05/1971, residente a Milano (CF: RSSMRA71E41F205E). Affetta da bronchite cronica nota e allergia alla penicillina. Soggetto della televisita pneumologica del 16/06/2025.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      }],
      "reference" : {
        "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
      },
      "name" : "Specialista - Dr. Marco Ferrari",
      "description" : "Dr. Marco Ferrari, medico specialista in Pneumologia (CF: FRRMRC75T10H501K). Erogatore della televisita pneumologica del 16/06/2025 presso la U.O. Pneumologia dell'Ospedale Sandro Pertini.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      }],
      "reference" : {
        "reference" : "PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42"
      },
      "name" : "Ruolo - Dr. Marco Ferrari, Pneumologo ASL Roma 1",
      "description" : "Ruolo professionale del Dr. Marco Ferrari come Pneumologo (specialità #38) presso la U.O. Pneumologia dell'Ospedale Sandro Pertini, ASL Roma 1. Autore e firmatario del referto di televisita.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
      },
      "name" : "Televisita Pneumologica - Maria Rossi 16/06/2025",
      "description" : "Incontro virtuale (classe VR) di natura pneumologica erogato il 16/06/2025 dalle 09:00 alle 09:45. Basato sulla richiesta del MMG (ServiceRequest AAZ123456789) e prenotato tramite Appointment. Struttura erogatrice: ASL Roma 1.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Appointment"
      }],
      "reference" : {
        "reference" : "Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908"
      },
      "name" : "Appuntamento Televisita Pneumologica - Maria Rossi",
      "description" : "Prenotazione della televisita pneumologica per Maria Rossi, schedulata il 16/06/2025 dalle 09:00 alle 09:45, erogata dal Dr. Marco Ferrari. Creata il 02/06/2025 su richiesta del MMG.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/AppointmentTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      }],
      "reference" : {
        "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
      },
      "name" : "Richiesta Televisita Pneumologica - Maria Rossi",
      "description" : "Richiesta di televisita pneumologica (NRE: AAZ123456789) inviata dal Medico di Medicina Generale per Maria Rossi, motivata da follow-up per bronchite cronica (SNOMED 13645005). Redatta il 02/06/2025, con data prevista di erogazione 16/06/2025.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ServiceRequestTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AllergyIntolerance"
      }],
      "reference" : {
        "reference" : "AllergyIntolerance/1360bd6a-3855-48d3-aa33-96a9d961bb94"
      },
      "name" : "Allergia - Penicillina (Maria Rossi)",
      "description" : "Allergia alla penicillina (SNOMED 91936005) documentata per Maria Rossi, clinicamente attiva e verificata. Rilevata in fase di inquadramento clinico iniziale durante la televisita.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a"
      },
      "name" : "Terapia in atto - Beclometasone 100 mcg (Maria Rossi)",
      "description" : "Terapia farmacologica in atto di Maria Rossi al momento della televisita: Beclometasone dipropionato 100 mcg spray inalatorio (ATC R03BA01), assunto come terapia inalatoria di mantenimento per bronchite cronica dall'01/01/2025.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f"
      },
      "name" : "Proposta Terapeutica - Acetilcisteina 600 mg",
      "description" : "Proposta terapeutica del Dr. Marco Ferrari al termine della televisita: Acetilcisteina 600 mg granulato effervescente (ATC R05CB01), mucolitico indicato a supporto della gestione della bronchite cronica di Maria Rossi.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f"
      },
      "name" : "Esempio di Televisita Pneumologica",
      "description" : "Esempio di istanza ProcedureTelevisita per una televisita pneumologica di controllo (codice 89.01.L). Include tutti gli elementi previsti dal profilo: stato, codice, soggetto, incontro, periodo, operatore, estensione modalità, motivazione, esito, referto e note.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/7cbbe77d-dcdb-409b-a215-6361ad7873d5"
      },
      "name" : "Quesito Diagnostico - Tosse persistente post-COVID",
      "description" : "Quesito diagnostico formulato dal MMG: tosse persistente post-COVID (ICD-9 786.2). Motivo clinico della richiesta di televisita pneumologica per Maria Rossi.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/84f911ee-b09d-4325-a3f3-a973a0c5ad8f"
      },
      "name" : "Anamnesi - Maria Rossi",
      "description" : "Anamnesi raccolta durante la televisita pneumologica del 16/06/2025: bronchite cronica nota, non fumatrice. Raccolta dal Dr. Marco Ferrari in modalità remota.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/c2a2b1ea-9d7e-41b9-83a5-cc2e71c0b865"
      },
      "name" : "Esame Obiettivo Remoto - Maria Rossi",
      "description" : "Esame obiettivo rilevato durante la televisita pneumologica del 16/06/2025: tosse secca intermittente segnalata dalla paziente durante la videochiamata con il Dr. Marco Ferrari.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/9dfdf0c9-a837-42d5-987c-6170c75cc476"
      },
      "name" : "Esami Precedenti - TC Torace 10/05/2025",
      "description" : "TC torace eseguita il 10/05/2025, precedente alla televisita. Risultato: negativa per lesioni polmonari evolutive, con lieve ispessimento peribronchiale compatibile con bronchite cronica. Portata in rassegna dal Dr. Marco Ferrari.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/ecc5c95f-a1c0-483c-b48e-5fd84762c393"
      },
      "name" : "Confronto Esami - Miglioramento quadro bronchiolitico",
      "description" : "Confronto con i precedenti esami del paziente effettuato dal Dr. Marco Ferrari: lieve miglioramento del quadro bronchiolitico rispetto al controllo precedente, senza segni di progressione.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/a465cf01-05e6-4f38-8f6a-b5d6c4168c94"
      },
      "name" : "Referto Televisita Pneumologica - Maria Rossi",
      "description" : "Referto clinico redatto dal Dr. Marco Ferrari al termine della televisita pneumologica: sintomi respiratori in lieve miglioramento, assenza di complicanze, terapia inalatoria confermata.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/1729dcef-ac19-434b-82e7-b6e6e51e74b3"
      },
      "name" : "Diagnosi - Bronchite Cronica Mucopurulenta (ICD-9 491.1)",
      "description" : "Diagnosi formulata dal Dr. Marco Ferrari: bronchite cronica mucopurulenta (ICD-9 491.1) in fase stabile, con sintomatologia respiratoria lieve (tosse secca persistente) e buona risposta alla terapia inalatoria in corso.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/1611ed98-7577-48ab-9587-7ab4fc96e191"
      },
      "name" : "Conclusioni Televisita - Monitoraggio consigliato",
      "description" : "Conclusioni della televisita pneumologica del 16/06/2025: buona risposta al trattamento inalatorio. Il Dr. Marco Ferrari raccomanda monitoraggio periodico e spirometria di controllo tra 3 mesi.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/2054e65c-2012-4286-aac7-ce2f23e8be31"
      },
      "name" : "Suggerimenti al MMG - Spirometria di controllo",
      "description" : "Suggerimenti del Dr. Marco Ferrari per il Medico di Medicina Generale di Maria Rossi: valutare spirometria di controllo entro 3 mesi per monitoraggio della funzionalità respiratoria.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/1b401b53-f564-4730-bb13-45d5620596f0"
      },
      "name" : "Accertamenti Consigliati - Emogasanalisi domiciliare",
      "description" : "Accertamenti diagnostici consigliati dal Dr. Marco Ferrari a seguito della televisita: controllo emogasanalisi a domicilio per monitoraggio dei parametri respiratori di Maria Rossi.",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      }],
      "reference" : {
        "reference" : "DocumentReference/4f6c71e1-cc6e-4428-ae9b-0118c0a928cb"
      },
      "name" : "Allegato - TC Torace 10/05/2025 (Maria Rossi)",
      "description" : "Referto della TC torace eseguita il 10/05/2025 allegato alla televisita pneumologica come documento di riferimento clinico, in formato PDF.",
      "exampleBoolean" : true,
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/asl-roma-1"
      },
      "name" : "ASL Roma 1",
      "description" : "Esempio di Azienda Sanitaria Locale (ASL)",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/osp-pertini"
      },
      "name" : "Presidio Sandro Pertini",
      "description" : "Presidio ospedaliero facente parte di ASL Roma 1",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2",
      "groupingId" : "GroupF"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/uo-cardiologia-pertini"
      },
      "name" : "U.O. Pneumologia - Ospedale Pertini",
      "description" : "Unità Operativa di Pneumologia afferente all'Ospedale Pertini",
      "exampleCanonical" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3",
      "groupingId" : "GroupF"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "scenario.html"
        }],
        "nameUrl" : "scenario.html",
        "title" : "Scenario",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "RefertoDiTelevisita.html"
        }],
        "nameUrl" : "RefertoDiTelevisita.html",
        "title" : "Modello Funzionale",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "modelmap.html"
        }],
        "nameUrl" : "modelmap.html",
        "title" : "Mapping verso i Profili",
        "generation" : "html",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-composition.html"
          }],
          "nameUrl" : "map-composition.html",
          "title" : "Composition - Referto di Televisita",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-patient.html"
          }],
          "nameUrl" : "map-patient.html",
          "title" : "Patient - Paziente",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-encounter.html"
          }],
          "nameUrl" : "map-encounter.html",
          "title" : "Encounter - Sessione di Televisita",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-appointment.html"
          }],
          "nameUrl" : "map-appointment.html",
          "title" : "Appointment - Appuntamento",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-servicerequest.html"
          }],
          "nameUrl" : "map-servicerequest.html",
          "title" : "ServiceRequest - Richiesta",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-allergy.html"
          }],
          "nameUrl" : "map-allergy.html",
          "title" : "AllergyIntolerance - Allergie",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-medicationrequest.html"
          }],
          "nameUrl" : "map-medicationrequest.html",
          "title" : "MedicationRequest - Terapia Consigliata",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-procedure.html"
          }],
          "nameUrl" : "map-procedure.html",
          "title" : "Procedure - Prestazioni",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "map-organization.html"
          }],
          "nameUrl" : "map-organization.html",
          "title" : "Organization - Struttura Erogatrice",
          "generation" : "html"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
