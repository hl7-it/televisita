# Televisita Pneumologica - Maria Rossi 16/06/2025 - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Televisita Pneumologica - Maria Rossi 16/06/2025**

## Example Encounter: Televisita Pneumologica - Maria Rossi 16/06/2025

Profile: [Encounter Televisita](StructureDefinition-EncounterTelevisita.md)

**identifier**: `http://hl7.it/fhir/televisita/sid/codiceNosologico`/POD.123e4567-e89b-12d3-a456-426614174000

**status**: Finished

**class**: [ActCode: VR](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActCode.html#v3-ActCode-VR) (Virtual)

**priority**: routine

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**basedOn**: [ServiceRequest: identifier = AAZ123456789; requisition = REQ-20250616-0001; status = active; intent = order; category = Pneumologia; priority = routine; occurrence[x] = 2025-06-16 09:00:00+0200; authoredOn = 2025-06-02 09:15:00+0200; reasonCode = Chronic obstructive lung disease; note = Prestazione da eseguire in modalità remota tramite piattaforma XTelemed](ServiceRequest-d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc.md)

### Participants

| | |
| :--- | :--- |
| - | **Individual** |
| * | [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md) |

**appointment**: [Appointment: identifier = TV-20250616-001; status = booked; serviceCategory = Counselling; reasonCode = Chronic obstructive lung disease; start = 2025-06-16 09:00:00+0200; end = 2025-06-16 09:45:00+0200; created = 2025-06-02 09:00:00+0200](Appointment-9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908.md)

**period**: 2025-06-16 09:00:00+0200 --> 2025-06-16 09:45:00+0200

**serviceProvider**: [Organization ASL Roma 1](Organization-asl-roma-1.md)



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
  },
  "identifier" : [{
    "system" : "http://hl7.it/fhir/televisita/sid/codiceNosologico",
    "value" : "POD.123e4567-e89b-12d3-a456-426614174000"
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "VR",
    "display" : "Virtual"
  },
  "priority" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActPriority",
      "code" : "R",
      "display" : "routine"
    }]
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/d3f1a9b0-8c3d-4e8f-b2e2-59d8b02a6fdc"
  }],
  "participant" : [{
    "individual" : {
      "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
    }
  }],
  "appointment" : [{
    "reference" : "Appointment/9c7e5f13-47bd-4a0a-a6bb-c9e39fd3a908"
  }],
  "period" : {
    "start" : "2025-06-16T09:00:00+02:00",
    "end" : "2025-06-16T09:45:00+02:00"
  },
  "serviceProvider" : {
    "reference" : "Organization/asl-roma-1"
  }
}

```
