# VS - URI Identificativo ENI - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VS - URI Identificativo ENI**

## ValueSet: VS - URI Identificativo ENI 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ValueSet/vs-uri-id-eni | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:VsUriIdEni |

 
ValueSet dei sistemi di identificazione (URI) utilizzabili per il codice ENI (Europeo Non Iscritto al SSN). 

 **References** 

* [Patient Televisita](StructureDefinition-PatientTelevisita.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vs-uri-id-eni",
  "url" : "http://hl7.it/fhir/televisita/ValueSet/vs-uri-id-eni",
  "version" : "0.2.0",
  "name" : "VsUriIdEni",
  "title" : "VS - URI Identificativo ENI",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "ValueSet dei sistemi di identificazione (URI) utilizzabili per il codice ENI (Europeo Non Iscritto al SSN).",
  "compose" : {
    "include" : [{
      "system" : "urn:ietf:rfc:3986",
      "concept" : [{
        "code" : "http://hl7.it/sid/eni",
        "display" : "Identificativo ENI"
      }]
    }]
  }
}

```
