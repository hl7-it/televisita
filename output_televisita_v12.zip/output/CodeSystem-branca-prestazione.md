# Branca Prestazione - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Branca Prestazione**

## CodeSystem: Branca Prestazione (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:BrancaPrestazione |

 
CodeSystem contenente le branche. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [SpecialitaMedicheVS](ValueSet-specialita-mediche.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "branca-prestazione",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/branca-prestazione",
  "version" : "0.2.0",
  "name" : "BrancaPrestazione",
  "title" : "Branca Prestazione",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "CodeSystem contenente le branche.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 26,
  "concept" : [{
    "code" : "01",
    "display" : "Anestesia"
  },
  {
    "code" : "02",
    "display" : "Cardiologia"
  },
  {
    "code" : "03",
    "display" : "Chirurgia generale"
  },
  {
    "code" : "04",
    "display" : "Chirurgia plastica"
  },
  {
    "code" : "05",
    "display" : "Chirurgia vascolare – Angiologia"
  },
  {
    "code" : "06",
    "display" : "Dermosifilopatia"
  },
  {
    "code" : "07",
    "display" : "Diagnostica per immagini - Medicina nucleare"
  },
  {
    "code" : "08",
    "display" : "Diagnostica per immagini - Radiologia diagnostica"
  },
  {
    "code" : "09",
    "display" : "Endocrinologia"
  },
  {
    "code" : "10",
    "display" : "Gastroenterologia - Chirurgia ed endoscopia digestiva"
  },
  {
    "code" : "11",
    "display" : "Lab. analisi chimico cliniche e microbiologiche - Microbiologia – Virologia - Anatomia e istologia patologica - GeneticaImmunoematologia e s. trasf."
  },
  {
    "code" : "12",
    "display" : "Medicina fisica e riabilitazione - Recupero e riabilitazione funzionale dei motulesi e neurolesi"
  },
  {
    "code" : "13",
    "display" : "Nefrologia"
  },
  {
    "code" : "14",
    "display" : "Neurochirurgia"
  },
  {
    "code" : "15",
    "display" : "Neurologia"
  },
  {
    "code" : "16",
    "display" : "Oculistica"
  },
  {
    "code" : "17",
    "display" : "Odontostomatologia - Chirurgia maxillo facciale"
  },
  {
    "code" : "18",
    "display" : "Oncologia"
  },
  {
    "code" : "19",
    "display" : "Ortopedia e traumatologia"
  },
  {
    "code" : "20",
    "display" : "Ostetricia e ginecologia"
  },
  {
    "code" : "21",
    "display" : "Otorinolaringoiatria"
  },
  {
    "code" : "22",
    "display" : "Pneumologia"
  },
  {
    "code" : "23",
    "display" : "Psichiatria"
  },
  {
    "code" : "24",
    "display" : "Radioterapia"
  },
  {
    "code" : "25",
    "display" : "Urologia"
  },
  {
    "code" : "26",
    "display" : "Altro"
  }]
}

```
