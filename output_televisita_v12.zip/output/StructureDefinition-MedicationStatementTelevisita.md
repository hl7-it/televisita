# MedicationStatement Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MedicationStatement Televisita**

## Resource Profile: MedicationStatement Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:MedicationStatementTelevisita |

 
Profilo della risorsa MedicationStatement utilizzato per rappresentare la terapia farmacologica in atto nel paziente al momento della televisita, ovvero farmaci già assunti indipendentemente da una prescrizione corrente. 

**Usages:**

* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)
* Examples for this Profile: [MedicationStatement/e62c9f1d-9c0b-4433-853b-06ec5074f19a](MedicationStatement-e62c9f1d-9c0b-4433-853b-06ec5074f19a.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-MedicationStatementTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-MedicationStatementTelevisita.csv), [Excel](StructureDefinition-MedicationStatementTelevisita.xlsx), [Schematron](StructureDefinition-MedicationStatementTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "MedicationStatementTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita",
  "version" : "0.2.0",
  "name" : "MedicationStatementTelevisita",
  "title" : "MedicationStatement Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa MedicationStatement utilizzato per rappresentare la terapia farmacologica in atto nel paziente al momento della televisita, ovvero farmaci già assunti indipendentemente da una prescrizione corrente.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "MedicationStatement",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/MedicationStatement",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "MedicationStatement",
      "path" : "MedicationStatement",
      "short" : "Terapia farmacologica in corso al momento della televisita.",
      "definition" : "Rappresenta un farmaco che il paziente sta assumendo o ha assunto al momento della televisita. A differenza di MedicationRequest (terapia consigliata), questa risorsa descrive la terapia già in atto, raccolta in fase di anamnesi farmacologica."
    },
    {
      "id" : "MedicationStatement.status",
      "path" : "MedicationStatement.status",
      "short" : "Stato della dichiarazione della terapia in atto.",
      "definition" : "Indica lo stato corrente della terapia farmacologica dichiarata. I valori tipici nel contesto della televisita sono: 'active' (terapia in corso), 'completed' (terapia conclusa), 'entered-in-error' (inserita per errore).",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/medication-statement-status|4.0.1"
      }
    },
    {
      "id" : "MedicationStatement.medication[x]",
      "path" : "MedicationStatement.medication[x]",
      "short" : "Farmaco assunto dal paziente.",
      "definition" : "Identificativo del farmaco espresso tramite codice. Il sistema di codifica preferito è AIC (Autorizzazione all'Immissione in Commercio) dell'AIFA oppure ATC, con il nome commerciale o la denominazione comune internazionale (DCI) in `text`.",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "MedicationStatement.medication[x].coding",
      "path" : "MedicationStatement.medication[x].coding",
      "short" : "Codifica del farmaco (es. AIC, ATC, SNOMED CT).",
      "definition" : "Codifica strutturata del farmaco tramite un sistema di codifica standard riconosciuto (AIC, ATC, SNOMED CT).",
      "min" : 1
    },
    {
      "id" : "MedicationStatement.medication[x].coding.system",
      "path" : "MedicationStatement.medication[x].coding.system",
      "short" : "Sistema di codifica del farmaco.",
      "min" : 1
    },
    {
      "id" : "MedicationStatement.medication[x].coding.code",
      "path" : "MedicationStatement.medication[x].coding.code",
      "short" : "Codice del farmaco nel sistema indicato.",
      "min" : 1
    },
    {
      "id" : "MedicationStatement.medication[x].coding.display",
      "path" : "MedicationStatement.medication[x].coding.display",
      "short" : "Descrizione leggibile del farmaco nel sistema di codifica."
    },
    {
      "id" : "MedicationStatement.medication[x].text",
      "path" : "MedicationStatement.medication[x].text",
      "short" : "Denominazione testuale del farmaco (DCI o nome commerciale).",
      "definition" : "Testo in linguaggio naturale che descrive il farmaco, ad esempio il nome commerciale o la denominazione comune internazionale (DCI), utile quando il codice non è disponibile o come integrazione al codice."
    },
    {
      "id" : "MedicationStatement.subject",
      "path" : "MedicationStatement.subject",
      "short" : "Paziente a cui si riferisce la terapia farmacologica in atto.",
      "definition" : "Riferimento al paziente che sta assumendo il farmaco. Deve essere conforme al profilo PatientTelevisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "MedicationStatement.context",
      "path" : "MedicationStatement.context",
      "short" : "Sessione di televisita in cui la terapia è stata rilevata.",
      "definition" : "Riferimento all'Encounter (sessione di televisita) nel corso del quale è stata raccolta l'informazione relativa alla terapia in atto del paziente.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      }]
    },
    {
      "id" : "MedicationStatement.effective[x]",
      "path" : "MedicationStatement.effective[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "MedicationStatement.effective[x]:effectivePeriod",
      "path" : "MedicationStatement.effective[x]",
      "sliceName" : "effectivePeriod",
      "short" : "Periodo di assunzione del farmaco (data inizio – fine).",
      "definition" : "Intervallo temporale nel quale il paziente ha assunto o sta assumendo il farmaco. Utilizzare effectivePeriod quando sono noti sia l'inizio che la fine del trattamento.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "MedicationStatement.effective[x]:effectiveDateTime",
      "path" : "MedicationStatement.effective[x]",
      "sliceName" : "effectiveDateTime",
      "short" : "Data di rilevazione della terapia farmacologica.",
      "definition" : "Data e ora in cui è stata rilevata la terapia in atto, ad esempio nel corso dell'anamnesi farmacologica durante la televisita.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "MedicationStatement.dateAsserted",
      "path" : "MedicationStatement.dateAsserted",
      "short" : "Data in cui la terapia è stata dichiarata o rilevata.",
      "definition" : "Data e ora in cui il medico o il paziente ha dichiarato che il farmaco è in uso. Corrisponde in genere alla data della televisita."
    },
    {
      "id" : "MedicationStatement.informationSource",
      "path" : "MedicationStatement.informationSource",
      "short" : "Fonte dell'informazione sulla terapia farmacologica.",
      "definition" : "Indica chi ha fornito l'informazione relativa alla terapia in atto: il paziente stesso, un familiare (RelatedPerson), il medico curante (PractitionerTelevisita) o il medico nel suo ruolo professionale (PractitionerRoleTelevisita).",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
        "http://hl7.org/fhir/StructureDefinition/RelatedPerson"]
      }]
    },
    {
      "id" : "MedicationStatement.derivedFrom",
      "path" : "MedicationStatement.derivedFrom",
      "short" : "Risorsa da cui deriva questa dichiarazione terapeutica.",
      "definition" : "Riferimento a una o più risorse che hanno generato questa dichiarazione, ad esempio una MedicationRequest precedente o un'altra MedicationStatement proveniente dal Fascicolo Sanitario Elettronico o dal Medico di Medicina Generale."
    },
    {
      "id" : "MedicationStatement.reasonCode",
      "path" : "MedicationStatement.reasonCode",
      "short" : "Motivo clinico dell'assunzione del farmaco.",
      "definition" : "Codice o testo che descrive il motivo clinico per cui il paziente assume il farmaco (es. diagnosi, patologia cronica, sintomo)."
    },
    {
      "id" : "MedicationStatement.reasonReference",
      "path" : "MedicationStatement.reasonReference",
      "short" : "Condizione clinica o osservazione che motiva la terapia.",
      "definition" : "Riferimento a una Condition o ObservationTelevisita che descrive la problematica clinica per cui il farmaco è assunto, consentendo il collegamento strutturato tra terapia in atto e diagnosi.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "MedicationStatement.note",
      "path" : "MedicationStatement.note",
      "short" : "Note sulla terapia farmacologica in atto.",
      "definition" : "Annotazioni aggiuntive in testo libero relative alla terapia in corso, non altrimenti rappresentabili negli elementi strutturati (es. sospensione temporanea, intolleranza pregressa, motivazione del cambio di dose)."
    },
    {
      "id" : "MedicationStatement.dosage",
      "path" : "MedicationStatement.dosage",
      "short" : "Posologia della terapia farmacologica.",
      "definition" : "Descrizione della modalità di assunzione del farmaco: frequenza, via di somministrazione e dose. Può essere espressa in forma testuale (dosage.text) o strutturata."
    },
    {
      "id" : "MedicationStatement.dosage.text",
      "path" : "MedicationStatement.dosage.text",
      "short" : "Descrizione testuale della posologia.",
      "definition" : "Testo libero che descrive le istruzioni di dosaggio, ad esempio '1 compressa da 500 mg due volte al giorno'."
    },
    {
      "id" : "MedicationStatement.dosage.timing",
      "path" : "MedicationStatement.dosage.timing",
      "short" : "Tempistiche di somministrazione.",
      "definition" : "Struttura che descrive la frequenza e il ritmo di somministrazione del farmaco (es. ogni 8 ore, due volte al giorno)."
    },
    {
      "id" : "MedicationStatement.dosage.route",
      "path" : "MedicationStatement.dosage.route",
      "short" : "Via di somministrazione.",
      "definition" : "Specifica la via attraverso cui il farmaco viene somministrato (es. orale, endovenosa, topica)."
    },
    {
      "id" : "MedicationStatement.dosage.doseAndRate",
      "path" : "MedicationStatement.dosage.doseAndRate",
      "short" : "Dosaggio unitario per singola somministrazione.",
      "definition" : "Quantità di farmaco per singola somministrazione e la velocità (rate) di erogazione, se applicabile."
    },
    {
      "id" : "MedicationStatement.dosage.doseAndRate.dose[x]",
      "path" : "MedicationStatement.dosage.doseAndRate.dose[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "MedicationStatement.dosage.doseAndRate.dose[x]:doseQuantity",
      "path" : "MedicationStatement.dosage.doseAndRate.dose[x]",
      "sliceName" : "doseQuantity",
      "short" : "Dose espressa come quantità (es. 400 mg).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/SimpleQuantity"]
      }]
    }]
  }
}

```
