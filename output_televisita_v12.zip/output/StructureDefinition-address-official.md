# IndirizzoUfficiale - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IndirizzoUfficiale**

## Extension: IndirizzoUfficiale 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/address-official | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:OfficialAddress |

Definizione dell'indirizzo inteso come indirizzo 'ufficiale' di quella persona. Il significato di indirizzo 'ufficiale' dipende dal Paese. Questa estensione consente di specificare se questo indirizzo è o non è l'indirizzo ufficiale, oppure di indicare che si tratta dell'indirizzo ufficiale di quel Paese.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Address - ITA](StructureDefinition-AddressItTelemedicina.md)
* Examples for this Extension: [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-address-official.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-address-official.csv), [Excel](StructureDefinition-address-official.xlsx), [Schematron](StructureDefinition-address-official.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "address-official",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official",
  "version" : "0.2.0",
  "name" : "OfficialAddress",
  "title" : "IndirizzoUfficiale",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definizione dell'indirizzo inteso come indirizzo 'ufficiale' di quella persona. Il significato di indirizzo 'ufficiale' dipende dal Paese. Questa estensione consente di specificare se questo indirizzo è o non è l'indirizzo ufficiale, oppure di indicare che si tratta dell'indirizzo ufficiale di quel Paese.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Address"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Official Address",
      "definition" : "This extension allows to specify if this address is or it is not the official address, or to indicate that this is the official address for that country (true assumed)."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.it/fhir/televisita/StructureDefinition/address-official"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "min" : 1,
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
