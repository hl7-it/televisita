# Allergia - Penicillina (Maria Rossi) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Allergia - Penicillina (Maria Rossi)**

## Example AllergyIntolerance: Allergia - Penicillina (Maria Rossi)

Profile: [AllergyIntolerance Televisita](StructureDefinition-AllergyIntoleranceTelevisita.md)

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**code**: Allergy to penicillin

**patient**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)



## Resource Content

```json
{
  "resourceType" : "AllergyIntolerance",
  "id" : "1360bd6a-3855-48d3-aa33-96a9d961bb94",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
      "code" : "confirmed"
    }]
  },
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "91936005",
      "display" : "Allergy to penicillin"
    }]
  },
  "patient" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  }
}

```
