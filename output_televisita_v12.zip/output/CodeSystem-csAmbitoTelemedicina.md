# CodeSystem per gli ambiti della telemedicina - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CodeSystem per gli ambiti della telemedicina**

## CodeSystem: CodeSystem per gli ambiti della telemedicina (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/csAmbitoTelemedicina | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CodeSystem_ambitoTelemedicina |

 
Definisce il sistema di terminologie da usare per i codici degli ambiti di telemedicina 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSet_ambitoTelemedicina](ValueSet-vsAmbitoTelemedicina.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "csAmbitoTelemedicina",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/csAmbitoTelemedicina",
  "version" : "0.2.0",
  "name" : "CodeSystem_ambitoTelemedicina",
  "title" : "CodeSystem per gli ambiti della telemedicina",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definisce il sistema di terminologie da usare per i codici degli ambiti di telemedicina",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 10,
  "concept" : [{
    "code" : "0",
    "display" : "Richiesta Teleconsulto"
  },
  {
    "code" : "1",
    "display" : "Erogazione Teleconsulto"
  },
  {
    "code" : "2",
    "display" : "Relazione collaborativa per il teleconsulto/teleconsulenza"
  },
  {
    "code" : "3",
    "display" : "Relazione finale di Teleassistenza"
  },
  {
    "code" : "4",
    "display" : "Referto Televisita"
  },
  {
    "code" : "5",
    "display" : "Tesserino dispositivi per il Telemonitoraggio"
  },
  {
    "code" : "6",
    "display" : "Piano di Telemonitoraggio"
  },
  {
    "code" : "7",
    "display" : "Piano di Teleassistenza"
  },
  {
    "code" : "8",
    "display" : "Report rilevazioni Telemonitoraggio"
  },
  {
    "code" : "9",
    "display" : "Relazione finale prestazione di Telemonitoraggio/Teleriabilitazione"
  }]
}

```
