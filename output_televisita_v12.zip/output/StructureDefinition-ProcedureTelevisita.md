# Procedure Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Procedure Televisita**

## Resource Profile: Procedure Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ProcedureTelevisita |

 
Profilo della risorsa Procedure utilizzato per rappresentare le prestazioni e le procedure cliniche erogate nel corso della televisita, inclusi codici, periodi di erogazione, modalità esecutive e strumentazione utilizzata. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md) and [Encounter Televisita](StructureDefinition-EncounterTelevisita.md)
* Examples for this Profile: [Procedure/b81d2c4e-5a9f-4c97-90fb-2a3b726b123f](Procedure-b81d2c4e-5a9f-4c97-90fb-2a3b726b123f.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-ProcedureTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ProcedureTelevisita.csv), [Excel](StructureDefinition-ProcedureTelevisita.xlsx), [Schematron](StructureDefinition-ProcedureTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ProcedureTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita",
  "version" : "0.2.0",
  "name" : "ProcedureTelevisita",
  "title" : "Procedure Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Procedure utilizzato per rappresentare le prestazioni e le procedure cliniche erogate nel corso della televisita, inclusi codici, periodi di erogazione, modalità esecutive e strumentazione utilizzata.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Procedure",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Procedure",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Procedure",
      "path" : "Procedure",
      "short" : "Prestazione clinica erogata durante la televisita.",
      "definition" : "Rappresenta una prestazione sanitaria o una procedura clinica eseguita nel corso della televisita, identificata da un codice del Catalogo Nazionale delle Prestazioni, con indicazione del periodo di erogazione e delle modalità di esecuzione."
    },
    {
      "id" : "Procedure.extension",
      "path" : "Procedure.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Procedure.extension:ModalitaEsecuzioneProcedura",
      "path" : "Procedure.extension",
      "sliceName" : "ModalitaEsecuzioneProcedura",
      "short" : "Modalità di esecuzione della procedura operativa.",
      "definition" : "Descrizione della modalità pratica con cui è stata eseguita la procedura operativa nell'ambito della televisita.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/procedure-method|5.3.0"]
      }]
    },
    {
      "id" : "Procedure.identifier",
      "path" : "Procedure.identifier",
      "short" : "Identificativo della prestazione eseguita.",
      "definition" : "Identificativo assegnato alla prestazione o procedura erogata nell'ambito della televisita, utile per la tracciabilità clinica, amministrativa o di rendicontazione."
    },
    {
      "id" : "Procedure.basedOn",
      "path" : "Procedure.basedOn",
      "short" : "Richiesta su cui si basa questa procedura.",
      "definition" : "Riferimento alla risorsa ServiceRequest che contiene i dettagli della richiesta su cui si basa questa procedura di erogazione.",
      "comment" : "I riferimenti DEVONO essere un riferimento a una risorsa FHIR effettiva e DEVONO essere risolvibili. La risoluzione può avvenire tramite recupero dall'URL o trattando un riferimento assoluto come un URL canonico."
    },
    {
      "id" : "Procedure.partOf",
      "path" : "Procedure.partOf",
      "short" : "Prestazione o osservazione di cui questa procedura fa parte.",
      "definition" : "Riferimento a una procedura o osservazione più ampia di cui la prestazione eseguita rappresenta una componente.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure",
        "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Procedure.status",
      "path" : "Procedure.status",
      "short" : "Stato della prestazione eseguita.",
      "definition" : "Stato della procedura o prestazione documentata. Nel contesto della televisita, al termine dell'erogazione il valore atteso è generalmente `completed`.",
      "comment" : "Il codice \"unknown\" non deve essere utilizzato per comunicare altri stati. Il codice \"unknown\" deve essere usato quando si applica uno degli stati, ma il sistema autore non conosce lo stato attuale della procedura.\n\nQuesto elemento è etichettato come modificatore perché lo stato contiene codici che contrassegnano la risorsa come non valida al momento."
    },
    {
      "id" : "Procedure.category",
      "path" : "Procedure.category",
      "short" : "Categoria della procedura operativa eseguita.",
      "definition" : "Classifica la procedura in una categoria clinica. Nel contesto della televisita può indicare la branca specialistica o la tipologia di prestazione erogata."
    },
    {
      "id" : "Procedure.code",
      "path" : "Procedure.code",
      "short" : "Codice della prestazione eseguita.",
      "definition" : "CodeableConcept che contiene i codici identificativi delle tipologie di interventi, come ad esempio i codici del Catalogo Nazionale delle Prestazioni.",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/VsCatalogoNazionalePrestazioni"
      }
    },
    {
      "id" : "Procedure.subject",
      "path" : "Procedure.subject",
      "short" : "Paziente coinvolto nella procedura.",
      "definition" : "Riferimento all'assistito su cui è stata eseguita la procedura.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "Procedure.encounter",
      "path" : "Procedure.encounter",
      "short" : "Incontro di televisita.",
      "definition" : "Riferimento all'Encounter che rappresenta l'incontro clinico durante il quale la prestazione è stata effettivamente erogata.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      }]
    },
    {
      "id" : "Procedure.performed[x]",
      "path" : "Procedure.performed[x]",
      "short" : "Data e ora di esecuzione della procedura.",
      "definition" : "Periodo che contiene la data e l'ora di inizio e fine dell'erogazione della prestazione.",
      "min" : 1,
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "Procedure.recorder",
      "path" : "Procedure.recorder",
      "short" : "Soggetto che registra la prestazione.",
      "definition" : "Professionista sanitario o ruolo professionale che registra la prestazione eseguita nel sistema informativo.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Procedure.performer",
      "path" : "Procedure.performer",
      "short" : "Persone che hanno eseguito la procedura.",
      "definition" : "Elemento ripetibile contenente i riferimenti a chi prende parte alla procedura di intervento e alle tipologie di performance offerte durante la procedura."
    },
    {
      "id" : "Procedure.performer.actor",
      "path" : "Procedure.performer.actor",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1",
        "http://hl7.org/fhir/StructureDefinition/Patient"]
      }]
    },
    {
      "id" : "Procedure.reasonCode",
      "path" : "Procedure.reasonCode",
      "short" : "Motivo clinico della prestazione.",
      "definition" : "Motivo clinico, quesito diagnostico o indicazione che ha determinato l'esecuzione della prestazione nell'ambito della televisita."
    },
    {
      "id" : "Procedure.reasonReference",
      "path" : "Procedure.reasonReference",
      "short" : "Riferimenti clinici che motivano la prestazione.",
      "definition" : "Riferimento a condizioni cliniche, osservazioni, richieste o altri elementi clinici che giustificano l'esecuzione della prestazione.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Condition",
        "http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Procedure.outcome",
      "path" : "Procedure.outcome",
      "short" : "Parametri rilevanti al fine di caratterizzare la procedura.",
      "definition" : "Elemento utilizzato per gestire la relazione del professionista generata al termine dell'erogazione.",
      "comment" : "Se il risultato contiene solo testo narrativo, può essere catturato usando il CodeableConcept.text."
    },
    {
      "id" : "Procedure.outcome.text",
      "path" : "Procedure.outcome.text",
      "short" : "Testo libero per la relazione alla fine della procedura.",
      "definition" : "Testo in linguaggio naturale che descrive l'esito della prestazione. Campo disponibile per la relazione nel caso di Teleconsulto oppure Teleassistenza."
    },
    {
      "id" : "Procedure.report",
      "path" : "Procedure.report",
      "short" : "Referto o documento collegato alla prestazione.",
      "definition" : "Riferimento al documento clinico o al referto prodotto a seguito della prestazione eseguita nell'ambito della televisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita",
        "http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }]
    },
    {
      "id" : "Procedure.note",
      "path" : "Procedure.note",
      "short" : "Note sulla procedura.",
      "definition" : "Informazioni aggiuntive in testo libero relative alla procedura clinica eseguita, non altrimenti rappresentabili negli elementi strutturati."
    },
    {
      "id" : "Procedure.usedReference",
      "path" : "Procedure.usedReference",
      "short" : "Strumentazione utilizzata nel corso della procedura.",
      "definition" : "Riferimento a dispositivi, strumenti, piattaforme o altri elementi utilizzati durante l'erogazione della prestazione, ove rilevanti."
    }]
  }
}

```
