# MedicationRequest - Terapia Consigliata - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **MedicationRequest - Terapia Consigliata**

## MedicationRequest - Terapia Consigliata

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR.

Allegato 1 Telemedicina → Terapia farmacologica consigliata

 Questa pagina illustra come gli elementi informativi relativi alla terapia farmacologica consigliata, previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina", siano rappresentati nel corrispondente profilo FHIR. 

| | | | |
| :--- | :--- | :--- | :--- |
| Codice AIC/ATC farmaco | Codice AIC/ATC del farmaco o dei farmaci consigliato per la terapia farmacologica | MedicationRequest | MedicationRequest.medicationCodeableConcept.coding.code |
| Descrizione terapia farmacologica consigliata | Descrizione della terapia farmacologica consigliata | MedicationRequest | MedicationRequest.medicationCodeableConcept.text |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

