# Mapping verso i Profili - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* **Mapping verso i Profili**

## Mapping verso i Profili

 Le informazioni rappresentate all'interno delle risorse FHIR descritte nella presente guida derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina". Tali elementi costituiscono il riferimento principale per l'identificazione, la strutturazione e la rappresentazione delle informazioni cliniche e amministrative associate ai servizi di telemedicina. La definizione dei profili FHIR e delle relative modalità di scambio è stata effettuata a partire da tali requisiti informativi. 

Informazioni Allegato 1 Telemedicina - Profili FHIR

 Questa pagina illustra la mappatura tra gli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e i profili FHIR utilizzati nella presente Implementation Guide per la rappresentazione del referto di televisita.

Per ciascun elemento informativo vengono riportati:

* l'elemento informativo previsto dal D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina";
* la risorsa, il profilo o il datatype FHIR utilizzato nella presente guida;
* il collegamento ai dettagli della mappatura e alle relative regole di implementazione.

Profili core della guida di Televisita

| | |
| :--- | :--- |
| [ `BundleRefertodiTelevisita` ](StructureDefinition-BundleRefertodiTelevisita.md),[ `CompositionRefertoTelevisita` ](StructureDefinition-CompositionRefertoTelevisita.md) | [Composition Mapping](map-composition.md) |
| [ `ServiceRequestTelevisita` ](StructureDefinition-ServiceRequestTelevisita.md) | [ServiceRequest Mapping](map-servicerequest.md) |

Modelli correlati presenti nella guida di Televisita

| | |
| :--- | :--- |
| [ `PatientTelevisita` ](StructureDefinition-PatientTelevisita.md) | [Patient Mapping](map-patient.md) |
| [ `EncounterTelevisita` ](StructureDefinition-EncounterTelevisita.md) | [Encounter Mapping](map-encounter.md) |
| [ `AppointmentTelevisita` ](StructureDefinition-AppointmentTelevisita.md) | [Appointment Mapping](map-appointment.md) |
| [ `AllergyIntoleranceTelevisita` ](StructureDefinition-AllergyIntoleranceTelevisita.md) | [Allergy Mapping](map-allergy.md) |
| [ `MedicationRequestTelevisita` ](StructureDefinition-MedicationRequestTelevisita.md) | [MedicationRequest Mapping](map-medicationrequest.md) |
| [ `ProcedureTelevisita` ](StructureDefinition-ProcedureTelevisita.md) | [Procedure Mapping](map-procedure.md) |
| [ `OrganizationT1` ](StructureDefinition-OrganizationT1.md),[ `OrganizationT2` ](StructureDefinition-OrganizationT2.md),[ `OrganizationT3` ](StructureDefinition-OrganizationT3.md) | [Organization Mapping](map-organization.md) |

Supporting Models mapped in HL7 Europe Base/Core

