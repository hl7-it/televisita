# CompositionRefertoTelevisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CompositionRefertoTelevisita**

## Resource Profile: CompositionRefertoTelevisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CompositionRefertoTelevisita |

 
Profilo della Composition utilizzata nel contesto della Televisita. Rappresenta il documento clinico strutturato prodotto al termine di una sessione di televisita, includendo tutte le sezioni cliniche e amministrative previste dal D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md)
* Examples for this Profile: [Composition/aa011502-6ad2-430b-a439-01dddc36fd4e](Composition-aa011502-6ad2-430b-a439-01dddc36fd4e.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-CompositionRefertoTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CompositionRefertoTelevisita.csv), [Excel](StructureDefinition-CompositionRefertoTelevisita.xlsx), [Schematron](StructureDefinition-CompositionRefertoTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionRefertoTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita",
  "version" : "0.2.0",
  "name" : "CompositionRefertoTelevisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della Composition utilizzata nel contesto della Televisita. Rappresenta il documento clinico strutturato prodotto al termine di una sessione di televisita, includendo tutte le sezioni cliniche e amministrative previste dal D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition.identifier",
      "path" : "Composition.identifier",
      "short" : "Identificativo univoco del referto di televisita.",
      "definition" : "Identificativo univoco e persistente assegnato al referto di televisita. Consente di referenziare il documento in modo non ambiguo all'interno dei sistemi informativi sanitari."
    },
    {
      "id" : "Composition.type",
      "path" : "Composition.type",
      "short" : "Tipologia del documento clinico.",
      "definition" : "Codifica della tipologia documentale del referto di televisita. Il valore è vincolato al ValueSet VsTipologiaDocumentale che include i codici LOINC previsti per la telemedicina.",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "75496-0",
          "display" : "Telehealth Note"
        }]
      },
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vsTipologiaDocumentale"
      }
    },
    {
      "id" : "Composition.subject",
      "path" : "Composition.subject",
      "short" : "Paziente a cui si riferisce il referto.",
      "definition" : "Riferimento al paziente che ha effettuato la televisita. Deve essere conforme al profilo PatientTelevisita.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "Composition.encounter",
      "path" : "Composition.encounter",
      "short" : "Visita o sessione di televisita a cui il referto è associato.",
      "definition" : "Riferimento all'Encounter che rappresenta la sessione di televisita nel corso della quale è stato prodotto il referto.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/EncounterTelevisita"]
      }]
    },
    {
      "id" : "Composition.date",
      "path" : "Composition.date",
      "short" : "Data e ora di compilazione del referto.",
      "definition" : "Data e ora in cui il referto di televisita è stato redatto o modificato dal medico refertante."
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "short" : "Medico refertante o struttura sanitaria autore del documento.",
      "definition" : "Professionista sanitario (nella sua veste di ruolo) o struttura sanitaria che ha redatto il referto di televisita. In genere corrisponde allo specialista che ha condotto la sessione.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
      }]
    },
    {
      "id" : "Composition.title",
      "path" : "Composition.title",
      "short" : "Titolo del documento di televisita.",
      "definition" : "Titolo leggibile del referto. Il valore è fissato a 'Referto di Televisita'.",
      "patternString" : "Referto di Televisita"
    },
    {
      "id" : "Composition.attester",
      "path" : "Composition.attester",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "mode"
        }],
        "rules" : "open"
      },
      "short" : "Professionisti che attestano la validità del referto.",
      "definition" : "Professionisti che attestano la validità del documento. Se la risorsa è creata a fine documentale uno degli attester dovrebbe essere il firmatario, ovvero chi allega la firma digitale al documento.",
      "min" : 1
    },
    {
      "id" : "Composition.attester:legalAuthenticator",
      "path" : "Composition.attester",
      "sliceName" : "legalAuthenticator",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.attester:legalAuthenticator.mode",
      "path" : "Composition.attester.mode",
      "short" : "Modalità di attestazione: firma legale.",
      "patternCode" : "legal"
    },
    {
      "id" : "Composition.attester:legalAuthenticator.time",
      "path" : "Composition.attester.time",
      "short" : "Data e ora della firma del referto.",
      "definition" : "Data e ora in cui il medico refertante ha firmato digitalmente il documento.",
      "min" : 1
    },
    {
      "id" : "Composition.attester:legalAuthenticator.party",
      "path" : "Composition.attester.party",
      "short" : "Medico firmatario del referto.",
      "definition" : "Riferimento al professionista sanitario (PractitionerRoleTelevisita) che ha apposto la firma legale al referto di televisita.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita",
        "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita"]
      }]
    },
    {
      "id" : "Composition.relatesTo",
      "path" : "Composition.relatesTo",
      "short" : "Documenti clinici correlati al referto.",
      "definition" : "Riferimenti ad altri documenti correlati, ad esempio una precedente versione del referto, una richiesta di consulto o documentazione di sessioni precedenti."
    },
    {
      "id" : "Composition.event.code",
      "path" : "Composition.event.code",
      "short" : "Tipo di attività clinica svolta nella televisita.",
      "definition" : "Codifica dell'evento clinico documentato nel referto. Tipicamente descrive la tipologia di accesso o atto medico effettuato in modalità remota.",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v3-ActCode"
      }
    },
    {
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "code"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Sezioni cliniche e amministrative del referto di televisita.",
      "definition" : "Raccolta strutturata delle sezioni che compongono il referto di televisita. Ciascuna sezione è identificata da un codice LOINC e contiene le risorse cliniche pertinenti.",
      "min" : 2
    },
    {
      "id" : "Composition.section:questitoDiagnostico",
      "path" : "Composition.section",
      "sliceName" : "questitoDiagnostico",
      "short" : "Quesito diagnostico.",
      "definition" : "Sezione contenente il quesito diagnostico posto dal medico prescrittore, ovvero il motivo clinico per cui è stata richiesta la televisita.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:questitoDiagnostico.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29299-5"
        }]
      }
    },
    {
      "id" : "Composition.section:questitoDiagnostico.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale",
      "path" : "Composition.section",
      "sliceName" : "InquadramentoClinicoIniziale",
      "short" : "Inquadramento clinico iniziale del paziente.",
      "definition" : "Sezione che raccoglie le informazioni cliniche rilevanti del paziente al momento della televisita: anamnesi, allergie, terapia in atto ed esame obiettivo.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10164-2"
        }]
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section",
      "path" : "Composition.section.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "code"
        }],
        "rules" : "open"
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:anamnesi",
      "path" : "Composition.section.section",
      "sliceName" : "anamnesi",
      "short" : "Anamnesi del paziente.",
      "definition" : "Sezione contenente la storia clinica del paziente raccolta in occasione della televisita, comprensiva di patologie pregresse e familiarità.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "constraint" : [{
        "key" : "sec-obs-code-match",
        "severity" : "error",
        "human" : "Ogni ObservationNarrative in section.entry deve condividere il code con section.code.",
        "expression" : "entry.reference.resolve().ofType(Observation).empty() or entry.reference.resolve().ofType(Observation).where(code.coding.where(code.exists()).code.intersect(%context.code.coding.where(code.exists()).code).empty()).empty()",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:anamnesi.code",
      "path" : "Composition.section.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11329-0"
        }]
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:anamnesi.entry",
      "path" : "Composition.section.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:allergie",
      "path" : "Composition.section.section",
      "sliceName" : "allergie",
      "short" : "Allergie e intolleranze del paziente.",
      "definition" : "Sezione contenente le allergie e le reazioni avverse note del paziente, rappresentate tramite risorse AllergyIntoleranceTelevisita.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:allergie.code",
      "path" : "Composition.section.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "48765-2"
        }]
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:allergie.entry",
      "path" : "Composition.section.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/AllergyIntoleranceTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:terapiaFarmacologicaInAtto",
      "path" : "Composition.section.section",
      "sliceName" : "terapiaFarmacologicaInAtto",
      "short" : "Terapia farmacologica in corso al momento della televisita.",
      "definition" : "Sezione che elenca i farmaci assunti dal paziente al momento della televisita, rappresentati tramite risorse MedicationStatement.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:terapiaFarmacologicaInAtto.code",
      "path" : "Composition.section.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "10160-0"
        }]
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:terapiaFarmacologicaInAtto.entry",
      "path" : "Composition.section.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:esameObiettivo",
      "path" : "Composition.section.section",
      "sliceName" : "esameObiettivo",
      "short" : "Esame obiettivo rilevato durante la televisita.",
      "definition" : "Sezione contenente i rilievi dell'esame obiettivo effettuato dal medico in modalità remota durante la sessione di televisita.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "constraint" : [{
        "key" : "sec-obs-code-match",
        "severity" : "error",
        "human" : "Ogni ObservationNarrative in section.entry deve condividere il code con section.code.",
        "expression" : "entry.reference.resolve().ofType(Observation).empty() or entry.reference.resolve().ofType(Observation).where(code.coding.where(code.exists()).code.intersect(%context.code.coding.where(code.exists()).code).empty()).empty()",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"
      }]
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:esameObiettivo.code",
      "path" : "Composition.section.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29545-1"
        }]
      }
    },
    {
      "id" : "Composition.section:InquadramentoClinicoIniziale.section:esameObiettivo.entry",
      "path" : "Composition.section.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      }]
    },
    {
      "id" : "Composition.section:precedentiEsamiEseguiti",
      "path" : "Composition.section",
      "sliceName" : "precedentiEsamiEseguiti",
      "short" : "Precedenti esami ed indagini diagnostiche.",
      "definition" : "Sezione contenente i risultati di esami ed indagini diagnostiche precedentemente eseguiti dal paziente e rilevanti per la televisita.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:precedentiEsamiEseguiti.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "30954-2"
        }]
      }
    },
    {
      "id" : "Composition.section:precedentiEsamiEseguiti.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:confrontoPrecedentiEsamiEseguiti",
      "path" : "Composition.section",
      "sliceName" : "confrontoPrecedentiEsamiEseguiti",
      "short" : "Confronto con i precedenti esami eseguiti.",
      "definition" : "Sezione in cui il medico descrive il confronto tra i risultati attuali e i precedenti esami del paziente, evidenziando variazioni clinicamente significative.",
      "min" : 0,
      "max" : "1",
      "constraint" : [{
        "key" : "sec-obs-code-match",
        "severity" : "error",
        "human" : "Ogni ObservationNarrative in section.entry deve condividere il code con section.code.",
        "expression" : "entry.reference.resolve().ofType(Observation).empty() or entry.reference.resolve().ofType(Observation).where(code.coding.where(code.exists()).code.intersect(%context.code.coding.where(code.exists()).code).empty()).empty()",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"
      }]
    },
    {
      "id" : "Composition.section:confrontoPrecedentiEsamiEseguiti.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "93126-1"
        }]
      }
    },
    {
      "id" : "Composition.section:confrontoPrecedentiEsamiEseguiti.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      }]
    },
    {
      "id" : "Composition.section:referto",
      "path" : "Composition.section",
      "sliceName" : "referto",
      "short" : "Referto della televisita.",
      "definition" : "Sezione principale del documento, contenente il referto clinico prodotto dallo specialista al termine della sessione di televisita.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:referto.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "47045-0"
        }]
      }
    },
    {
      "id" : "Composition.section:referto.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:diagnosi",
      "path" : "Composition.section",
      "sliceName" : "diagnosi",
      "short" : "Diagnosi formulata dallo specialista.",
      "definition" : "Sezione contenente la diagnosi o il quadro clinico formulato dallo specialista al termine della televisita, codificato secondo i sistemi previsti (es. ICD-9-CM).",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:diagnosi.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "29548-5"
        }]
      }
    },
    {
      "id" : "Composition.section:diagnosi.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:conclusioni",
      "path" : "Composition.section",
      "sliceName" : "conclusioni",
      "short" : "Conclusioni cliniche della televisita.",
      "definition" : "Sezione contenente le conclusioni dello specialista al termine della sessione, incluso il giudizio clinico complessivo e le indicazioni per il follow-up.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:conclusioni.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55110-1"
        }]
      }
    },
    {
      "id" : "Composition.section:conclusioni.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:suggerimentiPerMedicoPrescrittore",
      "path" : "Composition.section",
      "sliceName" : "suggerimentiPerMedicoPrescrittore",
      "short" : "Suggerimenti dello specialista per il medico prescrittore.",
      "definition" : "Sezione contenente le indicazioni e raccomandazioni che lo specialista trasmette al medico di medicina generale o al medico prescrittore in esito alla televisita.",
      "min" : 0,
      "max" : "1",
      "constraint" : [{
        "key" : "sec-obs-code-match",
        "severity" : "error",
        "human" : "Ogni ObservationNarrative in section.entry deve condividere il code con section.code.",
        "expression" : "entry.reference.resolve().ofType(Observation).empty() or entry.reference.resolve().ofType(Observation).where(code.coding.where(code.exists()).code.intersect(%context.code.coding.where(code.exists()).code).empty()).empty()",
        "source" : "http://hl7.it/fhir/televisita/StructureDefinition/CompositionRefertoTelevisita"
      }]
    },
    {
      "id" : "Composition.section:suggerimentiPerMedicoPrescrittore.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "62385-0"
        }]
      }
    },
    {
      "id" : "Composition.section:suggerimentiPerMedicoPrescrittore.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisitaNarrative"]
      }]
    },
    {
      "id" : "Composition.section:accertamentiControlliConsigliati",
      "path" : "Composition.section",
      "sliceName" : "accertamentiControlliConsigliati",
      "short" : "Accertamenti e controlli consigliati.",
      "definition" : "Sezione contenente gli esami diagnostici, le indagini strumentali o i controlli clinici che lo specialista raccomanda a seguito della televisita.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:accertamentiControlliConsigliati.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "80615-8"
        }]
      }
    },
    {
      "id" : "Composition.section:accertamentiControlliConsigliati.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ObservationTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:terapiaFarmacologicaConsigliata",
      "path" : "Composition.section",
      "sliceName" : "terapiaFarmacologicaConsigliata",
      "short" : "Terapia farmacologica consigliata dallo specialista.",
      "definition" : "Sezione contenente la terapia farmacologica prescritta o consigliata dallo specialista in esito alla televisita, rappresentata tramite risorse MedicationRequestTelevisita.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:terapiaFarmacologicaConsigliata.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "93341-6"
        }]
      }
    },
    {
      "id" : "Composition.section:terapiaFarmacologicaConsigliata.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:prestazioni",
      "path" : "Composition.section",
      "sliceName" : "prestazioni",
      "short" : "Prestazioni specialistiche erogate durante la televisita.",
      "definition" : "Sezione obbligatoria contenente le prestazioni specialistiche erogate nel corso della sessione di televisita, identificate tramite codici del Catalogo Nazionale delle Prestazioni.",
      "min" : 1,
      "max" : "*"
    },
    {
      "id" : "Composition.section:prestazioni.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "62387-6"
        }]
      }
    },
    {
      "id" : "Composition.section:prestazioni.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/ProcedureTelevisita"]
      }]
    },
    {
      "id" : "Composition.section:allegati",
      "path" : "Composition.section",
      "sliceName" : "allegati",
      "short" : "Allegati al referto di televisita.",
      "definition" : "Sezione contenente documenti, immagini o altri file allegati al referto, come referti precedenti, immagini diagnostiche o filmati della sessione.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Composition.section:allegati.code",
      "path" : "Composition.section.code",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "77599-9"
        }]
      }
    },
    {
      "id" : "Composition.section:allegati.entry",
      "path" : "Composition.section.entry",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DocumentReference",
        "http://hl7.org/fhir/StructureDefinition/Binary",
        "http://hl7.org/fhir/StructureDefinition/Media"]
      }]
    }]
  }
}

```
