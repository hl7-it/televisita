# Proposta Terapeutica - Acetilcisteina 600 mg - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Proposta Terapeutica - Acetilcisteina 600 mg**

## Example MedicationRequest: Proposta Terapeutica - Acetilcisteina 600 mg

Profile: [MedicationRequest Televisita](StructureDefinition-MedicationRequestTelevisita.md)

**status**: Active

**intent**: Proposal

**medication**: N-acetilcisteina 600 mg granulato effervescente

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**authoredOn**: 2025-06-16

**requester**: [Practitioner Marco Ferrari ](Practitioner-2b373c5c-0fbf-4167-875b-47ee7fc5cd5d.md)

### DosageInstructions

| | |
| :--- | :--- |
| - | **Text** |
| * | 1 bustina da 600 mg una volta al giorno, discolta in acqua |



## Resource Content

```json
{
  "resourceType" : "MedicationRequest",
  "id" : "9282eb8d-b153-451a-bd0d-437efd13b45f",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita"]
  },
  "status" : "active",
  "intent" : "proposal",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.whocc.no/atc",
      "code" : "R05CB01",
      "display" : "acetylcysteine"
    }],
    "text" : "N-acetilcisteina 600 mg granulato effervescente"
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "authoredOn" : "2025-06-16",
  "requester" : {
    "reference" : "Practitioner/2b373c5c-0fbf-4167-875b-47ee7fc5cd5d"
  },
  "dosageInstruction" : [{
    "text" : "1 bustina da 600 mg una volta al giorno, discolta in acqua"
  }]
}

```
