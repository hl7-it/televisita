# Patient - Paziente - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Patient - Paziente**

## Patient - Paziente

Le informazioni rappresentate nella presente tabella derivano dagli elementi informativi definiti nell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e sono mappate sul corrispondente profilo FHIR.

Allegato 1 Telemedicina → Dati dell'assistito

 Questa pagina illustra come gli elementi informativi relativi all'assistito, previsti dall'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina", siano rappresentati nel corrispondente profilo FHIR. 

| | | | |
| :--- | :--- | :--- | :--- |
| Cognome assistito | Cognome dell'assistito | Patient | Patient.name.family |
| Nome assistito | Nome completo dell'assistito (come risulta in anagrafe) | Patient | Patient.name.given |
| Codice identificativo assistito | Codice Fiscale/STP/ENI/altro che rappresenta l'assistito | Patient | Patient.identifier |
| Sesso assistito | Genere dell'assistito | Patient | Patient.gender |
| Data di nascita assistito | Data di nascita dell'assistito | Patient | Patient.birthDate |
| Comune di nascita assistito | Comune di nascita dell'assistito | Patient | Patient.extension:luogoNascita |
| Indirizzo di residenza dell'assistito | Indirizzo della residenza dell'assistito | Patient | Patient.address.where(use='billing').line |
| CAP residenza assistito | CAP di residenza dell'assistito | Patient | Patient.address.where(use='billing').postalCode |
| Comune di residenza dell'assistito | Comune di residenza dell'assistito | Patient | Patient.address.where(use='billing').city |
| Provincia di residenza dell'assistito | Provincia di residenza dell'assistito | Patient | Patient.address.where(use='billing').district |
| Regione di residenza dell'assistito | Regione di residenza dell'assistito | Patient | Patient.address.where(use='billing').state |
| Stato di residenza dell'assistito | Stato di residenza dell'assistito | Patient | Patient.address.where(use='billing').country |
| Indirizzo di domicilio assistito | Indirizzo del domicilio dell'assistito | Patient | Patient.address.where(use='home').line |
| CAP domicilio assistito | CAP di domicilio dell'assistito | Patient | Patient.address.where(use='home').postalCode |
| Comune di domicilio dell'assistito | Comune di domicilio dell'assistito | Patient | Patient.address.where(use='home').city |
| Recapito telefonico assistito | Recapito telefonico dell'assistito (fisso e/o mobile) | Patient | Patient.telecom.where(system='phone') |
| e-mail assistito | Indirizzo e-mail dell'assistito | Patient | Patient.telecom.where(system='email') |
| PEC assistito | Indirizzo PEC dell'assistito | Patient | Patient.telecom.where(system='email').where(use='work' or extension.exists()) |

 Torna alla panoramica: [Allegato 1 Telemedicina → Profili FHIR](modelmap.md) 

