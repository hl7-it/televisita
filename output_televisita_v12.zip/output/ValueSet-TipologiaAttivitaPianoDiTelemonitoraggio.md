# Tipologia di attività nel Piano di Telemonitoraggio - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Tipologia di attività nel Piano di Telemonitoraggio**

## ValueSet: Tipologia di attività nel Piano di Telemonitoraggio 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/ValueSet/TipologiaAttivitaPianoDiTelemonitoraggio | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:TipologiaAttivitaPianoDiTelemonitoraggio |

 
ValueSet contenente la tipologia di attività inserite nel piano di Telemonitoraggio. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "TipologiaAttivitaPianoDiTelemonitoraggio",
  "url" : "http://hl7.it/fhir/televisita/ValueSet/TipologiaAttivitaPianoDiTelemonitoraggio",
  "version" : "0.2.0",
  "name" : "TipologiaAttivitaPianoDiTelemonitoraggio",
  "title" : "Tipologia di attività nel Piano di Telemonitoraggio",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "ValueSet contenente la tipologia di attività inserite nel piano di Telemonitoraggio.",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "715191006",
        "display" : "Telehealth asthma monitoring (regime/therapy)"
      },
      {
        "code" : "715280009",
        "display" : "Telehealth hypertension monitoring (regime/therapy)"
      },
      {
        "code" : "473199000",
        "display" : "Telehealth monitoring for chronic disease (regime/therapy)"
      },
      {
        "code" : "879780004",
        "display" : "Telehealth monitoring for chronic heart failure (regime/therapy)"
      },
      {
        "code" : "879782007",
        "display" : "Telehealth monitoring for diabetes mellitus (regime/therapy)"
      },
      {
        "code" : "879781000",
        "display" : "Telehealth monitoring for ischemic heart disease (regime/therapy)"
      },
      {
        "code" : "879783002",
        "display" : "Telehealth monitoring for psychological stress (regime/therapy)"
      },
      {
        "code" : "715279006",
        "display" : "Telehealth obesity monitoring (regime/therapy)"
      },
      {
        "code" : "879784008",
        "display" : "Telehealth rehabilitation monitoring (regime/therapy)"
      }]
    }]
  }
}

```
