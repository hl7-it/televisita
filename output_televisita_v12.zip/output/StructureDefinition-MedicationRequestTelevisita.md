# MedicationRequest Televisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MedicationRequest Televisita**

## Resource Profile: MedicationRequest Televisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:MedicationRequestTelevisita |

 
Profilo della risorsa MedicationRequest utilizzato per rappresentare la terapia farmacologica consigliata al termine della televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md)
* Examples for this Profile: [MedicationRequest/9282eb8d-b153-451a-bd0d-437efd13b45f](MedicationRequest-9282eb8d-b153-451a-bd0d-437efd13b45f.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-MedicationRequestTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-MedicationRequestTelevisita.csv), [Excel](StructureDefinition-MedicationRequestTelevisita.xlsx), [Schematron](StructureDefinition-MedicationRequestTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "MedicationRequestTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/MedicationRequestTelevisita",
  "version" : "0.2.0",
  "name" : "MedicationRequestTelevisita",
  "title" : "MedicationRequest Televisita",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa MedicationRequest utilizzato per rappresentare la terapia farmacologica consigliata al termine della televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "script10.6",
    "uri" : "http://ncpdp.org/SCRIPT10_6",
    "name" : "Mapping to NCPDP SCRIPT 10.6"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "MedicationRequest",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/MedicationRequest",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "MedicationRequest",
      "path" : "MedicationRequest",
      "short" : "Terapia farmacologica consigliata nella televisita.",
      "definition" : "Descrive la prescrizione o il consiglio terapeutico farmacologico formulato dal medico specialista al termine della televisita, inclusi il farmaco, il dosaggio, la via e i tempi di somministrazione."
    },
    {
      "id" : "MedicationRequest.status",
      "path" : "MedicationRequest.status",
      "short" : "Stato della richiesta di terapia farmacologica.",
      "definition" : "Stato attuale della MedicationRequest. I valori possibili includono: active, on-hold, cancelled, completed, entered-in-error, stopped, draft, unknown."
    },
    {
      "id" : "MedicationRequest.intent",
      "path" : "MedicationRequest.intent",
      "short" : "Scopo della richiesta (proposta terapeutica).",
      "definition" : "Nel contesto della televisita il valore è impostato a 'proposal', indicando che si tratta di una proposta terapeutica formulata dallo specialista.",
      "patternCode" : "proposal"
    },
    {
      "id" : "MedicationRequest.medication[x]",
      "path" : "MedicationRequest.medication[x]",
      "short" : "Definizione farmaco",
      "definition" : "Identifica il farmaco oggetto delle medication request."
    },
    {
      "id" : "MedicationRequest.subject",
      "path" : "MedicationRequest.subject",
      "short" : "Soggetto per cui è ricchiesta la medication",
      "definition" : "Soggetto per cui è ricchiesta la medication",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PatientTelevisita"]
      }]
    },
    {
      "id" : "MedicationRequest.requester",
      "path" : "MedicationRequest.requester",
      "short" : "Medico che ha formulato la terapia farmacologica.",
      "definition" : "Riferimento al medico specialista (PractitionerRole) che ha formulato la proposta terapeutica farmacologica nel contesto della televisita.",
      "min" : 1
    },
    {
      "id" : "MedicationRequest.dosageInstruction",
      "path" : "MedicationRequest.dosageInstruction",
      "short" : "Istruzioni di dosaggio e somministrazione.",
      "definition" : "Instuzioni di dosaggio e somministrazione"
    },
    {
      "id" : "MedicationRequest.dosageInstruction.timing",
      "path" : "MedicationRequest.dosageInstruction.timing",
      "short" : "Tempistiche di somministrazione del farmaco",
      "definition" : "Tempistiche di somministrazione del farmaco"
    },
    {
      "id" : "MedicationRequest.dosageInstruction.timing.repeat.bounds[x]",
      "path" : "MedicationRequest.dosageInstruction.timing.repeat.bounds[x]",
      "short" : "Range temporale nel quale è valida la posologia.",
      "definition" : "Range temporale nel quale è valida la posologia.",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "MedicationRequest.dosageInstruction.site",
      "path" : "MedicationRequest.dosageInstruction.site",
      "short" : "Sito di somministrazione",
      "definition" : "Sito di somministrazione"
    },
    {
      "id" : "MedicationRequest.dosageInstruction.route",
      "path" : "MedicationRequest.dosageInstruction.route",
      "short" : "Via di somministrazione",
      "definition" : "Via di somministrazione"
    },
    {
      "id" : "MedicationRequest.dosageInstruction.doseAndRate",
      "path" : "MedicationRequest.dosageInstruction.doseAndRate",
      "short" : "Dosaggio e frequenza del farmaco",
      "definition" : "Dosaggio e frequenza del farmaco"
    }]
  }
}

```
