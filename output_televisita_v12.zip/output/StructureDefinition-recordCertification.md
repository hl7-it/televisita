# Certificazione del Record - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Certificazione del Record**

## Extension: Certificazione del Record 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/recordCertification | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:ExtRecordCertification |

Estensione utilizzata per indicare che un'informazione associata (es. codice fiscale, indirizzo di residenza, dati anagrafici) è stata certificata o autocertificata da una specifica entità (persona od organizzazione). Nel contesto della televisita è impiegata per attestare l'autenticità degli identificativi dell'assistito e degli indirizzi riportati nel referto.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Address - ITA](StructureDefinition-AddressItTelemedicina.md) and [Patient Televisita](StructureDefinition-PatientTelevisita.md)
* Examples for this Extension: [Bundle/RefertoDiTelevisita](Bundle-RefertoDiTelevisita.md), [Bundle/RefertoDiTelevisitaTransaction](Bundle-RefertoDiTelevisitaTransaction.md) and [Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-recordCertification.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-recordCertification.csv), [Excel](StructureDefinition-recordCertification.xlsx), [Schematron](StructureDefinition-recordCertification.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "recordCertification",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/recordCertification",
  "version" : "0.2.0",
  "name" : "ExtRecordCertification",
  "title" : "Certificazione del Record",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Estensione utilizzata per indicare che un'informazione associata (es. codice fiscale, indirizzo di residenza, dati anagrafici) è stata certificata o autocertificata da una specifica entità (persona od organizzazione). Nel contesto della televisita è impiegata per attestare l'autenticità degli identificativi dell'assistito e degli indirizzi riportati nel referto.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Address"
  },
  {
    "type" : "element",
    "expression" : "Patient"
  },
  {
    "type" : "element",
    "expression" : "Patient.identifier"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Certificazione del dato da parte di un'entità autorevole.",
      "definition" : "Indica che il dato associato (es. codice fiscale, indirizzo di residenza) è stato certificato da una specifica entità istituzionale o autocertificato dall'assistito. Contiene informazioni sulla data di certificazione e sul soggetto certificante."
    },
    {
      "id" : "Extension.extension:when",
      "path" : "Extension.extension",
      "sliceName" : "when",
      "short" : "Data o periodo di certificazione.",
      "definition" : "Data puntuale o intervallo temporale in cui il dato è stato certificato dall'entità competente.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:when.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:when.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "when"
    },
    {
      "id" : "Extension.extension:when.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "dateTime"
      },
      {
        "code" : "Period"
      }]
    },
    {
      "id" : "Extension.extension:who",
      "path" : "Extension.extension",
      "sliceName" : "who",
      "short" : "Entità che ha effettuato la certificazione.",
      "definition" : "Riferimento all'entità (organizzazione o persona) che ha certificato il dato. Può essere espressa come codice (es. MEF, INPS, Comune) o come riferimento a una risorsa FHIR.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Extension.extension:who.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:who.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "who"
    },
    {
      "id" : "Extension.extension:who.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      },
      {
        "code" : "Reference"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/tipoCertificatore"
      }
    },
    {
      "id" : "Extension.extension:rank",
      "path" : "Extension.extension",
      "sliceName" : "rank",
      "short" : "Ordine di priorità della certificazione.",
      "definition" : "Valore decimale che indica il livello di priorità o affidabilità della certificazione, nei casi in cui siano presenti più certificazioni per lo stesso dato.",
      "min" : 0,
      "max" : "*"
    },
    {
      "id" : "Extension.extension:rank.extension",
      "path" : "Extension.extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.extension:rank.url",
      "path" : "Extension.extension.url",
      "fixedUri" : "rank"
    },
    {
      "id" : "Extension.extension:rank.value[x]",
      "path" : "Extension.extension.value[x]",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.it/fhir/televisita/StructureDefinition/recordCertification"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "max" : "0"
    }]
  }
}

```
