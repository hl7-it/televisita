# Organization T3 - Unità Operativa / Ambulatorio - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization T3 - Unità Operativa / Ambulatorio**

## Resource Profile: Organization T3 - Unità Operativa / Ambulatorio 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3 | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:OrganizationT3 |

 
Profilo della risorsa Organization di tipo 3, utilizzato per rappresentare le unità operative, i reparti e gli ambulatori nel contesto della telemedicina. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Examples for this Profile: [U.O. Pneumologia](Organization-uo-cardiologia-pertini.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-OrganizationT3.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-OrganizationT3.csv), [Excel](StructureDefinition-OrganizationT3.xlsx), [Schematron](StructureDefinition-OrganizationT3.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "OrganizationT3",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT3",
  "version" : "0.2.0",
  "name" : "OrganizationT3",
  "title" : "Organization T3 - Unità Operativa / Ambulatorio",
  "status" : "draft",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa Organization di tipo 3, utilizzato per rappresentare le unità operative, i reparti e gli ambulatori nel contesto della telemedicina.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Organization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Organization",
      "path" : "Organization",
      "short" : "Unità operativa o ambulatorio che eroga la televisita.",
      "definition" : "Rappresenta l'unità organizzativa di terzo livello (unità operativa, reparto, ambulatorio) che eroga direttamente la televisita nell'ambito del presidio (OrganizationT2) e dell'azienda sanitaria (OrganizationT1)."
    },
    {
      "id" : "Organization.identifier",
      "path" : "Organization.identifier",
      "short" : "Codice dell'unità operativa.",
      "definition" : "Identificativi usati per identificare l'unità operativa o ambulatorio su diversi sistemi informativi.",
      "min" : 1
    },
    {
      "id" : "Organization.type",
      "path" : "Organization.type",
      "short" : "Tipo di organizzazione",
      "definition" : "Il tipo di organizzazione di cui si tratta",
      "comment" : "Le organizzazioni possono essere di diversi tipi"
    },
    {
      "id" : "Organization.name",
      "path" : "Organization.name",
      "short" : "Nome dell'organizzazione.",
      "definition" : "Descrizione della Organization"
    },
    {
      "id" : "Organization.address.city",
      "path" : "Organization.address.city",
      "short" : "Comune"
    },
    {
      "id" : "Organization.address.district",
      "path" : "Organization.address.district",
      "short" : "Nome della provincia"
    },
    {
      "id" : "Organization.address.state",
      "path" : "Organization.address.state",
      "short" : "Sotto-unità dello stato (Regione)."
    },
    {
      "id" : "Organization.partOf",
      "path" : "Organization.partOf",
      "short" : "Presidio (T2) di cui questa unità fa parte.",
      "definition" : "Riferimento al presidio ospedaliero o alla struttura di secondo livello (OrganizationT2) alla quale appartiene l'unità operativa o l'ambulatorio.",
      "comment" : "Tale reference assume rilevanza in caso di Organization di tipo poliambulatorio, che è parte di una Organization di tipo asl: in questo caso si può ricorrere ad una reference di tipo logico",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : true
        }],
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT2"]
      }]
    }]
  }
}

```
