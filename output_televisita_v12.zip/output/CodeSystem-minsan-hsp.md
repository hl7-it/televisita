# MDS - Strutture di Ricovero - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MDS - Strutture di Ricovero**

## CodeSystem: MDS - Strutture di Ricovero 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/minsan-hsp | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:CsMDStruttureRicovero |

 
Ministero della Salute - Strutture di Ricovero 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VsMinisteroSaluteIdAziendeOspedaliere](ValueSet-minsan-idAziendeOspedaliere.md)
* [VsMinisteroSaluteIdStrutture](ValueSet-minsan-idStrutture.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "minsan-hsp",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/minsan-hsp",
  "version" : "0.2.0",
  "name" : "CsMDStruttureRicovero",
  "title" : "MDS - Strutture di Ricovero",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Ministero della Salute - Strutture di Ricovero",
  "caseSensitive" : false,
  "content" : "complete",
  "filter" : [{
    "code" : "regione",
    "description" : "Permette di ricercare i codici secondo il codice regionale",
    "operator" : ["="],
    "value" : "code"
  },
  {
    "code" : "comune",
    "description" : "Permette di ricercare i codici secondo il codice comunale",
    "operator" : ["="],
    "value" : "code"
  },
  {
    "code" : "aslTerritoriale",
    "description" : "Permette di ricercare i codici secondo il codice dell'asl territoriale",
    "operator" : ["="],
    "value" : "code"
  },
  {
    "code" : "codiceAzienda",
    "description" : "Permette di ricercare i codici secondo il codice azienda",
    "operator" : ["="],
    "value" : "code"
  },
  {
    "code" : "tipoStruttura",
    "description" : "Permette di ricercare i codici secondo il codice del tipo di struttura",
    "operator" : ["="],
    "value" : "code"
  },
  {
    "code" : "naturaGiuridica",
    "description" : "Permette di ricercare i codici secondo la natura giuridica",
    "operator" : ["="],
    "value" : "code"
  }],
  "property" : [{
    "code" : "regione",
    "description" : "proprietà che identifica la regione di appartenenza delle strutture di ricovero",
    "type" : "string"
  },
  {
    "code" : "comune",
    "description" : "proprietà che identifica il comune di appartenenza delle strutture di ricovero",
    "type" : "string"
  },
  {
    "code" : "aslTerritoriale",
    "description" : "proprietà che identifica l'ASL di appartenenza delle strutture di ricovero",
    "type" : "string"
  },
  {
    "code" : "codiceAzienda",
    "description" : "proprietà che identifica il codice dell'azienda",
    "type" : "string"
  },
  {
    "code" : "tipoStruttura",
    "description" : "proprietà che identifica il tipo di struttura delle strutture di ricovero",
    "type" : "string"
  },
  {
    "code" : "naturaGiuridica",
    "description" : "Proprietà che identifica la natura giurdica delle strutture di ricovero",
    "type" : "string"
  }],
  "concept" : [{
    "code" : "010904",
    "display" : "AZIENDA OSPEDALIERO UNIVERSITARIA S.LUIG",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001171"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010030",
    "display" : "OSPEDALI RIUNITI PINEROLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001191"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010079",
    "display" : "OSPEDALI RIUNITI RIVOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001219"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010614",
    "display" : "CASA DI CURA VILLE AUGUSTA - S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010615",
    "display" : "CASA DI CURA VILLA PATRIZIA - S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001194"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010621",
    "display" : "CASA DI CURA VILLA SERENA - S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001194"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010623",
    "display" : "VILLA PAPA GIOVANNI XXIII",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001189"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010646",
    "display" : "CASA DI CURA VILLA IRIS SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001189"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010651",
    "display" : "CASA DI CURA MADONNA DEI BOSCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010663",
    "display" : "MEDICAL SERVICE S.A.S",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001191"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010017",
    "display" : "OSPEDALE CIVICO CHIVASSO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001082"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010019",
    "display" : "PRESIDI OSPED. RIUNITI A.S.L. 6 CIRIE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001086"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010023",
    "display" : "OSPEDALI RIUNITI DEL CANAVESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001125"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010616",
    "display" : "CASA DI CURA CLINICA EPOREDIESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001125"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010617",
    "display" : "CASA DI CURA VILLE TURINA AMIONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001248"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010622",
    "display" : "CASA DI CURA VILLA IDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001128"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010644",
    "display" : "CASA DI CURA VILLA GRAZIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001237"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010667",
    "display" : "STUDIO MEDICO AURORA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001020"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010891",
    "display" : "BEATA VERGINE CONSOLATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001248"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010922",
    "display" : "FONDAZIONE DEL PIEMONTE PER L'ONCOLOGIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "922"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "010004",
    "display" : "OSPEDALI RIUNITI A.S.L. TO 5",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010618",
    "display" : "CASA DI CURA E RIPOSO S. LUCA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001183"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010620",
    "display" : "CASA DI CURA VILLA DI SALUTE SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001280"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010648",
    "display" : "ADRIANA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010661",
    "display" : "POLICLINICO SAN LUCA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010009",
    "display" : "OSPEDALE UNICO DEL VERCELLESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "002158"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010626",
    "display" : "POLICLINICO DI MONZA SPA - CASA DI CURA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "002158"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010657",
    "display" : "CASA DI CURA CENTRO R.R.F. MONS. LUIGI N",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "002079"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010032",
    "display" : "OSPEDALE DEGLI INFERMI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "096047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010627",
    "display" : "CASA DI CURA SAN GIORGIO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "096080"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010656",
    "display" : "POLICLINICO DI MONZA S.P.A. PRESIDIO CLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "096004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010905",
    "display" : "AZIENDA OSPED. NOVARA E GALLIATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003106"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010921",
    "display" : "FONDAZIONE SALVATORE MAUGERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003166"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "921"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010006",
    "display" : "ISTITUTO SS. TRINITA - BORGOMANERO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010628",
    "display" : "POLICLINICO DI MONZA SPA - PRESIDIO CLIN",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003106"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010630",
    "display" : "CASA DI CURA S.CARLO DI ARONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010649",
    "display" : "HABILITA S.P.A. - PRESIDIO I CEDRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003065"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010660",
    "display" : "CENTRO MEDICO POLISPECIALISTICO AMBULATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010665",
    "display" : "CASA DI CURA VILLA CRISTINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "003103"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010920",
    "display" : "ISTITUTO AUXOLOGICO ITALIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "103049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "920"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010005",
    "display" : "OSPEDALE UNICO PLURISEDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "103050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010629",
    "display" : "CASA DI CURA L'EREMO DI MIAZZINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "103015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010896",
    "display" : "CENTRO ORTOPEDICO DI QUADRANTE - COQ SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "103050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010906",
    "display" : "AZ. OSPEDAL. S. CROCE E CARLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "906"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010124",
    "display" : "PRESIDIO OSPEDALIERO AREA SUD - CN1",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004130"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010126",
    "display" : "PRESIDIO OSPEDALIERO AREA NORD - CN1",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004215"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010633",
    "display" : "ISTITUTO CLIMATICO DI ROBILANTE S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004185"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010634",
    "display" : "CASA DI CURA MONTESERRAT S.R.L",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004040"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010647",
    "display" : "FONDAZIONE ORIZZONTE SPERANZA - ONLUS CA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010659",
    "display" : "S.R.L. TERAPEUTICENTER - ISTITUTO MEDICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010670",
    "display" : "BIOMED SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004089"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010210"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "210"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010038",
    "display" : "OSPEDALE MICHELE FERRERO E PIETRO FERRER",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004238"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010211"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "211"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010631",
    "display" : "CASA DI CURA SAN MICHELE",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010211"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "211"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010632",
    "display" : "CASA DI CURA CITTA' DI BRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010211"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "211"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010635",
    "display" : "CASA DI CURA LA RESIDENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "004196"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010211"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "211"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010008",
    "display" : "OSPEDALI RIUNITI ASL AT",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "005005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010212"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "212"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010639",
    "display" : "CASA DI CURA S. ANNA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "005005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010212"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "212"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010026",
    "display" : "OSPEDALI RIUNITI ASL AL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010213"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "213"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010641",
    "display" : "CASA DI CURA VILLA IGEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010213"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "213"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010642",
    "display" : "CASA DI CURA SANT'ANNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010213"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "213"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010666",
    "display" : "POLICLINICO DI MONZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010213"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "213"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010907",
    "display" : "AZ. SS.ANTONIO E BIAGIO E C.ARRIGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "006003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010213"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "907"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010909",
    "display" : "AOU CITTA' DELLA SALUTE E DELLA SCIENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "909"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010003",
    "display" : "OSPEDALE MARIA VITTORIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010007",
    "display" : "OSPEDALE MARTINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010010",
    "display" : "OSPEDALE OFTALMICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010011",
    "display" : "TORINO NORD EMERGENZA SAN GIOVANNI BOSCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010013",
    "display" : "OSPEDALE AMEDEO DI SAVOIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "010601",
    "display" : "CLINICA PINNA PINTOR SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010603",
    "display" : "CLINICA SANTA CATERINA DA SIENA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010604",
    "display" : "SEDES SAPIENTIAE SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010610",
    "display" : "CASA DI CURA FORNACA DISESSANT",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010611",
    "display" : "VILLA MARIA PIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010612",
    "display" : "CASA DI CURA KOELLIKER OSPEDALINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010653",
    "display" : "PROMEA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010655",
    "display" : "CASA DI CURA CELLINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010662",
    "display" : "MOD CENTRO MEDICO CHIRURGICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010664",
    "display" : "LARC 2 S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010668",
    "display" : "LARC SPA DAY SURGERY TIPO C",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "010892",
    "display" : "PRESIDIO SANITARIO GRADENIGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010893",
    "display" : "PRESIDIO SANITARIO SAN CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010897",
    "display" : "PRESIDIO SANITARIO OSPEDALE COTTOLENGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010898",
    "display" : "PRESIDIO MAJOR",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010999",
    "display" : "AUSILIATRICE DON GNOCCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "010908",
    "display" : "OSPEDALE MAURIZIANO UMBERTO I - TORINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "010"
    },
    {
      "code" : "comune",
      "valueString" : "001272"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "010301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "908"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "020001",
    "display" : "OSPEDALE REGIONALE UMBERTO PARINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "020"
    },
    {
      "code" : "comune",
      "valueString" : "007003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "020101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "020002",
    "display" : "ISAV SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "020"
    },
    {
      "code" : "comune",
      "valueString" : "007063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "020101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030067",
    "display" : "OSPEDALE MAGGIORE DI LODI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "098031"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "709"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030079",
    "display" : "OSPEDALE CIVICO - CODOGNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "098019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "709"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030080",
    "display" : "OSPEDALE ROSSI - CASALPUSTERLENGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "098010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "709"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030083",
    "display" : "OSPEDALE DELMATI - SANT'ANGELO LODIGIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "098050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "709"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030709",
    "display" : "ASST DI LODI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "098031"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "709"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030056",
    "display" : "PRESIDIO OSPED. V. BUZZI - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "703"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030057",
    "display" : "OSPEDALE M. MELLONI - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "703"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030703",
    "display" : "ASST FATEBENEFRATELLI SACCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "703"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030910",
    "display" : "OSPEDALE FATEBENEFRATELLI E OFTALMICO -",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "703"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030916",
    "display" : "OSPEDALE L. SACCO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "703"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030701",
    "display" : "ASST GRANDE OSPEDALE METROPOLITANO NIGUA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "701"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030913",
    "display" : "OSPEDALE CA' GRANDA-NIGUARDA - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "701"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030071",
    "display" : "OSPEDALE S. MARIA DELLE STELLE MELZO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015142"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "708"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030072",
    "display" : "OSPEDALE DI VIZZOLO PREDABISSI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015244"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "708"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030085",
    "display" : "OSPEDALE UBOLDO - CERNUSCO S/NAVIGLIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "708"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030708",
    "display" : "ASST MELEGNANO E DELLA MARTESANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015244"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "708"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030051",
    "display" : "P.O. CITTA' DI SESTO S. GIOVANNI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015209"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "707"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030058",
    "display" : "OSPEDALE BASSINI - CINISELLO BALSAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015077"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "707"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030707",
    "display" : "ASST NORD MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015209"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "707"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030074",
    "display" : "OSPEDALE DI MAGENTA - ABBIATEGRASSO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015130"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "705"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030281",
    "display" : "OSPEDALE DI LEGNANO E CUGGIONO-LEGNANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015118"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "705"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030705",
    "display" : "ASST OVEST MILANESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015118"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "705"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030066",
    "display" : "OSPEDALE G.SALVINI-GARBAGNATE MIL.SE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015105"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "706"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030073",
    "display" : "OSPEDALE DI CIRCOLO - RHO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015182"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "706"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030283",
    "display" : "OSPEDALE G.CASATI-PASSIRANA RHO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015182"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "706"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030706",
    "display" : "ASST RHODENSE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015105"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "706"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030702",
    "display" : "ASST SANTI PAOLO E CARLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "702"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030914",
    "display" : "OSPEDALE S. PAOLO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "702"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030915",
    "display" : "OSPEDALE S. CARLO BORROMEO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "702"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030704",
    "display" : "ASST SPEC.ORT.TRAUMATOLOGICO G.PINI/CTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "704"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030911",
    "display" : "ISTITUTO ORTOPEDICO GAETANO PINI - MILAN",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "704"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030912",
    "display" : "P.O. CENTRO TRAUMATOLOGICO ORTOPEDICO -",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "704"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030096",
    "display" : "CASA DI CURA DEL POLICLINICO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030097",
    "display" : "ISTITUTO CLINICO CITTA' STUDI - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030100",
    "display" : "CASA DI CURA IGEA - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030101",
    "display" : "CASA DI CURA VILLA LETIZIA - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030103",
    "display" : "CASA DI CURA PALAZZOLO-FOND.DON GNOCCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030105",
    "display" : "CASA DI CURA S. CAMILLO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030110",
    "display" : "CASA DI CURA S. GIOVANNI - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030113",
    "display" : "CASA DI CURA LA MADONNINA - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030116",
    "display" : "CLINICA POLISPECIALISTICA SAN CARLO - S.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015166"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030121",
    "display" : "CASA DI CURA S. PIO X - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030124",
    "display" : "ISTITUTO STOMATOLOGICO ITALIANO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030125",
    "display" : "CASA DI CURA AMBROSIANA SPA-CESANO B.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030266",
    "display" : "CASA DI CURA COLUMBUS - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030352",
    "display" : "POLO GERIATRICO RIABILITATIVO-CINISELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015077"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030359",
    "display" : "FONDAZIONE EUROPEA DI RICERCA BIOMEDICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030363",
    "display" : "RESIDENZA ANNI AZZURRI MIRASOLE - OPERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015159"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030367",
    "display" : "OSPEDALE S. GIUSEPPE - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030378",
    "display" : "CENTRO CLINICO NEMO - FOND. SERENA - MIL",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "321"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030934",
    "display" : "CENTRO CARDIOLOGICO FOND. MONZINO - MI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "934"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030925",
    "display" : "FONDAZ.IRCCS CA' GRANDA - OSPEDALE MAGGI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "925"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "030922",
    "display" : "FOND.IRCCS ISTIT.NAZ.LE TUMORIMILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "922"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "030923",
    "display" : "FOND.IRCCS IST.NAZ.NEUROLOGICO C.BESTA-M",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "923"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "030949",
    "display" : "IRCCS IST. SCIENTIFICO DI RIABILITAZIONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "949"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030947",
    "display" : "I.R.C.C.S. POLICLINICO SAN DONATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015192"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "947"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030937",
    "display" : "IRCCS S.M.NASCENTE-FOND.DON C.GNOCCHI-MI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "937"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030935",
    "display" : "IRCCS S. RAFFAELE - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "935"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030936",
    "display" : "IST.AUXOLOGICO ITALIANO - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "936"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030943",
    "display" : "IST. CLIN. HUMANITAS - ROZZANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015189"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "943"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030941",
    "display" : "ISTITUTO EUROPEO DI ONCOLOGIA-MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "941"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030946",
    "display" : "OSPEDALE GALEAZZI SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "946"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030950",
    "display" : "SAN RAFFAELE TURRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015146"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030321"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "950"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030010",
    "display" : "OSPEDALE GALMARINI - TRADATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012127"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "710"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030012",
    "display" : "OSPEDALE CARLO ONDOLI - ANGERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "710"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030282",
    "display" : "PRESIDIO OSPEDALIERO DEL VERBANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "710"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030710",
    "display" : "ASST DEI SETTE LAGHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012133"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "710"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030901",
    "display" : "PRESIDIO OSPEDALIERO DI VARESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012133"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "710"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030004",
    "display" : "OSPEDALE DI CIRCOLO - BUSTO ARSIZIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "711"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030006",
    "display" : "OSP. S. ANTONIO ABATE - GALLARATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "711"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030008",
    "display" : "OSP. GENERALE PROVINCIALE - SARONNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012119"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "711"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030009",
    "display" : "OSPEDALE A.BELLINI - SOMMA LOMBARDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012123"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "711"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030711",
    "display" : "ASST DELLA VALLE OLONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "711"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030022",
    "display" : "UNICO PRESIDIO CANTU' MARIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "712"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030026",
    "display" : "OSPEDALE ERBA- RENALDI - MENAGGIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013145"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "712"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030712",
    "display" : "ASST LARIANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "712"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030902",
    "display" : "OSPEDALE S. ANNA - COMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013206"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "712"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030015",
    "display" : "CASA DI CURA SANTA MARIA - CASTELLANZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030017",
    "display" : "CASA DI CURA MATER DOMINI - CASTELLANZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030029",
    "display" : "OSP.SACRA FAMIGLIA - F.B.F. - ERBA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013095"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030030",
    "display" : "OSPEDALE VALDUCE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030032",
    "display" : "IST.CLINICO VILLA APRICA SPA-COMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030035",
    "display" : "C.O.F. LANZO HOSPITAL - ALTA VALLE INTEL",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013253"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030037",
    "display" : "CASA DI CURA VILLA S. BENEDETTO-ALBESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030038",
    "display" : "CASA DI CURA LE BETULLE-APPIANO GENTILE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030347",
    "display" : "CASA DI CURA VILLA S. GIUSEPPE-ANZANO DE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030364",
    "display" : "FOND. GAETANO E PIERA BORGHI - BREBBIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030372",
    "display" : "SINLAB ITALIA S.R.L. - COMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030388",
    "display" : "IST. RIV. E CURA-GRUPPO ISENI SANITA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012090"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030397",
    "display" : "CASA DI CURA LE TERRAZZE - CUNARDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "322"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030930",
    "display" : "IRCCS CENTRO MEDICO TRADATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "012127"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030322"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "930"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030274",
    "display" : "OSPEDALE VALCAMONICA - ESINE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "714"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030714",
    "display" : "ASST DELLA VALCAMONICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "714"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030042",
    "display" : "OSPEDALE SONDRIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014061"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "713"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030044",
    "display" : "OSPEDALE DI CHIAVENNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "713"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030045",
    "display" : "OSPEDALE MORBEGNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "713"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030713",
    "display" : "ASST DELLA VALTELLINA E DELL'ALTO LARIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014061"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "713"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030904",
    "display" : "OSPEDALE MORELLI - SONDALO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "014060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "713"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030031",
    "display" : "OSP. MORIGGIA PELASCINI - GRAVEDONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "013249"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030323"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "323"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030068",
    "display" : "PRESIDIO OSPEDALIERO DI DESIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "717"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030070",
    "display" : "PRESIDIO OSPEDALIERO DI CARATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "717"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030078",
    "display" : "PRESIDIO OSPEDALIERO DI VIMERCATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "717"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030082",
    "display" : "P.O. TRABATTONI RONZONI DI SEREGNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "717"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030717",
    "display" : "ASST DELLA BRIANZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "717"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030023",
    "display" : "OSPEDALE UMBERTO I - BELLANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "715"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030024",
    "display" : "OSPEDALE DI CIRCOLO S.L.MANDIC-MERATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "715"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030715",
    "display" : "ASST DI LECCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "715"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030903",
    "display" : "OSPEDALE DI CIRCOLO A. MANZONI - LECCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "715"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030033",
    "display" : "CASA DI CURA BEATO L.TALAMONI-LECCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030034",
    "display" : "CASA DI CURA G.B. MANGIONI - LECCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030106",
    "display" : "CASA DI CURA POLICLINICO - MONZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030107",
    "display" : "ISTITUTI CLINICI ZUCCHI SPA-MONZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030108",
    "display" : "CASA DI CURA ZUCCHI - CARATE BRIANZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030109",
    "display" : "CASA DI CURA VILLA BIANCA - LIMBIATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030284",
    "display" : "CENTRO DI RIABIL.VILLA BERETTA-COSTA M",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030417",
    "display" : "ISTITUTI CLINICI SCIENTIFICI MAUGERI - L",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "324"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030926",
    "display" : "FONDAZIONE IRCCS SAN GERARDO DEI TINTORI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "108033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "926"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "030920",
    "display" : "I.N.R.C.A.- PRESIDIO DI CASATENOVO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "920"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030948",
    "display" : "IRCCS MULTIMEDICA - MILANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "015209"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "948"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030931",
    "display" : "ISTITUTO SCIENTIFICO MEDEA-BOSISIO P.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "097009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030324"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "931"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030133",
    "display" : "OSPEDALE PESENTI FENAROLI - ALZANO L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030136",
    "display" : "OSPEDALE BRIOLINI - GAZZANIGA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016111"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030137",
    "display" : "OSP.LE SS.CAPITANIO E GEROSA - LOVERE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016128"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030140",
    "display" : "OSPEDALE BOLOGNINI - SERIATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016198"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030382",
    "display" : "OSPEDALE M. O. ANTONIO LOCATELLI-PIARIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016163"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030720",
    "display" : "ASST DI BERGAMO EST",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016198"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "720"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030131",
    "display" : "OSPEDALE DI TREVIGLIO E CARAVAGGIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016219"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "719"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030138",
    "display" : "OSP.LE SS.TRINITA'-ROMANO DI LOMBARDIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016183"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "719"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030719",
    "display" : "ASST DI BERGAMO OVEST",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016219"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "719"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030132",
    "display" : "OSPEDALE CIVILE - S.GIOVANNI BIANCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016188"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "718"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030718",
    "display" : "ASST PAPA GIOVANNI XXIII",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "718"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030905",
    "display" : "OSPEDALE PAPA GIOVANNI XXIII - BG",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "718"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030143",
    "display" : "HUMANITAS GAVAZZENI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030144",
    "display" : "CASA DI CURA BEATO PALAZZOLO - BERGAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030145",
    "display" : "HUMANITAS CASTELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030146",
    "display" : "CASA DI CURA S. FRANCESCO - BERGAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030147",
    "display" : "POLICLINICO SAN MARCO - OSIO SOTTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016153"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030148",
    "display" : "POLICLINICO SAN PIETRO - PONTE S. PIETR",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016170"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030149",
    "display" : "ISTITUTO CLINICO QUARENGHI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016190"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030337",
    "display" : "VILLA SANT'APOLLONIA S.R.L. - BERGAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030350",
    "display" : "OSPEDALE S.ISIDORO - TRESCORE B.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016218"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030354",
    "display" : "NEPHROCARE S.P.A. - SERIATE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016198"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030356",
    "display" : "ISTITUTO CLINICO HABILITA - CISERANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030360",
    "display" : "FERB-ONLUS C.TRO ALZHEIMER-GAZZANIGA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016111"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030379",
    "display" : "HABILITA IST.CLINICO-OSP.LE DI SARNICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016193"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030384",
    "display" : "C.R.C. MALATTIE RARE ALDO E CELE DACCO'-",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "016178"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030325"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "325"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030159",
    "display" : "PRESIDIO OSPEDALIERO DI MONTICHIARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017113"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "721"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030162",
    "display" : "PRESIDIO OSPEDALIERO GARDONE V.T.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "721"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030167",
    "display" : "OSPEDALE DEI BAMBINI - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "721"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030721",
    "display" : "ASST DEGLI SPEDALI CIVILI DI BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "721"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030906",
    "display" : "PRES.OSPEDAL.SPEDALI CIVILI BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "721"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030156",
    "display" : "OSPEDALE DI DESENZANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017067"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030157",
    "display" : "OSPEDALE CIVILE LA MEMORIA DI GAVARDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017077"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030158",
    "display" : "OSPEDALE DI LENO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017088"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030161",
    "display" : "PRESIDIO OSPEDALIERO DI SALO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017170"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030183",
    "display" : "OSPEDALE VILLA DEI COLLI DI LONATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017092"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030184",
    "display" : "OSPEDALE DI MANERBIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017103"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030723",
    "display" : "ASST DEL GARDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017067"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "723"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030154",
    "display" : "PRESIDIO OSPEDALIERO DI CHIARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "722"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030163",
    "display" : "PRESIDIO OSPEDALIERO DI ISEO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017085"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "722"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030722",
    "display" : "ASST DELLA FRANCIACORTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "722"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030175",
    "display" : "CASA DI CURA S. CAMILLO - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030176",
    "display" : "ISTITUTO CLINICO S. ANNA - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030177",
    "display" : "CASA DI CURA VILLA GEMMA-GARDONE RIV",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030178",
    "display" : "IST.CLIN. CITTA' DI BRESCIA - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030275",
    "display" : "ISTITUTO CLINICO S. ROCCO S.P.A. - OME",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017123"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030294",
    "display" : "CASA DI CURA DOMUS SALUTIS - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030295",
    "display" : "FONDAZIONE POLIAMBULANZA - BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030348",
    "display" : "CASA DI CURA VILLA BARBARANO - SALO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017170"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030362",
    "display" : "RESIDENZA ANNI AZZURRI - REZZATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017161"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030368",
    "display" : "C.TRO RIAB.E.SPALENZA-FOND.DON GNOCCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017166"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030369",
    "display" : "CENTRO MEDICO RICHIEDEI-PALAZZOLO S/O",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017133"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030408",
    "display" : "CENTRO CLINICO NEMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017081"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "326"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030932",
    "display" : "IRCCS CENTRO MEDICO DI LUMEZZANE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017096"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "932"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030942",
    "display" : "IRCCS S.GIOVANNI DI DIO-FBF- BRESCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "017029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030326"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "942"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030209",
    "display" : "OSPEDALE MAGGIORE - CREMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "726"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030215",
    "display" : "OSPEDALE S. MARTA - RIVOLTA D'ADDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019084"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "726"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030726",
    "display" : "ASST DI CREMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "726"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030273",
    "display" : "OSPEDALE OGLIO PO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019021"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "724"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030724",
    "display" : "ASST DI CREMONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "724"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030908",
    "display" : "OSPEDALE DI CREMONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "724"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030227",
    "display" : "PRESIDIO OSPEDALIERO - ASOLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "725"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030239",
    "display" : "OSP.CIVILE DESTRA SECCHIA-PIEVE CORIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020072"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "725"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030725",
    "display" : "ASST DI MANTOVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020030"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "725"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030907",
    "display" : "OSPEDALE C. POMA - MANTOVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020030"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "725"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030217",
    "display" : "CASA DI CURA ANCELLE DELLA CARITA'-CR",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030218",
    "display" : "CASA DI CURA S. CAMILLO - CREMONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030219",
    "display" : "CASA DI CURA FIGLIE DI S.CAMILLO-CR",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "019036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030259",
    "display" : "CASA DI CURA S. CLEMENTE - MANTOVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020030"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030353",
    "display" : "OSPEDALE CIVILE DI VOLTA MANTOVANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030355",
    "display" : "OSPEDALE DI SUZZARA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020065"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030357",
    "display" : "OSP. SAN PELLEGRINO - CASTIGLIONE D/S",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "327"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030933",
    "display" : "IRCCS CENTRO MEDICO DI CASTEL GOFFREDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "020015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030327"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "933"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030190",
    "display" : "OSPEDALE CARLO MIRA-CASORATE PRIMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030191",
    "display" : "OSPEDALE S.MARTINO - MEDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018088"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030192",
    "display" : "OSPEDALE SS.ANNUNZIATA - VARZI",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018171"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030193",
    "display" : "OSPEDALE CIVILE - VIGEVANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018177"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030194",
    "display" : "OSPEDALE CIVILE - VOGHERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018182"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030203",
    "display" : "OSPEDALE ASILO VITTORIA - MORTARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018102"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030383",
    "display" : "NUOVO OSPEDALE DI BRONI E STRADELLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018153"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030727",
    "display" : "ASST DI PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "727"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "030197",
    "display" : "CASA DI CURA VILLA ESPERIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018073"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "328"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030198",
    "display" : "ISTITUTO CLINICO BEATO MATTEO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018177"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "328"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030201",
    "display" : "CASA DI CURA CITTADELLA SOCIALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018113"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "328"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030202",
    "display" : "IST.DI CURA CITTA'DI PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "328"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "030939",
    "display" : "FOND.IST.NEUROL.C.MONDINO-PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "939"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030938",
    "display" : "IRCCS CENTRO MEDICO DI PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "938"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030940",
    "display" : "IRCCS CENTRO MEDICO MONTESCANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018097"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "940"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "030924",
    "display" : "POLICLINICO S. MATTEO - PAVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "030"
    },
    {
      "code" : "comune",
      "valueString" : "018110"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "030328"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "924"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "041001",
    "display" : "OSPEDALE CENTRALE DI BOLZANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041002",
    "display" : "OSPEDALE AZIENDALE DI MERANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041004",
    "display" : "OSPEDALE AZIENDALE DI BRESSANONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041005",
    "display" : "OSPEDALE AZIENDALE DI BRUNICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041006",
    "display" : "OSPEDALE DI BASE DI VIPITENO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021115"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041007",
    "display" : "OSPEDALE DI BASE DI SAN CANDIDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021077"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041011",
    "display" : "OSPEDALE DI BASE DI SILANDRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021093"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "041013",
    "display" : "MARIA Srl impresa sociale",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041014",
    "display" : "CASA DI CURA VILLA SANT'ANNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041015",
    "display" : "CASA DI CURA BONVICINI S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041017",
    "display" : "MELITTAKLINIK 1",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041026",
    "display" : "CASA DI CURA SALUS CENTER SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021099"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041028",
    "display" : "Centro di Chirurgia S.Anna",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041030",
    "display" : "DOLOMITI SPORTCLINIC SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021061"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041031",
    "display" : "Brixsana private clinic GmbH/srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041032",
    "display" : "CITY CLINIC SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041033",
    "display" : "MELITTAKLINIK 2",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "041034",
    "display" : "SANITAS BRUNICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "041"
    },
    {
      "code" : "comune",
      "valueString" : "021013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "041201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "042001",
    "display" : "OSPEDALE DI TRENTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022205"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042004",
    "display" : "PRESIDIO OSPEDALIERO DI BORGO VALSUGANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042005",
    "display" : "PRESIDIO OSPEDALIERO DI CLES",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022062"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042006",
    "display" : "OSPEDALE DI ROVERETO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022161"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042007",
    "display" : "PRESIDIO OSPEDALIERO DI TIONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022199"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042010",
    "display" : "PRESIDIO OSPEDALIERO DI ARCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042014",
    "display" : "PRESIDIO OSPEDALIERO DI CAVALESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "042015",
    "display" : "OSPEDALE SAN CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022205"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "042016",
    "display" : "KOS CARE SRL - U.O. OSP. S.PANCRAZIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "042018",
    "display" : "CASA DI CURA EREMO DI ARCO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "042019",
    "display" : "CASA DI CURA REGINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "042020",
    "display" : "CASA DI CURA SOLATRIX",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022161"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "042022",
    "display" : "CASA DI CURA VILLA BIANCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "042"
    },
    {
      "code" : "comune",
      "valueString" : "022205"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "042101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050149",
    "display" : "GVM CORTINA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "025016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050501"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "501"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050501",
    "display" : "OSPEDALI ULSS 1 DOLOMITI",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "025006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050501"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "501"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050072",
    "display" : "OSPEDALE DI MOTTA DI LIVENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050079",
    "display" : "OSPEDALE CLASSIFICATO SAN CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026086"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050080",
    "display" : "CASA DI CURA PARK VILLA NAPOLEON",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050081",
    "display" : "CASA DI CURA GIOVANNI XXIII",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026044"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050140",
    "display" : "IRCSS MEDEA CONEGLIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026021"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050502",
    "display" : "OSPEDALI DI TREVISO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "026086"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050502"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "502"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050097",
    "display" : "OSP. S.RAFFAELE ARCANG. FATEBENEFRATELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050503"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "503"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050098",
    "display" : "FONDAZIONE VILLA SALUS",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050503"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "503"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050099",
    "display" : "CASA DI CURA POLICLINICO SAN MARCO SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050503"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "503"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050503",
    "display" : "OSPEDALI AZIENDA ULSS N. 3 SERENISSIMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050503"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "503"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050951",
    "display" : "SAN CAMILLO IRCCS SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050503"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "503"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050100",
    "display" : "CASA DI CURA SILENO E ANNA RIZZOLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050504"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "504"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050504",
    "display" : "OSPEDALE AZIENDA U.L.S.S. N.4",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "027033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050504"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "504"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050141",
    "display" : "CASA DI CURA CITTÀ DI ROVIGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "029041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050505"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "505"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050150",
    "display" : "Casa di Cura Santa Maria Maddalena",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "029033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050505"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "505"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050151",
    "display" : "Casa di Cura Madonna della Salute",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "029052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050505"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "505"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050505",
    "display" : "OSPEDALI DI ROVIGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "029041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050505"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "505"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050901",
    "display" : "AZIENDA OSPEDALE - UNIVERSITA' PADOVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050120",
    "display" : "CASA DI CURA DIAZ",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050121",
    "display" : "CASA DI CURA VILLA MARIA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050122",
    "display" : "CASA DI CURA 'TRIESTE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050123",
    "display" : "CASA DI CURA ABANO TERME POLISPEC. E TER",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050124",
    "display" : "CASA DI CURA PARCO DEI TIGLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028089"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050506",
    "display" : "OSPEDALI EUGANEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "506"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050952",
    "display" : "IOV",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "028060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050506"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "952"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050507",
    "display" : "OSPEDALI DI BASSANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050507"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "507"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050045",
    "display" : "CASA DI CURA ERETENIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050508"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "508"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050046",
    "display" : "CASA DI CURA VILLA BERICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050508"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "508"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050047",
    "display" : "CASA DI CURA VILLA MARGHERITA KOS CARE",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050508"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "508"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050508",
    "display" : "OSPEDALI DI VICENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "024116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050508"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "508"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050017",
    "display" : "OSPEDALE SACRO CUORE DON CALABRIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050018",
    "display" : "OSPEDALE CLASSIFICATO VILLA S. GIULIANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050019",
    "display" : "CASA DI CURA CENTRO RIABILIT VERONESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050021",
    "display" : "CASA DI CURA VILLA GARDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050022",
    "display" : "OSPEDALE PEDERZOLI CASA DI CURA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "050023",
    "display" : "CLINICA SAN FRANCESCO SPA - Casa di cura",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050025",
    "display" : "CASA DI CURA VILLA SANTA CHIARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "050509",
    "display" : "OSPEDALI DI LEGNAGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "509"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "050912",
    "display" : "AZ.OSP.UNIVERSITARIA INTEGRATA VERONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "050"
    },
    {
      "code" : "comune",
      "valueString" : "023091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "050509"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "912"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060902",
    "display" : "CENTRO RIFERIMENTO ONCOLOGICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "093004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060040",
    "display" : "CASA DI CURA PRIVATA 'S.GIORGIO' SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "093033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "060041",
    "display" : "Presidio ospedaliero Santa Maria degli A",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "093033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060042",
    "display" : "Presidio ospedaliero San Vito al Tagliam",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "093041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060002",
    "display" : "IST.DI MEDICINA FISICA E RIABILITAZIONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030129"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060011",
    "display" : "POLICLINICO CITTA` DI UDINE - CC PRIVATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030129"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "060044",
    "display" : "PO 'Latisana e Palmanova'",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060045",
    "display" : "P.O. 'San Daniele del Friuli e Tolmezzo'",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030043"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060047",
    "display" : "PRESIDIO OSPEDALIERO 'S.M.M' DI UDINE",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "030129"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060029",
    "display" : "SANATORIO TRIESTINO S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "032006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "060033",
    "display" : "POLICLINICO TRIESTINO SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "032006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "060043",
    "display" : "PO 'Gorizia e Monfalcone'",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "031007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060046",
    "display" : "Presidio Osp. Cattinara e Maggiore di Ts",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "032006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "060901",
    "display" : "I.R.C.C.S. BURLO GAROFOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "060"
    },
    {
      "code" : "comune",
      "valueString" : "032006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "060207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070001",
    "display" : "PRESIDIO OSPEDALIERO UNIFICATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "008055"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070113",
    "display" : "SANT'ANNA Srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "008031"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070016",
    "display" : "Casa di Cura San Michele - ENNE S.r.l.",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "009002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070211",
    "display" : "PRESIDIO PONENTE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "009056"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070212",
    "display" : "PRESIDIO LEVANTE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "009056"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070025",
    "display" : "E.O. OSPEDALI GALLIERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "070051",
    "display" : "OSPEDALE EVANGELICO INTERNAZIONALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "070065",
    "display" : "CASA DI CURA VILLA MONTALLEGRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070066",
    "display" : "VILLA SERENA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070074",
    "display" : "ISTITUTO CARDIOVASCOLARE CAMOGLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070301",
    "display" : "PRESIDIO OSPEDALIERO METROPOLITANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070321",
    "display" : "IST. BIOMEDICAL S.p.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070960",
    "display" : "FONDAZIONE SALVATORE MAUGERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "070901",
    "display" : "IRCCS OSPEDALE POLICLINICO SAN MARTINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070940",
    "display" : "IST.G.GASLINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "940"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070039",
    "display" : "PRESIDIO OSPEDALIERO ASL4 CHIAVARESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070069",
    "display" : "ICLAS s.r.l.",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "010046"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070058",
    "display" : "PRESIDIO OSPEDALIERO DEL LEVANTE LIGURE",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "011015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "070070",
    "display" : "CASA DI CURA 'ALMA MATER'",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "011015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "070114",
    "display" : "CENTRO RIABILITAZIONE DON CARLO GNOCCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "070"
    },
    {
      "code" : "comune",
      "valueString" : "011015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "070105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080004",
    "display" : "PRESIDIO UNICO PIACENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "033032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080203",
    "display" : "CASA DI CURA PRIVATA PIACENZA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "033032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080204",
    "display" : "CASA DI CURA PRIVATA S. ANTONINO S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "033032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080205",
    "display" : "CASA DI CURA S.GIACOMO S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "033036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080101"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "101"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080902",
    "display" : "AZIENDA OSPEDALIERO-UNIVERSITARIA DI PAR",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080013",
    "display" : "PRESIDIO OSPEDALIERO AZIENDALE (AUSL PAR",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080206",
    "display" : "CASA DI CURA CITTA' DI PARMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080207",
    "display" : "HOSPITAL PICCOLE FIGLIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080208",
    "display" : "VILLA MARIA LUIGIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080209",
    "display" : "CASA DI CURA VILLA IGEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080210",
    "display" : "HOSPITAL VAL PARMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080253",
    "display" : "FONDAZIONE DON CARLO GNOCCHI ONLUS",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080254",
    "display" : "CENTRO CARDINAL FERRARI S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "034015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080102"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "102"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080021",
    "display" : "PRESIDIO OSPEDALIERO PROVINCIALE DI REGG",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "035033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080211",
    "display" : "SALUS HOSPITAL (CASA DI CURA PRIVATA)",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "035033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080212",
    "display" : "CASA DI CURA PRIVATA POLISPECIALISTICA V",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "035033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080103"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "103"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080904",
    "display" : "AZIENDA OSPEDALIERO-UNIVERSITARIA DI MOD",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080031",
    "display" : "PRESIDIO OSPEDALIERO PROVINCIALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080096",
    "display" : "NUOVO OSPEDALE CIVILE DI SASSUOLO S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036040"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080213",
    "display" : "HESPERIA HOSPITAL MODENA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080214",
    "display" : "PROF. FOGLIANI CASA DI CURA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080215",
    "display" : "OSPEDALE PRIVATO VILLA IGEA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080216",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA ROSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080218",
    "display" : "VILLA PINETA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "036030"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080104"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "104"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080053",
    "display" : "PRESIDIO OSPEDALIERO UNICO - AZIENDA DI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080153",
    "display" : "ISTITUTO DELLE SCIENZE NEUROLOGICHE DI B",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080219",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA CHIAR",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080220",
    "display" : "CASA DI CURA PROF. NOBILI S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080221",
    "display" : "CASA DI CURA VILLA ERBOSA OSPEDALE PRIVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080222",
    "display" : "OSPEDALE PRIVATO ACCREDITATO NIGRISOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080223",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA TORRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080224",
    "display" : "OSPEDALE PRIVATO ACCREDITATO CASA DI CUR",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080225",
    "display" : "CASA DI CURA MADRE FORTUNATA TONIOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080226",
    "display" : "OSPEDALE PRIVATO VILLALBA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080227",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA BARUZ",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080228",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA BELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080229",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA LAURA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080231",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA REGIN",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080255",
    "display" : "OSPEDALE PRIVATO SANTA VIOLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080256",
    "display" : "CASA DI CURA EUGENIO GRUPPIONI OSPEDALE",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "105"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080908",
    "display" : "IRCCS AZIENDA OSPEDALIERO-UNIVERSITARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "908"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080960",
    "display" : "ISTITUTO ORTOPEDICO RIZZOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080105"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "960"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080044",
    "display" : "PRESIDIO OSPEDALIERO IMOLA - CASTEL S. P",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080045",
    "display" : "OSPEDALE MONTECATONE REHABILITATION INST",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "037032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "080909",
    "display" : "AZIENDA OSPEDALIERO-UNIVERSITARIA DI FER",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "038008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "909"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080068",
    "display" : "PRESIDIO OSPEDALIERO UNICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "038006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080235",
    "display" : "CASA DI CURA QUISISANA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "038008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080236",
    "display" : "CASA DI CURA SALUS S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "038008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080072",
    "display" : "OSPEDALE SANTA MARIA DELLE CROCI RAVEN",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080079",
    "display" : "OSPEDALE UMBERTO 1° LUGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080082",
    "display" : "OSPEDALE DEGLI INFERMI  FAENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080085",
    "display" : "PRESIDIO OSPEDALIERO FORLI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080091",
    "display" : "PRESIDIO OSPEDALIERO CESENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080095",
    "display" : "PRESIDIO OSPEDALIERO RIMINI-SANTARCANGEL",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080100",
    "display" : "PRESIDIO OSPEDALIERO RICCIONE-CATTOLICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "080237",
    "display" : "OSPEDALE PRIVATO DOMUS NOVA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080238",
    "display" : "CASA DI CURA SAN FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080239",
    "display" : "VILLA MARIA CECILIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080240",
    "display" : "OSPEDALE PRIVATO SAN PIER DAMIANO HOSPI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080242",
    "display" : "CASA DI CURA PRIVATA VILLA AZZURRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "039015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080243",
    "display" : "OSPEDALE PRIVATO ACCREDITATO VILLA IGEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080244",
    "display" : "VILLA SERENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080245",
    "display" : "MALATESTA NOVELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080246",
    "display" : "CASA DI CURA PRIVATA SAN LORENZINO S.P.A",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080247",
    "display" : "SOL ET SALUS",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080249",
    "display" : "CASA DI CURA VILLA MARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080250",
    "display" : "LUCE SUL MARE",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080251",
    "display" : "VILLA SALUS S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080252",
    "display" : "CASA DI CURA PROF. E. MONTANARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "099011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "080921",
    "display" : "I.R.S.T. SRL IRCCS",
    "property" : [{
      "code" : "regione",
      "valueString" : "080"
    },
    {
      "code" : "comune",
      "valueString" : "040019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "080114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "090904",
    "display" : "AZIENDA OSPEDALIERA MEYER",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090207",
    "display" : "CASA DI CURA S. RITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "047011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090210",
    "display" : "CASA DI CURA VILLA FIORITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "100005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090213",
    "display" : "CASA DI CURA VILLA DONATELLO SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048043"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090214",
    "display" : "CASA DI CURA VILLA CHERUBINI PROSPERIUS",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090216",
    "display" : "KOS CARE S.R.L. VILLA DEI PINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090218",
    "display" : "IFCA SPA CASA DI CURA ULIVELLA E GLICINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090219",
    "display" : "VILLA MARIA TERESA HOSPITAL SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090229",
    "display" : "VILLA DELLE TERME SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090230",
    "display" : "CASA DI CURA VAL DI SIEVE SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090235",
    "display" : "CASA DI CURA LEONARDO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090240",
    "display" : "CASA DI CURA FRATE SOLE SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090243",
    "display" : "CENTRO DAY SURGERY MAURIZIO BUFALINI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090245",
    "display" : "CASA DI CURA SAN PAOLO SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "047014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090606",
    "display" : "SPEDALI RIUNITI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "047014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090607",
    "display" : "OSPEDALE DELLA VALDINIEVOLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "047012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090608",
    "display" : "NUOVO OSPEDALE DI PRATO S.STEFANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "100005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090627",
    "display" : "OSPEDALE DI BORGO SAN LORENZO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090629",
    "display" : "OSPEDALE FIORENTINO SUD-EST",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090632",
    "display" : "OSPEDALE FIORENTINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090642",
    "display" : "PRESIDIO OSPEDALIERO ASL 11 EMPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090910",
    "display" : "FONDAZIONE DON CARLO GNOCCHI - ONLUS",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "090903",
    "display" : "AZ. OSPEDALIERO - UNIVERSITARIA CAREGGI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "048017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "903"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090901",
    "display" : "AZIENDA OSPEDALIERO-UNIVERSITARIA PISANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090906",
    "display" : "FONDAZIONE STELLA MARIS - CALAMBRONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "090907",
    "display" : "FONDAZIONE CNR-RT G. MONASTERIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "9"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "090202",
    "display" : "CASA CURA S.CAMILLO FORTE DEI MARMI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090203",
    "display" : "CASA DI CURA MD BARBANTINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090204",
    "display" : "C. DI CURA M.D. BARBANTINI SANTA CHIARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090205",
    "display" : "CASA DI CURA S.ZITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090206",
    "display" : "CASA DI CURA VILLE DI NOZZANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090231",
    "display" : "CASA DI CURA SUORE DELL'ADDOLORATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090233",
    "display" : "CASA DI CURA PRIVATA SAN ROSSORE S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090234",
    "display" : "CASA DI CURA VILLA TIRRENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "049009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090241",
    "display" : "CEN.S. MARIA ALLA PINETA F. DON GNOCCHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "045010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090601",
    "display" : "PRESIDIO OSPEDALIERO ZONA LUNIGIANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "045007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090602",
    "display" : "PRESIDIO OSPEDALIERO ZONA DELLE APUANE",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "045003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090603",
    "display" : "PRESIDIO OSPEDALIERO VALLE DEL SERCHIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090604",
    "display" : "PRESIDIO OSPEDALIERO SAN LUCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090609",
    "display" : "PRESIDIO OSPEDALIERO S.MARIA MADDALENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090610",
    "display" : "PRESIDIO OSPEDALIERO FELICE LOTTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090613",
    "display" : "OSPEDALE LIVORNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "049009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090614",
    "display" : "OSP. ZONA B.VAL DI CECINA VAL DI CORNIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "049012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090615",
    "display" : "OSPEDALE DI PORTOFERRAIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "049014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090640",
    "display" : "OSPEDALE VERSILIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "046005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090909",
    "display" : "AUXILIUM VITAE VOLTERRA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "050039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "090902",
    "display" : "AZIENDA OSPEDALIERA UNIVERSITARIA SENESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090236",
    "display" : "CENTRO CHIRURGICO TOSCANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090237",
    "display" : "SAN GIUSEPPE HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090239",
    "display" : "RUGANI HOSPITAL SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "090618",
    "display" : "OSPEDALE DEL CASENTINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090619",
    "display" : "OSPEDALE DELLA VALTIBERINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090621",
    "display" : "OSPEDALE AREA ARETINA NORD",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090623",
    "display" : "OSPEDALE S.ANDREA MASSA MARITTIMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "053015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090624",
    "display" : "OSPEDALE DELLE COLLINE DELL'ALBEGNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "053018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090625",
    "display" : "OSPEDALE CIVILE DI CASTEL DEL PIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "053004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090626",
    "display" : "OSPEDALE DELLA MISERICORDIA GROSSETO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "053011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090634",
    "display" : "SERVIZIO PSICHIATRICO DIAGNOSI E CURA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090637",
    "display" : "PRESIDIO OSPEDALIERO AMIATA SENESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090638",
    "display" : "OSPEDALE DELL'ALTA VAL D'ELSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090639",
    "display" : "OSPEDALI RIUNITI DELLA VAL DI CHIANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "052015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090641",
    "display" : "OSPEDALE NUOVO VALDARNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090643",
    "display" : "NUOVO OSPEDALE VALDICHIANA S. MARGHERITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "090911",
    "display" : "CENTRO RIABILITAZIONE TERRANUOVA B. SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "090"
    },
    {
      "code" : "comune",
      "valueString" : "051026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "090203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "100701",
    "display" : "CASA DI CURA VILLA FIORITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "100702",
    "display" : "Istituto Clinico Porta Sole Casa di Cura",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "100703",
    "display" : "CLINICA LAMI",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "100704",
    "display" : "CASA DI CURA LIOTTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "100801",
    "display" : "PRESIDIO OSPEDALIERO ALTO TEVERE",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100803",
    "display" : "PRESIDIO OSPEDALIERO UNIFICATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100810",
    "display" : "PRESIDIO OSPEDALIERO GUBBIO E G.TADINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100901",
    "display" : "AZIENDA OSPEDALIERA DI PERUGIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100602",
    "display" : "SERVIZIO PSICHIATRICO DIAGNOSI E CURA",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "055032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100705",
    "display" : "CASA DI CURA VILLA AURORA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "100805",
    "display" : "POLO OSPEDALIERO SPOLETO",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100806",
    "display" : "SANTA MARIA DELLA STELLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "055023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100807",
    "display" : "PRESIDIO OSPEDALIERO NARNI AMELIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "055022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100809",
    "display" : "POLO OSPEDALIERO FOLIGNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "054018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "100902",
    "display" : "AZIENDA OSPEDALIERA 'S. MARIA' - TERNI",
    "property" : [{
      "code" : "regione",
      "valueString" : "100"
    },
    {
      "code" : "comune",
      "valueString" : "055032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "100202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110001",
    "display" : "PRESIDIO OSPEDALIERO AST1",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "041013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110002",
    "display" : "PRESIDIO OSPEDALIERO AST2",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110037",
    "display" : "CASA DI CURA VILLA SILVIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110039",
    "display" : "KOS CARE SRL - CLINICA VILLA JOLANDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110076",
    "display" : "CDC MARCHE - RETE IMPRESA AST2",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110905",
    "display" : "AZIENDA OSP. UNIVERSITARIA DELLE MARCHE",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110995",
    "display" : "CENTRO CLINICO NEMO ANCONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110921",
    "display" : "INRCA MARCHE",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "042002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "921"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110003",
    "display" : "PRESIDIO OSPEDALIERO AST3",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "043023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110077",
    "display" : "CDC MARCHE - RETE IMPRESA AST3",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "043013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110079",
    "display" : "CENTRO OSPEDALIERO SANTO STEFANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "043043"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110004",
    "display" : "PRESIDIO OSPEDALIERO AST4",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "109006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110304"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "304"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110078",
    "display" : "CDC MARCHE - RETE IMPRESA AST4/5",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "109006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110304"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "304"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "110005",
    "display" : "PRESIDIO OSPEDALIERO AST5",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "044007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "110071",
    "display" : "CASA DI CURA 'SAN GIUSEPPE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "110"
    },
    {
      "code" : "comune",
      "valueString" : "044007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "110305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120002",
    "display" : "OSPEDALE DI ACQUAPENDENTE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120003",
    "display" : "OSPEDALE DI CIVITACASTELLANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056021"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120007",
    "display" : "OSPEDALE DI TARQUINIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120014",
    "display" : "NUOVA S.TERESA DEL BAMBIN GESU`",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120015",
    "display" : "VILLA IMMACOLATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120271",
    "display" : "POLO OSPEDALIERO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120304",
    "display" : "CASA DI CURA NEPI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "056039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120109"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "109"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120019",
    "display" : "POLO OSPEDALIERO UNICO INTEGRATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "057059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120110"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "110"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120200",
    "display" : "PRESIDIO OSPEDALIERO NORD",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120204",
    "display" : "PRESIDIO OSPEDALIERO CENTRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120206",
    "display" : "PRESIDIO OSPEDALIERO SUD",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120209",
    "display" : "CASA DEL SOLE CLINICA TOMMASO COSTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120212",
    "display" : "ISTIT CHIR ORTOP TRAUMATOLOGICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120213",
    "display" : "CASA DI CURA SAN MARCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120214",
    "display" : "ISTITUTO FISIOTERAPICO C.FRANCESCHINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120215",
    "display" : "CASA DI CURA CITTA` DI APRILIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120278",
    "display" : "CASA DI CURA 'VILLA SILVANA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "059001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120111"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "111"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120216",
    "display" : "PO UNIFICATO :: FROSINONE - ALATRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120226",
    "display" : "OSPEDALE CIVILE S.S.TRINITA` N.SEDE SORA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120228",
    "display" : "OSPEDALE S. SCOLASTICA CASSINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120230",
    "display" : "CASA DI CURA PRIV. S. ANNA S.R.L CASSINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120235",
    "display" : "CASA DI CURA PRIV. VILLA SERENA CASSINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120236",
    "display" : "CASA DI CURA PRIV. SANTA TERESA ISOLA L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060043"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120277",
    "display" : "CASA CURA PRIVATA'SAN RAFFAELE' CASSINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120279",
    "display" : "I.N.I. DIV.DISTACCAT CITTA` BIANCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060085"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120291",
    "display" : "CASA DI CURA SRL 'SORA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "060074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120919",
    "display" : "AZIENDA OSPEDALIERA SANT`ANDREA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "919"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120902",
    "display" : "AZIENDA OSP. S.GIOVANNI/ADDOLORATA ROMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120908",
    "display" : "ISTITUTI FISIOTERAPICI OSPITALIERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "908"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120904",
    "display" : "OSPEDALE PEDIATRICO BAMBINO GESU`",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120905",
    "display" : "POLICLINICO A. GEMELLI E C.I.C.",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120906",
    "display" : "POLICLINICO U. I",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "906"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120026",
    "display" : "POLO OSPEDALIERO SANTO SPIRITO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120030",
    "display" : "OSPEDALE REGIONALE OFTALMICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120071",
    "display" : "OSPEDALE SAN PIETRO - FBF",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120073",
    "display" : "OSPEDALE SAN CARLO DI NANCY",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120074",
    "display" : "OSP. GEN. DI ZONA 'CRISTO RE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120079",
    "display" : "CASA DI CURA VILLA DOMELIA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120087",
    "display" : "CASA DI CURA POLICLINICO ITALIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120090",
    "display" : "CASA DI CURA VILLA BENEDETTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120092",
    "display" : "CASA DI CURA SANATRIX",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120098",
    "display" : "CASA DI CURA N.SIGNORA DELLA MERCEDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120105",
    "display" : "CASA DI CURA MARCO POLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120108",
    "display" : "CASA DI CURA ASSUNZIONE DI MARIA SS",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120114",
    "display" : "CASA DI CURA QUISISANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120115",
    "display" : "CASA DI CURA SANTA FAMIGLIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120118",
    "display" : "CASA DI CURA VILLA DEL ROSARIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120119",
    "display" : "CASA DI CURA VILLA MAFALDA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120120",
    "display" : "CASA DI CURA SAN DOMENICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120123",
    "display" : "CASA DI CURA VILLA STUART",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120129",
    "display" : "CASA DI CURA VILLA MARGHERITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120141",
    "display" : "CASA DI CURA SANTO VOLTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120144",
    "display" : "CLINICA VALLE GIULIA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120146",
    "display" : "CASA DI CURA S.RITA DA CASCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120150",
    "display" : "CASA DI CURA PIO XI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120158",
    "display" : "CASA DI CURA PAIDEIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120159",
    "display" : "CASA DI CURA NUOVA VILLA CLAUDIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120163",
    "display" : "CASA DI CURA SAN FELICIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120172",
    "display" : "CASA DI CURA MATER DEI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120180",
    "display" : "AURELIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120254",
    "display" : "ARS MEDICA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120256",
    "display" : "ARSBIOMEDICA DELLA SAF GESTIONI SANITARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120257",
    "display" : "CASA DI CURA S. MARIA DI LEUCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120264",
    "display" : "CASA DI CURA VILLA VERDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120285",
    "display" : "PRESIDIO OSPEDALIERO SAN FILIPPO NERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120288",
    "display" : "VILLA TIBERIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120293",
    "display" : "CASA DI CURA VILLA AURORA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120296",
    "display" : "CASA DI CURA VILLA BETANIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120297",
    "display" : "CLINICA FENICE PARIOLI srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120298",
    "display" : "CASA DI CURA SALUS INFIRMORUM",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120300",
    "display" : "CASA DI CURA VILLA VALERIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120301",
    "display" : "C.di C. AUXOLOGICO ROMA - BUON PASTORE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120303",
    "display" : "VILLA SALARIA HOSPITAL S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120305",
    "display" : "Ospedale Fatebenefatelli-Isola Tiberina",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120306",
    "display" : "CASA DI CURA S. DOMENICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120328",
    "display" : "CASA DI CURA PRIVATA `DON CARLO GNOCCHI`",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120911",
    "display" : "I.D.I. - FONDAZIONE LUIGI MARIA MONTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "120913",
    "display" : "IRCCS - FONDAZIONE G.B. BIETTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "120920",
    "display" : "AZ. OSP. UNIV. POLICLINICO TOR VERGATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "920"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120909",
    "display" : "I.R.C.C.S. S. LUCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "909"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "120915",
    "display" : "POLICL. UNIV. CAMPUS BIO MEDICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "915"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "120066",
    "display" : "OSPEDALE S. EUGENIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120076",
    "display" : "MADRE GIUSEPPINA VANNINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120085",
    "display" : "MADONNA DELLA FIDUCIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120089",
    "display" : "N.C.L. ISTITUTO DI NEUROSCIENZE S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120104",
    "display" : "CASA DI CURA VILLA FULVIA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120132",
    "display" : "CASA DI CURA GUARNIERI SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120135",
    "display" : "C.D.C. MATER MISERICORDIAE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120139",
    "display" : "CLINICA LATINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120143",
    "display" : "CONCORDIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120157",
    "display" : "C.D.C. FABIA MATER",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120166",
    "display" : "CASA DI CURA NUOVA ITOR",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120169",
    "display" : "NUOVA CLINICA ANNUNZIATELLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120245",
    "display" : "CENTRO RESIDENZIALE MEDICA GROUP",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120249",
    "display" : "C.D.C. VILLA ANNA MARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120265",
    "display" : "ROME AMERICAN HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120267",
    "display" : "OSPEDALE SANDRO PERTINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120290",
    "display" : "CASA DI CURA KAROL WOJTYLA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120294",
    "display" : "POLICLINICO CASILINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120901",
    "display" : "AZ.OSP.SAN CAMILLO-FORLANINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120918",
    "display" : "INMI 'L.SPALLANZANI' - IRCCS",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "918"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120910",
    "display" : "IRCCS SAN RAFFAELE PISANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "910"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120061",
    "display" : "OSPEDALE G. B. GRASSI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120065",
    "display" : "CENTRO PARAPLEGICI OSTIA ' Gennaro Di Ro",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120075",
    "display" : "OSPEDALE ISRAELITICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120113",
    "display" : "CASA DI CURA VILLA PIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120130",
    "display" : "CASA DI CURA VILLA SANDRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120133",
    "display" : "CASA DI CURA SALVATOR MUNDI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120138",
    "display" : "OSPEDALE SAN GIOVANNI BATTISTA-ACISMOM",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "120171",
    "display" : "CASA DI CURA CITTA` DI ROMA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120173",
    "display" : "EUROPEAN HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120191",
    "display" : "CASA DI CURA MERRY HOUSE/C.GERIATRICO RO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120262",
    "display" : "CASA DI CURA VILLA MARIA IMMACOLATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120283",
    "display" : "C. DI C. 'ISTITUTO CLINICO CARDIOLOGICO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120295",
    "display" : "POLICLINICO LUIGI DI LIEGRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120606",
    "display" : "CASA DI CURA S. RAFFAELE PORTUENSE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058091"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120045",
    "display" : "OSPEDALE SAN PAOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120059",
    "display" : "OSPEDALE PADRE PIO DI BRACCIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120140",
    "display" : "CASA DI CURA SILIGATO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120046",
    "display" : "OSPEDALE L.PARODI DELFINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120049",
    "display" : "OSPEDALE SS. GONFALONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058065"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120051",
    "display" : "OSPEDALE CIVILE CONIUGI BERNARDINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120052",
    "display" : "OSPEDALE A. ANGELUCCI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058103"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120053",
    "display" : "OSPEDALE S. GIOVANNI EVANGELISTA(TIVOLI)",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058104"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120088",
    "display" : "I.N.I. Srl Divisione Medicus Hotel",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058104"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120199",
    "display" : "I.N.I. Srl Divisione Villa Dante",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120284",
    "display" : "Nomentana Hospital srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058122"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120286",
    "display" : "Casa di Cura Villa Luana",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120043",
    "display" : "OSP. ANZIO-NETTUNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120047",
    "display" : "OSP. S.SEBASTIANO FRASCATI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120048",
    "display" : "OSP. S.GIUSEPPE MARINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058057"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120054",
    "display" : "OSP.'PAOLO COLOMBO' VELLETRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058111"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120082",
    "display" : "VILLA DELLE QUERCE-POLIGEST",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120096",
    "display" : "C.D.C. MADONNA DELLE GRAZIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058111"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120122",
    "display" : "C.D.C. SAN RAFFAELE ROCCA DI PAPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058086"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120134",
    "display" : "CASA DI CURA S.ANNA POMEZIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058079"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120176",
    "display" : "C.D.C. I.N.I. SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058046"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120280",
    "display" : "C.d.C San Raffaele Montecompatri",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120289",
    "display" : "VILLA DEI PINI ASA srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "120292",
    "display" : "Ospedale dei Castelli",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "120302",
    "display" : "OSPEDALE REGINA APOSTOLORUM",
    "property" : [{
      "code" : "regione",
      "valueString" : "120"
    },
    {
      "code" : "comune",
      "valueString" : "058003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "120206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "130001",
    "display" : "P.O.SAN SALVATORE L'AQUILA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130002",
    "display" : "PO SULMONA ' DELL' ANNUNZIATA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066098"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130003",
    "display" : "PO AVEZZANO 'S. FILIPPO E NICOLA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130005",
    "display" : "PRESIDIO OSPEDALIERO CASTEL DI SANGRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130006",
    "display" : "PO TAGLIACOZZO ' UMBERTO I'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066099"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130010",
    "display" : "CASA DI CURA 'DI LORENZO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130012",
    "display" : "CASA DI CURA L'IMMACOLATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130013",
    "display" : "CASA DI CURA 'S RAFFAELE SPA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066098"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130039",
    "display" : "CASA DI CURA I.N.I. CANISTRO",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130040",
    "display" : "CASA DI CURA PRIVATA VILLA LETIZIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130041",
    "display" : "NOVA SALUS SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "066102"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130026",
    "display" : "P.O. CLINICIZZ. 'SS. ANNUNZIATA' CHIETI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130028",
    "display" : "P.O. LANCIANO 'RENZETTI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069046"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130029",
    "display" : "P.O. VASTO 'S. PIO DA PIETRALCINA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069099"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130030",
    "display" : "P.O. ATESSA 'SAN CAMILLO DE LELLIS'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130032",
    "display" : "P.O. ORTONA 'G. BERNABEO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069058"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130035",
    "display" : "CASA DI CURA PRIVATA 'DOTT. SPATOCCO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130042",
    "display" : "CASA DI CURA S. FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "069099"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130018",
    "display" : "P.O. 'SPIRITO SANTO' PESCARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130019",
    "display" : "P.O. S. MASSIMO di PENNE",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130020",
    "display" : "P.O.'S.S. TRINITA'' POPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130022",
    "display" : "CASA DI CURA PIERANGELI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130024",
    "display" : "CASA di CURA VILLA SERENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "068012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "130014",
    "display" : "OSPEDALE MAZZINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "067041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130015",
    "display" : "OSPEDALE MARIA S.S. DELLO SPLENDORE",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "067025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130016",
    "display" : "OSPEDALE SAN LIBERATORE DI ATRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "067004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "130017",
    "display" : "OSPEDALE-VAL VIBRATA SANT'OMERO",
    "property" : [{
      "code" : "regione",
      "valueString" : "130"
    },
    {
      "code" : "comune",
      "valueString" : "067039"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "130204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "140001",
    "display" : "PRESIDIO OSPEDALIERO 'A.CARDARELLI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "140002",
    "display" : "PLESSO OSPEDALIERO 'S TIMOTEO- TERMOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "140003",
    "display" : "COMPLESSO OSPEDALIERO ISERNIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "094023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "140004",
    "display" : "CASA DI CURA VILLA MARIA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "140005",
    "display" : "CASA DI CURA PRIVATA VILLA ESTHER s.r.l.",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "140007",
    "display" : "GEMELLI MOLISE S.PA. - CAMPOBASSO",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "070006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "9"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "140008",
    "display" : "GEA MEDICA IST. EUROPEO di RIABILITAZION",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "094023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "140911",
    "display" : "NEUROMED I.R.C.C.S.",
    "property" : [{
      "code" : "regione",
      "valueString" : "140"
    },
    {
      "code" : "comune",
      "valueString" : "094038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "140201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150140",
    "display" : "OSPEDALE ARIANO IRPINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150143",
    "display" : "Pineta Grande SpA - CdiC Villa Esther",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150144",
    "display" : "CASA DI CURA VILLA MARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150145",
    "display" : "CASA DI CURA S.RITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150146",
    "display" : "CASA DI CURA VILLA MARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150148",
    "display" : "CASA DI CURA MONTEVERGINE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150149",
    "display" : "CASA DI CURA VILLA DEI PLATANI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150150",
    "display" : "OSPEDALE S.ANGELO DEI LOMBARDI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064092"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150449",
    "display" : "Casa di Cura Privata Villa Dei Pini SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150905",
    "display" : "AZIENDA OSPEDALIERA S. G. MOSCATI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "064008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150032",
    "display" : "OSP.SACRO CUORE DI GESU`FATEBENEFRATELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150033",
    "display" : "CASA DI CURA GE.P.O.S. SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150034",
    "display" : "CASA DI CURA NUOVA CLINICA S.RITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150035",
    "display" : "CASA DI CURA SAN FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150350",
    "display" : "C.M.R. S.P.A.- CENTRO MED.DIAGN.E RIAB.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150371",
    "display" : "KOS CARE s.r.l.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150911",
    "display" : "Istituti Clinici Scient. Maugeri s.p.a",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062074"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150906",
    "display" : "AZIENDA OSPEDALE `AO SAN PIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "062008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "906"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150907",
    "display" : "A.O. SANT'ANNA E SAN SEBASTIANO CASERTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "907"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150004",
    "display" : "OSPEDALE SAN GIUSEPPE E MELORIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061083"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150010",
    "display" : "PRESIDIO OSPEDALIERO 'SAN ROCCO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061088"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150013",
    "display" : "PRESIDIO OSPEDALIERO S.G.MOSCATI AVERSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150014",
    "display" : "CLINICA SANT`ANNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150016",
    "display" : "VILLA DEL SOLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150017",
    "display" : "CASA DI CURA VILLA FIORITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150018",
    "display" : "CASA DI CURA SAN PAOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150019",
    "display" : "CASA DI CURA 'VILLA FIORITA' SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150020",
    "display" : "CLINICA SAN MICHELE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150021",
    "display" : "CASA DI CURA PINETA GRANDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150022",
    "display" : "MINERVA S.P.A. SANTA MARIA DELLA SALUTE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061083"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150023",
    "display" : "VILLA DEI PINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061057"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150024",
    "display" : "CASA DI CURA VILLA ORTENSIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150025",
    "display" : "VILLA DEGLI ULIVI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150028",
    "display" : "VILLA DELLE MAGNOLIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061026"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150437",
    "display" : "PRESIDIO OSPEDALIERO MADDALONI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150438",
    "display" : "PRESIDIO OSPEDALIERO MARCIANISE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150439",
    "display" : "PRESIDIO OSPEDALIERO S.FELICE A CANCELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061075"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150440",
    "display" : "PRESIDIO OSPEDALIERO PIEDIMONTE MATESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "061057"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150902",
    "display" : "A.O.R.N. SANTOBONO-PAUSILIPON",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150909",
    "display" : "A.O.U. 'FEDERICO II' DI NAPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "909"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150073",
    "display" : "CASA DI CURA OSPEDALE FATEBENEFRATELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150075",
    "display" : "CASA DI CURA OSP. INTERNAZIONALE srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150078",
    "display" : "ALMA MATER S.p.A. 'Villa Camaldoli' SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150079",
    "display" : "CASA DI CURA VILLA ANGELA srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150081",
    "display" : "CASA DI CURA CLINIC CENTER SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150088",
    "display" : "HERMITAGE CAPODIMONTE SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150092",
    "display" : "CASA DI CURA VILLA DELLE QUERCE SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150093",
    "display" : "CASA DI CURA RUESCH SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150094",
    "display" : "CLINICA VESUVIO srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150095",
    "display" : "CLINICA MEDITERRANEA SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150099",
    "display" : "CLINICA SANTA PATRIZIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150104",
    "display" : "CASA DI CURA VILLA CINZIA srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150106",
    "display" : "CLINICA PINETA GRANDE SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150109",
    "display" : "CLINICA SANATRIX SpA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150196",
    "display" : "FONDAZIONE EVANGELICA BETANIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150442",
    "display" : "PRESIDIO OSPEDALIERO OSPEDALE DEL MARE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150443",
    "display" : "P.O. SAN PAOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150444",
    "display" : "P.O. SAN GIOVANNI BOSCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150445",
    "display" : "P.O. dei PELLEGRINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150446",
    "display" : "PO SANTA MARIA DI LORETO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150901",
    "display" : "AZIENDA OSPEDALIERA 'A. CARDARELLI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150903",
    "display" : "Azienda Ospedaliera dei Colli",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "903"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150908",
    "display" : "AZIENDA OSPEDALIERA UNIVERSITARIA UNICAM",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "908"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150910",
    "display" : "ISTITUTO NAZIONALE TUMORI DI NAPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "910"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150057",
    "display" : "OSPEDALE CIVILE S. GIOVANNI DI DIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063032"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150058",
    "display" : "OSPEDALE SAN GIULIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150070",
    "display" : "OSPEDALE RIZZOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150084",
    "display" : "CASA DI CURA VILLA DEI FIORI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150097",
    "display" : "CASA DI CURA VILLA MAIONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063087"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150101",
    "display" : "CASA DI CURA 'CLINICA S.ANTIMO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063020"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150116",
    "display" : "CASA DI CURA VILLA DEI FIORI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150118",
    "display" : "ISTITUTO DI CURA MARIA SS.DELLA PIETA`",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "150189",
    "display" : "OSP.CIV. GAETANINA SCOTTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063061"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150191",
    "display" : "OSPEDALE S.M.DELLE GRAZIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063060"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150082",
    "display" : "CASA DI CURA ' LA MADONNINA ' SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063066"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150100",
    "display" : "CASA DI CURA ' N.S. DI LOURDES ' SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063092"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150102",
    "display" : "CASA DI CURA S. MARIA LA BRUNA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063084"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150105",
    "display" : "CASA DI CURA VILLA STABIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150108",
    "display" : "CASA DI CURA CARDIOMED S.p.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150110",
    "display" : "CASA DI CURA MARIA ROSARIA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063058"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150111",
    "display" : "STAZIONE CLIMATICA BIANCHI srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063059"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150113",
    "display" : "CASA DI SALUTE S.LUCIA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063068"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150114",
    "display" : "CASA DI CURA A.GRIMALDI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063067"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150117",
    "display" : "IOS - EX CASA DI CURA ' MELUCCIO' SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063057"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150121",
    "display" : "IOS - EX CLINICA ' S. FELICE' SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063057"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150192",
    "display" : "CASA DI CURA S.MARIA DEL POZZO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063079"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150416",
    "display" : "OSPEDALI RIUNITI AREA STABIESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150417",
    "display" : "OSPEDALI RIUNITI PENISOLA SORRENTINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063080"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150436",
    "display" : "OSPEDALI RIUNITI AREA NOLANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150447",
    "display" : "P.O. TORRE DEL GRECO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063084"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150448",
    "display" : "P.O. BOSCOTRECASE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "063009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150904",
    "display" : "A.O.OO.RR.S.GIOVANNI DI DIO E RUGGI D`AR",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150154",
    "display" : "DEA UMBERTO I NOCERA INFERIORE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150158",
    "display" : "P.O. S. FRANCESCO D ASSISI OLIVETO CITRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065083"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150160",
    "display" : "PRESIDIO OSPEDALIERO LUIGI CURTO- POLLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065097"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150161",
    "display" : "PRESIDIO OSPEDALIERO 'IMMACOLATA' SAPRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065134"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150162",
    "display" : "DEA EBOLI BATTIPAGLIA ROCCADASPIDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150163",
    "display" : "P.O. MARTIRI DI VILLA MALTA SARNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065135"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150165",
    "display" : "DEA VALLO DELLA LUCANIA-AGROPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065154"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "150167",
    "display" : "HYPPOCRATICA SPA CDC VILLA DEL SOLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150170",
    "display" : "ICM-Istituto Clinico Mediterraneo S.p.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150171",
    "display" : "LA QUIETE - S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065090"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150173",
    "display" : "CASA DI CURA PRIVATA SALUS S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150175",
    "display" : "Campolongo Hospital S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150176",
    "display" : "'CASA DI CURA PROF.DOTT. LUIGI COBELLIS'",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065154"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150177",
    "display" : "CASA DI CURA TORTORELLA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065116"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150178",
    "display" : "VILLA CHIARUGI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065078"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "150420",
    "display" : "VILLA SILVIA 'G.F.MONTESANO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "150"
    },
    {
      "code" : "comune",
      "valueString" : "065108"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "150207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160101",
    "display" : "CASA DI CURA 'SALUS' - BRINDISI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160151",
    "display" : "IRCCS 'E.MEDEA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "160161",
    "display" : "OSPEDALE OSTUNI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160162",
    "display" : "OSPEDALE FRANCAVILLA FONTANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160170",
    "display" : "OSPEDALE BRINDISI 'PERRINO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "074001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160106"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "106"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160074",
    "display" : "OSPEDALE MANDURIA 'GIANNUZZI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160075",
    "display" : "OSPEDALE CIVILE MARTINA FRANCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160111",
    "display" : "CASA DI CURA BERNARDINI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160112",
    "display" : "CASA DI CURA D'AMORE S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160114",
    "display" : "CASA DI CURA SAN CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160115",
    "display" : "CASA DI CURA SANTA RITA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160116",
    "display" : "CASA DI CURA VILLA VERDE S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160141",
    "display" : "CASA DI CURA VILLA BIANCA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160146",
    "display" : "CENTRO MEDICO RIABILITAZIONE ICS MAUGERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160149",
    "display" : "FONDAZIONE CITTADELLA DELLA CARITA`",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160168",
    "display" : "OSPEDALE CASTELLANETA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160172",
    "display" : "PRESIDIO OSPEDALERO CENTRALE TARANTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "073027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160112"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "112"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160174",
    "display" : "OSPEDALE ANDRIA - 'L. BONOMO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "110001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160113"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "113"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160177",
    "display" : "OSPEDALE BARLETTA - 'MONS. R. DIMICCOLI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "110002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160113"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "113"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160178",
    "display" : "OSPEDALE BISCEGLIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "110003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160113"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "113"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160180",
    "display" : "UNIVERSO SALUTE OSP. DON UVA - BISCEGLIE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "110003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160113"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "113"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160907",
    "display" : "AO UNIV. CONS. POLICLINICO BARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "907"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160078",
    "display" : "EE OSPEDALE REGIONALE 'F. MIULLI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "160087",
    "display" : "CASA DI CURA SANTA MARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160098",
    "display" : "CASA DI CURA - VILLA LUCIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160100",
    "display" : "CASA DI CURA PRIVATA MONTE IMPERATORE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072031"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160140",
    "display" : "ANTHEA HOSPITAL S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160147",
    "display" : "CASA DI CURA C.B.H. MATER DEI HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160157",
    "display" : "OSPEDALE DELLA MURGIA 'F. PERINEI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160158",
    "display" : "OSPEDALE BARI 'SAN PAOLO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160159",
    "display" : "OSPEDALE MONOPOLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072030"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160160",
    "display" : "OSPEDALE PUTIGNANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160169",
    "display" : "OSPEDALE BARI 'DI VENERE' - TRIGGIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "114"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160906",
    "display" : "ICS MAUGERI SPA SOCIETA' BENEFIT",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "906"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "160902",
    "display" : "IRCCS 'SAVERIO DE BELLIS'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "902"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160901",
    "display" : "ISTITUTO TUMORI GIOVANNI PAOLO II",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "072006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160114"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160910",
    "display" : "AO UNIV. 'OO RR FOGGIA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "910"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160047",
    "display" : "OSPEDALE CERIGNOLA 'G.TATARELLA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071020"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160102",
    "display" : "CASA DI CURA PROF. BRODETTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160105",
    "display" : "CASA DI CURA LEONARDO DE LUCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160106",
    "display" : "CASA DI CURA 'S.MICHELE' gest. Brodetti",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160125",
    "display" : "CASA DI CURA UNIVERSO SALUTE - DON UVA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160163",
    "display" : "OSPEDALE SAN SEVERO - TERESA MASSELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160164",
    "display" : "OSPEDALE MANFREDONIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160181",
    "display" : "CASE CURA RIUNITE VILLA SERENA-S. FRANCE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071024"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "115"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160905",
    "display" : "OSPEDALE CASA SOLLIEVO DELLA SOFFERENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "071046"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160115"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.3"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico), in Lombardia Pubblico"
    }]
  },
  {
    "code" : "160062",
    "display" : "OSPEDALE GALATINA 'S. CATERINA NOVELLA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160063",
    "display" : "OSPEDALE GALLIPOLI 'SACRO CUORE DI GESU'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075031"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160080",
    "display" : "OSPEDALE REGIONALE EE 'G. PANICO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075088"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "160107",
    "display" : "CASA DI CURA 'PROF. PETRUCCIANI' S.r.l.",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160108",
    "display" : "CASA DI CURA VILLA BIANCA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160109",
    "display" : "CASA DI CURA VILLA VERDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160110",
    "display" : "CASA DI CURA SAN FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160150",
    "display" : "CASA DI CURA CITTA' DI LECCE",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160152",
    "display" : "CASA DI CURA RIABILITATIVA EUROITALIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "160165",
    "display" : "OSPEDALE COPERTINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075022"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160166",
    "display" : "OSPEDALE SCORRANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075073"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160167",
    "display" : "OSPEDALE CASARANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "160171",
    "display" : "OSPEDALE LECCE - 'V FAZZI' (SAN CESARIO)",
    "property" : [{
      "code" : "regione",
      "valueString" : "160"
    },
    {
      "code" : "comune",
      "valueString" : "075035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "160116"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "116"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170901",
    "display" : "AZIENDA OSPEDALIERA REGIONALE 'S. CARLO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "901"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170032",
    "display" : "Fondazione Don Carlo Gnocchi - Onlus",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170034",
    "display" : "LUNGODEGENZA RIABILITATIVA CHIAROMONTE",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170035",
    "display" : "LUNGODEGENZA E RIABILITAZIONE VENOSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076095"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170036",
    "display" : "LUNGODEGENZA RIABILITATIVA LAURIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170037",
    "display" : "UNIVERSO SALUTE BASILICATA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "170910",
    "display" : "C.R.O.B. - I.R.C.C.S.",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "076066"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "910"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170010",
    "display" : "PRESIDIO DISTRETTUALE STIGLIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "077027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170011",
    "display" : "PRESIDIO OSPEDALIERO - MATERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "077014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "170012",
    "display" : "PRESIDIO DISTRETTUALE TRICARICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "170"
    },
    {
      "code" : "comune",
      "valueString" : "077028"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "170202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180001",
    "display" : "IGRECO Ospedali Riuniti ex La Madonnina",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180002",
    "display" : "IGRECO Osp. Riuniti Madonna della Catena",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180003",
    "display" : "IGRECO Ospedali Riuniti ex Sacro Cuore",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180006",
    "display" : "OSPEDALE CIVILE FERRARI - CASTROVILLARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180008",
    "display" : "P.O. PRAIA A MARE",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078101"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180010",
    "display" : "OSPEDALE SPOKE ROSSANO-CORIGLIANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078157"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180011",
    "display" : "P.O.BEATO ANGELICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180012",
    "display" : "Ospedale Spoke Cetraro-Paola",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078040"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180015",
    "display" : "OSPEDALE CIVILE SGF",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078119"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180016",
    "display" : "OSPEDALE GUDO CHIDICHIMO TREBISACCE",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078150"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180019",
    "display" : "CASA DI CURA VILLA DEL SOLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180025",
    "display" : "CASA DI CURA TRICARICO ROSANO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180027",
    "display" : "CASA DI CURA CASCINI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180029",
    "display" : "CASA DI CURA SCARNATI",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180081",
    "display" : "CASA DI CURA M.MISASI GR.S.BARTOLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180084",
    "display" : "MEDICAL HOTEL CLIMAT. SPES PIETR.'ARENA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078117"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180086",
    "display" : "CASA DI CURA SAN FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078079"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180912",
    "display" : "AZIENDA OSPEDALIERA DI COSENZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "912"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180916",
    "display" : "I.N.R.C.A. Cosenza",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "078045"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "916"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180004",
    "display" : "ISTITUTO S.ANNA VIA SIRIS 11",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180005",
    "display" : "ISTITUTO S.ANNA SS - 106 KM 243",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180032",
    "display" : "OSPEDALE CIVILE SAN GIOVANNI DI DIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180045",
    "display" : "CASA DI CURA S.RITA DOTT. CAPARRA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180085",
    "display" : "ROMOLO HOSPITAL ( EX VILLA EVA )",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180101",
    "display" : "CALABRODENTAL SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180102",
    "display" : "SADEL DI SALVATORE BAFFA SPA ( EX OLIVET",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180103",
    "display" : "CASA DI CURA MADONNA DELLO SCOGLIO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180107",
    "display" : "marrelli hospital",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "101010"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180914",
    "display" : "A.O.U. MATER DOMINI CATANZARO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "914"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180033",
    "display" : "PO LAMEZIA TERME",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079160"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180040",
    "display" : "OSPEDALE DI SOVERIA MANNELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079138"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180043",
    "display" : "CASA DI CURA VILLA DEL SOLE",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180050",
    "display" : "CASA DI CURA VILLA SERENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180051",
    "display" : "CASA DI CURA VILLA MICHELINO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079160"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180053",
    "display" : "CASA DI CURA SANT`ANNA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180055",
    "display" : "OSPEDALE BASSO IONIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079137"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180150",
    "display" : "Villa Rachele S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079069"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180913",
    "display" : "Azienda Ospedaliera Pugliese - Ciaccio",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "079023"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "913"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180034",
    "display" : "P.O. JAZZOLINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "102047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180035",
    "display" : "P.O. TROPEA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "102044"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180047",
    "display" : "VILLA DEI GERANI",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "102047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180057",
    "display" : "P.O. SERRA SAN BRUNO",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "102037"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180059",
    "display" : "OSPEDALE CIVILE LOCRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080043"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180061",
    "display" : "P.O. 'S. MARIA DEGLI UNGHERESI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080061"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180062",
    "display" : "OSPEDALE 'TIBERIO EVOLI' - MELITO P.S.",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080050"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180068",
    "display" : "P.O. 'GIOVANNI XXIII'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "180071",
    "display" : "ISTITUTO ORTOPEDICO MEZZOGIORNO D`ITALIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180073",
    "display" : "CASA DI CURA 'VILLA AURORA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180074",
    "display" : "POLICLINICO 'MADONNA DELLA CONSOLAZIONE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180075",
    "display" : "CASA DI CURA 'VILLA CAMINITI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080096"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180076",
    "display" : "CASA DI CURA 'VILLA S.ANNA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180077",
    "display" : "CASA DI CURA 'VILLA ELISA' S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "180915",
    "display" : "Azienda Osped. Bianchi Melacrino Morelli",
    "property" : [{
      "code" : "regione",
      "valueString" : "180"
    },
    {
      "code" : "comune",
      "valueString" : "080063"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "180205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "915"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190301",
    "display" : "P.O. S. GIOVANNI DI DIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190302",
    "display" : "P.O. BARONE LOMBARDO - CANICATTI'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190303",
    "display" : "P.O. S. GIACOMO D'ALTOPASSO LICATA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084021"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190304",
    "display" : "P.O. F.LLI PARLAPIANO - RIBERA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190305",
    "display" : "P.O. GIOVANNI PAOLO II",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190503",
    "display" : "CASA DI SALUTE IGNAZIO ATTARDI S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084040"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190504",
    "display" : "SIA CASA DI CURA S. ANNA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "084001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190201"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "201"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190306",
    "display" : "P.O. Sant'Elia (ex AO)",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190307",
    "display" : "P.O. M. IMMACOLATA LONGO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190308",
    "display" : "P.O.MADDALENA RAIMONDI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190309",
    "display" : "P.O. VITTORIO EMANUELE (ex AO)",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190310",
    "display" : "P.O. SANTO STEFANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190311",
    "display" : "P.O. SUOR CECILIA BASAROCCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190505",
    "display" : "CASA DI CURA 'REGINA PACIS'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085016"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190506",
    "display" : "SO.GE.SA.SPA.C.DI.C.S.BARBARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "085007"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190202"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "202"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190921",
    "display" : "A.O. per l'Emergenza Cannizzaro",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "921"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190923",
    "display" : "A.O.U. POLICLINICO - VITTORIO EMANUELE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "923"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190922",
    "display" : "ARNAS GARIBALDI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "922"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190312",
    "display" : "P.O. S. Marta e S. Venera Acireale",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190313",
    "display" : "S.Giovanni Di Dio e S.Isidoro Giarre",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190314",
    "display" : "P.O. Maria SS.Addolorata Biancavilla",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190315",
    "display" : "P.O. Castiglione Prestianni Bronte",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190316",
    "display" : "P.O. SS. Salvatore Paternò",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087033"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190317",
    "display" : "P.O. Gravina e S. Pietro Caltagirone",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190318",
    "display" : "P.O. Basso Ragusa Militello",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087025"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190511",
    "display" : "CENTRO CLIN.MORGAGNI srl c/o Di Stef Vel",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190512",
    "display" : "CASA DI CURA MADONNA DEL ROSARIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190513",
    "display" : "CASA DI CURA G.B. MORGAGNI S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190516",
    "display" : "MATER DEI DI G.NESI & C. S.P.A",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190517",
    "display" : "CASA DI CURA VILLA DEI GERANI SrL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190519",
    "display" : "HUMANITAS ISTITUTO CLINICO CATANESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087029"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190520",
    "display" : "CASA CURA CENTRO CATANESE MED. E CH.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190521",
    "display" : "CASA DI CURA CARMIDE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190523",
    "display" : "CASA DI CURA GIBIINO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190553",
    "display" : "CASA DI CURA RIABILITATIVA VILLA SOFIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087004"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190554",
    "display" : "ISTITUTO ONCOLOGICO DEL MEDITERRANEO SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190555",
    "display" : "CASA DI CURA MONS. G. CALACIURA Cenacolo",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190710",
    "display" : "CASA DI CURA PROF.E.FALCIDIA SrL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190712",
    "display" : "Casa di Cura MUSUMECI Gescas",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087019"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190715",
    "display" : "CASA DI CURA VILLA S.FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190723",
    "display" : "CASA DI CURA VALSALVA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190724",
    "display" : "ISCAS MORGAGNI NORD SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190725",
    "display" : "PRIVATE HOSPITAL ARGENTO srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190726",
    "display" : "ISTITUTO CLINICO VIDIMURA srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190727",
    "display" : "LUCINA RESIDENCE srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190728",
    "display" : "CLINICA SANT'AGATA Tigano srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190729",
    "display" : "CENTRO CLIN.MORGAGNI srl.c/o Check Point",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "087042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190203"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "203"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190319",
    "display" : "P. O. 'UMBERTO I'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190320",
    "display" : "P. O. 'M. CHIELLO'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190321",
    "display" : "P. O. 'FERRO-CAPRA-BRANCIFORTE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190322",
    "display" : "P. O. 'CARLO BASILOTTA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "204"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190950",
    "display" : "ASSOCIAZIONE OASI MARIA SS",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "086018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190204"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "950"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "190323",
    "display" : "P.O. 'NUOVO CUTRONI ZODDA' BARCELLONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083005"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190324",
    "display" : "P.O. LIPARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083041"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190325",
    "display" : "P.O. 'G. FOGLIANI' MILAZZO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083049"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190326",
    "display" : "P.O.' S. VINCENZO' TAORMINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083097"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190327",
    "display" : "P.O. 'SS. SALVATORE' MISTRETTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190328",
    "display" : "P.O. 'BARONE-ROMEO' PATTI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083066"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190329",
    "display" : "STABILIMENTO OSPED. S. AGATA MILITELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083084"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190524",
    "display" : "I.O.M.I. F.SCALABRINO GANZIRRI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190525",
    "display" : "CASA DI CURA S.CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190526",
    "display" : "CASA DI CURA CRISTO RE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190527",
    "display" : "CASA DI CURA CARMONA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190528",
    "display" : "CASA DI CURA VILLA SALUS S.A.S.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190530",
    "display" : "C.O.T. S.P.A. (CURE ORTOPED. TRAUM.)",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190531",
    "display" : "CASA DI CURA VILLA IGEA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190601",
    "display" : "CENTRO CHIRURGICO VILLA MARIA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190716",
    "display" : "CASA DI CURA CAPPELLANI GIOMI S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "205"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190924",
    "display" : "Azienda Ospedaliera Papardo",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "924"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190925",
    "display" : "Azienda Osp. Univ. G. Martino",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "925"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190960",
    "display" : "IRCCS Centro Neurolesi 'Bonino Pulejo'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "083048"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190205"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "960"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190926",
    "display" : "A.O.R Villa Sofia Cervello",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "926"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190179",
    "display" : "FOND. IST. S. RAFFAELE - GIGLIO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082027"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "8"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "190199",
    "display" : "OSP. BUCCHERI LA FERLA FATEBENEFRATELLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "4"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "190330",
    "display" : "P.O. DEI BIANCHI CORLEONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082034"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190332",
    "display" : "P.O. CIVICO PARTINICO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082054"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190333",
    "display" : "P.O. MADONNA DELL'ALTO - PETR. SOTTANA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082056"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190334",
    "display" : "P.O. S. CIMINO TERMINI IMERESE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190335",
    "display" : "P.O. G. F. INGRASSIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190337",
    "display" : "P.O. VILLA DELLE GINESTRE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190532",
    "display" : "CASA DI CURA IGEA S.N.C.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082054"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190533",
    "display" : "CASA DI CURA CANDELA SPA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190534",
    "display" : "CASA DI CURE ORESTANO S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190536",
    "display" : "CASA DI CURA 'TRIOLO ZANCLA' S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190537",
    "display" : "CASA DI CURA SERENA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190538",
    "display" : "CASA DI CURA NOTO PASQUALINO S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190539",
    "display" : "NUOVA CASA DI CURA D`ANNA PIA ASS. SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190540",
    "display" : "NUOVA CASA DI CURA DEMMA srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190541",
    "display" : "CASA DI CURA MACCHIARELLA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190542",
    "display" : "CASA DI CURA TORINA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190543",
    "display" : "CASA DI CURA VILLA MARGHERITA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190545",
    "display" : "CASA DI CURE COSENTINO DI KAROL S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190551",
    "display" : "CASA DI CURA LA MADDALENA S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190602",
    "display" : "CENTRO ANDROS S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190718",
    "display" : "CASA DI CURA LATTERI VALSAVA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190720",
    "display" : "CASA DI CURA MARIA ELEONORA HOSPITAL srl",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "206"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190927",
    "display" : "Azienda Ospedaliera 'Civico-Di Cristina-",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "927"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190928",
    "display" : "AZ.OSP.UNIV.P.GIACCONE",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "928"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190970",
    "display" : "Dipartimento Rizzoli-Sicilia",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "970"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190929",
    "display" : "IRCCS Ismett",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "082053"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190206"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "929"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "3.2"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato (Equiparato a pubblico)"
    }]
  },
  {
    "code" : "190338",
    "display" : "OSPEDALE 'Giovanni Paolo II° M.P. A.'",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190339",
    "display" : "OSPEDALE REGINA MARGHERITA COMISO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190340",
    "display" : "OSPEDALE MAGGIORE MODICA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190341",
    "display" : "OSPEDALE BUSACCA SCICLI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190342",
    "display" : "OSPEDALE GUZZARDI VITTORIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190552",
    "display" : "CASA DI CURA CLINICA DEL MEDITERRANEO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "088009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190207"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "207"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190343",
    "display" : "P.O. DI MARIA AVOLA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089002"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190344",
    "display" : "P.O. TRIGONA NOTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089013"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190345",
    "display" : "P.O. UMBERTO I (EX A.O.)",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190346",
    "display" : "P.O. MUSCATELLO AUGUSTA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190347",
    "display" : "OSPEDALE GENERALE DI ZONA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190348",
    "display" : "P.O. A. Rizza",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190507",
    "display" : "CASA DI CURA SANTA LUCIA GLEF",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190508",
    "display" : "CASA DI CURA VILLA MAURITIUS ARC",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190509",
    "display" : "IST.ORT. VILLA SALUS I. GALATIOTO SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190550",
    "display" : "C. DI CURA 'VILLA AZZURRA' - GESIN SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190701",
    "display" : "CLINICA VILLA RIZZO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190702",
    "display" : "CASA DI CURA 'VILLA AURELIA' SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "089017"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190208"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "208"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190349",
    "display" : "P.O. SAN VITO E SANTO SPIRITO -ALCAMO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081001"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190350",
    "display" : "P.O. 'B. NAGAR' - PANTELLERIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081014"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190351",
    "display" : "P.O. S. ANTONIO ABATE - TRAPANI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190352",
    "display" : "P.O. V.EMANUELE II CASTELVETRANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190353",
    "display" : "P.O.PAOLO BORSELLINO - MARSALA",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190354",
    "display" : "P.O.ABELE AJELLO-MAZARA D.VALLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081012"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190355",
    "display" : "P.O. VITTORIO EMANUELE III - SALEMI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081018"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "190501",
    "display" : "CASA DI CURA VILLA DEI GERANI",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190502",
    "display" : "CASA DI CURA SANT`ANNA SRL.",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081008"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190549",
    "display" : "CASA DI CURA MORANA SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081011"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "190556",
    "display" : "CASA DI CURA RIABIL. VITTORIA S.r.l",
    "property" : [{
      "code" : "regione",
      "valueString" : "190"
    },
    {
      "code" : "comune",
      "valueString" : "081006"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "190209"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "209"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200002",
    "display" : "OSPEDALE CIVILE ALGHERO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090003"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200003",
    "display" : "OSPEDALE CIVILE OZIERI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090052"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200013",
    "display" : "POLICLINICO SASSARESE - LABOR S.p.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090064"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "301"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200905",
    "display" : "AZIENDA OSPEDALIERO UNIVERSITARIA SS",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090064"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200301"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "905"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200006",
    "display" : "P.O. PAOLO DETTORI - TEMPIO P.",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090070"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200011",
    "display" : "P.O. PAOLO MERLO LA MADDALENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200012",
    "display" : "P.O. GIOVANNI PAOLO II OLBIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200057",
    "display" : "MATER OLBIA HOSPITAL",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "090047"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200302"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "302"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200017",
    "display" : "P.O. SAN FRANCESCO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200018",
    "display" : "P.O. C. ZONCHELLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200020",
    "display" : "P.O. SAN CAMILLO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091086"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200303"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "303"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200019",
    "display" : "P.O. 'NOSTRA SIGNORA DELLA MERCEDE'",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091037"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200304"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "304"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200023",
    "display" : "CLINICA TOMMASINI SRL",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "091035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200304"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "304"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200021",
    "display" : "P.O. 'A.G. MASTINO' - BOSA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "095079"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200052",
    "display" : "P. OSPEDALIERO 'SAN MARTINO' - ORISTANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "095038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200053",
    "display" : "P. OSPEDALIERO 'G.P. DELOGU' - GHILARZA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "095021"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200054",
    "display" : "C.C. 'MADONNA DEL RIMEDIO' - ORISTANO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "095038"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200305"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "305"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200034",
    "display" : "PRESIDIO OSPEDALIERO N.S. DI BONARIA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111062"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200306"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "306"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200028",
    "display" : "P.O.SIRAI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200307"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "307"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200029",
    "display" : "P.O.SANTA BARBARA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200307"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "307"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200030",
    "display" : "P.O.CTO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111035"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200307"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "307"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200906",
    "display" : "A.O.U. CAGLIARI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "906"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "2.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200022",
    "display" : "P.O. S.GIUSEPPE",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111036"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200025",
    "display" : "P.O. R. BINAGHI",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200026",
    "display" : "P.O. MARINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200031",
    "display" : "P.O. SS. TRINITA'",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200035",
    "display" : "P.O. SAN MARCELLINO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "111042"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200040",
    "display" : "CASA DI CURA S.ANNA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200042",
    "display" : "CASA DI CURA S. ANTONIO S.P.A.",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200044",
    "display" : "CASA DI CURA VILLA ELENA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200045",
    "display" : "NUOVA CASA DI CURA S.R.L.",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092015"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200056",
    "display" : "KINETIKA SARDEGNA",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092051"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "5.1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Privato"
    }]
  },
  {
    "code" : "200060",
    "display" : "P.O MICROCITEMICO A.CAO",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "308"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "1"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  },
  {
    "code" : "200904",
    "display" : "AZIENDA OSPEDALIERA G.BROTZU",
    "property" : [{
      "code" : "regione",
      "valueString" : "200"
    },
    {
      "code" : "comune",
      "valueString" : "092009"
    },
    {
      "code" : "aslTerritoriale",
      "valueString" : "200308"
    },
    {
      "code" : "codiceAzienda",
      "valueString" : "904"
    },
    {
      "code" : "tipoStruttura",
      "valueString" : "0"
    },
    {
      "code" : "naturaGiuridica",
      "valueString" : "Pubblico"
    }]
  }]
}

```
