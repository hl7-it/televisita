# Terapia in atto - Beclometasone 100 mcg (Maria Rossi) - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Terapia in atto - Beclometasone 100 mcg (Maria Rossi)**

## Example MedicationStatement: Terapia in atto - Beclometasone 100 mcg (Maria Rossi)

Profile: [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md)

**status**: Active

**medication**: Beclometasone 100 mcg spray inalatorio

**subject**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**context**: [Encounter: identifier = http://hl7.it/fhir/televisita/sid/codiceNosologico#POD.123e4567-e89b-12d3-a456-426614174000; status = finished; class = Virtual (ActCode#VR); priority = routine; period = 2025-06-16 09:00:00+0200 --> 2025-06-16 09:45:00+0200](Encounter-a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2.md)

**effective**: 2025-01-10 --> 2025-06-16

**dateAsserted**: 2025-06-16

**informationSource**: [Maria Rossi Female, DoB: 1971-05-01 ( http://hl7.it/sid/codiceFiscale#RSSMRA71E41F205E)](Patient-2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82.md)

**reasonCode**: Bronchite cronica - terapia inalatoria di mantenimento

> **dosage****text**: 2 inalazioni da 100 mcg due volte al giorno**route**: Oral route

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 100 mcg (Details: UCUM codeug = 'ug') |




## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "e62c9f1d-9c0b-4433-853b-06ec5074f19a",
  "meta" : {
    "profile" : ["http://hl7.it/fhir/televisita/StructureDefinition/MedicationStatementTelevisita"]
  },
  "status" : "active",
  "medicationCodeableConcept" : {
    "coding" : [{
      "system" : "http://www.whocc.no/atc",
      "code" : "R03BA01",
      "display" : "beclometasone"
    }],
    "text" : "Beclometasone 100 mcg spray inalatorio"
  },
  "subject" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "context" : {
    "reference" : "Encounter/a2aaf911-51e7-4e38-a7ca-2817c0fcc6d2"
  },
  "effectivePeriod" : {
    "start" : "2025-01-10",
    "end" : "2025-06-16"
  },
  "dateAsserted" : "2025-06-16",
  "informationSource" : {
    "reference" : "Patient/2e7e0fe3-f0bf-4e0a-8228-b8e7fcec8c82"
  },
  "reasonCode" : [{
    "text" : "Bronchite cronica - terapia inalatoria di mantenimento"
  }],
  "dosage" : [{
    "text" : "2 inalazioni da 100 mcg due volte al giorno",
    "route" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "26643006",
        "display" : "Oral route"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 100,
        "unit" : "mcg",
        "system" : "http://unitsofmeasure.org",
        "code" : "ug"
      }
    }]
  }]
}

```
