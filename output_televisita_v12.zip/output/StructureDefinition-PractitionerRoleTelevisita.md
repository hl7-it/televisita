# PractitionerRoleTelevisita - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PractitionerRoleTelevisita**

## Resource Profile: PractitionerRoleTelevisita 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita | *Version*:0.2.0 |
| Active as of 2026-07-01 | *Computable Name*:PractitionerRoleTelevisita |

 
Profilo della risorsa PractitionerRole utilizzato per rappresentare il ruolo professionale del medico specialista o di altro operatore sanitario nell'ambito dell'erogazione della televisita. 

**Usages:**

* Use this Profile: [Bundle Referto di Televisita - Transaction](StructureDefinition-BundleRefertoDiTelevisitaTransaction.md) and [Bundle Referto di televisita](StructureDefinition-BundleRefertodiTelevisita.md)
* Refer to this Profile: [CompositionRefertoTelevisita](StructureDefinition-CompositionRefertoTelevisita.md), [Encounter Televisita](StructureDefinition-EncounterTelevisita.md), [MedicationStatement Televisita](StructureDefinition-MedicationStatementTelevisita.md), [Patient Televisita](StructureDefinition-PatientTelevisita.md)... Show 2 more, [Procedure Televisita](StructureDefinition-ProcedureTelevisita.md) and [ServiceRequest Televisita](StructureDefinition-ServiceRequestTelevisita.md)
* Examples for this Profile: [PractitionerRole/e446e848-2bd4-423a-b2f8-5d25687e2f42](PractitionerRole-e446e848-2bd4-423a-b2f8-5d25687e2f42.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/televisita|current/StructureDefinition/StructureDefinition-PractitionerRoleTelevisita.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-PractitionerRoleTelevisita.csv), [Excel](StructureDefinition-PractitionerRoleTelevisita.xlsx), [Schematron](StructureDefinition-PractitionerRoleTelevisita.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "PractitionerRoleTelevisita",
  "url" : "http://hl7.it/fhir/televisita/StructureDefinition/PractitionerRoleTelevisita",
  "version" : "0.2.0",
  "name" : "PractitionerRoleTelevisita",
  "title" : "PractitionerRoleTelevisita",
  "status" : "active",
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Profilo della risorsa PractitionerRole utilizzato per rappresentare il ruolo professionale del medico specialista o di altro operatore sanitario nell'ambito dell'erogazione della televisita.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "PractitionerRole",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/PractitionerRole",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "PractitionerRole",
      "path" : "PractitionerRole",
      "short" : "Ruolo professionale del medico nella televisita.",
      "definition" : "Rappresenta il ruolo che un professionista sanitario ricopre in una specifica organizzazione per l'erogazione della televisita, comprensivo di specialità, riferimento all'organizzazione e recapiti."
    },
    {
      "id" : "PractitionerRole.identifier",
      "path" : "PractitionerRole.identifier",
      "short" : "Identificativo dell'operatore (e.g. Codice Fiscale, ID Regionale)",
      "definition" : "Identificatori aziendali specifici di un ruolo/località."
    },
    {
      "id" : "PractitionerRole.period",
      "path" : "PractitionerRole.period",
      "short" : "Periodo durante il quale il professionista è autorizzato a svolgere il ruolo.",
      "definition" : "Il periodo in cui la persona è autorizzata ad agire come professionista in questi ruoli per l'organizzazione.",
      "comment" : "Un Periodo specifica un intervallo di tempo; il contesto d'uso specificherà se si applica l'intero intervallo (ad esempio, \"il paziente è stato ricoverato in ospedale per questo intervallo di tempo\") o se si applica un valore dell'intervallo (ad esempio, \"la somministrazione al paziente è avvenuta tra questi due momenti\").\n\nPeriodo non è usato per una durata (una misura del tempo trascorso). Vedere [Duration](datatypes.html#Duration)."
    },
    {
      "id" : "PractitionerRole.practitioner",
      "path" : "PractitionerRole.practitioner",
      "short" : "Dettagli dell'operatore",
      "definition" : "Il professionista è in grado di fornire i servizi definiti per l'organizzazione.",
      "comment" : "I riferimenti DEVONO essere un riferimento a una risorsa FHIR effettiva e DEVONO essere risolvibili (consentendo il controllo dell'accesso, la temporanea indisponibilità, ecc.) La risoluzione può avvenire tramite il recupero dell'URL o, se applicabile al tipo di risorsa, trattando un riferimento assoluto come un URL canonico e cercandolo in un registro/repository locale.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/PractitionerTelevisita"]
      }]
    },
    {
      "id" : "PractitionerRole.organization",
      "path" : "PractitionerRole.organization",
      "short" : "Organizzazione di Appartenenza",
      "definition" : "L'organizzazione in cui il professionista svolge i ruoli associati.",
      "comment" : "I riferimenti DEVONO essere un riferimento a una risorsa FHIR effettiva e DEVONO essere risolvibili (consentendo il controllo dell'accesso, la temporanea indisponibilità, ecc.) La risoluzione può avvenire tramite il recupero dell'URL o, se applicabile al tipo di risorsa, trattando un riferimento assoluto come un URL canonico e cercandolo in un registro/repository locale.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.it/fhir/televisita/StructureDefinition/OrganizationT1"]
      }]
    },
    {
      "id" : "PractitionerRole.code",
      "path" : "PractitionerRole.code",
      "short" : "Ruoli che questo professionista può svolgere.",
      "definition" : "Ruoli che questo professionista è autorizzato a svolgere per l'organizzazione.",
      "comment" : "Una persona può avere più di un ruolo."
    },
    {
      "id" : "PractitionerRole.specialty",
      "path" : "PractitionerRole.specialty",
      "short" : "Branca specialistica del professionista.",
      "definition" : "Specialità clinica del professionista sanitario nel contesto della televisita (es. cardiologia, neurologia, dermatologia). Il valore è vincolato al ValueSet delle specialità ambulatoriali.",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.it/fhir/televisita/ValueSet/vsspecialityPractitionerRole"
      }
    },
    {
      "id" : "PractitionerRole.telecom",
      "path" : "PractitionerRole.telecom",
      "short" : "Recapiti del professionista nel ruolo specifico.",
      "definition" : "Numeri di telefono, indirizzi e-mail o altri recapiti del professionista nell'ambito del ruolo svolto per l'organizzazione, utilizzabili nell'ambito del percorso di televisita."
    },
    {
      "id" : "PractitionerRole.availableTime",
      "path" : "PractitionerRole.availableTime",
      "short" : "Disponibilità oraria per le televisite.",
      "definition" : "Indica i giorni e gli orari in cui il professionista è disponibile per l'erogazione di televisite nell'ambito del ruolo ricoperto."
    }]
  }
}

```
