# Organization - Struttura Erogatrice - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Mapping verso i Profili**](modelmap.md)
* **Organization - Struttura Erogatrice**

## Organization - Struttura Erogatrice

Questa pagina descrive la mappatura tra i campi dell'Allegato 1 del D.M. Salute 19 novembre 2025, pubblicato in GU Serie Generale n. 301 del 30 dicembre 2025 recante "Disciplina del trattamento dei dati personali nell'ambito della infrastruttura della Piattaforma nazionale telemedicina" e i corrispondenti profili FHIR.

Allegato 1 Telemedicina → Strutture organizzative

 La risorsa `Organization` rappresenta l'azienda sanitaria, il presidio e l'unità operativa responsabili dell'erogazione della televisita, raggiungibili tramite il `PractitionerRole` dell'autore della Composition. 

**Contesto di mappatura:**
`Composition.author.resolve().ofType(PractitionerRole).organization.resolve().ofType(Organization)`

| | | | |
| :--- | :--- | :--- | :--- |
| Codice e descrizione dell'azienda sanitaria | Codice e descrizione dell'azienda sanitaria | Composition/PractitionerRole/Organization | `Composition.author.resolve().ofType(PractitionerRole).organization.resolve().ofType(Organization).identifier + name` |
| Codice e descrizione del presidio | Codice e descrizione del presidio | Composition/PractitionerRole/Organization | `Composition.author.resolve().ofType(PractitionerRole).organization.resolve().ofType(Organization).partOf.identifier + name` |
| Codice e descrizione dell'unità operativa | Codice e descrizione dell'unità operativa | Composition/PractitionerRole/Organization | `Composition.author.resolve().ofType(PractitionerRole).organization.resolve().ofType(Organization).identifier + name` |
| Numero telefono Unità Operativa / CUP / Azienda Sanitaria | Numero di telefono dell'Unità Operativa / CUP / Azienda Sanitaria | Composition/PractitionerRole/Organization | `Composition.author.resolve().ofType(PractitionerRole).organization.resolve().ofType(Organization).contact.telecom.where(system='phone')` |

 Torna alla panoramica: [Modello di mappatura](modelmap.md) 

