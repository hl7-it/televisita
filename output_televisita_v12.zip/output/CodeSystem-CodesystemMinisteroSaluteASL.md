# Ministero della Salute - ASL - Televisita v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ministero della Salute - ASL**

## CodeSystem: Ministero della Salute - ASL (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.it/fhir/televisita/CodeSystem/CodesystemMinisteroSaluteASL | *Version*:0.2.0 |
| Draft as of 2026-07-01 | *Computable Name*:CodesystemMinisteroDellaSalute_ASL |

 
Definisce il sistema di terminologie da usare per il codice ASL ereditato da Hl7.it 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValuesetMinisteroDellaSalute_IDASL](ValueSet-ValuesetMinisteroSaluteidASL.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CodesystemMinisteroSaluteASL",
  "url" : "http://hl7.it/fhir/televisita/CodeSystem/CodesystemMinisteroSaluteASL",
  "version" : "0.2.0",
  "name" : "CodesystemMinisteroDellaSalute_ASL",
  "title" : "Ministero della Salute - ASL",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-07-01T17:16:40+02:00",
  "publisher" : "Example Publisher",
  "contact" : [{
    "name" : "Example Publisher",
    "telecom" : [{
      "system" : "url",
      "value" : "http://example.org/example-publisher"
    }]
  }],
  "description" : "Definisce il sistema di terminologie da usare per il codice ASL ereditato da Hl7.it",
  "caseSensitive" : true,
  "versionNeeded" : false,
  "content" : "complete",
  "count" : 184,
  "concept" : [{
    "code" : "010201",
    "display" : "TO1"
  },
  {
    "code" : "010202",
    "display" : "TO2"
  },
  {
    "code" : "010203",
    "display" : "TO3"
  },
  {
    "code" : "010204",
    "display" : "TO4"
  },
  {
    "code" : "010205",
    "display" : "TO5"
  },
  {
    "code" : "010206",
    "display" : "VC"
  },
  {
    "code" : "010207",
    "display" : "BI"
  },
  {
    "code" : "010208",
    "display" : "NO"
  },
  {
    "code" : "010209",
    "display" : "VCO"
  },
  {
    "code" : "010210",
    "display" : "CN1"
  },
  {
    "code" : "010211",
    "display" : "CN2"
  },
  {
    "code" : "010212",
    "display" : "AT"
  },
  {
    "code" : "010213",
    "display" : "AL"
  },
  {
    "code" : "010301",
    "display" : "ASL CITTA' DI TORINO"
  },
  {
    "code" : "020101",
    "display" : "AZIENDA U.S.L. VALLE D'AOSTA"
  },
  {
    "code" : "030301",
    "display" : "A.S.L. DELLA PROVINCIA DI BERGAMO"
  },
  {
    "code" : "030302",
    "display" : "A.S.L. DELLA PROVINCIA DI BRESCIA"
  },
  {
    "code" : "030303",
    "display" : "A.S.L. DELLA PROVINCIA DI COMO"
  },
  {
    "code" : "030304",
    "display" : "A.S.L. DELLA PROVINCIA DI CREMONA"
  },
  {
    "code" : "030305",
    "display" : "A.S.L. DELLA PROVINCIA DI LECCO"
  },
  {
    "code" : "030306",
    "display" : "A.S.L. DELLA PROVINCIA DI LODI"
  },
  {
    "code" : "030307",
    "display" : "A.S.L. DELLA PROVINCIA DI MANTOVA"
  },
  {
    "code" : "030308",
    "display" : "A.S.L. DI MILANO"
  },
  {
    "code" : "030309",
    "display" : "A.S.L. DELLA PROVINCIA DI MILANO 1"
  },
  {
    "code" : "030310",
    "display" : "A.S.L. DELLA PROVINCIA DI MILANO 2"
  },
  {
    "code" : "030311",
    "display" : "A.S.L. PROVINCIA DI MONZA E BRIANZA"
  },
  {
    "code" : "030312",
    "display" : "A.S.L. DELLA PROVINCIA DI PAVIA"
  },
  {
    "code" : "030313",
    "display" : "A.S.L. DELLA PROVINCIA DI SONDRIO"
  },
  {
    "code" : "030314",
    "display" : "A.S.L. DELLA PROVINCIA DI VARESE"
  },
  {
    "code" : "030315",
    "display" : "A.S.L. DI VALLECAMONICA-SEBINO"
  },
  {
    "code" : "030321",
    "display" : "ATS DELLA CITTA' METROPOLITANA DI MILANO"
  },
  {
    "code" : "030322",
    "display" : "ATS DELL'INSUBRIA"
  },
  {
    "code" : "030323",
    "display" : "ATS DELLA MONTAGNA"
  },
  {
    "code" : "030324",
    "display" : "ATS DELLA BRIANZA"
  },
  {
    "code" : "030325",
    "display" : "ATS DI BERGAMO"
  },
  {
    "code" : "030326",
    "display" : "ATS DI BRESCIA"
  },
  {
    "code" : "030327",
    "display" : "ATS DELLA VAL PADANA"
  },
  {
    "code" : "030328",
    "display" : "ATS DI PAVIA"
  },
  {
    "code" : "041201",
    "display" : "AZIENDA SANITARIA DELLA P.A. DI BOLZANO"
  },
  {
    "code" : "042101",
    "display" : "TRENTO"
  },
  {
    "code" : "050101",
    "display" : "BELLUNO"
  },
  {
    "code" : "050102",
    "display" : "FELTRE"
  },
  {
    "code" : "050103",
    "display" : "BASSANO DEL GRAPPA"
  },
  {
    "code" : "050104",
    "display" : "THIENE"
  },
  {
    "code" : "050105",
    "display" : "ARZIGNANO"
  },
  {
    "code" : "050106",
    "display" : "VICENZA"
  },
  {
    "code" : "050107",
    "display" : "PIEVE DI SOLIGO"
  },
  {
    "code" : "050108",
    "display" : "ASOLO"
  },
  {
    "code" : "050109",
    "display" : "TREVISO"
  },
  {
    "code" : "050110",
    "display" : "S. DONA' DI PIAVE"
  },
  {
    "code" : "050112",
    "display" : "VENEZIANA"
  },
  {
    "code" : "050113",
    "display" : "MIRANO"
  },
  {
    "code" : "050114",
    "display" : "CHIOGGIA"
  },
  {
    "code" : "050115",
    "display" : "CITTADELLA"
  },
  {
    "code" : "050116",
    "display" : "PADOVA"
  },
  {
    "code" : "050117",
    "display" : "MONSELICE"
  },
  {
    "code" : "050118",
    "display" : "ROVIGO"
  },
  {
    "code" : "050119",
    "display" : "ADRIA"
  },
  {
    "code" : "050120",
    "display" : "VERONA"
  },
  {
    "code" : "050121",
    "display" : "LEGNAGO"
  },
  {
    "code" : "050122",
    "display" : "BUSSOLENGO"
  },
  {
    "code" : "050501",
    "display" : "AZIENDA ULSS N. 1 DOLOMITI"
  },
  {
    "code" : "050502",
    "display" : "AZIENDA ULSS N. 2 MARCA TREVIGIANA"
  },
  {
    "code" : "050503",
    "display" : "AZIENDA ULSS N. 3 SERENISSIMA"
  },
  {
    "code" : "050504",
    "display" : "AZIENDA ULSS N. 4 VENETO ORIENTALE"
  },
  {
    "code" : "050505",
    "display" : "AZIENDA ULSS N. 5 POLESANA"
  },
  {
    "code" : "050506",
    "display" : "AZIENDA ULSS N. 6 EUGANEA"
  },
  {
    "code" : "050507",
    "display" : "AZIENDA ULSS N. 7 PEDEMONTANA"
  },
  {
    "code" : "050508",
    "display" : "AZIENDA ULSS N. 8 BERICA"
  },
  {
    "code" : "050509",
    "display" : "AZIENDA ULSS N. 9 SCALIGERA"
  },
  {
    "code" : "060101",
    "display" : "TRIESTINA"
  },
  {
    "code" : "060102",
    "display" : "ISONTINA"
  },
  {
    "code" : "060103",
    "display" : "ALTO FRIULI"
  },
  {
    "code" : "060104",
    "display" : "MEDIO FRIULI"
  },
  {
    "code" : "060105",
    "display" : "BASSA FRIULANA"
  },
  {
    "code" : "060106",
    "display" : "FRIULI OCCIDENTALE"
  },
  {
    "code" : "060201",
    "display" : "ASUI DI TRIESTE"
  },
  {
    "code" : "060202",
    "display" : "BASSA FRIULANA - ISONTINA"
  },
  {
    "code" : "060203",
    "display" : "ALTO FRIULI - COLLINARE - MEDIO FRIULI"
  },
  {
    "code" : "060204",
    "display" : "ASUI DI UDINE"
  },
  {
    "code" : "060205",
    "display" : "AS FRIULI OCCIDENTALE"
  },
  {
    "code" : "060206",
    "display" : "ASU FRIULI CENTRALE"
  },
  {
    "code" : "060207",
    "display" : "ASU GIULIANO ISONTINA"
  },
  {
    "code" : "070101",
    "display" : "IMPERIESE"
  },
  {
    "code" : "070102",
    "display" : "SAVONESE"
  },
  {
    "code" : "070103",
    "display" : "GENOVESE"
  },
  {
    "code" : "070104",
    "display" : "CHIAVARESE"
  },
  {
    "code" : "070105",
    "display" : "SPEZZINO"
  },
  {
    "code" : "080101",
    "display" : "AZIENDA USL PIACENZA"
  },
  {
    "code" : "080102",
    "display" : "AZIENDA USL PARMA"
  },
  {
    "code" : "080103",
    "display" : "AZIENDA USL REGGIO EMILIA"
  },
  {
    "code" : "080104",
    "display" : "AZIENDA USL MODENA"
  },
  {
    "code" : "080105",
    "display" : "AZIENDA USL BOLOGNA"
  },
  {
    "code" : "080106",
    "display" : "AZIENDA USL IMOLA"
  },
  {
    "code" : "080109",
    "display" : "AZIENDA USL FERRARA"
  },
  {
    "code" : "080110",
    "display" : "AZIENDA USL RAVENNA"
  },
  {
    "code" : "080111",
    "display" : "AZIENDA USL FORLI'"
  },
  {
    "code" : "080112",
    "display" : "AZIENDA USL CESENA"
  },
  {
    "code" : "080113",
    "display" : "AZIENDA USL RIMINI"
  },
  {
    "code" : "080114",
    "display" : "AZIENDA USL DELLA ROMAGNA"
  },
  {
    "code" : "090101",
    "display" : "MASSA CARRARA"
  },
  {
    "code" : "090102",
    "display" : "LUCCA"
  },
  {
    "code" : "090103",
    "display" : "PISTOIA"
  },
  {
    "code" : "090104",
    "display" : "PRATO"
  },
  {
    "code" : "090105",
    "display" : "PISA"
  },
  {
    "code" : "090106",
    "display" : "LIVORNO"
  },
  {
    "code" : "090107",
    "display" : "SIENA"
  },
  {
    "code" : "090108",
    "display" : "AREZZO"
  },
  {
    "code" : "090109",
    "display" : "GROSSETO"
  },
  {
    "code" : "090110",
    "display" : "FIRENZE"
  },
  {
    "code" : "090111",
    "display" : "EMPOLI"
  },
  {
    "code" : "090112",
    "display" : "VERSILIA"
  },
  {
    "code" : "090201",
    "display" : "AZIENDA USL TOSCANA CENTRO"
  },
  {
    "code" : "090202",
    "display" : "AZIENDA USL TOSCANA NORD-OVEST"
  },
  {
    "code" : "090203",
    "display" : "AZIENDA USL TOSCANA SUD-EST"
  },
  {
    "code" : "100101",
    "display" : "ASL 1 - CITTA' DI CASTELLO"
  },
  {
    "code" : "100102",
    "display" : "USL 2 - PERUGIA"
  },
  {
    "code" : "100103",
    "display" : "ASL 3 - FOLIGNO"
  },
  {
    "code" : "100201",
    "display" : "AUSL UMBRIA N. 1"
  },
  {
    "code" : "100202",
    "display" : "AUSL UMBRIA N. 2"
  },
  {
    "code" : "100204",
    "display" : "ASL 4 - TERNI"
  },
  {
    "code" : "110201",
    "display" : "ASUR"
  },
  {
    "code" : "120101",
    "display" : "RM/A"
  },
  {
    "code" : "120102",
    "display" : "RM/B"
  },
  {
    "code" : "120103",
    "display" : "RM/C"
  },
  {
    "code" : "120104",
    "display" : "RM/D"
  },
  {
    "code" : "120105",
    "display" : "RM/E"
  },
  {
    "code" : "120106",
    "display" : "RM/F"
  },
  {
    "code" : "120107",
    "display" : "RM/G"
  },
  {
    "code" : "120108",
    "display" : "RM/H"
  },
  {
    "code" : "120109",
    "display" : "VITERBO"
  },
  {
    "code" : "120110",
    "display" : "RIETI"
  },
  {
    "code" : "120111",
    "display" : "LATINA"
  },
  {
    "code" : "120112",
    "display" : "FROSINONE"
  },
  {
    "code" : "120201",
    "display" : "ROMA 1"
  },
  {
    "code" : "120202",
    "display" : "ROMA 2"
  },
  {
    "code" : "120203",
    "display" : "ROMA 3"
  },
  {
    "code" : "120204",
    "display" : "ROMA 4"
  },
  {
    "code" : "120205",
    "display" : "ROMA 5"
  },
  {
    "code" : "120206",
    "display" : "ROMA 6"
  },
  {
    "code" : "130201",
    "display" : "AVEZZANO-SULMONA-L'AQUILA"
  },
  {
    "code" : "130202",
    "display" : "LANCIANO-VASTO-CHIETI"
  },
  {
    "code" : "130203",
    "display" : "PESCARA"
  },
  {
    "code" : "130204",
    "display" : "TERAMO"
  },
  {
    "code" : "140201",
    "display" : "ASREM"
  },
  {
    "code" : "150201",
    "display" : "A.S.L. AVELLINO"
  },
  {
    "code" : "150202",
    "display" : "A.S.L. BENEVENTO"
  },
  {
    "code" : "150203",
    "display" : "A.S.L. CASERTA"
  },
  {
    "code" : "150204",
    "display" : "A.S.L. NAPOLI 1 CENTRO"
  },
  {
    "code" : "150205",
    "display" : "A.S.L. NAPOLI 2 NORD"
  },
  {
    "code" : "150206",
    "display" : "A.S.L. NAPOLI 3 SUD"
  },
  {
    "code" : "150207",
    "display" : "A.S.L. SALERNO"
  },
  {
    "code" : "160106",
    "display" : "ASL BR"
  },
  {
    "code" : "160112",
    "display" : "ASL TA"
  },
  {
    "code" : "160113",
    "display" : "ASL BT"
  },
  {
    "code" : "160114",
    "display" : "ASL BA"
  },
  {
    "code" : "160115",
    "display" : "ASL FG"
  },
  {
    "code" : "160116",
    "display" : "ASL LE"
  },
  {
    "code" : "170201",
    "display" : "AZIENDA SANITARIA LOCALE DI POTENZA ASP"
  },
  {
    "code" : "170202",
    "display" : "AZIENDA SANITARIA LOCALE DI MATERA  ASM"
  },
  {
    "code" : "180109",
    "display" : "LOCRI"
  },
  {
    "code" : "180201",
    "display" : "A.S.P. COSENZA"
  },
  {
    "code" : "180202",
    "display" : "A.S.P. CROTONE"
  },
  {
    "code" : "180203",
    "display" : "A.S.P. CATANZARO"
  },
  {
    "code" : "180204",
    "display" : "A.S.P. VIBO VALENTIA"
  },
  {
    "code" : "180205",
    "display" : "A.S.P. REGGIO CALABRIA"
  },
  {
    "code" : "190201",
    "display" : "ASP AGRIGENTO"
  },
  {
    "code" : "190202",
    "display" : "ASP CALTANISSETTA"
  },
  {
    "code" : "190203",
    "display" : "ASP CATANIA"
  },
  {
    "code" : "190204",
    "display" : "ASP ENNA"
  },
  {
    "code" : "190205",
    "display" : "ASP MESSINA"
  },
  {
    "code" : "190206",
    "display" : "ASP PALERMO"
  },
  {
    "code" : "190207",
    "display" : "ASP RAGUSA"
  },
  {
    "code" : "190208",
    "display" : "ASP SIRACUSA"
  },
  {
    "code" : "190209",
    "display" : "ASP DI TRAPANI"
  },
  {
    "code" : "200101",
    "display" : "SASSARI"
  },
  {
    "code" : "200102",
    "display" : "OLBIA"
  },
  {
    "code" : "200103",
    "display" : "NUORO"
  },
  {
    "code" : "200104",
    "display" : "LANUSEI"
  },
  {
    "code" : "200105",
    "display" : "ORISTANO"
  },
  {
    "code" : "200106",
    "display" : "SANLURI"
  },
  {
    "code" : "200107",
    "display" : "CARBONIA"
  },
  {
    "code" : "200108",
    "display" : "CAGLIARI"
  },
  {
    "code" : "200201",
    "display" : "AZIENDA PER LA TUTELA DELLA SALUTE"
  }]
}

```
